/*
 *  File: Database.hpp
 *  Copyright (c) 2024 Sinflower
 *
 *  MIT License
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 *
 */

#pragma once

#include "FileCoder.hpp"

#include <format>
#include <fstream>
#include <nlohmann/json.hpp>
#include <string>

class Field
{
public:
	Field() = default;

	explicit Field(FileCoder& coder)
	{
		m_name = coder.ReadString();
	}

	void DumpProject(FileCoder& coder) const
	{
		coder.WriteString(m_name);
	}

	nlohmann::ordered_json ToJson() const
	{
		nlohmann::ordered_json j;
		j["name"] = ToUTF8(m_name);

		if (!m_stringArgs.empty())
		{
			j["stringArgs"] = nlohmann::ordered_json::array();

			for (const tString& stringArg : m_stringArgs)
				j["stringArgs"].push_back(ToUTF8(stringArg));
		}

		return j;
	}

	void Patch(const nlohmann::ordered_json& j)
	{
		CHECK_JSON_KEY(j, "name", "fields");

		m_name = ToUTF16(j["name"].get<std::string>());

		if (j.contains("stringArgs"))
		{
			m_stringArgs.clear();
			for (const auto& stringArg : j["stringArgs"])
				m_stringArgs.push_back(ToUTF16(stringArg.get<std::string>()));
		}
	}

	void ReadDat(FileCoder& coder)
	{
		m_indexInfo = coder.ReadInt();
	}

	void DumpDat(FileCoder& coder) const
	{
		coder.WriteInt(m_indexInfo);
	}

	bool IsValid() const
	{
		return m_indexInfo >= INT_START;
	}

	bool IsString() const
	{
		return m_indexInfo >= STRING_START;
	}

	bool IsInt() const
	{
		return !IsString();
	}

	uint32_t Index() const
	{
		if (IsString())
			return m_indexInfo - STRING_START;
		else
			return m_indexInfo - INT_START;
	}

	void SetType(const uint8_t& type)
	{
		m_type = type;
	}

	const uint8_t& GetType() const
	{
		return m_type;
	}

	void SetUnknown1(const tString& unknown1)
	{
		m_unknown1 = unknown1;
	}

	const tString& GetUnknown1() const
	{
		return m_unknown1;
	}

	void SetStringArgs(const tStrings& stringArgs)
	{
		m_stringArgs = stringArgs;
	}

	const tStrings& GetStringArgs() const
	{
		return m_stringArgs;
	}

	void SetArgs(const uInts& args)
	{
		m_args = args;
	}

	const uInts& GetArgs() const
	{
		return m_args;
	}

	void SetDefaultValue(const uint32_t& defaultValue)
	{
		m_defaultValue = defaultValue;
	}

	const uint32_t& GetDefaultValue() const
	{
		return m_defaultValue;
	}

	const tString& GetName() const
	{
		return m_name;
	}

	void SetName(const tString& name)
	{
		m_name = name;
	}

private:
private:
	tString m_name          = TEXT("");
	uint8_t m_type          = 0;
	tString m_unknown1      = TEXT("");
	tStrings m_stringArgs   = {};
	uInts m_args            = {};
	uint32_t m_defaultValue = 0;
	uint32_t m_indexInfo    = 0;

	static const uint32_t STRING_START = 0x07D0;
	static const uint32_t INT_START    = 0x03E8;
};

using Fields = std::vector<Field>;

class Data
{
public:
	// Don't use = default here to prevent potential issues with a vector of Data
	Data() {}

	explicit Data(FileCoder& coder)
	{
		m_name = coder.ReadString();
	}

	void DumpProject(FileCoder& coder) const
	{
		coder.WriteString(m_name);
	}

	nlohmann::ordered_json ToJson() const
	{
		nlohmann::ordered_json j;
		j["name"] = ToUTF8(m_name);
		j["data"] = nlohmann::json::array();

		if (m_stringValues.empty() && m_intValues.empty())
			return j;

		for (const Field& field : *m_pFields)
		{
			nlohmann::ordered_json fieldData;
			fieldData["name"] = ToUTF8(field.GetName());

			if (field.IsValid())
			{
				if (field.IsString())
					fieldData["value"] = ToUTF8(m_stringValues[field.Index()]);
				else
					fieldData["value"] = m_intValues[field.Index()];
			}
			else
				fieldData["value"] = "INVALID_IGNORE";

			j["data"].push_back(fieldData);
		}

		return j;
	}

	void Patch(const nlohmann::ordered_json& j)
	{
		CHECK_JSON_KEY(j, "name", "data");
		CHECK_JSON_KEY(j, "data", "data");

		m_name = ToUTF16(j["name"]);

		if (m_stringValues.empty() && m_intValues.empty()) return;

		for (std::size_t i = 0; i < m_pFields->size(); i++)
		{
			const nlohmann::ordered_json& fieldData = j["data"][i];
			const std::string dataStr               = std::format("data[{}]", i);

			const Field& field    = m_pFields->at(i);
			std::string fieldName = ToUTF8(field.GetName());

			if (!field.IsValid()) continue;

			CHECK_JSON_KEY(fieldData, "name", dataStr);
			CHECK_JSON_KEY(fieldData, "value", dataStr);

			const std::string fieldNameJson = fieldData["name"].get<std::string>();

			if (fieldName != fieldNameJson)
				throw WolfRPGException(std::format("{}Data field name mismatch at index {} - Expected: \"{}\" - Got: \"{}\"", ERROR_TAG, i, fieldName, fieldNameJson));

			if (field.IsString())
				m_stringValues[field.Index()] = ToUTF16(fieldData["value"].get<std::string>());
			else
				m_intValues[field.Index()] = fieldData["value"].get<uint32_t>();
		}
	}

	void ReadDat(FileCoder& coder, Fields& fields, const uint32_t& fieldsSize)
	{
		m_pFields       = &fields;
		uint32_t intCnt = 0;
		uint32_t strCnt = 0;

		for (uint32_t i = 0; i < fieldsSize; i++)
		{
			if (fields[i].IsString())
				strCnt++;
			else
				intCnt++;
		}

		for (uint32_t i = 0; i < intCnt; i++)
			m_intValues.push_back(coder.ReadInt());

		for (uint32_t i = 0; i < strCnt; i++)
			m_stringValues.push_back(coder.ReadString());
	}

	void DumpDat(FileCoder& coder) const
	{
		for (const uint32_t& i : m_intValues)
			coder.WriteInt(i);

		for (const tString& str : m_stringValues)
			coder.WriteString(str);
	}

	const tString& GetName() const
	{
		return m_name;
	}

	void SetName(const tString& name)
	{
		m_name = name;
	}

private:
private:
	tString m_name          = TEXT("");
	uInts m_intValues       = {};
	tStrings m_stringValues = {};
	Fields* m_pFields       = nullptr;
};

using Datas = std::vector<Data>;

class Type
{
public:
	explicit Type(FileCoder& coder)
	{
		m_name            = coder.ReadString();
		uint32_t fieldCnt = coder.ReadInt();
		for (uint32_t i = 0; i < fieldCnt; i++)
			m_fields.push_back(Field(coder));

		uint32_t dataCnt = coder.ReadInt();
		for (uint32_t i = 0; i < dataCnt; i++)
			m_data.push_back(Data(coder));

		m_description = coder.ReadString();

		m_fieldTypeListSize = coder.ReadInt();
		uint32_t index      = 0;

		for (index = 0; index < m_fields.size(); index++)
			m_fields[index].SetType(coder.ReadByte());

		coder.Skip(m_fieldTypeListSize - index);

		index = coder.ReadInt();
		for (uint32_t i = 0; i < index; i++)
			m_fields[i].SetUnknown1(coder.ReadString());

		index = coder.ReadInt();
		for (uint32_t i = 0; i < index; i++)
		{
			tStrings stringArgs;
			uint32_t argsCnt = coder.ReadInt();
			for (uint32_t j = 0; j < argsCnt; j++)
				stringArgs.push_back(coder.ReadString());
			m_fields[i].SetStringArgs(stringArgs);
		}

		index = coder.ReadInt();
		for (uint32_t i = 0; i < index; i++)
		{
			uInts args;
			uint32_t argsCnt = coder.ReadInt();
			for (uint32_t j = 0; j < argsCnt; j++)
				args.push_back(coder.ReadInt());
			m_fields[i].SetArgs(args);
		}

		index = coder.ReadInt();
		for (uint32_t i = 0; i < index; i++)
			m_fields[i].SetDefaultValue(coder.ReadInt());
	}

	void DumpProject(FileCoder& coder) const
	{
		coder.WriteString(m_name);
		coder.WriteInt(m_fields.size());

		for (const Field& field : m_fields)
			field.DumpProject(coder);

		coder.WriteInt(m_data.size());
		for (const Data& data : m_data)
			data.DumpProject(coder);

		coder.WriteString(m_description);

		coder.WriteInt(m_fieldTypeListSize);

		for (const Field& field : m_fields)
			coder.WriteByte(field.GetType());

		for (uint32_t index = static_cast<uint32_t>(m_fields.size()); index < m_fieldTypeListSize; index++)
			coder.WriteByte(0);

		coder.WriteInt(m_fields.size());
		for (const Field& field : m_fields)
			coder.WriteString(field.GetUnknown1());

		coder.WriteInt(m_fields.size());
		for (const Field& field : m_fields)
		{
			coder.WriteInt(field.GetStringArgs().size());
			for (const tString& stringArg : field.GetStringArgs())
				coder.WriteString(stringArg);
		}

		coder.WriteInt(m_fields.size());
		for (const Field& field : m_fields)
		{
			coder.WriteInt(field.GetArgs().size());
			for (const uint32_t& arg : field.GetArgs())
				coder.WriteInt(arg);
		}

		coder.WriteInt(m_fields.size());
		for (const Field& field : m_fields)
			coder.WriteInt(field.GetDefaultValue());
	}

	bool ReadDat(FileCoder& coder)
	{
		VERIFY_MAGIC(coder, DAT_TYPE_SEPARATOR);
		m_unknown1   = coder.ReadInt();
		m_fieldsSize = coder.ReadInt();

		if (m_unknown1 == STRING_INDICATOR)
			m_unknown2 = coder.ReadString();

		for (uint32_t i = 0; i < m_fieldsSize; i++)
			m_fields[i].ReadDat(coder);

		uint32_t dataSize = coder.ReadInt();

		if (m_data.size() > dataSize)
			m_data.resize(dataSize);

		for (Data& datum : m_data)
			datum.ReadDat(coder, m_fields, m_fieldsSize);

		return true;
	}

	void DumpDat(FileCoder& coder) const
	{
		coder.Write(DAT_TYPE_SEPARATOR);
		coder.WriteInt(m_unknown1);

		coder.WriteInt(m_fieldsSize);

		if (m_unknown1 == STRING_INDICATOR)
			coder.WriteString(m_unknown2);

		for (uint32_t i = 0; i < m_fieldsSize; i++)
			m_fields[i].DumpDat(coder);

		coder.WriteInt(m_data.size());
		for (const Data& datum : m_data)
			datum.DumpDat(coder);
	}

	nlohmann::ordered_json ToJson() const
	{
		nlohmann::ordered_json j;
		j["name"]        = ToUTF8(m_name);
		j["description"] = ToUTF8(m_description);
		j["fields"]      = nlohmann::json::array();
		j["data"]        = nlohmann::json::array();

		for (const Field& field : m_fields)
			j["fields"].push_back(field.ToJson());

		for (const Data& data : m_data)
			j["data"].push_back(data.ToJson());

		return j;
	}

	void Patch(const nlohmann::ordered_json& j)
	{
		CHECK_JSON_KEY(j, "name", "types");
		CHECK_JSON_KEY(j, "description", "types");
		CHECK_JSON_KEY(j, "fields", "types");
		CHECK_JSON_KEY(j, "data", "types");

		m_name        = ToUTF16(j["name"].get<std::string>());
		m_description = ToUTF16(j["description"].get<std::string>());

		if (m_fields.size() != j["fields"].size())
			throw WolfRPGException(std::format("{}Count mismatch for object 'fields' expected: {} - got: {}", ERROR_TAG, m_fields.size(), j["fields"].size()));

		for (std::size_t i = 0; i < m_fields.size(); i++)
			m_fields[i].Patch(j["fields"][i]);

		if (m_data.size() != j["data"].size())
			throw WolfRPGException(std::format("{}Count mismatch for object 'data' expected: {} - got: {}", ERROR_TAG, m_data.size(), j["data"].size()));

		for (std::size_t i = 0; i < m_data.size(); i++)
			m_data[i].Patch(j["data"][i]);
	}

	void FixPro35Description()
	{
		// Remove all Ascii characters < 0x20 from the description
		m_description.erase(std::remove_if(m_description.begin(), m_description.end(),
										   [](const wchar_t& c) { return c < 0x20 && c != 0x0A && c != 0x0D; }),
							m_description.end());
	}

	const Fields& GetFields() const
	{
		return m_fields;
	}

	const Datas& GetData() const
	{
		return m_data;
	}

	const tString& GetName() const
	{
		return m_name;
	}

	void SetName(const tString& name)
	{
		m_name = name;
	}

	const tString& GetDescription() const
	{
		return m_description;
	}

	void SetDescription(const tString& description)
	{
		m_description = description;
	}

private:
private:
	tString m_name               = TEXT("");
	tString m_description        = TEXT("");
	Fields m_fields              = {};
	uint32_t m_fieldsSize        = 0;
	Datas m_data                 = {};
	uint32_t m_unknown1          = 0;
	uint32_t m_fieldTypeListSize = 0;
	tString m_unknown2           = TEXT("");

	inline static const Bytes DAT_TYPE_SEPARATOR{ 0xFE, 0xFF, 0xFF, 0xFF };
	static constexpr uint32_t STRING_INDICATOR = 0x0001D4C0;
};

using Types = std::vector<Type>;

// TODO: Why not derive from WolfDataBase?
class Database
{
public:
	Database(const std::filesystem::path& projectFilePath, const std::filesystem::path& datFilePath) :
		m_projectFilePath(projectFilePath),
		m_datFilePath(datFilePath)
	{
		m_valid = init();
	}

	void Dump(const std::filesystem::path& outputPath) const
	{
		{
			const std::filesystem::path fileName = ::GetFileName(m_projectFilePath);

			g_activeFile = fileName;

			std::filesystem::path outputFilePath = outputPath / fileName;
			FileCoder coder(outputFilePath, FileCoder::Mode::WRITE, WolfFileType::Project);
			coder.WriteInt(m_types.size());
			for (const Type& type : m_types)
				type.DumpProject(coder);
		}

		const std::filesystem::path fileName = ::GetFileName(m_datFilePath);

		g_activeFile = fileName;

		std::filesystem::path outputFilePath = outputPath / fileName;
		FileCoder coder(outputFilePath, FileCoder::Mode::WRITE, WolfFileType::DataBase, DAT_SEED_INDICES);
		FileCoder bufCoder(FileCoder::Mode::WRITE, WolfFileType::DataBase);
		FileCoder* pCoder = &coder;

		coder.Write(DAT_MAGIC_NUMBER);
		coder.WriteByte(m_version);

		if (m_version == 0xC4)
			pCoder = &bufCoder;

		pCoder->WriteInt(m_types.size());
		for (const Type& type : m_types)
			type.DumpDat(*pCoder);

		pCoder->WriteByte(m_version);

		if (m_version == 0xC4)
		{
			bufCoder.Pack();
			coder.WriteCoder(bufCoder);
		}
	}

	void ToJson(const std::filesystem::path& outputPath) const
	{
		const std::filesystem::path fileName = ::GetFileNameNoExt(m_datFilePath);

		g_activeFile = fileName;

		nlohmann::ordered_json j;
		j["types"] = nlohmann::json::array();

		for (const Type& type : m_types)
			j["types"].push_back(type.ToJson());

		std::filesystem::path outputFilePath = outputPath / fileName;
		outputFilePath += ".json";

		std::ofstream out(outputFilePath);
		out.exceptions(std::ios::failbit | std::ios::badbit);
		out << j.dump(4);

		out.close();
	}

	void Patch(const std::filesystem::path& patchFolderPath)
	{
		const std::filesystem::path fileName = ::GetFileNameNoExt(m_datFilePath);

		g_activeFile = fileName;

		std::filesystem::path patchFilePath = patchFolderPath / fileName;
		patchFilePath += ".json";

		if (!std::filesystem::exists(patchFilePath))
			throw WolfRPGException(std::format(L"{}Patch file not found: {}", ERROR_TAGW, patchFilePath.wstring()));

		nlohmann::ordered_json j;
		std::ifstream in(patchFilePath);
		in >> j;
		in.close();

		CHECK_JSON_KEY(j, "types", "Database");

		if (m_types.size() != j["types"].size())
			throw WolfRPGException(std::format("{}Count mismatch for object 'types' expected: {} - got: {}", ERROR_TAG, m_types.size(), j["types"].size()));

		for (std::size_t i = 0; i < m_types.size(); i++)
			m_types[i].Patch(j["types"][i]);
	}

	void FixPro35TypeDescriptions()
	{
		for (Type& type : m_types)
			type.FixPro35Description();
	}

	const Types& GetTypes() const
	{
		return m_types;
	}

	const bool& IsValid() const
	{
		return m_valid;
	}

private:
	bool init()
	{
		g_activeFile = ::GetFileName(m_datFilePath);
		FileCoder coder(m_datFilePath, FileCoder::Mode::READ, WolfFileType::DataBase, DAT_SEED_INDICES);

		if (!coder.WasEncrypted())
			VERIFY_MAGIC(coder, DAT_MAGIC_NUMBER)

		m_version = coder.ReadByte();

		// Process the project file
		{
			g_activeFile = ::GetFileName(m_projectFilePath);
			FileCoder coder(m_projectFilePath, FileCoder::Mode::READ, WolfFileType::Project);
			uint32_t typeCnt = coder.ReadInt();
			for (uint32_t i = 0; i < typeCnt; i++)
				m_types.push_back(Type(coder));

			if (!coder.IsEof())
				throw WolfRPGException(std::format(L"{}Project file [{}] has more data than expected", ERROR_TAGW, m_projectFilePath.wstring()));
		}

		g_activeFile     = ::GetFileName(m_datFilePath);
		uint32_t typeCnt = coder.ReadInt();
		if (typeCnt != m_types.size())
			throw WolfRPGException(std::format(L"{}Database [{}] project and dat type count mismatch expected: {}  - got: {}", ERROR_TAGW, m_datFilePath.wstring(), m_types.size(), typeCnt));

		uint32_t cnt = 0;
		for (Type& type : m_types)
		{
			cnt++;
			if (!type.ReadDat(coder))
				throw WolfRPGException(std::format("{}Failed at readDat for type({})", ERROR_TAG, cnt));
		}

		if (coder.ReadByte() != m_version)
			throw WolfRPGException(std::format(L"{}No {} terminator at the end of [{}]", ERROR_TAGW, Dec2HexW(m_version), m_datFilePath.wstring()));

		if (!coder.IsEof())
			throw WolfRPGException(std::format(L"{}Database [{}] has more data than expected", ERROR_TAGW, m_datFilePath.wstring()));

		return true;
	}

private:
	Types m_types       = {};
	Bytes m_cryptHeader = {};

	uint8_t m_version = 0;
	bool m_valid      = false;
	std::filesystem::path m_projectFilePath;
	std::filesystem::path m_datFilePath;

	inline static const SeedIncides DAT_SEED_INDICES = { 0, 3, 9 };
	inline static const MagicNumber DAT_MAGIC_NUMBER{ { 0x57, 0x00, 0x00, 0x4F, 0x4C, 0x00, 0x46, 0x4D, 0x00 }, 5 };
};

using Databases = std::vector<Database>;
