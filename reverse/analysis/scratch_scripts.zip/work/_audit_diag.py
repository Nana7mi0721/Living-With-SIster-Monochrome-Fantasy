
import json, os, io, glob, re, collections
OUT=io.StringIO()
# where do scene/word/EnemyGraphic/CharaChip refs come from?
sites=json.load(open('work/_audit_refs.json',encoding='utf-8'))
for cat in ['scene/','word/','hword/','EnemyGraphic/','CharaChip/','BattleEffect/','Fog_BackGround/','FIcon/','BalloonBase_CafeLatte/','MapChip/','SystemFile/','SystemGraphic/','cutin/','cg/','hscene/','DLC_data/','1.4.0/','Picture/','SE/','BGM/','MapData/']:
    refs=[p for p in sites['referenced'] if p.startswith(cat)]
    miss=[p for p in sites['missing'] if p.startswith(cat)]
    srcs=collections.Counter()
    for p in refs:
        for s in sites['referenced'][p]:
            srcs[s[0]]+=1
    OUT.write('%-22s resolved %4d  missing %4d  sources %s\n' % (cat,len(refs),len(miss),dict(srcs)))
OUT.write('\n== missing sample by prefix ==\n')
bypre=collections.defaultdict(list)
for p in sites['missing']:
    bypre[p.split('/')[0] if '/' in p else '(none)'].append(p)
for k in sorted(bypre,key=lambda x:-len(bypre[x])):
    OUT.write('%s: %d\n' % (k,len(bypre[k])))
    for p in sorted(bypre[k])[:6]:
        OUT.write('    %s  <- %s\n' % (p, sites['missing'][p][0]))
open('work/_audit_out2.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
