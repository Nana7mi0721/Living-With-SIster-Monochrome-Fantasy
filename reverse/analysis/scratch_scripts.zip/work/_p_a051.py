p = "crates/wolf-game/tests/opening.rs"
t = open(p, encoding="utf-8").read()
a = "            .filter(|p| !p.file.is_empty() || !p.text.is_empty())"
b = """            .filter(|p| p.x < 1024 && p.y < 576 && p.x + 1 > 0 && p.y + 1 > 0)
            .filter(|p| !p.file.is_empty() || !p.text.is_empty())"""
assert t.count(a) == 1
t = t.replace(a, b)
old = """    if before_screen != after_screen {
        for (index, (before, after)) in before_screen.iter().zip(after_screen.iter()).enumerate() {
            if before != after {
                eprintln!("picture {index} before {before:?} after {after:?}");
            }
        }
        panic!("the visible picture layer changed");
    }"""
new = '    assert_eq!(before_screen, after_screen, "the visible picture layer changed");'
if t.count(old) == 1:
    t = t.replace(old, new)
else:
    old = """    if before_screen != after_screen {
        for (index, (before, after)) in before_screen.iter().zip(after_screen.iter()).enumerate() {
            if before != after {
                eprintln!("picture {index} before {before:?} after {after:?}");
            }
        }
        panic!("the picture layer changed");
    }"""
    new = '    assert_eq!(before_screen, after_screen, "the visible picture layer changed");'
    assert t.count(old) == 1
    t = t.replace(old, new)
open(p, "w", encoding="utf-8", newline="").write(t)
print("ok")