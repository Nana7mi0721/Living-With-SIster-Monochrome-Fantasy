import io, re
p = r'crates/wolf-game/src/atlas.rs'
s = io.open(p, encoding='utf-8').read()
start = s.index("            // WOLF's message markup")
end = s.index('            text: wolf_format::messagetext::strip(')
comment = (
    '            // WOLF message markup (font size, colour, alignment, line breaks) is\n'
    '            // display control, not characters: a renderer handed the raw string would\n'
    '            // draw the escapes. The tokenizer keeps a lossless view for tools/tests;\n'
    '            // the screen wants the stripped one (see wolf-format::messagetext).\n'
)
s = s[:start] + comment + s[end:]
io.open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('patched')