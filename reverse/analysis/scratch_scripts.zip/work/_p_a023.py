import io, os, json, collections
path = "docs/BASELINE.json"
t = io.open(path, encoding="utf-8", newline="").read()
d = json.loads(t, object_pairs_hook=collections.OrderedDict)
os_ = d["opening_slice"]["message_state"]
os_["non_black"] = 157014
os_["text_items"] = 6
os_["glyphs"] = 67
os_["lines"] = 6
os_["styled"] = True
mw = d["message_window"]
mw["measured"] = collections.OrderedDict([("rows", 7), ("chars", 73), ("items", 6), ("glyphs", 67), ("lines", 6), ("non_black", 157014)])
mw["styled_layout"] = collections.OrderedDict([
    ("api", "message::layout_styled(text, &Vars, frames, &dyn Colours) -> Layout"),
    ("runs", "Layout.runs: Vec<Run { text, rect: [f32;4], font_px, colour: Option<[u8;3]>, outline }>"),
    ("laws", [
        "\\f[n] changes the font size",
        "\\c[n] resolves through SysDatabase type 12; an unknown index keeps the previous colour",
        "\\E enables the outline ring",
        "<C> centres the current row; <R> right-aligns it",
        "typewriter counts plain glyphs; a cut inside a run keeps that run style",
        "cursor sits at the end of the last visible row plus CURSOR_GAP",
    ]),
    ("cli_slack", "the CLI adds one em of width to each run: the layout measures with the half-em rule while cosmic-text shapes with the real advance, so an exact box wraps the last glyph"),
    ("note", "plain layout() still exists for tests and emits one white run per row; the capture/play paths use layout_styled"),
])
so = d["save_opcodes"]
so["live_writer"] = collections.OrderedDict([
    ("entry", "Game::save_to(path)"),
    ("template", "base_save (the save the game was loaded from), or Save/System.sav for a new game"),
    ("writes", [
        "SavePart2: playtime_frames and Sys3/Sys4",
        "SavePart3: 800 normal variables, live common-event self numeric variables and CSelf5..9 strings",
        "SavePart5: the current picture table (savegame::part5_from_screen / picture_to_record)",
        "VariableDatabase: engine CDataBase cells via Databases::write_into",
    ]),
    ("part5_encoding", "text pictures become the 02/05/06 escape stream (encode_picture_text); retail escape 04 decodes to \\f[n] but re-encodes as 05, semantic-only equality"),
    ("vardb", "Databases::write_into(&mut save.vardb) runs after set_part5 and before to_bytes_rebuilt(); a missed cell increments stats.unmodelled and records a 220 SaveLoad diagnostic"),
    ("tests", [
        "wolf-game a_saved_game_reloads_its_live_picture_layer",
        "wolf-game a_saved_game_keeps_the_database_cells",
        "wolf-game a_saved_game_reloads_its_live_picture_layer compares number/kind/file/x/y/anchor/scale/split/pattern for all 66 pictures",
    ]),
])
so["tests"] = [
    "wolf-vm save_ops_decode_slot_paths_and_store_the_221_answer",
    "wolf-game a_save_address_finds_normal_self_and_system_variables",
    "wolf-game a_save_write_reaches_the_next_read",
    "wolf-game a_save_file_round_trips_through_the_writer",
    "wolf-game a_saved_game_reloads_its_live_picture_layer",
    "wolf-game a_saved_game_keeps_the_database_cells",
]
so["partial"] = "220 mode 0 (full save constructed from Game state) is implemented (see live_writer); 221 flag=1 sites ev94 pc335/345/348 remain unverified; retail escape 04 in SavePart5 text records is semantically but not byte-identically re-encoded"
io.open(path + ".new", "w", encoding="utf-8", newline="").write(json.dumps(d, indent=1, ensure_ascii=False) + "\n")
os.replace(path + ".new", path)
print("ok", len(d))