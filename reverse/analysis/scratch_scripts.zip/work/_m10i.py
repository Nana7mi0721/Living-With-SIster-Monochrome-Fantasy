import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
keep={111,121,124,125,172,179,210,300,250,401,420,499,180,190,191}
def dump(eid, lo=0, hi=10**9):
    e=by[eid]; cm=e['cmds']
    print(f"===== CE{eid} run={e['run']} ncmds={len(cm)} =====")
    for i,c in enumerate(cm):
        if i<lo or i>hi: continue
        if c['c'] in keep:
            a=c.get('a',[]); s=c.get('s',[])
            extra=(' '+repr(s)) if s else ''
            print(f"pc{i} {c['c']} {a}{extra}")
dump(188,0,210)

