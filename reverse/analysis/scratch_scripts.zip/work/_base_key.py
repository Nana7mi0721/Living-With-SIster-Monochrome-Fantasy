import io, os, json
p = "crates/wolf-cli/src/main.rs"
s = io.open(p, encoding="utf-8", newline="").read()
old = "game.boot().map(|()| ()).map_err(|err| err.to_string())"
assert s.count(old) >= 1
s = s.replace(old, "game.boot().map_err(|err| err.to_string())")
out = p + ".new"
io.open(out, "w", encoding="utf-8", newline="").write(s)
os.replace(out, p)
print("cli patched")

bp = "docs/BASELINE.json"
text = io.open(bp, encoding="utf-8", newline="").read()
data = json.loads(text)
data["key_input"] = {
  "opcode": 123,
  "model": "key code, not bitmask",
  "codes": {"none": 0, "down": 2, "left": 4, "right": 6, "up": 8, "decide": 10, "cancel": 11, "sub": 12},
  "diagonals_inferred": [1, 3, 7, 9],
  "codes_seen_but_unnamed": [13, 14, 20, 100, 300],
  "sites": 218,
  "mask_histogram": {"145": 91, "144": 28, "176": 20, "16": 10, "177": 7, "49": 3, "241": 3, "33": 2, "1": 2, "64": 5, "32": 6, "48": 5, "784": 1, "771": 1, "183": 1, "184": 1, "160": 2, "257": 1, "512": 1, "17": 27},
  "note": "The mask argument is still unexplained; the port answers with the code of whatever is held, which satisfies every comparison the game performs."
}
data["choice_window"] = {
  "position": "Sys3 (x), Sys4 (y); there is no centred default",
  "sys3_writes_gamewide": 2,
  "sys4_writes_gamewide": 87,
  "title_event": {"sys3": 512, "sys4": 1000, "note": "y=1000 is off the 576-tall screen, so the original title shows no engine window; the boot map repositions it to y=150 before calling event 42"},
  "cancel_rule": "102 bit4 = 0 means a 421 cancel branch exists (153 blocks); bit4 = 1 means cancel cannot be taken (342 blocks)",
}
lines = text.split(chr(10))
body = json.dumps(data, indent=1, ensure_ascii=False).split(chr(10))
io.open(bp + ".new", "w", encoding="utf-8", newline="").write(chr(10).join(body) + chr(10))
os.replace(bp + ".new", bp)
json.load(io.open(bp, encoding="utf-8", newline=""))
print("baseline keys", len(data))
