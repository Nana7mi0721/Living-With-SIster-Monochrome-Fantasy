import json,sys,collections
sys.stdout.reconfigure(encoding='utf-8')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
rows=[]
for e in ev:
    for i,c in enumerate(e['cmds']):
        if c['c']==290:
            rows.append((e['id'],e['title'],i,c['a'],c['bd']))
print("total",len(rows))
print("argc hist:",collections.Counter(len(r[3]) for r in rows))
print("head hist:",collections.Counter(r[3][0] for r in rows).most_common())
print("head>>4:",collections.Counter(r[3][0]>>4 for r in rows).most_common())
print("head&0xF:",collections.Counter(r[3][0]&0xF for r in rows).most_common())
print()
# per type, print args
bytype=collections.defaultdict(list)
for r in rows: bytype[r[3][0]>>4].append(r)
for t in sorted(bytype):
    g=bytype[t]
    print(f"=== type {t}  count={len(g)}  argc={collections.Counter(len(r[3]) for r in g).most_common()}")
    # arg2,arg3 relationship
    same=sum(1 for r in g if len(r[3])>3 and r[3][2]==r[3][3])
    print(f"   arg2==arg3: {same}/{len(g)}")
    print("   duration(arg1) hist:",collections.Counter(r[3][1] for r in g).most_common(12))
    for r in g[:14]:
        print(f"   ev{r[0]:<4} pc{r[2]:<6} a={r[3]}  {r[1][:28]}")
