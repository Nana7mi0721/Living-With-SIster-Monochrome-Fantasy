import io, os
def rep(path, a, b):
    t = io.open(path, encoding='utf-8', newline='').read()
    assert t.count(a) == 1, (path, a[:60], t.count(a))
    t = t.replace(a, b)
    tmp = path + '.new'
    w = io.open(tmp, 'w', encoding='utf-8', newline='')
    w.write(t); w.close()
    os.replace(tmp, path)

E = 'crates/wolf-vm/src/exec.rs'
rep(E, 'assert_eq!(vm.vars.get(1), 1, "skipped past the first label");',
    'assert_eq!(vm.vars.get(1), 0, "landed past the m2 body");')
print('patched')