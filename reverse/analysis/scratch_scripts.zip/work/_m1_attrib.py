# -*- coding: utf-8 -*-
"""Attribute every traced 150 Picture op to its static site(s): match on
(kind, action, string payload, argc) inside the title closure.

The trace carries the *evaluated* numbers (picture number, args), so it can tell
us which picture numbers exist; the static side carries the source event+slot.
Where a picture number is written as a self variable the static side shows the
variable code, and this table is the join between the two.
"""
import collections, io, json, re

events = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
map_evs = {e['id']: e for e in tm['events']}
clos = json.load(io.open('work/_m1_closure2.json', encoding='utf-8'))
rows = clos['from_map_event2']['reached']

def norm(cmds):
    out = []
    for c in cmds:
        if 'c' in c:
            out.append({'c': c['c'], 'a': [int(x) for x in c['a']], 's': list(c.get('s') or [])})
        else:
            out.append({'c': c.get('code', 0),
                        'a': [int(x) for x in (c.get('intArgs') or [])],
                        's': list(c.get('stringArgs') or [])})
    return out

sites = []
for r in rows:
    if r['kind'] == 'c':
        cmds = norm(by_id[r['id']]['cmds'])
        tag = 'c%d' % r['id']
    else:
        cmds = []
        for p in map_evs[r['id']]['pages']:
            cmds.extend(norm(p['list']))
        tag = 'm%d' % r['id']
    for i, c in enumerate(cmds):
        if c['c'] != 150 or len(c['a']) < 2:
            continue
        head = c['a'][0]
        sites.append({'event': tag, 'slot': i,
                      'action': {0: 'Draw', 1: 'Move', 2: 'Erase'}.get(head & 0x0F, 'Set'),
                      'kind': (head >> 4) & 0x07, 'num': c['a'][1],
                      'argc': len(c['a']) - 2, 'strs': list(c['s']), 'args': c['a'][2:]})

def key(site):
    return (site['kind'], site['action'], tuple(site['strs']), site['argc'])

index = collections.defaultdict(list)
for s in sites:
    index[key(s)].append(s)

LINE = re.compile(r'^  150 picture  #(-?\d+) kind (\d+) (\w+) file=(.*?) text=(.*?) args=\[(.*?)\]$')
hist = collections.defaultdict(lambda: collections.Counter())
counts = collections.Counter()
with io.open('work/_m1_trace2.txt', encoding='utf-8') as fh:
    for raw in fh:
        m = LINE.match(raw.rstrip('\n'))
        if not m:
            continue
        num = int(m.group(1)); kind = int(m.group(2)); action = m.group(3)
        file_s = m.group(4); text_s = m.group(5)
        args = [int(x) for x in m.group(6).split(',') if x.strip()]
        payload = file_s if file_s else text_s
        counts[(num, action, kind)] += 1
        cands = index.get((kind, action, (payload,), len(args)), [])
        if not cands:
            cands = [s for s in sites if s['kind'] == kind and s['action'] == action
                     and s['argc'] == len(args) and s['strs'] and s['strs'][0][:40] == payload[:40]]
        for s in cands:
            hist[num]['%s slot %d (num_raw=%d)' % (s['event'], s['slot'], s['num'])] += 1

print('=== traced 150 ops by picture number, attributed to static sites ===')
for num in sorted(hist):
    print('#%d' % num)
    for k, v in hist[num].most_common():
        print('    %-28s x%d' % (k, v))
    print('')
print('=== op counts (num, action, kind) ===')
for k, v in sorted(counts.items(), key=lambda kv: (kv[0][0], kv[0][1])):
    print('  %s x%d' % (k, v))
