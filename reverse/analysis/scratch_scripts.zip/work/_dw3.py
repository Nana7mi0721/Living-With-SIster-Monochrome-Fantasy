import struct
exec(open('work/_dw2.py').read().split('names=[]')[0].replace('print(','#print('))
# find first file entry
daddr,pdir,num,faddr=d_at(DirStart)
print('root num',num,'faddr',faddr)
for i in range(3):
    rel=FileStart+faddr+i*64
    na,attr,da,ds,ps=f_at(rel)
    print('entry',i,'na',na,'attr',attr,'da',da,'ds',ds,'ps',ps)
    print('  bytes', hb[na:na+40].hex(' '))
    print('  ascii', repr(hb[na:na+40]))