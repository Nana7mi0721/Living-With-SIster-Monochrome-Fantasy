import io, json, collections
path = "docs/BASELINE.json"
t = io.open(path, encoding="utf-8").read()
d = json.loads(t, object_pairs_hook=collections.OrderedDict)
ch = d["opening_slice"]["choice_state"]
ch["instructions"] = 30539
ch["picture_ops"] = 748
ch["db_accesses"] = 128
ch["database_writes"] = 15
ch["messages"] = 2
ch["quads"] = 10
ch["text_pictures"] = 4
ch["non_black"] = 35816
ch["live_pictures"] = 21
ch["choice_anchor"] = [512, 192]
ch["choice_rect"] = [512, 192, 242, 148]
ms = d["opening_slice"]["message_state"]
ms["instructions"] = 31427
ms["picture_ops"] = 2392
ms["db_accesses"] = 98
ms["database_writes"] = 13
ms["quads"] = 9
ms["text_pictures"] = 0
ms["live_pictures"] = 21
d["picture_tone"]["type_5_name"] = "\u70b9\u6ec5A [\u660e\u6ec5]"
d["effect_290"] = collections.OrderedDict([
  ("doc", "docs/OPCODE_290.md v2"),
  ("source", "the 11 type ids were read out of WOLF RPG Editor 3.735 Editor.exe as a zero-gap const array of u16 + UTF-16LE names at 0xA847E0"),
  ("types", collections.OrderedDict([("0","\u30d5\u30e9\u30c3\u30b7\u30e5 flash"),("1","\u30ab\u30e9\u30fc\u88dc\u6b63 colour assign"),("2","\u63cf\u753b\u5ea7\u6a19\u30b7\u30d5\u30c8 draw shift"),("3","\u30b7\u30a7\u30a4\u30af shake"),("4","\u30ba\u30fc\u30e0 zoom"),("5","\u70b9\u6ec5A blink"),("6","\u70b9\u6ec5B blink (0 uses)"),("7","\u81ea\u52d5\u62e1\u5927\u7e2e\u5c0f breathe"),("8","\u30d1\u30bf\u30fc\u30f3\u5207\u66ff 1\u56de"),("9","\u30d1\u30bf\u30fc\u30f3\u5207\u66ff \u30eb\u30fc\u30d7"),("10","\u30d1\u30bf\u30fc\u30f3\u5207\u66ff \u5f80\u5fa9")])),
  ("sites_total", 810),
  ("sites_common_events", 640),
  ("sites_map_events", 170),
  ("argument_shape", "290 is argc 7 = [head, duration, lo, hi, p1, p2, p3]; args[2..3] is a CLOSED picture range [lo, hi], not picture A -> picture B (type 4 has 43/49 sites with arg3 = arg2 + 1 = button art + button text; type 5 [390, 500] dims 72 pictures at once)"),
  ("implemented", "type 5 blink only (picture_tone above)"),
  ("unimplemented", "types 0, 2, 3, 4, 7, 8, 9, 10")
])
d["transitions"] = collections.OrderedDict([
  ("source", "opcode 150 move whose tail carries [head | 0x1000000, nothing, duration, nothing, nothing]"),
  ("sites_moves_total", 3365),
  ("sites_teleport", 2817),
  ("sites_duration_zero", 168),
  ("sites_unresolved_self_var", 52),
  ("sites_animated", 328),
  ("durations_observed", [2, 16]),
  ("cap", "MAX_TRANSITION_FRAMES 600"),
  ("law", "from = the pose before merge_args, to = the merged pose, linear over age/duration; duration 0, above the cap, or an unresolved self variable teleports instead"),
  ("decisive_pair", "ev63 pc93 parks the message window with no tail; ev63 pc94 is the same arguments plus 16777216,3 and slides over 3 frames")
])
d["offscreen_cull"] = collections.OrderedDict([
  ("rule", "picture::on_screen(dst): positive extent, dst[0]+dst[2] > 0, dst[1]+dst[3] > 0, dst[0] < 1024, dst[1] < 576"),
  ("why", "event 98 (the balloon-message library) parks its 24 controls at (-2784, 2880); without the test each panel still cost a skin pack and up to 30 quads"),
  ("effect", "opening choice capture 38 -> 10 quads and 11 -> 4 text pictures; message capture 37 -> 9 quads and 7 -> 0 text pictures"),
  ("pixel_proof", "imgdiff reports identical: true on both captures before and after")
])
d["engine_events"] = collections.OrderedDict([
  ("always", [48, 261, 269, 270, 271, 224, 225, 213, 214, 41]),
  ("auto_start", [241]),
  ("implicit", [63]),
  ("unique_total", 12),
  ("doc", "docs/ENGINE_EVENTS.md (section 10 is the Lead appendix with the measured A/B)"),
  ("order_matters", "48 fills the system variables; 261 precedes 270 (270 reads 2700000..2700005); 269 precedes 270 (270 tests 1600099); 225 publishes Sys71/72 that 224 and 213 consume"),
  ("title_parity", "each of the nine ENGINE_ALWAYS candidates alone is pixel-identical to starting none; all together mean abs 0.012 / psnr 67.20 dB at frame 716"),
  ("excluded", "343 has 44 by-id calls but its condition variable has no writer; 43 has zero call sites"),
  ("cli_switch", "wolf-cli capture --engine-events <id,id,...> (an empty value starts none)")
])
d["database_layer"]["engine_defaults"] = "apply_engine_defaults writes the coordinate scale into CData (18, 97) / (18, 98) and the message-window skin name into Data (18, 0, 24)"
d["database_layer"]["write_ops"] = collections.OrderedDict([("0","assign"),("1","add"),("2","sub"),("3","mul"),("4","div"),("5","rem"),("6","max"),("7","min")])
d["database_layer"]["write_law"] = "flags & 0x1000 == 0 means WRITE; the operand comes from int arg 4 (argc >= 5) or from the string argument (argc == 4); a write never stores anything back into the source variable"
out = json.dumps(d, indent=1, ensure_ascii=False) + "\n"
io.open(path + ".new", "w", encoding="utf-8", newline="").write(out)
import os; os.replace(path + ".new", path)
print("keys", len(d))
print(json.dumps(d["opening_slice"], ensure_ascii=False)[:200])