import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
title2ids={}
for e in ces:
    title2ids.setdefault(e['title'],[]).append(e['id'])
# titles of interest
for t in ['X┣◆戦闘初期化','X┣◆戦闘キャラ配置','X[戦]戦闘変数初期化','X[戦]主人公DB→戦闘DBコピー','X[戦]敵DB→戦闘DBコピー','X[戦]敵/味方·勝敗判定','X┣◆主人公ＤＢ復元','X┣◆戦闘終了処理','X[戦]キャラクタID取得']:
    print(repr(t),'->',title2ids.get(t))
print('--- CE190 exact a for stack reads ---')
for i in [12,35,36,37,38,39,40]:
    c=by[190]['cmds'][i]
    print('CE190 pc',i,c['c'],c.get('a'),c.get('s'))
print('--- CE172 exact ---')
for i in range(0,60):
    c=by[172]['cmds'][i]
    if c['c'] in (111,250,300,121,179):
        print('CE172 pc',i,c['c'],c.get('a'),c.get('s'))

