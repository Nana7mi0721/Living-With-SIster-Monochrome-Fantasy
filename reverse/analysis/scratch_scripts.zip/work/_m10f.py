import json,collections
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
tgt=set(range(140,205))
print("=== op210 call edges among CE140..204 ===")
edges=collections.defaultdict(list)
calls_to=collections.defaultdict(list)
for e in ces:
    for i,cm in enumerate(e['cmds']):
        if cm['c']==210 and cm.get('a'):
            v=cm['a'][0]
            if 500000<=v<700000:
                t=v-500000
                if t in tgt:
                    calls_to[t].append((e['id'],i))
for t in sorted(calls_to):
    who=calls_to[t]
    print(f"CE{t:<4} <- {len(who)} calls from: "+", ".join(f"CE{a}@pc{b}" for a,b in who[:12])+(" ..." if len(who)>12 else ""))

