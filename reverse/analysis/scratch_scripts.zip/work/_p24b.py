import json, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
for target in ['charicon.png','WindowBase_amania.png','CursorBase.png']:
    print('==', target)
    for ev in ce:
        for i,c in enumerate(ev['cmds']):
            for s in c['s']:
                if target in s:
                    print('  ev', ev['id'], ev['title'][:20], 'pc', i, 'op', c['c'], 'a', c['a'], 's', s[:90])

