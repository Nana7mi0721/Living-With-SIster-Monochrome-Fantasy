
import json,io,collections,sys,re
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
m101=[]
for e in ce:
    for c in e['cmds']:
        op,a,s=norm(c)
        if op==101: m101.append(('ce',e['id'],a,s))
for m in mp.values():
    for ev in m.get('events',[]):
        for c in ev.get('cmds',[]):
            op,a,s=norm(c)
            if op==101: m101.append(('mp',m.get('title'),a,s))
pat=collections.Counter()
for src,eid,a,s in m101:
    t=s[0] if s else ''
    m=re.match(r'@([^\\\n]{0,12})',t)
    if m: pat[m.group(1)]+=1
print('texts starting with @:',sum(pat.values()),'of',len(m101))
print('top prefixes',pat.most_common(20))
# what if any: distribution of first char
fc=collections.Counter((s[0][:1] if s else '') for _,_,a,s in m101)
print('first char top',fc.most_common(12))
# sample whole texts starting with @digit
n=0
for src,eid,a,s in m101:
    if s and re.match(r'@\d',s[0]):
        print('  ',src,eid,repr(s[0][:90])); n+=1
        if n>=6: break
