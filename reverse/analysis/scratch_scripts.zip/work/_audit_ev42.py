
import json,io
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
by={e['id']:e for e in lst}
e=by[42]
W('ev42 title=%r'%e['title'])
for i,c in enumerate(e['cmds'][:8]):
    W('  #%d c=%s s=%r'%(i,c['c'],c.get('s')))
sd=json.load(open('work/wolftl/dump/db/SysDatabase.json',encoding='utf-8'))
t0=sd['types'][0]
W('\nSysDatabase type0 name=%r fields=%s'%(t0['name'],[f['name'] for f in t0['fields']]))
for i,row in enumerate(t0['data']):
    vals={d['name']:d['value'] for d in row.get('data',[])}
    mp=vals.get('マップファイル名')
    if mp: W('  row %2d name=%-14r map=%r'%(i,row.get('name'),mp))
open('work/_audit_out33.txt','w',encoding='utf-8').write(OUT.getvalue()); print('ok')
