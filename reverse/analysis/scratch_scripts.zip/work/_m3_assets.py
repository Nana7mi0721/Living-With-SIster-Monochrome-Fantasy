
import json,os,collections,re
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"]
L=[]
def p(s=""): L.append(s)
p("## H closure members (%d)"%len(H))
for i in H:
    e=idx[i]
    p("ev%-4d run=%d slots=%-5d %s"%(i,e["run"],len(e["cmds"]),e["title"]))

p("")
p("## asset strings referenced inside H closure (150 file / 140 sound / 270 party / 122 / 111-str)")
for i in H:
    e=idx[i]
    files=collections.Counter(); snd=collections.Counter(); other=collections.Counter()
    for c in e["cmds"]:
        op=c["c"]; s=c.get("s") or []
        for x in s:
            if not isinstance(x,str): continue
            if re.search(r"\.(png|jpg|jpeg|bmp|webp|gif|mp3|ogg|wav|mid|m4a|mp4)$",x,re.I):
                if op==150: files[x]+=1
                elif op==140: snd[x]+=1
                else: other["%d:%s"%(op,x)]+=1
    if files or snd or other:
        p("--- ev%d %s"%(i,e["title"]))
        for k,v in files.most_common(60): p("    150 %-58s x%d"%(k,v))
        for k,v in snd.most_common(20): p("    140 %-58s x%d"%(k,v))
        for k,v in list(other.items())[:40]: p("    oth %s"%k)
open(os.path.join(W,"_m3_out5.txt"),"w",encoding="utf-8").write("\n".join(L))
print("lines",len(L))
