import io, os
p = "crates/wolf-game/src/game.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = "        let sys = |index: i32| self.vm.vars.get_sys(index);"
assert t.count(a) == 1
t = t.replace(a, "        let sys = |index: usize| self.vm.vars.get_sys(index);")
t = t.replace("        let (cursor_x, cursor_y) = (sys(5), sys(6));", "        let (cursor_x, cursor_y) = (sys(5), sys(6));")
io.open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("ok")