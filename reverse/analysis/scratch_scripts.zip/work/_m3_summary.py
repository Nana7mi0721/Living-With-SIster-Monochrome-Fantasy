
# -*- coding: utf-8 -*-
import json, collections, io
ce = json.load(open("work/_ce_full.json", encoding="utf-8"))
HO, MI, WD, FL = 2000004, 2000005, 2000006, 2000008
call217 = collections.Counter()
deltas = collections.Counter()
writes = {HO: collections.Counter(), MI: collections.Counter(), WD: collections.Counter(), FL: collections.Counter()}
pics = collections.defaultdict(set)
for ev in ce:
    eid = ev["id"]
    for k, c in enumerate(ev["cmds"]):
        a = c.get("a") or []
        s = c.get("s") or []
        if c["c"] == 210 and len(a) >= 3 and a[0] == 500217:
            call217[eid] += 1
            deltas[a[2]] += 1
        if c["c"] == 121 and a and a[0] in (HO, MI, WD, FL):
            writes[a[0]][eid] += 1
        if c["c"] == 150 and len(a) > 1 and a[1] in (6200, 6210, 6211):
            pics[a[1]].add(eid)
out = io.StringIO()
out.write("events total = %d\n" % len(ce))
out.write("217 call sites = %d across %d events\n" % (sum(call217.values()), len(call217)))
out.write("delta histogram = %s\n" % sorted(deltas.items()))
out.write("top 217 callers = %s\n" % call217.most_common(8))
for v, name in ((HO, "hour"), (MI, "minute"), (WD, "weekday"), (FL, "flag8")):
    out.write("writes %s(%d): sites=%d events=%d -> %s\n" % (
        name, v, sum(writes[v].values()), len(writes[v]), writes[v].most_common(6)))
for p, evs in pics.items():
    out.write("picture %d drawn by %d events: %s\n" % (p, len(evs), sorted(evs)))
open("work/_m3_summary.txt", "w", encoding="utf-8").write(out.getvalue())
print("written")
