import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
t = t.replace("game.databases.set_num(crate::db::Container::CData, 0, 12, 0, 4242);", "game.databases.set_num(crate::db::Container::CData, 0, 12, 5, 4242);")
t = t.replace("refreshed.databases.num(crate::db::Container::CData, 0, 12, 0),", "refreshed.databases.num(crate::db::Container::CData, 0, 12, 5),")
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")