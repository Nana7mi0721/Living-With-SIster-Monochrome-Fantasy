import io, os
root = r'E:/Study/github program/imoto life'
def read(p):
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()
def write(p, s):
    with io.open(p + '.new', 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    os.replace(p + '.new', p)
# part1: make the page-table count field agree with the vector
p1 = os.path.join(root, 'crates/wolf-save/src/part1.rs')
s = read(p1)
old = '''        if self.items.len() > 0x1_0000 {'''
new = '''        if usize::try_from(self.count) != Ok(self.items.len()) {
            return Err(Error::field(
                "SavePart1_1_1 count",
                out.len(),
                format!(
                    "m_var7 says {} entr(ies) but {} were stored",
                    self.count,
                    self.items.len()
                ),
            ));
        }
        if self.items.len() > 0x1_0000 {'''
assert old in s
write(p1, s.replace(old, new, 1))
print('ok part1 count check')