import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
print("=== scan op250 writes/reads of type20/21 rows 4,69,72,75 ===")
for e in ces:
    for i,c in enumerate(e['cmds']):
        if c['c']==250:
            a=c.get('a',[])
            if len(a)>=2 and a[0] in (20,21) and a[1] in (4,69,72,75):
                print(f"CE{e['id']} pc{i} a={a} s={c.get('s')}")
print("=== CE140 戦闘変数初期化 dump ===")
e=by[140]; print("ncmds",len(e['cmds']))
for i,c in enumerate(e['cmds']):
    if c['c'] in (111,121,124,125,172,179,210,300,250,401,420,499,180,190,191):
        print("pc",i,c['c'],c.get('a'),c.get('s'))

