import io, os
def rep(path, a, b):
    t = io.open(path, encoding='utf-8', newline='').read()
    assert t.count(a) == 1, (path, a[:60], t.count(a))
    t = t.replace(a, b)
    tmp = path + '.new'
    w = io.open(tmp, 'w', encoding='utf-8', newline='')
    w.write(t); w.close()
    os.replace(tmp, path)

P = 'crates/wolf-vm/src/program.rs'
rep(P, 'pub const NO_RETURN_VALUE: u32 = u32::MAX;',
    'pub const NO_RETURN_VALUE: u32 = u32::MAX;\n'
    '\n'
    '/// Self bank a common event keeps its own variables in.\n'
    '///\n'
    '/// All 550 events address their own state through magic `1_600_000 + slot`\n'
    '/// (32,391 reads and 9,642 writes land in group 6, and not one write lands in\n'
    '/// group 0), so group 6 is where a common event lives - including the call\n'
    '/// arguments the engine writes at [`crate::magic::SELF_ARG_BASE`].\n'
    'pub const COMMON_SELF_BASE: usize = 600;\n'
    '\n'
    '/// Self bank a map page keeps its own variables in.\n'
    '///\n'
    '/// The editor spells a map event own state as `1_100_000 + slot`: the YADOT-WOLF\n'
    '/// docs show an event writing `1100005` and the debug window reporting it as\n'
    '/// `1000025`, i.e. group 1 slot 5. No map page in this game expands a\n'
    '/// `\\cself[n]` escape, so this value is inferred from the documented magic\n'
    '/// rather than measured against a capture.\n'
    'pub const MAP_SELF_BASE: usize = 100;')

rep(P, '    pub return_value_id: u32,\n    /// The instruction stream, unchanged from the file.',
    '    pub return_value_id: u32,\n'
    '    /// Self bank this program own variables live in.\n'
    '    ///\n'
    '    /// `\\cself[n]` means slot `n` of the running event, so the escape resolves to\n'
    '    /// `self_base + n`. The magic operands stored in the file already carry the\n'
    '    /// same base explicitly, which is why this field is only consulted by the\n'
    '    /// text expander. See [`COMMON_SELF_BASE`] and [`MAP_SELF_BASE`].\n'
    '    pub self_base: usize,\n'
    '    /// The instruction stream, unchanged from the file.')

rep(P, '        program.return_value_id = event.return_value_id;',
    '        program.return_value_id = event.return_value_id;\n        program.self_base = COMMON_SELF_BASE;')

rep(P, '            return_value_id: NO_RETURN_VALUE,',
    '            return_value_id: NO_RETURN_VALUE,\n            self_base: MAP_SELF_BASE,')

E = 'crates/wolf-vm/src/exec.rs'
rep(E, 'impl VarLookup for Instance {\n    fn lookup_num(&self, bank: EscapeBank, index: usize) -> i32 {\n        match bank {\n            EscapeBank::SelfVar => self.self_vars.get(index),',
    '/// `\\cself[n]` names slot `n` of the running event, which is NOT bank `n`:\n'
    '/// a common event keeps its own variables in group 6, a map page in group 1\n'
    '/// (see [`crate::program::COMMON_SELF_BASE`]). The file spells the same slots\n'
    '/// absolutely as magic `1_600_000 + n`, so only the escape needs this offset.\n'
    'impl VarLookup for Instance {\n    fn lookup_num(&self, bank: EscapeBank, index: usize) -> i32 {\n        match bank {\n            EscapeBank::SelfVar => self.self_vars.get(self.program.self_base + index),')

rep(E, '            EscapeBank::SelfVar => self.self_vars.get_str(index).to_owned(),',
    '            EscapeBank::SelfVar => {\n                self.self_vars.get_str(self.program.self_base + index).to_owned()\n            }')

rep(E, '            EscapeBank::SelfVar => self.inst.self_vars.get(index),',
    '            EscapeBank::SelfVar => self.inst.self_vars.get(self.inst.program.self_base + index),')

rep(E, '            EscapeBank::SelfVar => self.inst.self_vars.get_str(index).to_owned(),',
    '            EscapeBank::SelfVar => self\n                .inst\n                .self_vars\n                .get_str(self.inst.program.self_base + index)\n                .to_owned(),')

print('patched')