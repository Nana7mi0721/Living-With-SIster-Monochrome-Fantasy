import io, json, sys
sys.stdout.reconfigure(encoding='utf-8')
root = r'E:/Study/github program/imoto life'
d = json.load(io.open(root + '/work/wolftl/dump/db/CDataBase.json', encoding='utf-8'))
t0 = d['types'][0]
print('name:', t0['name'], 'fields:', len(t0['fields']), 'data rows:', len(t0['data']))
for i, row in enumerate(t0['data']):
    vals = row.get('data', [])
    first = [v.get('value') for v in vals[:6]]
    print(i, row.get('name'), first)
