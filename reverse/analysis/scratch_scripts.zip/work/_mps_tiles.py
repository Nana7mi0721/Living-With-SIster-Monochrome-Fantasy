import io, struct, os, collections
def u32(d,p): return struct.unpack_from('<I', d, p)[0]
def parse(path):
    d = io.open(path,'rb').read()
    p = 20
    assert d[10:16] == b'WOLFM\x00', d[10:16]
    p = 24
    ver = d[p]; p += 1
    n = u32(d,p); p += 4
    title = d[p:p+n].split(b'\x00')[0].decode('utf-8','replace'); p += n
    tileset = u32(d,p); p += 4
    w = u32(d,p); p += 4
    h = u32(d,p); p += 4
    ev = u32(d,p); p += 4
    first = u32(d,p); p += 4
    layers = []
    if first == 0xFFFFFFFF:
        layers = [[0xFFFFFFFF]*(w*h) for _ in range(3)]
    else:
        for L in range(3):
            layers.append(list(struct.unpack_from('<%dI' % (w*h), d, p))); p += w*h*4
    return dict(title=title, tileset=tileset, w=w, h=h, layers=layers, ver=ver)
rows = []
for f in sorted(os.listdir('work/full/MapData')):
    if not f.endswith('.mps'): continue
    m = parse(os.path.join('work/full/MapData', f))
    base = collections.Counter()
    autos = collections.Counter()
    for L in m['layers']:
        for v in L:
            if v == 0xFFFFFFFF: continue
            a = v // 100000
            if a > 0: autos[a] += 1
            else: base[v] += 1
    print(f, 'ts', m['tileset'], m['w'], 'x', m['h'], 'base_max', max(base) if base else None,
          'base_distinct', len(base), 'autos', sorted(autos)[:8], 'n_auto_ids', len(autos))
    rows.append((f, m['tileset'], base, autos))
