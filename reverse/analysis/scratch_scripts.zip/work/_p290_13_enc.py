
import zipfile, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')
print('head', data[:64].hex())
for enc in ['cp932','utf-16-le','utf-8']:
    for w in ['ファイル','ピクチャ','エフェクト']:
        b = w.encode(enc, errors='replace')
        print(enc, w, data.count(b))
# ASCII markers
for m in [b'TForm', b'Delphi', b'UPX', b'Borland', b'.text', b'MZ', b'PE\x00\x00', b'pyinstaller', b'_MEI', b'node', b'electron', b'v8_context']:
    print(m, data.count(m))
