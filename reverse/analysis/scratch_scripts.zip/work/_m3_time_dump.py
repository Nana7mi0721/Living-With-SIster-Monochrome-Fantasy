import json,os,sys
sys.stdout.reconfigure(encoding="utf-8")
W="work"
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
for eid in (217,329,317):
    e=idx[eid]
    print("="*20, "ev%d"%eid, e["title"], "run=%d"%e["run"], "slots=%d"%len(e["cmds"]))
    for i,c in enumerate(e["cmds"]):
        if not c["c"]: continue
        print("pc%-5d op%-5d bd%-2d a=%s s=%s"%(i,c["c"],c.get("bd",0),c.get("a"),json.dumps(c.get("s"),ensure_ascii=False) if c.get("s") else ""))