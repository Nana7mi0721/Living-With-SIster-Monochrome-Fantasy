import json, io
events = json.load(io.open("work/_ce_full.json", encoding="utf-8"))
ev = [e for e in events if e["id"] == 63][0]
cmds = ev["cmds"]
for i in range(54, 90):
    c = cmds[i]
    s = c["s"][0][:26] if c["s"] else ""
    print("%3d op=%-4d bd=%d a=%s s=%r" % (i, c["c"], c["bd"], c["a"], s))