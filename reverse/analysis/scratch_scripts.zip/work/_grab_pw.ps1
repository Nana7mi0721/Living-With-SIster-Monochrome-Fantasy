$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class W5 {
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
}
"@
$gameDir = 'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
$proc = Start-Process -FilePath (Join-Path $gameDir 'Game.exe') -WorkingDirectory $gameDir -PassThru
Start-Sleep -Seconds 75
$proc.Refresh()
$h = $proc.MainWindowHandle
$c = New-Object W5+RECT
[void][W5]::GetClientRect($h, [ref]$c)
$w = $c.Right - $c.Left; $hh = $c.Bottom - $c.Top
Write-Output ("client " + $w + "x" + $hh)
function Shot($name) {
  $bmp = New-Object System.Drawing.Bitmap $w, $hh
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $hdc = $g.GetHdc()
  $ok = [W5]::PrintWindow($h, $hdc, 3)
  $g.ReleaseHdc($hdc)
  $out = 'E:\Study\github program\imoto life\work\out\' + $name + '.png'
  $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
  $g.Dispose(); $bmp.Dispose()
  Write-Output ("shot " + $name + " ok=" + $ok + " hash=" + (Get-FileHash $out).Hash.Substring(0,8))
}
Shot 'pw_0'
Start-Sleep -Seconds 5
Shot 'pw_1'
Start-Sleep -Seconds 10
Shot 'pw_2'
Start-Sleep -Seconds 15
Shot 'pw_3'
try { Stop-Process -Id $proc.Id -Force } catch {}
Write-Output 'done'
