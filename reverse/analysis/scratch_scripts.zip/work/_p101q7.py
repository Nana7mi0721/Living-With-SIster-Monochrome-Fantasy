
import json,io,collections,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
items=[norm(c) for e in ce for c in e['cmds']]
items+=[norm(c) for m in mp.values() for ev in m.get('events',[]) for c in ev.get('cmds',[])]
for base in (150,137,22,14):
    w=[a[:4] for op,a,s in items if op in (121,124) and a and a[0]==9000000+base]
    print('Sys%-4d writers %d %s'%(base,len(w),w[:3]))
