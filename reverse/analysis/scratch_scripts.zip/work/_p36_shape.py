
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
print(type(d), len(d))
if isinstance(d,dict):
    k=list(d)[:3]; print(k)
    v=d[k[0]]; print(type(v), list(v)[:8] if isinstance(v,dict) else len(v))
    print(json.dumps(v,ensure_ascii=False)[:800])
else:
    print(json.dumps(d[0],ensure_ascii=False)[:800])
