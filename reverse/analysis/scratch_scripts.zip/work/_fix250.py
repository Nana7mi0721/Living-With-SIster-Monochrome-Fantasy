import io,sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
p = 'docs/OPCODE_250.md'
lines = open(p, encoding='utf-8').read().split(chr(10))
out = []
n = 0
for i,l in enumerate(lines):
    need = i > 0 and (l.startswith('#') or l.strip() == '---')
    if need and out and out[-1].strip() != '':
        out.append('')
        n += 1
    out.append(l)
s = chr(10).join(out)
if not s.endswith(chr(10)): s += chr(10)
open(p,'w',encoding='utf-8',newline='\n').write(s)
print('inserted', n, 'bytes', len(s.encode('utf-8')), 'lines', s.count(chr(10)))