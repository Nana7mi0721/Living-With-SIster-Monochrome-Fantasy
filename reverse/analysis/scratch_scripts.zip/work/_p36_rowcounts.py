
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(open('work/wolftl/dump/db/CDataBase.json',encoding='utf-8'))
print(type(d), list(d)[:10] if isinstance(d,dict) else len(d))
types=d['types'] if isinstance(d,dict) and 'types' in d else d
print('ntypes',len(types))
for t in [0,2,3,5,6,7,8,10,11,12,13,14,15,16,17,18,19,21,22,24]:
    tt=types[t]
    name=tt.get('name')
    data=tt.get('data',[])
    print('type%-3d %-28s rows=%d'%(t,name,len(data)))
