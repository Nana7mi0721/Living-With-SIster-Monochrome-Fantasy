import io, os
spec = 'docs/SAVE_SPEC.md'
text = io.open(spec, encoding='utf-8', newline='').read()
a = 'self_var(131, 12) = 该档的槽号（2/3/4/5/6/7/8；SaveData01 / SaveData08 / System.sav 都是 8）。'
assert text.count(a) == 1, text.count(a)
b = 'self_var(131, 12) 逐档为 8/2/3/4/5/6/7/8/8 —— SaveData01 是 8 而不是 1，所以它更像'
b += '「最后一次在存读档界面里选中的槽」，而不是「本档是第几号槽」【未验证】。'
text = text.replace(a, b)
io.open(spec + '.new', 'w', encoding='utf-8', newline='').write(text)
os.replace(spec + '.new', spec)
print('ok')