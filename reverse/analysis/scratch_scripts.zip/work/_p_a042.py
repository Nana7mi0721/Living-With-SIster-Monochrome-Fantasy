path = "crates/wolf-game/tests/opening.rs"
raw = open(path, "rb").read()
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
a = """    println!("title path choices: {:?}", game.choices.as_ref().map(|c| c.options.clone()));\n    println!("title path diagnostics: {:?}", game.diagnostics.keys().collect::<Vec<_>>());\n    println!("title path stats: {:?}", game.stats);\n"""+chr(10)

assert t.count(a) == 1
t = t.replace(a, "")
open(path, "wb").write(t.encode("utf-8"))
print("done")