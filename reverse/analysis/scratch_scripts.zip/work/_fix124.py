import io
p = r"E:\Study\github program\imoto life\crates\wolf-vm\src\exec.rs"
s = io.open(p, encoding="utf-8").read()
pairs = [
    ("assert_eq!(vm.vars.get(0), 1, 'hover answer');", 'assert_eq!(vm.vars.get(0), 1, "hover answer");'),
    ("assert_eq!(vm.vars.get(1), 0, 'in-use answer');", 'assert_eq!(vm.vars.get(1), 0, "in-use answer");'),
    ("assert_eq!(vm.vars.get(2), 640, 'mouse x from the short form');", 'assert_eq!(vm.vars.get(2), 640, "mouse x from the short form");'),
    ("assert_eq!(vm.vars.get(3), 8, 'unanswered field keeps the old value');", 'assert_eq!(vm.vars.get(3), 8, "unanswered field keeps the old value");'),
    ("assert!(host.logs.is_empty(), 'unexpected logs');", 'assert!(host.logs.is_empty(), "unexpected logs");'),
    ("let ev = event(77, 'self id', vec![cmd(124, &[2_000_000, 0x3000, 18], &[])]);", 'let ev = event(77, "self id", vec![cmd(124, &[2_000_000, 0x3000, 18], &[])]);'),
]
for a, b in pairs:
    if a not in s:
        print("MISS", a[:50])
    s = s.replace(a, b)
io.open(p, "w", encoding="utf-8", newline="\n").write(s)
print("patched")
