# -*- coding: utf-8 -*-
import io, os, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BT = chr(96)

raw = open('work/_map_audit_md.txt', encoding='utf-8').read().splitlines()
sections, cur, buf = {}, None, []
for line in raw:
    if line.startswith('@@'):
        if cur:
            sections[cur] = '\n'.join(buf).strip('\n')
        cur, buf = line[2:].strip(), []
    else:
        buf.append(line)
if cur:
    sections[cur] = '\n'.join(buf).strip('\n')

HDR = '| ev | name | page | trigger | cond slot 0 | cond slot 1 | cond slot 2 | cond slot 3 | cmds | boot-active |'
NEWHDR = '| ev | 事件名 | 页 | trigger | 条件槽 0 | 条件槽 1 | 条件槽 2 | 条件槽 3 | 槽数 | 新 VM 激活 |'

def fmt_table(text):
    out = []
    for line in text.splitlines():
        if line.strip() == HDR:
            out.append(NEWHDR)
            continue
        if line.startswith('| '):
            cells = line.split('|')
            for i in range(1, len(cells) - 1):
                s = cells[i].strip()
                if s == '-':
                    s = '—'
                elif s == 'yes':
                    s = '✓'
                elif s == 'no':
                    s = ''
                cells[i] = ' ' + s + ' '
            out.append('|'.join(cells))
        else:
            out.append(line)
    return '\n'.join(out)

def fmt_prec(text):
    t = text.strip()
    if t.startswith('(no multi-page'):
        return '本图全部事件都是单页（没有优先级竞争）。'
    out = []
    for line in t.splitlines():
        s = line.strip()
        if not s.startswith('- ev'):
            out.append(s)
            continue
        parts = s.split(' - ')
        head = parts[0].replace(BT, '「', 1).replace(BT, '」')
        pages = parts[1].split()[0]
        combos = int(parts[1].split('/')[1].split()[0])
        wins = parts[2]
        wins = wins[wins.find('(') + 1:wins.rfind(')')].replace(', ', ' ')
        nlive = parts[3].count(',') + 1
        dom = 0 if len(parts) < 5 else parts[4].count(';') + 1
        out.append('%s —— %s 页 / %s 组合；胜出 %s；可胜页 %d/%d；低页必输对 %d'
                   % (head, pages, format(combos, ','), wins, nlive, int(pages), dom))
    return '\n'.join(out)

doc = ''.join(open('work/_doc%d.txt' % i, encoding='utf-8').read() for i in (1, 2, 3, 4))
doc = re.sub(r'@@TABLE ([^\s]+)', lambda m: fmt_table(sections.get('TABLE ' + m.group(1), '（缺表 ' + m.group(1) + '）')), doc)
doc = re.sub(r'@@PREC ([^\s]+)', lambda m: fmt_prec(sections.get('PREC ' + m.group(1), '（缺 ' + m.group(1) + '）')), doc)
doc = re.sub(r'@@INC ([^\s]+)', lambda m: open('work/_doc' + m.group(1) + '.txt', encoding='utf-8').read().rstrip('\n'), doc)
doc = doc.replace('«BT»', BT)
doc = doc.rstrip('\n') + '\n'
open('docs/MAP_AUDIT.md', 'w', encoding='utf-8', newline='\n').write(doc)
print('lines %d chars %d' % (doc.count('\n'), len(doc)))
print('stray markers:', doc.count('@@'), '| BT placeholders:', doc.count('«BT»'), '| table headers:', doc.count('| ev | 事件名'))
print('untranslated english in prec:', doc.count('enumerated'))
