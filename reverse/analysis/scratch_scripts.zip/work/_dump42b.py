
import json
d = json.load(open('work/_ce_full.json', encoding='utf-8'))
evs = d['events'] if isinstance(d, dict) else d
ev = [e for e in evs if e.get('id') == 42][0]
cs = ev['cmds']
for i in range(78, len(cs)):
    c = cs[i]
    print(i, c['c'], c['a'], len(c.get('s') or []), c.get('bd'))
