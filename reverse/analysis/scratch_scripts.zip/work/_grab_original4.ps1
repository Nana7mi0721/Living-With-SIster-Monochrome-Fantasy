$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class W4 {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
}
"@
$gameDir = 'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
$proc = Start-Process -FilePath (Join-Path $gameDir 'Game.exe') -WorkingDirectory $gameDir -PassThru
Start-Sleep -Seconds 70
$proc.Refresh()
$h = $proc.MainWindowHandle
[void][W4]::ShowWindow($h, 9)
[void][W4]::SetForegroundWindow($h)
Start-Sleep -Seconds 2
$c = New-Object W4+RECT
[void][W4]::GetClientRect($h, [ref]$c)
$p = New-Object W4+POINT
[void][W4]::ClientToScreen($h, [ref]$p)
$w = $c.Right - $c.Left; $hh = $c.Bottom - $c.Top
function Shot($name) {
  $bmp = New-Object System.Drawing.Bitmap $w, $hh
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.CopyFromScreen($p.X, $p.Y, 0, 0, (New-Object System.Drawing.Size $w, $hh))
  $out = 'E:\Study\github program\imoto life\work\out\' + $name + '.png'
  $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
  $g.Dispose(); $bmp.Dispose()
  $h2 = (Get-FileHash $out).Hash.Substring(0,8)
  Write-Output ("shot " + $name + " " + $w + "x" + $hh + " hash=" + $h2)
}
Shot 'late_0'
[System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
Start-Sleep -Seconds 3
Shot 'late_1'
[System.Windows.Forms.SendKeys]::SendWait(' ')
Start-Sleep -Seconds 3
Shot 'late_2'
Start-Sleep -Seconds 6
Shot 'late_3'
try { Stop-Process -Id $proc.Id -Force } catch {}
Write-Output 'done'
