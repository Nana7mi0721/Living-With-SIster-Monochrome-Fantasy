# -*- coding: utf-8 -*-
import json, sys, io, struct, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Load the audit dump, but also re-parse for teleports and graphics
src = open('work/_map_audit.py', encoding='utf-8').read()
d = json.load(open('work/_map_audit.json', encoding='utf-8'))

REGISTERED = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps']
CONTROL = ['SampleMapB.mps']

def cmp(c, val):
    op = c['op']; v = c['value']
    if op == 0: return val > v
    if op == 1: return val >= v
    if op == 2: return val == v
    if op == 3: return val <= v
    if op == 4: return val < v
    if op == 5: return val != v
    return False

def met(page, getv):
    for c in page['conds']:
        if c['enabled'] and not cmp(c, getv(c['var'])):
            return False
    return True

def active(event, getv):
    for i in range(len(event['pages'])-1, -1, -1):
        if met(event['pages'][i], getv):
            return i
    return None

print('=== REGISTERED MAP SHAPES ===')
for f in REGISTERED + CONTROL:
    m = d[f]
    pages = [p for e in m['events'] for p in e['pages']]
    print('%-16s %3dx%-3d ts=%d tiles=%-3s ev=%2d pages=%3d cmds=%5d reg=%s' % (
        f, m['w'], m['h'], m['tileset'], 'NO' if m['no_tiles'] else 'YES',
        len(m['events']), len(pages), sum(p['cmds'] for p in pages),
        'YES' if f in REGISTERED else 'control'))

print()
print('=== FRESH VM (all vars 0): active page per event ===')
for f in REGISTERED + CONTROL:
    m = d[f]
    zero = lambda var: 0
    on = []
    for e in m['events']:
        a = active(e, zero)
        if a is not None:
            on.append((e['id'], a, e['pages'][a]['trigger'], e['pages'][a]['cmds']))
    print('%-16s %d active:' % (f, len(on)), on)

print()
print('=== 130 teleports (map pages) ===')
te = []
for f, m in d.items():
    for e in m['events']:
        for p in e['pages']:
            for ci, c in enumerate(p['commands'] if 'commands' in p else []):
                pass
print('(need commands; see next probe)')
