# -*- coding: utf-8 -*-
"""Dump common event 42 (the M1 title screen) instruction by instruction.

Source: work/_ce_full.json, the raw parse of BasicData/CommonEvent.dat.
Output: work/_ev42_dump.txt
"""
import json
import io

d = json.load(open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in d}
e = by_id[42]
lines = []
lines.append('id=%d title=%s run=%d op=%d slots=%d'
             % (e['id'], e['title'], e['run'], e['op'], len(e['cmds'])))
for i, c in enumerate(e['cmds']):
    lines.append('%3d c=%4d a=%s s=%s bd=%d' % (i, c['c'], c['a'], c['s'], c['bd']))
io.open('work/_ev42_dump.txt', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
print('lines', len(lines))
