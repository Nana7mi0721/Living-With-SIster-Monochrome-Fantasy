import io, os
path = "crates/wolf-cli/src/main.rs"
t = io.open(path, encoding="utf-8", newline="").read()
start = t.index("    // The engine draws 101 message text itself")
end = t.index("    renderer.draw_text(&items);", start)
new = """    // The engine draws 101 message text itself: the frame comes from common event 63 as
    // ordinary pictures, the glyphs come from here. Only the newest message is visible,
    // which is the order the interpreter produces.
    if let Some(layout) = game.message_layout() {
        let message = game.messages.last().expect("layout implies a message");
        let preview: String = message.text.chars().take(60).collect();
        let typing = if layout.typing { ", typing" } else { "" };
        let cursor = layout.cursor.map_or(String::new(), |at| {
            format!(", cursor at [{:.0},{:.0}]", at[0], at[1])
        });
        println!(
            "  message   : {} row(s), {}/{} char(s), font {:.0} at [{:.0},{:.0}], wrap {:.0}{}{}",
            layout.rows.len(),
            layout.typed,
            layout.total,
            layout.font_px,
            layout.rows.first().map_or(0.0, |row| row.rect[0]),
            layout.rows.first().map_or(0.0, |row| row.rect[1]),
            layout.rows.first().map_or(0.0, |row| row.rect[2]),
            typing,
            cursor
        );
        println!("    text    : {preview:?}");
        for run in &layout.runs {
            let mut item = TextItem::new(run.text.clone(), run.rect, run.font_px)
                .with_colour(run.colour.unwrap_or(wolf_game::message::DEFAULT_COLOUR));
            if run.outline {
                item = item.with_outline(2, [0, 0, 0]);
            }
            items.push(item);
        }
    }
"""
t = t[:start] + new + t[end:]
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")