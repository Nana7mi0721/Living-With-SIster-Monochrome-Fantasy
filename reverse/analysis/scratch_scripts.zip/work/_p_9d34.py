import io, os
Q = chr(39)

def read(path):
    with io.open(path, encoding="utf-8", newline="") as fh:
        return fh.read()

def write(path, text):
    tmp = path + ".new"
    with io.open(tmp, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)
    os.replace(tmp, path)

def sub(text, a, b):
    assert a in text, "anchor missing: " + a[:70]
    assert text.count(a) == 1, "anchor not unique: " + a[:70]
    return text.replace(a, b)

p = "crates/wolf-game/src/game.rs"
t = read(p)

t = sub(t,
    "use wolf_format::commonevent::CommonEventData;\nuse wolf_format::mps::Map;",
    "use wolf_format::commonevent::CommonEventData;\nuse wolf_format::gamedat::GameDat;\nuse wolf_format::mps::Map;")

t = sub(t, "ChoiceReply, DbOp, Host, LogLevel,", "ChoiceReply, DbOp, DbValue, Host, LogLevel,")

t = sub(t,
    "use crate::assets::Assets;\nuse crate::map_runtime::MapRuntime;",
    "use crate::assets::Assets;\nuse crate::db::Databases;\nuse crate::map_runtime::MapRuntime;")

t = sub(t,
    "    /// Decoded assets, cached by WOLF asset name.\n    pub assets: Assets,",
    "    /// Decoded assets, cached by WOLF asset name.\n"
    "    pub assets: Assets,\n"
    "    /// The three .dat databases plus the cells the engine fills in itself\n"
    "    /// (see [`crate::db`]). Opcode 250 answers every read from here.\n"
    "    pub databases: Databases,")

t = sub(t,
    "        let events = read_events(&basic.join("CommonEvent.dat"))?;\n"
    "        let programs = ProgramSet::from_common_events(&events);\n"
    "        Ok(Self {\n"
    "            vm: Vm::new(programs),\n"
    "            screen: Screen::new(),\n"
    "            assets: Assets::new(&root),",
    "        let events = read_events(&basic.join("CommonEvent.dat"))?;\n"
    "        let programs = ProgramSet::from_common_events(&events);\n"
    "        // Common event 63 multiplies every message-window measurement by the\n"
    "        // coordinate scale, which is the tile size; Game.dat is the only place\n"
    "        // that value lives (docs/FORMAT_SPEC.md section 2.4).\n"
    "        let tile_size = std::fs::read(root.join("Game.dat"))\n"
    "            .or_else(|_| std::fs::read(basic.join("Game.dat")))\n"
    "            .ok()\n"
    "            .and_then(|bytes| GameDat::parse(&bytes).ok())\n"
    "            .map_or(crate::db::DEFAULT_TILE_SIZE, |dat| dat.tile_size());\n"
    "        let databases = Databases::load(&basic, tile_size);\n"
    "        Ok(Self {\n"
    "            vm: Vm::new(programs),\n"
    "            screen: Screen::new(),\n"
    "            assets: Assets::new(&root),\n"
    "            databases,")

t = sub(t,
    "struct GameHost<" + Q + "a> {\n    screen: &" + Q + "a mut Screen,\n    assets: &" + Q + "a mut Assets,",
    "struct GameHost<" + Q + "a> {\n"
    "    screen: &" + Q + "a mut Screen,\n"
    "    assets: &" + Q + "a mut Assets,\n"
    "    databases: &" + Q + "a mut crate::db::Databases,")

t = sub(t,
    "            screen: &mut self.screen,\n            assets: &mut self.assets,",
    "            screen: &mut self.screen,\n            assets: &mut self.assets,\n            databases: &mut self.databases,")

t = sub(t,
    "    fn database(&mut self, op: &DbOp) {\n        let _ = op;\n        self.stats.databases += 1;\n    }",
    "    fn database(&mut self, op: &DbOp) -> Option<DbValue> {\n"
    "        self.stats.databases += 1;\n"
    "        let (db_type, row, column) = (op.db_type, op.data_id, op.item_id);\n"
    "        if let Some(value) = self.databases.num(db_type, row, column) {\n"
    "            return Some(DbValue::Num(value));\n"
    "        }\n"
    "        if let Some(text) = self.databases.text(db_type, row, column) {\n"
    "            return Some(DbValue::Str(text.to_owned()));\n"
    "        }\n"
    "        self.note(format!(\n"
    "            \"250 DatabaseAccess: ({db_type}, {row}, {column}) flags {:#x} unanswered\",\n"
    "            op.flags\n"
    "        ));\n"
    "        None\n"
    "    }")

write(p, t)
print("game.rs patched")