
import io,sys,json,struct,os
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
ROOT=r'E:\Study\github program\imoto life'
CE=json.load(open(os.path.join(ROOT,'work','_ce_full.json'),encoding='utf-8'))
ev={e['id']:e for e in CE}
e63=ev[63]
print('CE63 title=',e63['title'])
for pc in range(20,30):
    c=e63['cmds'][pc]
    print(' pc%-4d c=%-4d a=%s s=%s'%(pc,c['c'],c['a'],c['s']))

# 1) raw bytes proof
raw=open(os.path.join(ROOT,'work','full','BasicData','CommonEvent.dat'),'rb').read()
pat=struct.pack('<B',6)+struct.pack('<I',250)+struct.pack('<ii',18,0)+struct.pack('<i',24)+struct.pack('<i',0x51200)+struct.pack('<i',1600009)
print('\npattern len',len(pat),pat.hex())
idx=[]; st=0
while True:
    k=raw.find(pat,st)
    if k<0: break
    idx.append(k); st=k+1
print('occurrences:',[hex(x) for x in idx])
for k in idx[:3]:
    seg=raw[k:k+40]
    print(' off 0x%08X'%k, ' '.join('%02x'%b for b in seg))

# 2) every 250 site with arg0==18 and bits89==2
def sites():
    for e in CE:
        for ci,c in enumerate(e['cmds']):
            if c['c']==250: yield ('CE%d'%e['id'],ci,c['a'],c['s'],e['title'])
    mp=json.load(open(os.path.join(ROOT,'work','maps_full.json'),encoding='utf-8'))
    for mk,m in mp.items():
        for evt in m['events']:
            for ci,c in enumerate(evt['cmds']):
                if c['code']==250: yield ('%s/e%d'%(mk,evt['id']),ci,c['ints'],c['strs'],'')
tot=0; a18=[]; 
for tag,ci,a,s,t in sites():
    tot+=1
    if len(a)<4: continue
    if ((a[3]>>8)&3)!=2: continue
    if a[0]!=18: continue
    a18.append((tag,ci,a,s))
print('\ntotal 250 sites',tot,'  arg0==18 & bits89==2 :',len(a18))
from collections import Counter
print(' their arg2 histogram:',dict(sorted(Counter(x[2][2] for x in a18).items())))
c22=[x for x in a18 if x[2][2]==22]
print('\n sites with arg2==22 (n=%d):'%len(c22))
for tag,ci,a,s in c22[:20]:
    print('  ',tag,'pc',ci,'a=',a,'s=',s)
print('\n sites whose label mentions ウィンドウ (n):')
w=[x for x in a18 if any('ウィンドウ' in y for y in x[3])]
print('  ',len(w))
for tag,ci,a,s in w[:15]:
    print('  ',tag,'pc',ci,'a=',a,'s=',s)
