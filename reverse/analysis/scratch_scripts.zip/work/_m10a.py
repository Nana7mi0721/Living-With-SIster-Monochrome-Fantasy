import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
def asc(ss):
    return [ (s.encode('ascii','ignore').decode() if isinstance(s,str) else s) for s in ss]
def dump(cid, maxn=10000):
    e=by.get(cid)
    if not e: print('MISSING',cid); return
    print(f"### CE{cid} run={e.get('run')} op={e.get('op')} condvar={e.get('condvar')} condval={e.get('condval')} title={e.get('title','')!r} ncmds={len(e['cmds'])}")
    for i,cm in enumerate(e['cmds'][:maxn]):
        c=cm['c']; a=cm.get('a',[]); s=asc(cm.get('s',[]))
        extra=(' '+str(s)) if s else ''
        print(f"{i:>4} op{c} {a}{extra}")
    if len(e['cmds'])>maxn: print(f"... ({len(e['cmds'])} cmds)")
for cid in [172]:
    dump(cid); print()

