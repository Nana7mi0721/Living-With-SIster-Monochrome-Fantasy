import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """        save.set_part5(&part5)
            .map_err(|err| format!("220 SaveLoad: cannot encode part5: {err}"))?;

        let bytes = save"""
b = """        save.set_part5(&part5)
            .map_err(|err| format!("220 SaveLoad: cannot encode part5: {err}"))?;

        // Runtime 250 writes live in the database layer, not in the interpreter banks, so
        // they have to be folded into the save variable database before the file is built.
        let (written, missed) = self.databases.write_into(&mut save.vardb);
        if missed > 0 {
            let text = format!(
                "220 SaveLoad: {written} database cell(s) written, {missed} cell(s) could not be encoded"
            );
            *self.diagnostics.entry(text).or_insert(0) += 1;
            self.stats.unmodelled += 1;
        }

        let bytes = save"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")