
import json,io,os,collections
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
live=set(fin['live']); sizes=fin['sizes']
IMG={'.png','.jpg','.jpeg','.bmp','.webp','.gif'}
def ext(p): return os.path.splitext(p)[1].lower()
per=collections.defaultdict(lambda:[0,0,0])  # files,bytes,px
overs=[]
for p in live:
    if ext(p) not in IMG: continue
    d=p.split('/')[0]
    with Image.open(os.path.join('work/all',p)) as im:
        w,h=im.size
    per[d][0]+=1; per[d][1]+=sizes[p]; per[d][2]+=w*h
    if w>2048 or h>2048: overs.append((max(w,h),w,h,p))
W('%-20s %5s %12s %14s %8s'%('dir','imgs','bytes','pixels','2048 sheets'))
for d,(n,b,px) in sorted(per.items(),key=lambda kv:-kv[1][2]):
    W('%-20s %5d %12d %14d %8.1f'%(d,n,b,px,px/4194304))
W('\nimages with a side > 2048: %d'%len(overs))
for mx,w,h,p in sorted(overs,reverse=True)[:12]: W('  %5dx%-5d %s'%(w,h,p))
W('\ntotal overs px: %d'%sum(w*h for _,w,h,_ in overs))
open('work/_audit_out21.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
