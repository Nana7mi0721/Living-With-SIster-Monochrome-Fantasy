
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ma=json.load(open('work/_map_audit.json',encoding='utf-8'))
ev1=[e for e in ma['SampleMapA.mps']['events'] if e['id']==1][0]
p=ev1['pages'][2]
print('page keys:',list(p.keys()))
print(json.dumps(p,ensure_ascii=False)[:900])
