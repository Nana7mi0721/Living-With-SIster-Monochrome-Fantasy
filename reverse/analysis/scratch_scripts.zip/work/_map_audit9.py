# -*- coding: utf-8 -*-
import sys, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
d = json.load(open('work/_map_audit_data.json',encoding='utf-8'))
OPN={0:'>',1:'>=',2:'==',3:'<=',4:'<',5:'!=',6:'&'}
TRIG={0:'confirm',1:'autorun',2:'parallel',3:'touch'}
def cs2str(cs):
    if not cs: return '-'
    return ' '.join('%s%s%s' % (c['var_name'],OPN[c['op']],c['value']) for c in cs)
print('=== per-event table (registered maps + control) ===')
for f in ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps','SampleMapB.mps']:
    m=d['maps'][f]
    print()
    print('## %s  %dx%d tileset=%d tiles=%d layers=%d events=%d slots=%d title=%r' % (f,m['w'],m['h'],m['tileset'],m['has_tiles'],m['layers'],len(m['events']),m['slots'],m['title']))
    for e in m['events']:
        print('  ev%-3d %-28r (%d,%d) pages=%d live=%s dead=%s fresh=%s' % (e['id'],e['name'],e['x'],e['y'],len(e['pages']),e['live'],e['dead'],e['fresh']))
        for p in e['pages']:
            print('        p%-2d trig=%-8s conds=%-40s cmds=%-5d%s' % (p['page'],TRIG[p['trigger']],cs2str(p['conds']),p['cmds'],'  <-fresh' if p['fresh'] else ''))
