import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """        assert_eq!(before, after);
    }

    #[test]
    fn a_missing_data_root_is_an_error_not_a_panic() {"""
b = """        assert_eq!(before, after);
    }

    #[test]
    fn a_saved_game_keeps_the_database_cells() {
        let Some(root) = have_data() else { return };
        let mut template = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        template.pop();
        template.pop();
        template.push("work");
        template.push("retail_backup");
        template.push("Save");
        template.push("SaveData01.sav");
        let Ok(bytes) = std::fs::read(&template) else { return };
        let mut game = Game::new(&root).expect("game");
        game.base_save = Some(wolf_save::SaveFile::parse(&bytes).expect("template parses"));
        game.load_save(&template).expect("load");
        game.databases.set_num(crate::db::Container::CData, 0, 12, 0, 4242);

        let mut out = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        out.push("..");
        out.push("..");
        out.push("target");
        out.push("test-scratch");
        std::fs::create_dir_all(&out).expect("scratch dir");
        out.push("savegame-database.sav");
        game.save_to(&out).expect("save");

        let mut refreshed = Game::new(&root).expect("game");
        refreshed.load_save(&out).expect("reload");
        assert_eq!(
            refreshed.databases.num(crate::db::Container::CData, 0, 12, 0),
            Some(4242)
        );
    }

    #[test]
    fn a_missing_data_root_is_an_error_not_a_panic() {"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")