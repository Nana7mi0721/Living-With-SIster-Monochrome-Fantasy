import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={x['id']:x for x in ce}
def vname(v):
    if 2000000<=v<3000000: return 'v%d'%(v-2000000)
    if 1000000<=v<2000000: return 'self%d'%(v-1000000)
    return str(v)
def condof(a):
    n=a[0]&0xF; cs=[]
    for i in range(n):
        cs.append(vname(a[1+i*3])+{1:'>=',2:'==',3:'<=',5:'!='}.get(a[3+i*3],'op'+str(a[3+i*3]))+str(a[2+i*3]))
    return '['+','.join(cs)+']'
nm={111:'IF',401:'CASE',420:'ELSE',499:'END',102:'CHOICE',421:'CANCEL',172:'BREAK',210:'CALL',211:'CALLEX',121:'SET',122:'LABEL',212:'SUB212',213:'SUB213',103:'TEXT',0:'NOP'}
cmds=by[328]['cmds']
print('CE328 total cmds',len(cmds))
for pc in range(680,min(1035,len(cmds))):
    c=cmds[pc]; op=c['c']; a=c['a']; s=c['s']
    name=nm.get(op,str(op))
    ex=''
    if op==111: ex=condof(a)
    elif op in (121,124,210,211): ex=str(a)
    elif op==401: ex='case'+str(a[0]) if a else ''
    elif op==102: ex='n=%d'%(a[0] if a else -1)
    elif op in (212,213): ex=str(a)+(' '+repr(s[0])[:40] if s else '')
    elif s: ex=repr(s[0])[:50]
    print('pc%-4d %-6s %s'%(pc,name,ex))
