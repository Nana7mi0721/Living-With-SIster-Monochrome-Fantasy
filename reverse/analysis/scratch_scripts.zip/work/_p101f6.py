
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
ids={}
for e in ce: ids.setdefault(e['id'],0); ids[e['id']]+=1
print('num events',len(ce),'min id',min(ids),'dups',[k for k,v in ids.items() if v>1][:5])
for e in ce[:3]:
    print('id',e['id'],'title',repr(e['title']),'ncmds',len(e['cmds']))
for e in ce:
    if e['id'] in (0,1,63,550):
        print('--- id',e['id'],repr(e['title']),'ncmds',len(e['cmds']),'run',e.get('run'))
print('ids 0..3 present:',[e['id'] for e in ce if e['id']<4])
print('max id',max(ids))
