import io, os
path = "crates/wolf-vm/src/exec.rs"
t = io.open(path, encoding="utf-8", newline="").read()
def rep(a,b):
    global t
    assert t.count(a) == 1, (a, t.count(a))
    t = t.replace(a,b)

rep("""    fn key_code(&mut self, mask: u32) -> i32 {
        let _ = mask;
        0
    }
""", """    fn key_code(&mut self, mask: u32) -> i32 {
        let _ = mask;
        0
    }

    /// Like [`Host::key_code`], with the key bits opcode 125 asked the engine to
    /// press even when the player is not touching the keyboard.
    ///
    /// The interpreter passes its current `InputState::auto_keys` here on every
    /// 123 poll. A host that owns a real keyboard can OR the bits into its held-key
    /// state; the default ignores them, which keeps every headless host unchanged.
    fn key_code_auto(&mut self, mask: u32, auto: u32) -> i32 {
        let _ = auto;
        self.key_code(mask)
    }
""")

rep("""                // A key the script banned with 126 must read as not pressed.
                let mask = arg(cmd, 1) as u32 & !input.ban_keys;
                store_num(inst, vars, target, host.key_code(mask));
""", """                // A key the script banned with 126 must read as not pressed; a key
                // it asked for with 125 is handed to the host, which owns the keyboard.
                let mask = arg(cmd, 1) as u32 & !input.ban_keys;
                store_num(inst, vars, target, host.key_code_auto(mask, input.auto_keys));
""")

rep("""/// Banning is applied by the interpreter itself: the banned bits are cleared out
/// of the mask handed to the host, so a banned key reads as not pressed. Auto
/// input is only stored - forcing a key press needs the host, which owns the
/// real keyboard, so a host that wants the feature reads this field. No M1/M2
/// acceptance path calls 125; 126 does appear in the opening script (it bans
/// every key for the cutscene).
""", """/// Banning is applied by the interpreter itself: the banned bits are cleared out
/// of the mask handed to the host, so a banned key reads as not pressed. Auto
/// input is passed to the host on every 123 poll through `Host::key_code_auto`;
/// a host that owns a real keyboard ORs it into the held-key state, while a
/// headless host keeps its default "nobody is touching the keyboard". 126 appears
/// in the opening script (it bans every key for the cutscene); 125 is polled by the
/// UI cursor events in the real game.
""")

rep("""        // Every 290 effect the interpreter decoded: (type, duration, evaluated args).
        effects: Vec<(i32, i32, Vec<i32>)>,
    }
""", """        // Every 290 effect the interpreter decoded: (type, duration, evaluated args).
        effects: Vec<(i32, i32, Vec<i32>)>,
        // Every 123 poll the host answered: (mask, auto-input bits).
        key_polls: Vec<(u32, u32)>,
    }
""")

rep("""        fn effect(&mut self, kind: i32, duration: i32, args: &[i32]) {
            self.effects.push((kind, duration, args.to_vec()));
        }
""", """        fn effect(&mut self, kind: i32, duration: i32, args: &[i32]) {
            self.effects.push((kind, duration, args.to_vec()));
        }
        fn key_code_auto(&mut self, mask: u32, auto: u32) -> i32 {
            self.key_polls.push((mask, auto));
            0
        }
""")

rep("""    #[test]
    fn a_dismissed_message_is_closed_on_the_host() {
""", """    #[test]
    fn auto_input_reaches_the_host_with_the_poll_mask() {
        // 125 remembers the key bits the script wants pressed; the next 123 must
        // carry them to the host, not just leave them in the interpreter.
        let ev = event(
            5,
            "auto input",
            vec![
                cmd(125, &[16], &[]),
                cmd(123, &[2_000_000, 247], &[]),
                cmd(125, &[0], &[]),
                cmd(123, &[2_000_001, 247], &[]),
            ],
        );
        let mut vm = vm_with(vec![ev]);
        vm.start_event(5).unwrap();
        let mut host = Recorder::default();
        vm.step_frame(&mut host);
        assert_eq!(host.key_polls, vec![(247, 16), (247, 0)]);
    }

    #[test]
    fn a_dismissed_message_is_closed_on_the_host() {
""")

io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("patched")
