
import json,io,sys,struct
sys.stdout.reconfigure(encoding='utf-8')
def png(p):
    d=open(p,'rb').read(33)
    w,h=struct.unpack('>II',d[16:24]); return w,h
for p in ('work/all/SystemFile/Text_Pause.png','work/all/SystemFile/WindowBase.png','work/all/SystemFile/CursorBase.png','work/all/SystemFile/Button01.png'):
    print(p, png(p))
d=json.load(io.open('work/wolftl/dump/db/CDataBase.json',encoding='utf-8'))
T=d['types']
print('CDataBase types:',len(T))
for i,t in enumerate(T):
    print(i, repr(t.get('name')), 'rows',len(t.get('data',[])), 'fields',[f.get('name') for f in (t.get('fields') or [])][:30])
