# -*- coding: utf-8 -*-
import json, sys, io, itertools
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BT = chr(96)
d = json.load(open('work/_map_audit_data.json', encoding='utf-8'))
REG = ['TitleMap.mps', 'SampleMapA.mps', 'SampleMapA_1.mps', 'Map003.mps', 'Map024.mps', 'Map031.mps']
CTL = ['SampleMapB.mps']
TRIG = {0: 'confirm', 1: 'autorun', 2: 'parallel', 3: 'touch'}
OPN = {0: '>', 1: '>=', 2: '==', 3: '<=', 4: '<', 5: '!=', 6: '&'}
for f in REG + CTL:
    m = d['maps'][f]
    multi = [e for e in m['events'] if len(e['pages']) > 1]
    print(f, 'events', len(m['events']), 'pages', sum(len(e['pages']) for e in m['events']), 'multi', len(multi))
print()
print('=== boot-active table rows ===')
for f in REG + CTL + ['Dungeon.mps', 'Map002.mps']:
    m = d['maps'][f]
    rows = []
    for e in m['events']:
        for p in e['pages']:
            if p['fresh']:
                conds = ' '.join('%s%s%s' % (c['var_name'], OPN[c['op']], c['value']) for c in p['conds']) or '-'
                rows.append((e['id'], e['name'], p['page'], TRIG[p['trigger']], p['cmds'], conds))
    print(f, len(rows))
    for r in rows:
        print('  | %d | %s | %d | %s | %d | %s |' % r)
