import io, os
def patch(path, pairs):
    t = io.open(path, encoding="utf-8", newline="").read()
    for a, b in pairs:
        assert t.count(a) == 1, (path, a, t.count(a))
        t = t.replace(a, b)
    io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
    os.replace(path + ".new", path)

patch("crates/wolf-vm/src/exec.rs", [
("""                let (face, text) = split_face(&expanded);
                host.show_message(text, face);""",
"""                let (face, text) = split_face(&expanded);
                // `@n` is the per-message face override; the message-window coroutine
                // (common event 63) reads Sys0 to pick the face picture, so publish it
                // before the host sees the text (docs/OPCODE_101.md section 4.2).
                if let Some(face) = face {
                    vars.set_sys(0, face);
                }
                host.show_message(text, face);"""),
("""        assert_eq!(host.messages, vec!["hello".to_owned()]);
        assert_eq!(host.faces, vec![Some(2)]);
        assert_eq!(vm.vars.get(0), 0);""",
"""        assert_eq!(host.messages, vec!["hello".to_owned()]);
        assert_eq!(host.faces, vec![Some(2)]);
        assert_eq!(vm.vars.get_sys(0), 2, "`@2` must reach Sys0 for the frame painter");
        assert_eq!(vm.vars.get(0), 0);"""),
])
print("patched")