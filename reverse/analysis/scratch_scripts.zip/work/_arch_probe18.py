# -*- coding: utf-8 -*-
import struct, os, zlib
G = r"E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy"
D = os.path.join(G, "Data")
p = os.path.join(D, "word.wolf")
f = open(p, "rb")
head = f.read(48)
Head, Ver, HeadSize, DataStart, NameTbl, FileTbl, DirTbl, CodePage = struct.unpack("<HHIQQQQQ", head)
print("Head=%04x Ver=%d HeadSize=0x%x DataStart=0x%x Name=0x%x File=0x%x Dir=0x%x CodePage=0x%x" % (Head,Ver,HeadSize,DataStart,NameTbl,FileTbl,DirTbl,CodePage))
# directory table
f.seek(DirTbl)
d0 = f.read(32)
dirAddr, parent, fhNum, fhAddr = struct.unpack("<QQQQ", d0)
print("root dir: dirAddr=%d parent=%d fhNum=%d fhAddr=%d" % (dirAddr,parent,fhNum,fhAddr))
f.seek(FileTbl)
fh = f.read(64)
nameAddr, attr, ct, la, lw, dataAddr, dataSize, press = struct.unpack("<QQQQQQQQ", fh)
print("filehead0: nameAddr=%d attr=%d dataAddr=%d dataSize=%d press=0x%x" % (nameAddr,attr,dataAddr,dataSize,press))
# filename is a length-prefixed bitmap-string; try reading raw at NameTbl+nameAddr
f.seek(NameTbl + nameAddr)
raw = f.read(24)
print("raw name bytes:", raw[:24])
