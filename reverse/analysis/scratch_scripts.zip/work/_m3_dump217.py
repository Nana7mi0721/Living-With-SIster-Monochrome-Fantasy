import json, io
ce = json.load(open("work/_ce_full.json", encoding="utf-8"))
d = {e["id"]: e for e in ce}
out = io.open("work/_m3_ev217.txt", "w", encoding="utf-8")
e = d[217]
out.write("### ev217 %s run=%s op=%s\n" % (e["title"], e["run"], e["op"]))
for i, c in enumerate(e["cmds"]):
    if c["c"] == 0:
        continue
    out.write("pc%-4d bd=%s c=%s a=%s s=%s\n" % (i, c["bd"], c["c"], c["a"], c["s"]))
out.close()
print("wrote work/_m3_ev217.txt")

# who reads 2000008?
hits = []
for e in ce:
    for i, c in enumerate(e["cmds"]):
        if 2000008 in c["a"] or 2000008 in [x for x in c["a"]]:
            hits.append((e["id"], e["title"], i, c["c"], c["a"]))
print("### readers of 2000008:", len(hits))
for h in hits:
    print(h)
