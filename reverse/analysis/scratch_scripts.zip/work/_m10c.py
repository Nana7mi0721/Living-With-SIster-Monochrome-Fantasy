import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
def a1(s): return (s.encode('ascii','ignore').decode() if isinstance(s,str) else s)
def dump(cid, only=None, maxn=100000):
    e=by.get(cid)
    if not e: print('MISSING',cid); return
    print(f"### CE{cid} title={e.get('title','')!r} ncmds={len(e['cmds'])}")
    for i,cm in enumerate(e['cmds']):
        c=cm['c']; a=cm.get('a',[])
        if only and c not in only: continue
        s=[a1(x) for x in cm.get('s',[]) if x]
        print(f"{i:>4} op{c} {a}{(' '+str(s)) if s else ''}")
        if i>=maxn: print('...'); break
for cid in [144,147,372]:
    dump(cid, only={250,121,124,111,210,172,179,300}); print()
print('===== var14 (2000014) writers =====')
for e in ces:
    for i,cm in enumerate(e['cmds']):
        c=cm['c']; a=cm.get('a',[])
        if c in (121,124) and a and a[0]==2000014:
            print(f"CE{e['id']} pc{i} op{c} {a} {[a1(x) for x in cm.get('s',[]) if x]}")
print('===== var218 (2000218) writers/readers 111 =====')
for e in ces:
    for i,cm in enumerate(e['cmds']):
        c=cm['c']; a=cm.get('a',[])
        if c in (121,124) and a and a[0]==2000218:
            print(f"CE{e['id']} pc{i} op{c} {a} {[a1(x) for x in cm.get('s',[]) if x]}")
        if c==111 and 2000218 in a:
            print(f"CE{e['id']} pc{i} op111 {a}")

