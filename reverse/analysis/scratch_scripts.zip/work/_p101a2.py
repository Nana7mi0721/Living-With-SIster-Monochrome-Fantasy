
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(io.open('work/wolftl/dump/db/SysDatabase.json',encoding='utf-8'))
T=d['types']
t=T[12]
for i,row in enumerate(t['data']):
    if i<18: continue
    v={x['name']:x['value'] for x in row['data']}
    print('  %2d %-26s R=%s G=%s B=%s'%(i,row.get('name'),v.get('赤(0-255)'),v.get('緑(0-255)'),v.get('青(0-255)')))
print('--- type 24 rows 0..5')
t24=T[24]
for i,row in enumerate(t24['data'][:6]): print('  %2d %-24s %s'%(i,row.get('name'),json.dumps(row.get('data'),ensure_ascii=False)))
print('--- type 18 (座標倍率) rows 0..8')
t18=T[18]
print('fields=',json.dumps(t18['fields'],ensure_ascii=False),'rows=',len(t18['data']))
for i,row in enumerate(t18['data'][:9]): print('  %2d %-16s %s'%(i,row.get('name'),json.dumps(row.get('data'),ensure_ascii=False)[:100]))
print('--- type 16 (ウィンドウ画像)')
t16=T[16]
print('fields=',json.dumps(t16['fields'],ensure_ascii=False),'rows=',len(t16['data']))
for i,row in enumerate(t16['data'][:6]): print('  %2d %-24s %s'%(i,row.get('name'),json.dumps(row.get('data'),ensure_ascii=False)[:110]))
print('--- type 17 (顔グラフィック) fields/rows')
t17=T[17]
print('fields=',json.dumps(t17['fields'],ensure_ascii=False),'rows=',len(t17['data']))
for i,row in enumerate(t17['data'][:4]): print('  %2d %-20s %s'%(i,row.get('name'),json.dumps(row.get('data'),ensure_ascii=False)[:100]))
