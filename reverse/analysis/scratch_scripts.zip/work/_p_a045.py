p = "docs/M2_SLICE.md"
raw = open(p, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13)+chr(10), chr(10))
a = "| git HEAD | `dc85636`（styled 101 message `layout_styled` / SavePart5 图片表写回 / vardb `write_into` 接线 / 220 mode 0 整档保存） |"
b = "| git HEAD | `ba761be`（`130` 地图传送与标题→新游戏链；此前 `dc85636` 为 styled 101 message / SavePart5 图片表写回 / vardb `write_into` / 220 mode 0） |"
assert t.count(a) == 1
t = t.replace(a, b)
if crlf: t = t.replace(chr(10), chr(13)+chr(10))
open(p, "wb").write(t.encode("utf-8"))
print("ok")