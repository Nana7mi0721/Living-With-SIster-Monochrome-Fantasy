from pathlib import Path
p = Path("crates/wolf-game/src/db.rs")
lines = p.read_text(encoding="utf-8").splitlines(keepends=True)
# 1-based 430..446 -> 0-based 429..445; move the helper block before the cell_address doc.
helper = lines[433:446]
doc = lines[429:433]
blank = ["\n"]
out = lines[:429] + helper + blank + doc + lines[446:]
p.write_text("".join(out), encoding="utf-8", newline="")
print("moved")
