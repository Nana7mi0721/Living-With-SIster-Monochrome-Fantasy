
import json,collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
# pair openers to closers by exact bd match, using a stack per event
OPEN={111:'cond',102:'choice',179:'looptimes',170:'loop',176:'loop2'}
CLOSE={499,498}
unmatched=collections.Counter(); strays=collections.Counter(); pairs=0; bad=0
tid=collections.Counter()
for ev in d:
    cm=ev['cmds']
    stack=[]  # (bd, idx, op)
    for i,c in enumerate(cm):
        o=c['c']; b=c['bd']
        if o in OPEN:
            stack.append((b,i,o))
        elif o in CLOSE:
            # find top of stack with same bd
            if stack and stack[-1][0]==b:
                ob,oi,oo=stack.pop(); pairs+=1; tid[(oo,o)]+=1
            else:
                strays[(o,b)]+=1
    for b,i,o in stack: unmatched[(o,b)]+=1
print('pairs',pairs,'pair kinds',dict(tid))
print('strays(closer without opener at same bd)',dict(strays))
print('unmatched openers',dict(unmatched))
