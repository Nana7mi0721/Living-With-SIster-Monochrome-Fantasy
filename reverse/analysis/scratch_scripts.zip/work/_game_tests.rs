#[cfg(test)]
mod tests {
    use super::*;
    use crate::key;

    fn data_root() -> PathBuf {
        if let Ok(value) = std::env::var("WOLF_DATA_ROOT") {
            if !value.is_empty() {
                return PathBuf::from(value);
            }
        }
        let mut path = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        path.pop();
        path.pop();
        path.push("work");
        path.push("full");
        path
    }

    fn have_data() -> Option<PathBuf> {
        let root = data_root();
        if root.join("BasicData").join("CommonEvent.dat").is_file() {
            Some(root)
        } else {
            eprintln!("skipping: no game data at {}", root.display());
            None
        }
    }

    #[test]
    fn a_missing_data_root_is_an_error_not_a_panic() {
        let err = match Game::new("no-such-root") {
            Ok(_) => panic!("loading from a bogus root must fail"),
            Err(err) => err,
        };
        assert!(matches!(err, GameError::Io { .. }), "unexpected: {err}");
    }

    #[test]
    fn the_title_event_parks_on_its_menu_after_one_graphic() {
        let Some(root) = have_data() else { return };
        let mut game = Game::new(&root).expect("game");
        game.start_title().expect("title event");
        let mut peak = 0usize;
        let mut last = FrameOutcome::default();
        for _ in 0..200 {
            last = game.frame();
            peak = peak.max(last.report.running);
        }
        // The real title script: draw one full-screen graphic, start one BGM, open a
        // three-option prompt. Everything the old capture showed beyond that came from a
        // branch fall-through bug that reached the save/load screen chain.
        assert!(
            (30..=120).contains(&game.stats.instructions),
            "{} instruction(s)",
            game.stats.instructions
        );
        assert_eq!(peak, 1, "the title event is a single coroutine");
        assert!(game.choices.is_some(), "the title prompt should be open");
        assert_eq!(game.stats.pictures, 1);
        assert!(last.idle, "a parked title does no work");
        let pictures: Vec<_> = game.screen.iter().collect();
        assert_eq!(pictures.len(), 1);
        assert_eq!(pictures[0].number, -2, "the title layer is the whole screen");
        assert!(pictures[0].is_screen_layer());
        assert!(pictures[0].file.contains("TitleGraphic"));
        assert_eq!(
            game.stats.warnings, 0,
            "diagnostics: {:?}",
            game.diagnostics
        );
    }

    #[test]
    fn the_title_menu_advances_when_the_confirm_key_is_pressed() {
        let Some(root) = have_data() else { return };
        let mut game = Game::new(&root).expect("game");
        game.start_title().expect("title event");
        for _ in 0..30 {
            game.frame();
        }
        // With no keys held the script parks on its menu: a handful of instructions and
        // then nothing, which is what the original game does.
        let parked = game.stats.instructions;
        assert!(parked < 200, "the title should park quickly, ran {parked}");
        for _ in 0..30 {
            game.frame();
        }
        assert_eq!(
            game.stats.instructions, parked,
            "a parked title must not keep executing"
        );

        // A fresh confirm press has to wake it up and close the prompt.
        game.key_bits = key::OK;
        game.frame();
        game.key_bits = 0;
        for _ in 0..60 {
            game.frame();
        }
        assert!(
            game.stats.instructions > parked,
            "confirm did not advance the menu: {parked} -> {}",
            game.stats.instructions
        );
        assert!(game.choices.is_none(), "the prompt should be answered");
    }

    #[test]
    fn booting_reaches_the_title_art_and_confirm_opens_the_menu() {
        let Some(root) = have_data() else { return };
        let mut game = Game::new(&root).expect("game");
        if let Err(err) = game.boot() {
            eprintln!("skipping: {err}");
            return;
        }
        for _ in 0..800 {
            game.frame();
        }
        // Three splashes and then the real title art, which is a picture and not a common
        // event: the boot map event draws it before it calls event 42.
        let art = game
            .screen
            .iter()
            .find(|picture| picture.file.contains("title01"))
            .expect("the title art should be on screen");
        assert_eq!(art.number, 12000);
        assert_eq!((art.x, art.y), (0, 0));
        let banner = game
            .screen
            .iter()
            .find(|picture| picture.file.contains("Button01"))
            .expect("the hint banner should be on screen");
        assert_eq!(banner.anchor, ANCHOR_CENTRE, "head word 4096 centres it");
        assert_eq!((banner.x, banner.y), (512, 520));

        // One confirm press plays the door sound, erases the banner and enters the menu.
        game.key_bits = key::OK;
        game.frame();
        game.key_bits = 0;
        for _ in 0..240 {
            game.frame();
        }
        let choices = game
            .choices
            .as_ref()
            .expect("confirm should land on the title menu");
        assert_eq!(choices.options, ["1", "2", "3"]);
        assert!(
            game.screen
                .iter()
                .all(|picture| !picture.file.contains("Button01")),
            "the hint banner is erased on the way into the menu"
        );
    }
}
