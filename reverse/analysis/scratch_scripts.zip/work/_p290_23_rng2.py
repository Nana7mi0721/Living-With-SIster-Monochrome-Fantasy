
import zipfile, sys, io, json, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
ed = z.read('Editor.exe')

# find all literals containing 'ピクチャ' shorter than 20 chars
hits = []
i = 0
n = len(ed)
needle = 'ピクチャ'.encode('utf-16-le')
pos = 0
while True:
    pos = ed.find(needle, pos)
    if pos < 0: break
    hits.append(pos); pos += 2
print('### occurrences of ピクチャ =', len(hits))
seen = set()
for p in hits:
    # rewind to length prefix heuristically: try 0..24 bytes back
    for back in range(0, 40, 2):
        q = p - 2 - back
        if q < 0: continue
        L = int.from_bytes(ed[q:q+2], 'little')
        if L*2 == back + 8 or (L*2 == (back + 8)): pass
        try:
            s = ed[q+2:q+2+2*L].decode('utf-16-le')
        except Exception:
            continue
        if s.startswith('ピクチャ') or 'ピクチャ' in s:
            if len(s) <= 24 and q not in seen:
                seen.add(q); print('  0x%x  %s' % (q, s))
            break

ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
if isinstance(ce, dict): ce = list(ce.values())
maps = json.load(open('work/maps_full.json', encoding='utf-8'))
sites = []
for ev in ce:
    for i, c in enumerate(ev.get('cmds') or []):
        if c.get('c') == 290: sites.append(('CE%s' % ev.get('id'), i, c.get('a') or []))
for mk, mv in maps.items():
    for ev in mv.get('events') or []:
        for i, c in enumerate(ev.get('cmds') or []):
            if c.get('code') == 290: sites.append(('%s:ev%s' % (mk, ev.get('id')), i, c.get('ints') or []))

print()
print('### picA vs picB: distribution of arg3-arg2 per type (810 sites)')
by = collections.defaultdict(collections.Counter)
for (tag, pc, a) in sites:
    by[(a[0] >> 4) & 0xF][a[3] - a[2]] += 1
for t in sorted(by):
    print('  type %-2d  d=arg3-arg2 %s' % (t, dict(sorted(by[t].items()))))

print()
print('### examples where picA != picB (first 12 per type)')
shown = collections.Counter()
for (tag, pc, a) in sorted(sites):
    t = (a[0] >> 4) & 0xF
    if a[2] != a[3] and shown[t] < 12:
        shown[t] += 1
        print('  type %-2d %s pc%-5d a=%s' % (t, tag, pc, a))
