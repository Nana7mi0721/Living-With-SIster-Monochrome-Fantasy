
import json,io,glob,os,re,collections
OUT=io.StringIO()
PREF=['scene/','word/','hword/','EnemyGraphic/','Fog_BackGround/','MapData/','cg/','Picture/','CharaChip/','BattleEffect/','FIcon/','cutin/','hscene/','DLC_data/','1.4.0/','BGM/','SE/','SystemFile/','SystemGraphic/','MapChip/','Kagura/','BalloonBase_CafeLatte/']
cnt=collections.Counter(); samples=collections.defaultdict(list)
def scan(s,where,code):
    for p in PREF:
        if p.lower() in s.lower():
            cnt[p]+=1
            if len(samples[p])<6: samples[p].append((where,code,s[:80]))
for f in sorted(glob.glob('work/wolftl/dump/common/*.json')):
    j=json.load(open(f,encoding='utf-8'))
    for c in j['commands']:
        for s in c.get('stringArgs',[]):
            scan(s,'ev%d'%j['id'],c['code'])
for f in sorted(glob.glob('work/wolftl/dump/mps/*.json')):
    j=json.load(open(f,encoding='utf-8'))
    for e in j.get('events',[]):
        for pg in e.get('pages',[]):
            for c in pg.get('list',[]):
                for s in c.get('stringArgs',[]):
                    scan(s,os.path.basename(f),c['code'])
for k,v in json.load(open('work/maps_full.json',encoding='utf-8')).items():
    for e in v.get('events',[]):
        for c in e.get('cmds',[]):
            for s in c.get('strs',[]): scan(s,k,c['code'])
for name in ['SysDatabase','DataBase','CDataBase']:
    d=json.load(open('work/wolftl/dump/db/%s.json'%name,encoding='utf-8'))
    for i,t in enumerate(d['types']):
        for r,row in enumerate(t['data']):
            for fld in row['data']:
                v=fld['value']
                if isinstance(v,str): scan(v,'%s t%d r%d'%(name,i,r),0)
OUT.write('== substring occurrences of dir prefixes (all string fields) ==\n')
for p in PREF: OUT.write('%-22s %5d\n'%(p,cnt[p]))
OUT.write('\n== samples ==\n')
for p in PREF:
    if samples[p]:
        OUT.write('%s\n'%p)
        for s in samples[p]: OUT.write('    %s\n'%(s,))
open('work/_audit_out4.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
