import json, io, collections
ce = json.load(open("work/_ce_full.json", encoding="utf-8"))
d = {e["id"]: e for e in ce}

callers = collections.Counter()
deltas = collections.Counter()
per_event = []
for e in ce:
    n = 0
    for i, c in enumerate(e["cmds"]):
        if c["c"] == 210 and len(c["a"]) >= 3 and c["a"][0] == 500217:
            n += 1
            argn = c["a"][1]
            val = c["a"][2] if len(c["a"]) > 2 else None
            deltas[val] += 1
    if n:
        per_event.append((e["id"], e["title"], n))

print("events calling 217:", len(per_event), "total call sites:", sum(x[2] for x in per_event))
print("delta histogram:", dict(sorted(deltas.items(), key=lambda kv: (kv[0] is None, kv[0]))))
print()
for eid, title, n in sorted(per_event, key=lambda x: -x[2]):
    print("ev%-4d %-20s %d" % (eid, title, n))

print()
print("=== ev236 calls to 217 and clock writes")
for i, c in enumerate(d[236]["cmds"]):
    if c["c"] == 210 and c["a"] and c["a"][0] == 500217:
        print("ev236 pc%d a=%s" % (i, c["a"]))
    if c["c"] == 121 and c["a"] and c["a"][0] in (2000004, 2000005, 2000006, 2000008):
        print("ev236 pc%d c121 a=%s" % (i, c["a"]))

print()
print("=== ev329 clock/wait structure pc 240-300")
e = d[329]
for i, c in enumerate(e["cmds"]):
    if c["c"] == 0:
        continue
    if 240 <= i <= 300:
        print("pc%-4d bd=%s c=%-4s a=%s s=%s" % (i, c["bd"], c["c"], c["a"], c["s"]))
