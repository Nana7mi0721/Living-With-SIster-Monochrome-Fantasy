# -*- coding: utf-8 -*-
import json, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
d=json.load(open('work/_map_audit.json',encoding='utf-8'))
print('=== per map ===')
for f,m in d.items():
    print('%-16s %dx%d ts=%d tiles=%s title=%r ev=%d pages=%d' % (f,m['w'],m['h'],m['tileset'],'NO' if m['no_tiles'] else 'YES',m['title'],len(m['events']),sum(len(e['pages']) for e in m['events'])))
print()
print('=== trigger bytes per map ===')
for f,m in d.items():
    tb={}
    for e in m['events']:
        for p in e['pages']:
            tb[p['trigger']]=tb.get(p['trigger'],0)+1
    print('%-16s %s' % (f, sorted(tb.items())))
print()
print('=== condition flag bytes (raw) ===')
raw={}
for f,m in d.items():
    for e in m['events']:
        for p in e['pages']:
            for c in p['conds']:
                raw[c['raw']]=raw.get(c['raw'],0)+1
print(sorted(raw.items()))
print()
print('=== enabled conditions by operator ===')
op={}
en=0; tot=0
for f,m in d.items():
    for e in m['events']:
        for p in e['pages']:
            for c in p['conds']:
                tot+=1
                if c['enabled']:
                    en+=1; op[c['op']]=op.get(c['op'],0)+1
print('slots',tot,'enabled',en,'ops',sorted(op.items()))
print()
print('=== events with >1 page ===')
for f,m in d.items():
    for e in m['events']:
        if len(e['pages'])>1:
            print('%-16s id=%3d %-20r (%d,%d) pages=%d triggers=%s' % (f,e['id'],e['name'],e['x'],e['y'],len(e['pages']),[p['trigger'] for p in e['pages']]))
