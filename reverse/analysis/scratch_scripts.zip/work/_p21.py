
import json, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
ev = next(e for e in ce if e['id'] == 270)
print(ev['title'], len(ev['cmds']))
for i,c in enumerate(ev['cmds'][:3]):
    print(i, c)
print('--- ret:', ev['ret'])

