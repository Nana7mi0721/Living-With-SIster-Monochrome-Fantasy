import io, json, collections, os
p = 'docs/BASELINE.json'
d = json.load(io.open(p, encoding='utf-8'), object_pairs_hook=collections.OrderedDict)
pre = d['precompile']
pre['blocks'] = 13433
pre['conditions'] = 10866
pre['cases'] = 18555
pre['else_cases'] = 3279
pre['cancel_cases'] = 153
pre['orphan_cases'] = 0
pre['orphan_ends'] = 0
pre['implicit_closes'] = 54
pre['unclosed_blocks'] = 0
story = collections.OrderedDict([
    ('command', 'capture --map-run SampleMapA --event 0 --frames 900 --answer 3 --answer-delay 1'),
    ('note', '打开『继承点分配』菜单后答第 4 选项，剧情推进到床边场景（含 HUD）'),
    ('frames', 900),
    ('instructions', 51297),
    ('picture_ops', 1881),
    ('sounds', 8),
    ('db_accesses', 436),
    ('database_writes', 38),
    ('db_labels', 31),
    ('messages', 39),
    ('choices', 5),
    ('warnings', 0),
    ('coroutines', 6),
    ('live_pictures', 69),
    ('quads', 12),
    ('text_pictures', 31),
    ('atlas_images', 12),
    ('atlas_fill', '30.3% of 2048x2048'),
    ('non_black', 548241),
])
d.setdefault('opening_slice', collections.OrderedDict())['story_state'] = story
c112 = collections.OrderedDict([
    ('law', '112 与 111 共用一套块栈（BlockKind::Condition），只是比较方式不同；它同样以 401/420/499 收尾'),
    ('sites_common_events', 123),
    ('sites_map_pages', 21),
    ('argc', '1 + (head & 0x0F) 个条件，每个条件一个字符串变量'),
    ('strc', 4),
    ('before', collections.OrderedDict([
        ('blocks', 13310), ('conditions', 10743), ('cases', 18460),
        ('else_cases', 3246), ('cancel_cases', 150),
        ('orphan_cases', 131), ('orphan_ends', 138),
        ('implicit_closes', 66), ('unclosed_blocks', 3),
    ])),
    ('after', collections.OrderedDict([
        ('blocks', 13433), ('conditions', 10866), ('cases', 18555),
        ('else_cases', 3279), ('cancel_cases', 153),
        ('orphan_cases', 0), ('orphan_ends', 0),
        ('implicit_closes', 54), ('unclosed_blocks', 0),
    ])),
    ('proof', '条件数 = 111(10743) + 112(123)，case 数 = 401 语音统计(18555)，else = 420(3279)，cancel = 421(153)，且孤儿计数全部归零'),
    ('symptom_fixed', 'SampleMapA 事件 0 的继承菜单 102 块 end 提前 150 槽，答完跳进 case 体中间，绕回 213 重置 形成死循环：900 帧烧掉 163,206,432 条指令且全黑'),
    ('after_fix', '同一命令 51,297 条指令、39 条消息、5 次选择、0 警告、92.9% 非黑'),
    ('doc', 'docs/OPCODE_112.md'),
])
d['condition_112'] = c112
out = json.dumps(d, ensure_ascii=False, indent=1) + '\n'
io.open(p + '.new', 'w', encoding='utf-8', newline='').write(out)
os.replace(p + '.new', p)
print('keys', len(d))