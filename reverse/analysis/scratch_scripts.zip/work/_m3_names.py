
import json,os,collections,re
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
T=[338,340,341,343,346,350,351,353,354,357,358,365,367,372,407,410,445]
L=[]
def p(s=""): L.append(s)

# search ALL strings (ce + maps) for substring 'カットイン' or '文字エフェクト'
p("## strings containing カットイン / 文字エフェクト / 文字効果")
for e in ce:
    for i,c in enumerate(e["cmds"]):
        for s in (c.get("s") or []):
            if isinstance(s,str) and ("カットイン" in s or "文字エフェクト" in s or "文字効果" in s):
                p("ce%-4d pc%-5d op%-5d %r"%(e["id"],i,c["c"],s))
for mn,m in maps.items():
    for ev in m.get("events",[]):
        for i,c in enumerate(ev.get("cmds",[])):
            for s in (c.get("strs") or []):
                if isinstance(s,str) and ("カットイン" in s or "文字エフェクト" in s):
                    p("map %s ev%s pc%d op%d %r"%(mn,ev.get("id"),i,c.get("code"),s))
open(os.path.join(W,"_m3_out2.txt"),"w",encoding="utf-8").write("\n".join(L))
print("lines",len(L))
