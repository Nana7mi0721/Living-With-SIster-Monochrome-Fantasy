import io, os
from PIL import Image
import sys
sys.path.insert(0, 'work')
root = 'work/full/MapChip'
for f in sorted(os.listdir(root)):
    p = os.path.join(root, f)
    if os.path.isfile(p):
        try:
            im = Image.open(p)
            print(f, im.size, im.mode)
        except Exception as e:
            print(f, 'ERR', e)
print('--- CharaChip sample ---')
root2 = 'work/full/CharaChip'
names = sorted(os.listdir(root2))[:8]
for f in names:
    p = os.path.join(root2, f)
    if os.path.isfile(p):
        try:
            im = Image.open(p)
            print(f, im.size, im.mode)
        except Exception as e:
            print(f, 'ERR', e)
print('count charachip', len(os.listdir(root2)))
