# -*- coding: utf-8 -*-
"""What writes the self variables that hold picture numbers (self[20]=1600020,
self[21]=1600021, self[10]=1600010, self[11]=1600011)?  Also: which events own the
150 sites that carry those numbers, so section 2 can name the owner per picture."""
import collections, io, json

events = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
map_evs = {e['id']: e for e in tm['events']}
clos = json.load(io.open('work/_m1_closure2.json', encoding='utf-8'))
rows = clos['from_map_event2']['reached']

def norm(cmds):
    out = []
    for c in cmds:
        if 'c' in c:
            out.append({'c': c['c'], 'a': [int(x) for x in c['a']], 's': list(c.get('s') or [])})
        else:
            out.append({'c': c.get('code', 0),
                        'a': [int(x) for x in (c.get('intArgs') or [])],
                        's': list(c.get('stringArgs') or [])})
    return out

WATCH = {1600010, 1600011, 1600020, 1600021}
for r in rows:
    if r['kind'] == 'c':
        cmds = norm(by_id[r['id']]['cmds']); tag = 'c%d' % r['id']
    else:
        cmds = []
        for p in map_evs[r['id']]['pages']:
            cmds.extend(norm(p['list']))
        tag = 'm%d' % r['id']
    for i, c in enumerate(cmds):
        if c['c'] == 121 and c['a'] and c['a'][0] in WATCH:
            print('%-7s slot %-4d 121 args=%s' % (tag, i, c['a']))
