
import json, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))
print(type(ce), len(ce))
if isinstance(ce, dict):
    k = list(ce)[:3]; print(k)
    ev = ce[k[0]]
    print(type(ev), list(ev)[:10] if isinstance(ev, dict) else ev[:1])
else:
    ev = ce[0]; print(list(ev)[:12])
    print(json.dumps(ev['cmd'][:2], ensure_ascii=False)[:300] if 'cmd' in ev else 'no cmd')

