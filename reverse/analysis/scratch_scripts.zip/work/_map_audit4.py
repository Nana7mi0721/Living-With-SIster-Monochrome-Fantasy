# -*- coding: utf-8 -*-
import json, sys, io, struct, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base = r'work\full\MapData'

def parse_mps(p):
    b=open(p,'rb').read(); st={'o':0}
    def u1():
        v=b[st['o']]; st['o']+=1; return v
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        return s.split(b'\x00')[0].decode('utf-8','replace')
    st['o']=16; u1(); st['o']+=3; u4(); u1(); tstr()
    ts=u4(); w=u4(); h=u4(); ec=u4(); fp=u4()
    if fp!=0xFFFFFFFF: st['o'] += w*h*3*4 - 4
    events=[]
    while b[st['o']]==0x6F:
        u1(); u4(); eid=u4(); name=tstr(); x=u4(); y=u4(); pc=u4(); u4()
        pages=[]
        for _ in range(pc):
            u1(); chip=u4(); gfx=tstr()
            direction=u1(); frame=u1(); op=u1(); disp=u1(); trig=u1()
            sw=[u1() for _ in range(4)]; vn=[u4() for _ in range(4)]; vv=[s4() for _ in range(4)]
            [u1() for _ in range(6)]
            rl=u4()
            for _ in range(rl):
                u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
            ncmd=u4(); cmds=[]
            for _ in range(ncmd):
                cnt=u1()
                if cnt>0: o=u4(); a=[s4() for _ in range(cnt-1)]
                else: o=0; a=[]
                d=u1(); sc=u1()
                strs=[tstr() for _ in range(sc)]
                hr=u1()
                if hr!=0:
                    st['o']+=6; rl2=u4()
                    for _ in range(rl2):
                        u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
                cmds.append({'op':o,'args':a,'strings':strs})
            u4(); shadow=u1(); rex=u1(); rey=u1(); footer=u1()
            pages.append({'trigger':trig,'cmds':cmds,'gfx':gfx,'chip':chip,'footer':footer,
                          'sw':sw,'vn':vn,'vv':vv})
        u1()
        events.append({'id':eid,'name':name,'x':x,'y':y,'pages':pages})
    return {'ts':ts,'w':w,'h':h,'events':events}

REG = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps']
CTRL = ['SampleMapB.mps']
ALL = REG + CTRL + ['Dungeon.mps','Map002.mps']

maps={f:parse_mps(os.path.join(base,f)) for f in ALL}

print('=== opcode 130 sites in MAP EVENT PAGES ===')
for f in ALL:
    m=maps[f]
    for e in m['events']:
        for pi,p in enumerate(e['pages']):
            for ci,c in enumerate(p['cmds']):
                if c['op']==130:
                    print('%-16s ev=%3d %-18r page=%d pc=%3d args=%s strs=%s' % (f,e['id'],e['name'],pi,ci,c['args'],c['strings']))

print()
print('=== opcode 103 / 99 sites (verify what they are) ===')
for f in ALL:
    m=maps[f]
    for e in m['events']:
        for pi,p in enumerate(e['pages']):
            for ci,c in enumerate(p['cmds']):
                if c['op'] in (99,103,104,105):
                    print('%-16s ev=%3d page=%d pc=%3d op=%d args=%s strs=%s' % (f,e['id'],pi,ci,c['op'],c['args'],c['strings']))

print()
print('=== graphics: page graphics / chip ids ===')
for f in REG:
    m=maps[f]
    gs=set()
    for e in m['events']:
        for p in e['pages']:
            gs.add((p['gfx'],p['chip']))
    print('%-16s distinct=%d %s' % (f,len(gs),sorted(gs)[:6]))
