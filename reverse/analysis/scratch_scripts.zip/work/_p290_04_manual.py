
import io,sys,re,html
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
b=open('work/_effect_manual.html','rb').read()
txt=None
for enc in ('utf-8','cp932','euc-jp'):
    try:
        t=b.decode(enc)
        if 'エフェクト' in t:
            txt=t; print('decoded with',enc); break
    except Exception as e: pass
print('declared:',re.search(rb'charset=["\']?([\w-]+)',b))
if txt is None: sys.exit('no decode')
t=re.sub(r'<script.*?</script>','',txt,flags=re.S|re.I)
t=re.sub(r'<style.*?</style>','',t,flags=re.S|re.I)
t=re.sub(r'<br\s*/?>','\n',t,flags=re.I)
t=re.sub(r'</(p|div|tr|td|th|li|h\d)>','\n',t,flags=re.I)
t=re.sub(r'<[^>]+>','',t)
t=html.unescape(t)
lines=[l.strip() for l in t.split('\n')]
lines=[l for l in lines if l]
open('work/_effect_manual.txt','w',encoding='utf-8').write('\n'.join(lines))
print('lines',len(lines))
print('\n'.join(lines[:120]))
