import io, os

def cut(path, first, last, expect_last):
    lines = io.open(path, encoding="utf-8", newline="").read().split("\n")
    idx = last - 1
    assert lines[idx].strip() == expect_last, "line %d is %r" % (last, lines[idx])
    del lines[first - 1:last]
    open(path + ".new", "w", encoding="utf-8", newline="").write("\n".join(lines))
    os.replace(path + ".new", path)
    print("cut", path, first, last)

cut("crates/wolf-cli/src/main.rs", 1229, 1240, "const TEXT_PX: f32 = 22.0;")
cut("crates/wolf-cli/src/play.rs", 35, 39, "const TEXT_PX: f32 = 22.0;")

def sub(path, a, b):
    t = io.open(path, encoding="utf-8", newline="").read()
    assert t.count(a) == 1, ("count", t.count(a))
    open(path + ".new", "w", encoding="utf-8", newline="").write(t.replace(a, b))
    os.replace(path + ".new", path)
    print("sub", path)

sub("crates/wolf-cli/src/main.rs", "TextItem::new(text.text.clone(), text.rect, TEXT_PX)", "TextItem::new(text.text.clone(), text.rect, choice::TEXT_PX)")
sub("crates/wolf-cli/src/play.rs", "TextItem::new(text.text.clone(), text.rect, TEXT_PX)", "TextItem::new(text.text.clone(), text.rect, choice::TEXT_PX)")