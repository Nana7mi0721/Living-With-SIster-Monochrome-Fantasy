
import json,io,collections,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
items=[(e['id'],norm(c)) for e in ce for c in e['cmds']]
items+=[('M',norm(c)) for m in mp.values() for ev in m.get('events',[]) for c in ev.get('cmds',[])]
m101=[(eid,a,s) for eid,(op,a,s) in items if op==101]
print('101 count',len(m101))
print('argc hist',collections.Counter(len(a) for _,a,s in m101).most_common())
print('strc hist',collections.Counter(len(s) for _,a,s in m101).most_common())
print('samples with argc>0:')
for eid,a,s in m101:
    if a: print('  ',eid,a,repr(s[0][:50]) if s else None); break
print('multi-string samples:')
n=0
for eid,a,s in m101:
    if len(s)>1:
        print('  ',eid,'argc',len(a),a,'strs',[x[:40] for x in s]); n+=1
        if n>=5: break
print('total multi-string',sum(1 for _,a,s in m101 if len(s)>1))
# LF-containing 101
lf=[(eid,s[0]) for eid,a,s in m101 if s and '\n' in s[0]]
print('101 whose text has raw LF:',len(lf))
for eid,t in lf[:3]: print('   ',eid,repr(t[:120]))
# text length stats
import statistics
L=[len(s[0]) for _,a,s in m101 if s]
print('len min/med/max',min(L),statistics.median(L),max(L),'mean %.1f'%(sum(L)/len(L)))
print('>=3 lines',sum(1 for _,a,s in m101 if s and s[0].count('\n')>=2))
