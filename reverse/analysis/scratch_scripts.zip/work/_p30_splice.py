import io, os
root = r'E:/Study/github program/imoto life'
def read(p):
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()
def write(p, s):
    with io.open(p + '.new', 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    os.replace(p + '.new', p)
p = os.path.join(root, 'crates/wolf-save/src/vardb.rs')
s = read(p)
add = read(os.path.join(root, 'work/_add_vardb.rs'))
assert 'impl VariableDatabase {' not in s
s = s.rstrip() + chr(10) + add
s = s.replace('use crate::{ensure_fits, mem_data};', 'use crate::{ensure_fits, mem_data, push_i32, push_mem_data, push_u32, push_u8};', 1)
write(p, s)
print('ok lines', len(s.split(chr(10))))