
import json,io,os,collections,hashlib
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
sizes=fin['sizes']
never=set(fin['never']); live=set(fin['live']); deadref=set(fin['deadref'])
DATA={'BasicData','MapData'}

# 1) live byte share by dir
tot_live=sum(sizes[p] for p in live)
W('live assets total %d B'%tot_live)
agg=collections.defaultdict(int)
for p in live: agg[p.split('/')[0]]+=sizes[p]
for d,b in sorted(agg.items(),key=lambda kv:-kv[1])[:8]:
    W('  %-20s %12d  %5.1f%%'%(d,b,100*b/tot_live))

# 2) duplicates among live assets
groups=collections.defaultdict(list)
for p in sorted(live):
    groups[sizes[p]].append(p)
dup_bytes=0; dup_files=0; examples=[]
for sz,ps in groups.items():
    if len(ps)<2: continue
    h=collections.defaultdict(list)
    for p in ps:
        with open(os.path.join('work/all',p),'rb') as f:
            h[hashlib.md5(f.read()).hexdigest()].append(p)
    for d,fl in h.items():
        if len(fl)>1:
            dup_files+=len(fl)-1; dup_bytes+=sz*(len(fl)-1)
            if len(examples)<8: examples.append((sz,fl))
W('\nduplicate content among live assets: %d redundant files / %d B'%(dup_files,dup_bytes))
for sz,fl in examples: W('  %9d x%d  %s'%(sz,len(fl),' == '.join(fl)))

# 3) ttf / index.html references anywhere
W('\n== font & html references in all strings ==')
import re
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
hits=collections.Counter()
for e in lst:
    for c in e['cmds']:
        for s in (c.get('s') or []):
            for m in re.findall(r'[^\\s/\\\\]+\.(?:ttf|otf|html|dat|ini|vdf)', s, re.I):
                hits[m]+=1
W('  %s'%hits.most_common(15))
mf=json.load(open('work/maps_full.json',encoding='utf-8'))
mh=collections.Counter()
for k,v in mf.items():
    for e in v['events']:
        for c in e['cmds']:
            for s in (c.get('strs') or []):
                for m in re.findall(r'[^\\s/\\\\]+\.(?:ttf|otf|html)', s, re.I): mh[m]+=1
W('  map-side: %s'%mh.most_common(10))

# 4) install footprint of the real Steam dir
W('\n== real install (E:/SteamLibrary/.../Living With SIster Monochrome Fantasy) ==')
for label,path in [('Data/*.wolf','Data'),('loose','.')]:
    pass
open('work/_audit_out16.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
