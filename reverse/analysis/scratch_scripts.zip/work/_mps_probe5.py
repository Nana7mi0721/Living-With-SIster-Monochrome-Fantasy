
import struct, os, collections
base = r'work\full\MapData'
for f in sorted(os.listdir(base)):
    if not f.endswith('.mps'): continue
    b = open(os.path.join(base,f),'rb').read()
    o = 16
    o+=1+3
    o+=4
    o+=1
    n = struct.unpack_from('<I',b,o)[0]; o+=4+n
    ts,w,h,ec = struct.unpack_from('<IIII',b,o); o+=16
    fp = struct.unpack_from('<I',b,o)[0]
    if fp == 0xFFFFFFFF:
        print(f, 'NO TILES'); continue
    nc = w*h
    vals = struct.unpack_from('<%dI' % (nc*3), b, o)
    L = [vals[0:nc], vals[nc:2*nc], vals[2*nc:]]
    P = [[vals[i*3+k] for i in range(nc)] for k in range(3)]
    def runs(seq):
        r=[]; cur=1
        for i in range(1,len(seq)):
            if seq[i]==seq[i-1]: cur+=1
            else: r.append(cur); cur=1
        r.append(cur); return sum(r)/len(r), max(r)
    print('== %s %dx%d' % (f,w,h))
    print('   layer-major runs avg/max:', ['%.2f/%d'%runs(l) for l in L])
    print('   pixel-major runs avg/max:', ['%.2f/%d'%runs(l) for l in P])
    print('   layer-major distinct:', [sorted(collections.Counter(l).items(), key=lambda kv:-kv[1])[:6] for l in L])
    print('   pixel-major distinct:', [sorted(collections.Counter(l).items(), key=lambda kv:-kv[1])[:6] for l in P])
    # row coherence: for layer-major, count row-uniform rows
    for name,X in (('layer',L),('pixel',P)):
        rowuni = [sum(1 for r in range(h) if len(set(X[k][r*w:(r+1)*w]))==1) for k in range(3)]
        print('   %s row-uniform rows (of %d):' % (name,h), rowuni)
