import json,sys,collections
sys.stdout.reconfigure(encoding='utf-8')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
rows=[]
for e in ev:
    for i,c in enumerate(e['cmds']):
        if c['c']==150: rows.append((e['id'],e['title'],i,c['a'],c['s']))
for n in (19,18):
    g=[r for r in rows if len(r[3])==n]
    print(f"=== argc {n}: {len(g)}")
    for r in g[:10]:
        print(f"   ev{r[0]} pc{r[2]} a={r[3]} s={r[4][:1]} {r[1][:18]}")
    print("   head hist:",collections.Counter(r[3][0] for r in g).most_common(8))
