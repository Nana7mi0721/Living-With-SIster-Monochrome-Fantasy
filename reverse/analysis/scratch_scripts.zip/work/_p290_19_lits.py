
import zipfile, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')

def parse(a, b):
    out = []
    i = a
    while i + 2 <= b:
        n = int.from_bytes(data[i:i+2], 'little')
        if 1 <= n <= 60 and i + 2 + 2*n <= b:
            raw = data[i+2:i+2+2*n]
            try:
                s = raw.decode('utf-16-le')
            except Exception:
                s = None
            if s and all(ord(c) >= 0x20 for c in s):
                out.append((i, n, s))
                i += 2 + 2*n
                continue
        i += 1
    return out

for (off, n, s) in parse(0xa84700, 0xa84900):
    print(hex(off), n, s)
