import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
hits=[]
for e in ev:
    for i,c in enumerate(e['cmds']):
        if 12001 in c['a'] or '12001' in ''.join(c['s']):
            hits.append((e['id'],e['title'],i,c['c'],c['a'],c['s']))
for h in hits: print(h)
print("---- CE hits",len(hits))
