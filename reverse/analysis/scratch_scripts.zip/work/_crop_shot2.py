
from PIL import Image
src=r'C:/Users/REISEN/.dsh/attachments/v1/objects/48/48b03b8df72d48b419b159869356953a31eef9a3fc8e754e0d287e7a0c687e28'
im=Image.open(src); w,h=im.size
print(w,h)
out=r'work/out'
im.crop((0,780,w,1183)).resize((int(w*1.4),int(403*1.4)),Image.LANCZOS).save(out+'/shot2.png')
