import io, os
path = "crates/wolf-cli/src/main.rs"
t = io.open(path, encoding="utf-8", newline="").read()
start = t.index("        for run in &layout.runs {\n                eprintln!")
end = t.index("        for run in &layout.runs {\n            // Give each run", start + 10)
t = t[:start] + t[end:]
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")