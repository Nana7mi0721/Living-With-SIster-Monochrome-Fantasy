
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ce}
e=by[48]; cm=e['cmds']
print('CE48',e['title'],len(cm))
for i in range(140,210):
    if i>=len(cm): break
    c=cm[i]
    print(('>>' if i==153 else '  ')+'pc%-4d c=%-4d a=%s s=%s bd=%d'%(i,c['c'],c['a'],[x[:34] for x in c['s']],c['bd']))
