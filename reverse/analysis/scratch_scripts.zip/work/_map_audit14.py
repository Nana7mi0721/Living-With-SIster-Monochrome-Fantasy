# -*- coding: utf-8 -*-
import sys, io, os, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
src = open('work/_map_audit10.py', encoding='utf-8').read()
pre = src.split("REG = [")[0]
pre = '\n'.join(l for l in pre.splitlines() if not l.startswith('import sys') and not l.startswith('sys.stdout'))
g = {}
exec(compile(pre, 'walklib', 'exec'), g)
parse_mps = g['parse_mps']
base = r'work\full\MapData'
REG = ['TitleMap.mps', 'SampleMapA.mps', 'SampleMapA_1.mps', 'Map003.mps', 'Map024.mps', 'Map031.mps']
CTL = ['SampleMapB.mps']
ORPH = ['Dungeon.mps', 'Map002.mps']
maps = {f: parse_mps(os.path.join(base, f)) for f in REG + CTL + ORPH}

print('| map | dims | tiles | layers | events | pages | slots | confirm | autorun | parallel | touch | op150 | hover | op123 |')
print('| :--- | :--- | :--- | --: | --: | --: | --: | --: | --: | --: | --: | --: | --: | --: |')
grand = collections.Counter()
for f in REG + CTL + ORPH:
    m = maps[f]
    tr = collections.Counter(); op = collections.Counter(); hover = 0
    pages = 0
    for e in m['events']:
        pages += len(e['pages'])
        for p in e['pages']:
            tr[p['trigger']] += 1
            for c in p['cmds']:
                op[c['op']] += 1
                a = c['args']
                if c['op'] == 124 and len(a) >= 4 and a[1] == 0x4000 and a[3] == 8:
                    hover += 1
    layers = 3 if m.get('w') and True else 0
    print('| %s | %dx%d | %s | %d | %d | %d | %d | %d | %d | %d | %d | %d | %d | %d |' % (
        f, m['w'], m['h'], 'yes' if m['ts'] is not None and True else '?', 0,
        len(m['events']), pages, sum(op.values()), tr[0], tr[1], tr[2], tr[3], op[150], hover, op[123]))
print()
# distinct pictures in op150 for registered maps
pics = set(); magic = 0; tot = 0
for f in REG:
    for e in maps[f]['events']:
        for p in e['pages']:
            for c in p['cmds']:
                if c['op'] == 150 and len(c['args']) >= 2:
                    tot += 1
                    pid = c['args'][1]
                    if 0 <= pid < 1000000:
                        pics.add(pid)
                    else:
                        magic += 1
print('op150 in registered maps: total=%d  literal picture ids=%d distinct=%d  magic(variable) ids=%d' % (tot, tot - magic, len(pics), magic))
print('picture id range:', min(pics), '..', max(pics))
# condition variables across registered maps
cv = collections.Counter()
for f in REG:
    for e in maps[f]['events']:
        for p in e['pages']:
            for i in range(4):
                if p['sw'][i] & 0x0F == 1:
                    cv[p['vn'][i]] += 1
def vn(v):
    if 1000000 <= v < 2000000: return 'self%d' % (v - 1000000)
    if 2000000 <= v < 3000000: return 'v%d' % (v - 2000000)
    if 9000000 <= v < 10000000: return 'sys%d' % (v - 9000000)
    return 'raw%d' % v
print()
print('enabled condition slots in registered maps:', sum(cv.values()), 'distinct variables:', len(cv))
print('vars:', sorted(vn(v) for v in cv))
print()
print('layer sanity: every parsed map w/h:', {f: (maps[f]['w'], maps[f]['h']) for f in maps})
