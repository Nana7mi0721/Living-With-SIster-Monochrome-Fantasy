
import json, os, collections
os.chdir(r'E:\Study\github program\imoto life')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
idset=set(e['id'] for e in ev)
# hypothesis: 210 arg0 = 500000 + event_id
lit=[]; dyn=[]
for e in ev:
    for c in e['cmds']:
        if c['c']==210:
            v=c['a'][0]
            if 500000<=v<600000: lit.append(v-500000)
            else: dyn.append(v)
print('210 literal calls', len(lit), 'dynamic', len(dyn))
print('literal ids all valid?', all(x in idset for x in lit), 'bad:', [x for x in lit if x not in idset][:5])
print('literal id range', min(lit), max(lit))
dc=collections.Counter(dyn)
print('dynamic arg0 values:', dc.most_common(12))
# 300 CommonEventByName args
c300=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==300: c300[(tuple(c['a']), tuple(c['s']))]+=1
print('300 samples:'); 
for k,v in c300.most_common(6): print('  ',v,k)
# 401 ChoiceCase args
c401=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==401: c401[c['a'][0]]+=1
print('401 arg0 dist', c401.most_common(10))
# 101 message args
c101=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==101: c101[tuple(c['a'])]+=1
print('101 args', c101.most_common(8))
# 180 wait args
c180=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==180: c180[c['a'][0]]+=1
print('180 wait frames', c180.most_common(12))
