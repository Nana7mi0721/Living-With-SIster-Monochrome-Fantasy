# -*- coding: utf-8 -*-
"""Emit MAP_AUDIT tables: per-map page tables + highest-active-page precedence analysis."""
import json, sys, io, itertools
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BT = chr(96)

d = json.load(open('work/_map_audit_data.json', encoding='utf-8'))
OPN = {0: '>', 1: '>=', 2: '==', 3: '<=', 4: '<', 5: '!=', 6: '&'}
TRIG = {0: 'confirm', 1: 'autorun', 2: 'parallel', 3: 'touch'}
REG = ['TitleMap.mps', 'SampleMapA.mps', 'SampleMapA_1.mps', 'Map003.mps', 'Map024.mps', 'Map031.mps']
CTL = ['SampleMapB.mps']

def slot_str(page, i):
    for c in page['conds']:
        if c['slot'] == i:
            return '%s%s%s' % (c['var_name'], OPN[c['op']], c['value'])
    return ''

def matches(c, val):
    op = c['op']
    if op == 2: return val == c['value']
    if op == 1: return val >= c['value']
    if op == 3: return val <= c['value']
    if op == 5: return val != c['value']
    if op == 0: return val > c['value']
    if op == 4: return val < c['value']
    return False

def ok_page(p, env):
    return all(matches(c, env[c['var_name']]) for c in p['conds'])

def analyse(event):
    pages = event['pages']
    n = len(pages)
    allvars = []
    for p in pages:
        for c in p['conds']:
            if c['var_name'] not in allvars:
                allvars.append(c['var_name'])
    dom = {}
    for v in allvars:
        dom[v] = {0}
    for p in pages:
        for c in p['conds']:
            t = c['value']
            dom[c['var_name']] |= {t - 1, t, t + 1, t ^ 1, t | 1, -1}
    combos = list(itertools.product(*[sorted(dom[v]) for v in allvars])) if allvars else [()]
    winners = []
    oks = []
    for combo in combos:
        env = dict(zip(allvars, combo))
        mask = [ok_page(p, env) for p in pages]
        oks.append(mask)
        win = None
        for i in range(n - 1, -1, -1):
            if mask[i]:
                win = i
                break
        winners.append(win)
    live = sorted({w for w in winners if w is not None})
    wins = {i: sum(1 for w in winners if w == i) for i in range(n)}
    dominated = []
    for i in range(n):
        for j in range(i + 1, n):
            both = False
            always_beats = True
            for k, combo in enumerate(combos):
                if oks[k][i] and oks[k][j]:
                    both = True
                    if winners[k] == i:
                        always_beats = False
            if both and always_beats:
                dominated.append((i, j))
    return live, len(combos), wins, dominated

def table_for(f):
    m = d['maps'][f]
    lines = []
    lines.append('| ev | name | page | trigger | cond slot 0 | cond slot 1 | cond slot 2 | cond slot 3 | cmds | boot-active |')
    lines.append('| --: | :--- | --: | :--- | :--- | :--- | :--- | :--- | --: | :--: |')
    for e in m['events']:
        for p in e['pages']:
            raw = p.get('raw_sw') or []
            cells = []
            for i in range(4):
                r = ('%02X' % raw[i]) if i < len(raw) else ''
                s = slot_str(p, i)
                if r and s:
                    cells.append(BT + r + ' ' + s + BT)
                elif r:
                    cells.append(BT + r + BT)
                else:
                    cells.append(s if s else '-')
            lines.append('| %d | %s | %d | %s | %s | %s | %s | %s | %d | %s |' % (
                e['id'], e['name'], p['page'], TRIG[p['trigger']], cells[0], cells[1], cells[2], cells[3],
                p['cmds'], 'yes' if p['fresh'] else ''))
    return '\n'.join(lines)

def prec_section(f):
    m = d['maps'][f]
    out = []
    for e in m['events']:
        if len(e['pages']) < 2:
            continue
        live, ncombos, wins, dominated = analyse(e)
        winstr = ', '.join('p%d:%d' % (i, wins[i]) for i in range(len(e['pages'])) if wins[i])
        if dominated:
            rel = '; '.join('p%d can never win when p%d also matches' % (i, j) for i, j in dominated)
        else:
            rel = 'no page is dominated by a higher one'
        fmt = '- ev%d ' + BT + '%s' + BT + ' - %d pages / %d enumerated assignments - wins per page (%s) - live %s - %s'
        out.append(fmt % (e['id'], e['name'], len(e['pages']), ncombos, winstr, live, rel))
    return '\n'.join(out)

parts = []
for f in REG:
    parts.append('@@TABLE %s' % f)
    parts.append(table_for(f))
    parts.append('')
    parts.append('@@PREC %s' % f)
    ps = prec_section(f)
    parts.append(ps if ps else '(no multi-page events)')
    parts.append('')
parts.append('@@TABLE SampleMapB.mps')
parts.append(table_for('SampleMapB.mps'))
open('work/_map_audit_md.txt', 'w', encoding='utf-8').write('\n'.join(parts))
print('wrote work/_map_audit_md.txt')
for f in REG + CTL:
    m = d['maps'][f]
    multi = [e for e in m['events'] if len(e['pages']) > 1]
    tot = 0
    shadow = 0
    for e in multi:
        r = analyse(e)
        tot += r[1]
        shadow += len(r[3])
    print('%-16s events=%-3d multi=%-3d combos=%-6d dominated_pairs=%d' % (f, len(m['events']), len(multi), tot, shadow))
