path = "crates/wolf-game/tests/opening.rs"
raw = open(path, "rb").read()
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
a = """    let prompt = game.choices.as_ref().expect("the opening prompt is open");\n    assert_eq!(\n        prompt.options,\n        ["广阔的战场", "广袤的森林", "微风吹拂而过的麦田", "有人在等我的家"],\n        "the title menu did not reach the opening prompt"\n    );\n"""
b = """    println!("title path choices: {:?}", game.choices.as_ref().map(|c| c.options.clone()));\n    println!("title path diagnostics: {:?}", game.diagnostics.keys().collect::<Vec<_>>());\n    println!("title path stats: {:?}", game.stats);\n    let prompt = game.choices.as_ref().expect("the opening prompt is open");\n    assert_eq!(\n        prompt.options,\n        ["广阔的战场", "广袤的森林", "微风吹拂而过的麦田", "有人在等我的家"],\n        "the title menu did not reach the opening prompt"\n    );\n"""
assert t.count(a) == 1
t = t.replace(a, b)
open(path, "wb").write(t.encode("utf-8"))
print("done")