import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
old = """    fn key_code(&mut self, mask: u32) -> i32 {
        // The mask is deliberately unused: one mask can yield six different codes,
        // see crates/wolf-game/src/key.rs.
        let _ = mask;
        crate::key::code(self.key_bits)
    }
"""
new = """    fn key_code(&mut self, mask: u32) -> i32 {
        // The mask is deliberately unused: one mask can yield six different codes,
        // see crates/wolf-game/src/key.rs.
        let _ = mask;
        crate::key::code(self.key_bits)
    }

    fn key_code_auto(&mut self, mask: u32, auto: u32) -> i32 {
        // Opcode 125 exists exactly for script-driven input: the key bits it names
        // are pressed even when the player is not touching the keyboard. The mask is
        // still irrelevant for the code mapping, as above.
        let _ = mask;
        crate::key::code(self.key_bits | auto)
    }
"""
assert t.count(old) == 1
t = t.replace(old, new)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("patched")
