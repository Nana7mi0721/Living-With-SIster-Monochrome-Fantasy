import io, os
path = "docs/M2_SLICE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """立绘 picture 90 `Picture/stand_imouto_paja2.png` 按 6x2 精灵表取第 2 格，画在 `[600,80,400,650]`。

## 3. `150` 图片指令的四个语义修正（M2 的核心发现）"""
b = """立绘 picture 90 `Picture/stand_imouto_paja2.png` 按 6x2 精灵表取第 2 格，画在 `[600,80,400,650]`。

### 2.5 整档回写（220 mode 0，本批新增）

`Game::save_to` 以本局载入的存档（或新游戏的 `Save/System.sav`）为模板，写回：Part2 的 playtime / Sys3 / Sys4，
Part3 的 800 个通常变量与活着的公共事件 self 数值 + `CSelf5..9` 字符串，Part5 的当前图片表（`part5_from_screen`），
以及 `Databases::write_into` 收集的 CDataBase 运行时单元格。测试：`a_saved_game_reloads_its_live_picture_layer`
（66 张图逐字段相同）与 `a_saved_game_keeps_the_database_cells`（(0,12,5)=4242 保存后重新载入仍是 4242）。
唯一非字节等价的写回是 retail 文本图 escape 04（带字距字体）：语义上仍是 `\f[n]`，写回成 05。

## 3. `150` 图片指令的四个语义修正（M2 的核心发现）"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")