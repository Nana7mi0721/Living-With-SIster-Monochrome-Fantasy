
import struct, os, collections
base = r'work\full\MapData'
for f in sorted(os.listdir(base)):
    if not f.endswith('.mps'): continue
    b = open(os.path.join(base,f),'rb').read()
    o=16; o+=1+3+4+1
    n=struct.unpack_from('<I',b,o)[0]; o+=4+n
    ts,w,h,ec=struct.unpack_from('<IIII',b,o); o+=16
    fp=struct.unpack_from('<I',b,o)[0]
    if fp==0xFFFFFFFF: continue
    nc=w*h
    vals=struct.unpack_from('<%dI'%(nc*3),b,o)
    L=[vals[0:nc],vals[nc:2*nc],vals[2*nc:]]
    P=[[vals[i*3+k] for i in range(nc)] for k in range(3)]
    def neighbor_rate(X):
        out=[]
        for lay in X:
            same=0; tot=0
            for y in range(h):
                for x in range(w):
                    i=y*w+x
                    if x+1<w:
                        tot+=1; same += lay[i]==lay[i+1]
                    if y+1<h:
                        tot+=1; same += lay[i]==lay[i+w]
            out.append(round(same/tot,3))
        return out
    def empty_counts(X):
        return [sum(1 for v in lay if v==0xFFFFFFFF) for lay in X]
    def distinct(X):
        return [len(set(lay)) for lay in X]
    print('==',f,w,'x',h)
    print('   layer-major neighbor-rate', neighbor_rate(L), 'FF', empty_counts(L), 'distinct', distinct(L))
    print('   pixel-major neighbor-rate', neighbor_rate(P), 'FF', empty_counts(P), 'distinct', distinct(P))
