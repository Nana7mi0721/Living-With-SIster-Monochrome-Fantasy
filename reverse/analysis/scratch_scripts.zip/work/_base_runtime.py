import json, io
p = "docs/BASELINE.json"
d = json.load(io.open(p, encoding="utf-8"))
d["map_runtime"] = {
 "map": "MapData/SampleMapA.mps (64x36, 40 events, 134 pages)",
 "selection_rule": "per event, the highest page whose activation conditions hold; page 0 is not a fallback; an event whose conditions all fail does not run",
 "tracked_events": 40,
 "active_with_fresh_vm": 4,
 "active_triggers": {"1": 1, "2": 3},
 "active_events": [
  {"event": 0, "page": 0, "trigger": 1, "slots": 846, "title_kind": "new game processing (linear story script)"},
  {"event": 13, "page": 0, "trigger": 2, "slots": 2},
  {"event": 15, "page": 0, "trigger": 2, "slots": 295},
  {"event": 25, "page": 0, "trigger": 2, "slots": 34}
 ],
 "page_switch_probe": {"variable": 62, "event": 9, "pages": 10, "measured": {"1": 0, "5": 4, "10": 9, "99": None}},
 "parallel_restart_run": {"frames": 120, "pages": 3, "starts": 360, "instructions": 3720},
 "note": "An earlier revision started every automatic page unconditionally (87 pages, 21,023,494 instructions over 120 frames). That is superseded: page conditions cut the live set to 4 and 3,720 instructions. SampleMapA event 0 spins through a whole 200,000 instruction budget per frame when the host answers nothing (it is a story script waiting on messages and choices), so perf tests must exclude it with collect_except."
}
tmp = p + ".new"
io.open(tmp, "w", encoding="utf-8", newline="").write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")
import os; os.replace(tmp, p)
print("keys", len(d))
