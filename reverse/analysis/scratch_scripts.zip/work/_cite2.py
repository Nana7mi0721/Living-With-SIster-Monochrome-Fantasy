
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ma=json.load(open('work/_map_audit.json',encoding='utf-8'))
ev1=[e for e in ma['SampleMapA.mps']['events'] if e['id']==1][0]
for p in ev1['pages']:
    print('page',p['index'],'trigger',p.get('trigger'),'ncmds',len(p['cmds']))
    print('  conds:',json.dumps(p.get('conds'),ensure_ascii=False)[:300])
