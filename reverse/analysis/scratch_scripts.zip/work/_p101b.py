import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
d = json.load(io.open('work/wolftl/dump/db/DataBase.json', encoding='utf-8'))
print('type', type(d))
if isinstance(d, dict):
    print('keys', list(d.keys())[:20])
    for k,v in d.items():
        print(' ', k, type(v), (len(v) if hasattr(v,'__len__') else ''))
