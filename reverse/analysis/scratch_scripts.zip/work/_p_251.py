import json, io, collections
ce = json.load(io.open("work/_ce_full.json", encoding="utf-8"))
byid = {e["id"]: e for e in ce}
hist = collections.Counter()
sites = []
for e in ce:
    for i, c in enumerate(e["cmds"]):
        if c["c"] in (250, 251):
            hist[c["c"]] += 1
            if c["c"] == 251:
                sites.append((e["id"], i, c["a"], [s[:24] for s in c["s"]]))
print("hist", dict(hist))
print("251 sites", len(sites))
for s in sites[:40]:
    print(s)
print("=== ev48 head")
ev = byid[48]
print("cmds", len(ev["cmds"]))
for i, c in enumerate(ev["cmds"][:40]):
    print(i, "op", c["c"], "a", c["a"], "s", [x[:30] for x in c["s"]])