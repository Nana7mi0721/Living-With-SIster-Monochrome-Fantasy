
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(io.open('work/wolftl/dump/db/DataBase.json',encoding='utf-8'))
T=d.get('types') or []
print('userDB types',len(T))
for i,t in enumerate(T):
    print(i,repr(t.get('name')),'rows',len(t.get('data',[])),'fields',[f.get('name') for f in (t.get('fields') or [])][:8])
