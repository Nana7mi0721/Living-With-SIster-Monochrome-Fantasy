
// ---- VariableDatabase writer ------------------------------------------

impl VariableType {
    /// Encode one type exactly the way [VariableType::parse] reads it.
    ///
    /// `m_unknown` doubles as the field count when it is positive; when it is
    /// -1 or lower the real count lives in `m_fieldCount`, and `m_dis` is
    /// only present at -2 or lower. Every retail save here stores -2, which is
    /// why the four fields below all round-trip, but the other two shapes are
    /// written too so a hand-built database encodes like the game writes it.
    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        let mut out = Vec::with_capacity(8 + self.config.len() * 4 + self.rows.len() * 8);
        push_i32(&mut out, self.unknown);
        if self.unknown <= -1 {
            if self.unknown <= -2 {
                push_i32(&mut out, self.dis);
            }
            push_u32(&mut out, self.field_count);
        }
        for def in &self.config {
            push_u32(&mut out, *def);
        }
        push_u32(&mut out, self.row_count);
        if self.rows.len() != self.row_count as usize {
            return Err(Error::field(
                "VariableType rows",
                out.len(),
                format!(
                    "m_typeDataCount says {} row(s) but {} were stored",
                    self.row_count,
                    self.rows.len()
                ),
            ));
        }
        for (index, row) in self.rows.iter().enumerate() {
            if row.index as usize != index {
                return Err(Error::field(
                    "VariableType row index",
                    out.len(),
                    format!("row {index} claims to be row {}", row.index),
                ));
            }
            row.to_bytes(&mut out, &self.config)?;
        }
        Ok(out)
    }
}

impl VariableRow {
    /// One row: every numeric field in config order, then every textual one.
    ///
    /// [VariableRow::parse] sorts the two passes back together by id, so the
    /// in-memory order is field order while the on-disk order is kind order.
    /// This function therefore walks `config`, not `fields`.
    pub fn to_bytes(&self, out: &mut Vec<u8>, config: &[u32]) -> Result<()> {
        let mut seen = vec![false; config.len()];
        for (id, def) in config.iter().enumerate() {
            if *def < 2000 {
                match self.number(id as u32) {
                    Some(value) => push_i32(out, value),
                    None => {
                        return Err(Error::field(
                            "VariableRow number",
                            out.len(),
                            format!("row {} is missing numeric field {id}", self.index),
                        ))
                    }
                }
                seen[id] = true;
            }
        }
        for (id, def) in config.iter().enumerate() {
            if *def >= 2000 {
                match self.string(id as u32) {
                    Some(body) => push_mem_data(out, body, 4)?,
                    None => {
                        return Err(Error::field(
                            "VariableRow string",
                            out.len(),
                            format!("row {} is missing textual field {id}", self.index),
                        ))
                    }
                }
                seen[id] = true;
            }
        }
        // A field id that the config does not know would be dropped silently by
        // the loop above; refuse instead, so a hand-edited row cannot write a
        // file that parses back with fewer fields than it started with.
        for field in &self.fields {
            let id = field.id as usize;
            if id >= config.len() || !seen[id] {
                return Err(Error::field(
                    "VariableRow field",
                    out.len(),
                    format!(
                        "row {} holds field id {id}, which is not a numeric or textual entry of this type's {} field config",
                        self.index,
                        config.len()
                    ),
                ));
            }
        }
        Ok(())
    }
}

impl VariableDatabase {
    /// Encode the whole segment exactly the way [vardb::parse] reads it.
    ///
    /// The nine retail saves re-encode to their original bytes (see
    /// `tests/rebuild.rs`), which is the proof this mirrors the game.
    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        let mut out = Vec::with_capacity(5 + self.types.len() * 8);
        push_u8(&mut out, self.unknown);
        push_u32(&mut out, self.type_count);
        if self.types.len() != self.type_count as usize {
            return Err(Error::field(
                "VariableDatabase types",
                out.len(),
                format!(
                    "m_typeCount says {} type(s) but {} were stored",
                    self.type_count,
                    self.types.len()
                ),
            ));
        }
        for kind in &self.types {
            out.extend_from_slice(&kind.to_bytes()?);
        }
        Ok(out)
    }

    /// One type, or None when the index is past the end.
    #[must_use]
    pub fn type_of(&self, type_index: usize) -> Option<&VariableType> {
        self.types.get(type_index)
    }

    /// One row of one type.
    #[must_use]
    pub fn row(&self, type_index: usize, row_index: usize) -> Option<&VariableRow> {
        self.types.get(type_index)?.rows.get(row_index)
    }

    /// The numeric value of one cell, or None when it is out of range, the field
    /// is textual, or the field id is absent.
    #[must_use]
    pub fn number(&self, type_index: usize, row_index: usize, field_index: usize) -> Option<i32> {
        self.row(type_index, row_index)?
            .number(u32::try_from(field_index).ok()?)
    }

    /// The string body of one cell, with the same None rules as
    /// [VariableDatabase::number].
    #[must_use]
    pub fn string(&self, type_index: usize, row_index: usize, field_index: usize) -> Option<&[u8]> {
        self.row(type_index, row_index)?
            .string(u32::try_from(field_index).ok()?)
    }

    /// The string body of one cell decoded the way the game shows it.
    #[must_use]
    pub fn text(&self, type_index: usize, row_index: usize, field_index: usize) -> Option<String> {
        self.string(type_index, row_index)
            .map(crate::mem_string)
    }

    /// Whether the config entry for this field says "numeric".
    #[must_use]
    pub fn is_number_field(&self, type_index: usize, field_index: usize) -> Option<bool> {
        self.type_of(type_index)?
            .config
            .get(field_index)
            .map(|def| *def < 2000)
    }

    /// Write one numeric cell, adding the field when the id is absent.
    ///
    /// Returns false (and changes nothing) when the type, the row or the field
    /// id does not exist, or when the field is textual -- a wrong-kind write
    /// would be silently dropped by [VariableDatabase::to_bytes], so it is
    /// refused here instead.
    pub fn set_num(&mut self, type_index: usize, row_index: usize, field_index: usize, value: i32) -> bool {
        let Some(config_def) = self
            .types
            .get(type_index)
            .and_then(|kind| kind.config.get(field_index))
        else {
            return false;
        };
        if *config_def >= 2000 {
            return false;
        }
        let Some(kind) = self.types.get_mut(type_index) else {
            return false;
        };
        let Some(row) = kind.rows.get_mut(row_index) else {
            return false;
        };
        row.put_field(field_index as u32, VariableValue::Number(value));
        true
    }

    /// Write one textual cell, adding the field when the id is absent.
    ///
    /// The body is stored verbatim, NUL terminator included -- pass the bytes
    /// the game stores, not a bare string. Use [VariableDatabase::set_text] for
    /// the common case where the caller has a &str.
    pub fn set_string(
        &mut self,
        type_index: usize,
        row_index: usize,
        field_index: usize,
        body: &[u8],
    ) -> bool {
        let Some(config_def) = self
            .types
            .get(type_index)
            .and_then(|kind| kind.config.get(field_index))
        else {
            return false;
        };
        if *config_def < 2000 {
            return false;
        }
        let Some(kind) = self.types.get_mut(type_index) else {
            return false;
        };
        let Some(row) = kind.rows.get_mut(row_index) else {
            return false;
        };
        row.put_field(field_index as u32, VariableValue::String(body.to_vec()));
        true
    }

    /// Write one textual cell from a &str, appending the NUL the game stores.
    pub fn set_text(
        &mut self,
        type_index: usize,
        row_index: usize,
        field_index: usize,
        text: &str,
    ) -> bool {
        let mut body = text.as_bytes().to_vec();
        body.push(0);
        self.set_string(type_index, row_index, field_index, &body)
    }
}

impl VariableRow {
    /// Replace the field with this id, or insert it keeping the id order.
    fn put_field(&mut self, id: u32, value: VariableValue) {
        match self.fields.iter().position(|field| field.id == id) {
            Some(at) => self.fields[at].value = value,
            None => {
                let at = self
                    .fields
                    .iter()
                    .position(|field| field.id > id)
                    .unwrap_or(self.fields.len());
                self.fields.insert(at, VariableField { id, value });
            }
        }
    }
}
