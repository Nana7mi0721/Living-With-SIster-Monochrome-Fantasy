
import json
p = 'docs/BASELINE.json'
raw = open(p, encoding='utf-8').read()
lines = raw.split('\n')
# detect indentation of a top-level member line
member_indent = None
for ln in lines:
    if ln.strip().startswith('"Game.dat"'):
        member_indent = ln[:len(ln)-len(ln.lstrip())]
        break
print('member indent', repr(member_indent))
top = member_indent[:-1] if member_indent else '  '
print('top indent', repr(top))
idx = max(i for i, ln in enumerate(lines) if ln.strip() == '}')
print('closing at line', idx+1, 'total', len(lines))
print('prev line repr', repr(lines[idx-1]))
print('prev2 repr', repr(lines[idx-2]))
