import io,os,struct,sys,zlib
sys.stdout.reconfigure(encoding='utf-8')
def readpng(p):
    d=open(p,'rb').read()
    pos=8; w=h=bd=ct=None; idat=b''
    while pos<len(d):
        ln=struct.unpack('>I',d[pos:pos+4])[0]; typ=d[pos+4:pos+8]; data=d[pos+8:pos+8+ln]; pos+=12+ln
        if typ==b'IHDR': w,h,bd,ct=struct.unpack('>IIBB',data[:10])
        elif typ==b'IDAT': idat+=data
        elif typ==b'IEND': break
    raw=zlib.decompress(idat)
    nch={0:1,2:3,3:1,4:2,6:4}[ct]
    stride=w*nch
    out=bytearray(h*stride); prev=bytearray(stride); i=0
    for y in range(h):
        f=raw[i]; i+=1
        line=bytearray(raw[i:i+stride]); i+=stride
        if f==1:
            for x in range(nch,stride): line[x]=(line[x]+line[x-nch])&0xFF
        elif f==2:
            for x in range(stride): line[x]=(line[x]+prev[x])&0xFF
        elif f==3:
            for x in range(stride):
                a=line[x-nch] if x>=nch else 0
                line[x]=(line[x]+((a+prev[x])>>1))&0xFF
        elif f==4:
            for x in range(stride):
                a=line[x-nch] if x>=nch else 0
                b=prev[x]; c=prev[x-nch] if x>=nch else 0
                pa=abs(b-c); pb=abs(a-c); pc=abs(a+b-2*c)
                pr=a if (pa<=pb and pa<=pc) else (b if pb<=pc else c)
                line[x]=(line[x]+pr)&0xFF
        out[y*stride:(y+1)*stride]=line; prev=line
    return w,h,nch,out
import glob
targets=[(242,243,243),(217,220,221),(87,96,98)]
for f in sorted(glob.glob('work/out/*.png')):
    try:
        w,h,nch,px=readpng(f)
    except Exception as e:
        continue
    if nch<3 or w!=1024 or h!=576: continue
    best=None
    for t in targets:
        xs=[];ys=[];c=0
        for y in range(h):
            base=y*w*nch
            for x in range(w):
                o=base+x*nch
                if abs(px[o]-t[0])<=2 and abs(px[o+1]-t[1])<=2 and abs(px[o+2]-t[2])<=2:
                    c+=1; xs.append(x); ys.append(y)
        if c>800:
            print('%-46s t=%s n=%5d bbox x%4d..%4d y%4d..%4d'%(os.path.basename(f),t,c,min(xs),max(xs),min(ys),max(ys)))
            break