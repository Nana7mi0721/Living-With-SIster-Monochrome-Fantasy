
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(io.open('work/wolftl/dump/db/DataBase.json',encoding='utf-8'))
T=d['types']
for ti in (16,17,26):
    t=T[ti]
    print('=== type',ti,repr(t.get('name')))
    for ri,row in enumerate(t['data'][:9]):
        vals=[(f.get('name'),f.get('value')) for f in (row.get('data') or [])]
        print(' row%d'%ri, json.dumps(vals,ensure_ascii=False)[:400])
