# -*- coding: utf-8 -*-
"""Which self/global variable holds each high picture number (12004/12005/12053/
12054/12500/12501/12502)?  Scan the title closure for 121 SetVariable writes whose
value equals one of those numbers, then list the 150 sites that read that var.
"""
import collections, io, json

events = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
map_evs = {e['id']: e for e in tm['events']}
clos = json.load(io.open('work/_m1_closure2.json', encoding='utf-8'))
rows = clos['from_map_event2']['reached']

def norm(cmds):
    out = []
    for c in cmds:
        if 'c' in c:
            out.append({'c': c['c'], 'a': [int(x) for x in c['a']], 's': list(c.get('s') or [])})
        else:
            out.append({'c': c.get('code', 0),
                        'a': [int(x) for x in (c.get('intArgs') or [])],
                        's': list(c.get('stringArgs') or [])})
    return out

TARGETS = {12004, 12005, 12053, 12054, 12500, 12501, 12502}
bynum = collections.defaultdict(list)
allsites = []
for r in rows:
    if r['kind'] == 'c':
        cmds = norm(by_id[r['id']]['cmds']); tag = 'c%d' % r['id']
    else:
        cmds = []
        for p in map_evs[r['id']]['pages']:
            cmds.extend(norm(p['list']))
        tag = 'm%d' % r['id']
    for i, c in enumerate(cmds):
        if c['c'] == 121 and c['a']:
            target = c['a'][0]
            val = None
            for cand in c['a'][1:]:
                if cand in TARGETS:
                    val = cand
            if val:
                bynum[val].append('%s slot %d  121 target=%d args=%s' % (tag, i, target, c['a']))
        if c['c'] == 150 and len(c['a']) >= 2:
            allsites.append((tag, i, c['a'][0], c['a'][1]))

for num in sorted(bynum):
    print('#%d written by:' % num)
    for line in bynum[num]:
        print('   ', line)
print('')
print('=== 150 sites whose picture number is a variable (num_raw >= 1000000) ===')
seen = collections.Counter()
for tag, i, head, num in allsites:
    if num >= 1000000:
        seen[(tag, num)] += 1
for (tag, num), n in sorted(seen.items()):
    print('  %-7s num_raw=%-8d sites=%d' % (tag, num, n))
