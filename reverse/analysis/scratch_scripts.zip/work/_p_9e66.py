import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """        save.set_part3(&part3)
            .map_err(|err| format!("220 SaveLoad: cannot encode part3: {err}"))?;

        let bytes = save"""
b = """        save.set_part3(&part3)
            .map_err(|err| format!("220 SaveLoad: cannot encode part3: {err}"))?;

        // The picture table is the frame the player saved on. Rebuilding it from the live
        // Screen (rather than keeping the template Part5) is what makes a saved game look
        // like the scene the player was in when they pressed save.
        let part5 = crate::savegame::part5_from_screen(&self.screen);
        save.set_part5(&part5)
            .map_err(|err| format!("220 SaveLoad: cannot encode part5: {err}"))?;

        let bytes = save"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")