
import json, collections, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('E:/Study/github program/imoto life/work/_ce_full.json', encoding='utf-8'))
maps = json.load(open('E:/Study/github program/imoto life/work/maps_full.json', encoding='utf-8'))
hits = collections.Counter()
samples = []
for ev in ce:
    for i,c in enumerate(ev['cmds']):
        for j,v in enumerate(c['a']):
            if v == 1600004:
                hits[(c['c'], j)] += 1
                if len(samples) < 12:
                    samples.append((ev['id'], ev['cmds'][i]['c'], i, c['a'], c['s']))
for mname,m in maps.items():
    for e in m.get('events') or []:
        for i,c in enumerate(e.get('cmds') or []):
            for j,v in enumerate(c.get('ints') or []):
                if v == 1600004:
                    hits[(c['code'], j)] += 1
print("opcode/argindex:", dict(hits))
for s in samples:
    print(s[0], "code", s[1], "pc", s[2], s[3], s[4])
