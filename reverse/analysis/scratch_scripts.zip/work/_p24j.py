import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
CE = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by = {e['id']: e for e in CE}

def writes(eid, target):
    e = by[eid]
    out = []
    for k, c in enumerate(e['cmds']):
        if c['c'] in (121, 122, 124) and c['a'] and c['a'][0] == target:
            out.append((k, c['c'], c['a'], [t[:50] for t in c['s']]))
    return out

for eid, targets in ((94, [1600050, 1600010, 1600011]), (131, [1600005, 1600012, 1600001])):
    for t in targets:
        print('ev%d writes to %d:' % (eid, t))
        for w in writes(eid, t):
            print('   pc%-4d op%-4d %s %s' % (w[0], w[1], w[2], w[3]))
        print()

# ev131: the two 220 sites context
e = by[131]
for k in (233, 268):
    print('--- ev131 pc%d' % k)
    for j in range(max(0,k-6), min(len(e['cmds']), k+8)):
        x = e['cmds'][j]
        print('   %3d %3d %s %s' % (j, x['c'], x['a'], [t[:44] for t in x['s']]))
print()
# ev38 / ev436 / ev426 / ev223 220 context
for eid in (38, 223, 426, 436, 435):
    e = by[eid]
    for j, x in enumerate(e['cmds']):
        if x['c'] == 220:
            print('--- ev%d pc%d' % (eid, j))
            for k in range(max(0,j-5), min(len(e['cmds']), j+5)):
                y = e['cmds'][k]
                print('   %3d %3d %s %s' % (k, y['c'], y['a'], [t[:44] for t in y['s']]))
