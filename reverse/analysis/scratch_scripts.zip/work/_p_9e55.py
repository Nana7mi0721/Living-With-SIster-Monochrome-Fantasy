import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a))
    t = t.replace(a, b)

rep("""    save_requests: Vec<crate::savegame::SaveRequest>,""", """    save_requests: Vec<crate::savegame::SaveRequest>,
    /// The last save this game loaded or was born from, used as the template for
    /// 220 mode 0. A full save needs the map snapshot and object tables, which the
    /// running game does not otherwise keep; the template supplies them and the
    /// dynamic parts (play time, system anchor, normal variables, self variables)
    /// are copied from the live VM before writing.
    pub base_save: Option<wolf_save::SaveFile>,""")

rep("""        let databases = Databases::load(&basic, screen);
        Ok(Self {""", """        let databases = Databases::load(&basic, screen);
        // System.sav is a complete save file in this game: use it as the template so a
        // brand-new game can write its first save without inventing part1/part4.
        let base_save = crate::savegame::read_save(&root.join("Save").join("System.sav")).ok();
        Ok(Self {""")

rep("""            save_requests: Vec::new(),
            root,""", """            save_requests: Vec::new(),
            base_save,
            root,""")

rep("""    pub fn set_playtime_frames(&mut self, frames: u32) {
        self.playtime_frames = frames;
    }""", """    pub fn set_playtime_frames(&mut self, frames: u32) {
        self.playtime_frames = frames;
    }

    /// Writes the live game state to a save file.
    ///
    /// The map snapshot and object tables come from the base_save field (the save this
    /// game was loaded from, or System.sav for a new game); the pieces that change while
    /// playing are copied from the VM: play time, the Sys3/Sys4 choice anchor, the 800
    /// normal variables, and the self variables / self strings of every live common-event
    /// coroutine. Returns the number of encrypted bytes written.
    ///
    /// # Errors
    ///
    /// Fails when no template save is available or when a part cannot be encoded.
    pub fn save_to(&mut self, path: &Path) -> Result<usize, String> {
        let Some(mut save) = self.base_save.clone() else {
            return Err("220 SaveLoad: no template save (Save/System.sav is missing)".to_string());
        };

        let mut part2 = save.part2.clone();
        part2.vars3_21[0] = self.playtime_frames;
        part2.vars3_21[9] = self.vm.vars.get_sys(3) as u32;
        part2.vars3_21[10] = self.vm.vars.get_sys(4) as u32;
        save.set_part2(&part2)
            .map_err(|err| format!("220 SaveLoad: cannot encode part2: {err}"))?;

        let mut part3 = save.part3.clone();
        for index in 0..800 {
            let _ = part3.set_normal_var(index, self.vm.vars.get(index));
        }
        for instance in self.vm.instances() {
            if instance.program.self_base != wolf_vm::program::COMMON_SELF_BASE {
                continue;
            }
            let event = instance.event;
            for slot in 0..100 {
                let value = instance.self_vars.get(instance.program.self_base + slot);
                let _ = part3.set_self_var(event, slot, value);
            }
            for slot in 0..5 {
                let text = instance
                    .self_vars
                    .get_str(instance.program.self_base + 5 + slot);
                let _ = part3.set_self_string(event, slot, text);
            }
        }
        save.set_part3(&part3)
            .map_err(|err| format!("220 SaveLoad: cannot encode part3: {err}"))?;

        let bytes = save
            .to_bytes_rebuilt()
            .map_err(|err| format!("220 SaveLoad: cannot rebuild save: {err}"))?;
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|err| format!("220 SaveLoad: cannot create {}: {err}", parent.display()))?;
        }
        std::fs::write(path, &bytes)
            .map_err(|err| format!("220 SaveLoad: cannot write {}: {err}", path.display()))?;
        self.base_save = Some(save);
        Ok(bytes.len())
    }""")

io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("patched")
