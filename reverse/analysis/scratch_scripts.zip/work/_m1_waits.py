# -*- coding: utf-8 -*-
"""Where the title closure blocks: every 180 (Wait), 102 (Choices) and 123
(InputKey) site, plus 170/179/498 loop scaffolding, per event+slot."""
import collections, io, json

events = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
map_evs = {e['id']: e for e in tm['events']}
clos = json.load(io.open('work/_m1_closure2.json', encoding='utf-8'))
rows = clos['from_map_event2']['reached']

def norm(cmds):
    out = []
    for c in cmds:
        if 'c' in c:
            out.append({'c': c['c'], 'a': [int(x) for x in c['a']], 's': list(c.get('s') or [])})
        else:
            out.append({'c': c.get('code', 0),
                        'a': [int(x) for x in (c.get('intArgs') or [])],
                        's': list(c.get('stringArgs') or [])})
    return out

WANT = {180: 'Wait', 102: 'Choices', 123: 'InputKey', 175: 'EndGame'}
order = []
for r in rows:
    if r['kind'] == 'c':
        cmds = norm(by_id[r['id']]['cmds'])
        tag = 'c%d' % r['id']
    else:
        cmds = []
        for p in map_evs[r['id']]['pages']:
            cmds.extend(norm(p['list']))
        tag = 'm%d' % r['id']
    for i, c in enumerate(cmds):
        if c['c'] in WANT:
            order.append((tag, i, c['c'], c['a'], c['s']))

for c in (180, 102, 123, 175):
    sub = [x for x in order if x[2] == c]
    print('=== %d %s : %d site(s) ===' % (c, WANT[c], len(sub)))
    for tag, i, _, a, s in sub:
        print('  %-7s slot %-4d args=%s %s' % (tag, i, a, s if s else ''))
    print('')
