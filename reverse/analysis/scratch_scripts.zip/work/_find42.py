
import json
d = json.load(open('work/_ce_full.json', encoding='utf-8'))
ce = d['events'] if isinstance(d, dict) else d
mp = json.load(open('work/maps_full.json', encoding='utf-8'))
def calls(cmds, target):
    out=[]
    for i,c in enumerate(cmds):
        if c['code'] in (210,211,300):
            a=c.get('ints') or []
            if a and a[0]==target:
                out.append((i,c['code'],a))
    return out
print('CE callers of 42:', [(e['id'], calls(e['cmds'],500042)) for e in ce if calls(e['cmds'],500042)])
for name,m in mp.items():
    for ev in m['events']:
        cmds = ev.get('commands')
        if cmds is None:
            print('no commands key for', name, ev['id'], list(ev.keys())); continue
        r = calls(cmds, 500042)
        if r: print('MAP', name, 'ev', ev['id'], r)
