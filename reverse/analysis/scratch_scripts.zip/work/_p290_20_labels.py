
import zipfile, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')

def parse(a, b):
    out = []; i = a
    while i + 2 <= b:
        n = int.from_bytes(data[i:i+2], 'little')
        if 1 <= n <= 80 and i + 2 + 2*n <= b:
            try: s = data[i+2:i+2+2*n].decode('utf-16-le')
            except Exception: s = None
            if s and all(ord(c) >= 0x20 for c in s):
                out.append((i, n, s)); i += 2 + 2*n; continue
        i += 1
    return out

print('### param labels region')
for (off, n, s) in parse(0xa848a0, 0xa84b60):
    print(hex(off), n, s)

print()
print('### 色調整 / カラー補正 formatter context')
for m in re.finditer(re.escape('色調整'.encode('utf-16-le')), data):
    i = m.start()
    seg = data[max(0,i-200):i+320]
    s = seg.decode('utf-16-le', errors='replace')
    print(hex(i), ''.join(c if 0x20 <= ord(c) < 0xfffd else '·' for c in s))
