
import os,io,hashlib
G=r'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
def md5(p):
    h=hashlib.md5()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
tot=0; n=0
for root,ds,fs in os.walk(G):
    for f in fs:
        p=os.path.join(root,f)
        try: tot+=os.path.getsize(p); n+=1
        except OSError: pass
W('install total %d files / %d B'%(n,tot))
for sub in ['','Data']:
    d=os.path.join(G,sub); s=0; c=0
    for root,ds,fs in os.walk(d):
        for f in fs:
            p=os.path.join(root,f)
            if sub=='' and os.path.dirname(p)!=G: continue
            try: s+=os.path.getsize(p); c+=1
            except OSError: pass
    W('  %-6s %d files / %d B'%(sub or 'root',c,s))
W('\n-- top-level files by size --')
rows=[]
for f in os.listdir(G):
    p=os.path.join(G,f)
    if os.path.isfile(p): rows.append((os.path.getsize(p),f))
for s,f in sorted(rows,reverse=True)[:30]: W('%12d  %s'%(s,f))
W('\n-- fonts anywhere in install --')
for root,ds,fs in os.walk(G):
    for f in fs:
        if f.lower().endswith(('.ttf','.otf')):
            p=os.path.join(root,f)
            W('%10d  %-60s %s'%(os.path.getsize(p),os.path.relpath(p,G),md5(p)[:12]))
open(r'E:\Study\github program\imoto life\work\_audit_out34.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
