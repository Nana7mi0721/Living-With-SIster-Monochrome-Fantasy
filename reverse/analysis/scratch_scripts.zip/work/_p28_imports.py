import io, os
root = r'E:/Study/github program/imoto life'
def read(p):
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()
def write(p, s):
    with io.open(p + '.new', 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    os.replace(p + '.new', p)
def patch(rel, old, new):
    p = os.path.join(root, rel)
    s = read(p)
    assert old in s, rel + ' anchor missing'
    write(p, s.replace(old, new, 1))

patch('crates/wolf-save/src/part1.rs',
      'use crate::{ensure_fits, mem_data, signed_count};',
      'use crate::{ensure_fits, mem_data, push_count, push_mem_data, push_u16, push_u32, push_u8, signed_count};')
patch('crates/wolf-save/src/part2.rs',
      'use crate::{ensure_fits, mem_data, signed_count};',
      'use crate::{ensure_fits, mem_data, push_count, push_mem_data, push_u16, push_u32, push_u8, signed_count};')
patch('crates/wolf-save/src/part4.rs',
      'use crate::{ensure_fits, signed_count};',
      'use crate::{ensure_fits, push_count, push_u32, push_u64, push_u8, signed_count};')
patch('crates/wolf-save/src/part5.rs',
      'use wolf_format::error::Result;',
      'use wolf_format::error::{Error, Result};')
patch('crates/wolf-save/src/part5.rs',
      'use crate::{ensure_fits, mem_data, signed_count};',
      'use crate::{ensure_fits, mem_data, push_count, push_mem_data, push_u16, push_u32, push_u8, signed_count};')
print('patched')