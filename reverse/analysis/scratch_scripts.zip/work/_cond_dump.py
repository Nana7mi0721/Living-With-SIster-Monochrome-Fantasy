import json, collections
pages=json.load(open("work/_sw3.json"))
byev=collections.defaultdict(list)
for p in pages: byev[(p["map"],p["eid"])].append(p)

def dump(mapname, eids=None):
    print("=== ", mapname)
    for (m,eid),ps in sorted(byev.items()):
        if m!=mapname: continue
        if eids is not None and eid not in eids: continue
        print(" ev", eid, "pages", len(ps))
        for p in ps:
            conds=[(j,hex(p["sw"][j]),p["vars"][j][0],p["vars"][j][1]) for j in range(4) if p["sw"][j]&0xF]
            print("   pg",p["pi"],"trig",p["trig"],"conds",conds)

dump("SampleMapA.mps", {8,9,10,11})
dump("Dungeon.mps", {3})
dump("Map002.mps", {3})
print()
print("== mixed-trigger multi-page events")
for (m,eid),ps in sorted(byev.items()):
    if len(ps)>1 and len({p["trig"] for p in ps})>1:
        print(" ",m,eid,[(p["pi"],p["trig"]) for p in ps])
