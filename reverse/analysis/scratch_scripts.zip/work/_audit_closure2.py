
import json,io,collections
OUT=io.StringIO()
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
by_id={e['id']:e for e in lst}
by_title={}
for e in lst: by_title.setdefault(e['title'],e['id'])
def norm(cmds):
    out=[]
    for c in cmds:
        if 'c' in c: out.append((int(c['c']),[int(x) for x in c.get('a') or []],list(c.get('s') or [])))
        else: out.append((int(c.get('code',0)),[int(x) for x in (c.get('ints') or [])],list(c.get('strs') or [])))
    return out
def d210(raw):
    if 500000<=raw<=599999: return raw-500000
    if 600000<=raw<=699999: return raw-600000
    return None
edges=collections.defaultdict(set)
for e in lst:
    for op,a,s in norm(e['cmds']):
        if op==210 and a:
            t=d210(a[0])
            if t is not None and t in by_id: edges[('c',e['id'])].add(('c',t))
        elif op==300 and s:
            t=by_title.get(s[0])
            if t is not None: edges[('c',e['id'])].add(('c',t))
mf=json.load(open('work/maps_full.json',encoding='utf-8'))
for k,v in mf.items():
    for e in v['events']:
        for op,a,s in norm(e['cmds']):
            if op==210 and a:
                t=d210(a[0])
                if t is not None and t in by_id: edges[('m',k,e['id'])].add(('c',t))
            elif op==300 and s:
                t=by_title.get(s[0])
                if t is not None: edges[('m',k,e['id'])].add(('c',t))
cl=json.load(open('work/_audit_closure.json',encoding='utf-8'))
reg=cl['reg']
def closure(seeds):
    seen=set(); stack=list(seeds)
    while stack:
        cur=stack.pop()
        if cur in seen: continue
        seen.add(cur)
        for n in edges[cur]:
            if n not in seen: stack.append(n)
    return seen
auto=[e['id'] for e in lst if e.get('run')]
OUT.write('auto-start common events (run!=0): %d -> %s\n'%(len(auto),auto[:20]))
seeds=[('c',i) for i in auto]
for idx,f in reg.items():
    if f in mf:
        for e in mf[f]['events']: seeds.append(('m',f,e['id']))
game=closure(seeds)
gcreach=sorted(k[1] for k in game if k[0]=='c')
dead=sorted(set(e['id'] for e in lst)-set(gcreach))
OUT.write('seeds: %d\n'%len(seeds))
OUT.write('whole-game closure WITH auto-start: %d nodes (%d common, %d map)\n'%(
    len(game),len(gcreach),len([k for k in game if k[0]=='m'])))
OUT.write('still-dead common events: %d\n%s\n'%(len(dead),dead))
# are any dead events having run!=0 ?
OUT.write('dead with run!=0: %s\n'%[i for i in dead if by_id[i].get('run')])
# boot closure unchanged?
boot=closure([('m','TitleMap.mps',2)])
OUT.write('boot closure (TitleMap ev2): %d nodes, common %d\n'%(len(boot),len([k for k in boot if k[0]=='c'])))
boot2=closure([('m','TitleMap.mps',2)]+[('c',i) for i in auto])
OUT.write('boot+auto closure: %d nodes, common %d\n'%(len(boot2),len([k for k in boot2 if k[0]=='c'])))
json.dump({'game2':sorted(str(k) for k in game),'gcreach2':gcreach,'dead2':dead,'boot2':sorted(str(k) for k in boot2)},
          open('work/_audit_closure2.json','w',encoding='utf-8'),ensure_ascii=False)
open('work/_audit_out12.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
