
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ce}
SELF=1000000
sites=[]
for e in ce:
    cm=e['cmds']
    for i,c in enumerate(cm):
        if c['c']!=250 or not c['a']: continue
        if not (isinstance(c['a'][1],int) and c['a'][1]<0): continue
        sites.append((e['id'],i))
def prior_writes(eid,pc,slot):
    cm=by[eid]['cmds']; hits=[]
    for j in range(0,pc):
        c=cm[j]
        if c['c'] in (121,124) and c['a'] and c['a'][0]==slot:
            hits.append((j,c['c'],c['a']))
        if c['c']==123 and c['a'] and c['a'][0]==slot:
            hits.append((j,c['c'],c['a']))
    return hits
for eid,pc in sites:
    c=by[eid]['cmds'][pc]; a=c['a']
    fl=a[3] if len(a)>3 else 0
    val=a[4] if len(a)>4 else None
    info=''
    if val is None: info='no value arg'
    elif 1600000<=val<1700000:
        s=val-1000000
        pw=prior_writes(eid,pc,s)
        info='self%d written-before=%d %s'%(s,len(pw),pw[-2:] if pw else '')
    elif 1000000<=val<1100000: info='arg self[%d]'%(val-1000000)
    else: info='literal %s'%val
    print('CE%-4d pc%-4d type=%-3d row=%d val=%-8s %s'%(eid,pc,a[0],a[1],val,info))
