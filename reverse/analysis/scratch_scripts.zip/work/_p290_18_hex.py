
import zipfile, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')
# hexdump the region where 点滅A sits, to count how many literals are between it and 点滅B
seg = data[0xa84820:0xa84890]
print(' '.join('%02x'%b for b in seg))
print(seg.decode('utf-16-le', errors='replace'))
