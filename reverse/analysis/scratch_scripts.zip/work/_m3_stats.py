
import json,os,collections,re
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=sorted(json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"])
L=[]
def p(s=""): L.append(s)

op=collections.Counter(); instr=0; slots=0
for i in H:
    slots+=len(idx[i]["cmds"])
    for c in idx[i]["cmds"]:
        if c["c"]:
            op[c["c"]]+=1; instr+=1
p("## H closure totals: %d events, %d slots, %d instr, %d opcodes"%(len(H),slots,instr,len(op)))
p(", ".join("%d:%d"%(k,v) for k,v in op.most_common()))

# assets
p("")
p("## assets referenced by H closure")
files=collections.Counter(); snd=collections.Counter()
for i in H:
    for c in idx[i]["cmds"]:
        o=c["c"]; s=c.get("s") or []
        for x in s:
            if not isinstance(x,str): continue
            if re.search(r"\.(png|jpg|jpeg|bmp|webp|gif)$",x,re.I):
                if o==150: files[x]+=1
            elif re.search(r"\.(mp3|ogg|wav|mid|m4a)$",x,re.I):
                if o==140: snd[x]+=1
def size(rel):
    for base in ("all","full"):
        q=os.path.join(W,base,rel)
        if os.path.isfile(q): return os.path.getsize(q)
    return -1
tot=0; miss=[]; bydir=collections.Counter(); bydirN=collections.Counter()
for k,v in files.items():
    s=size(k)
    if s<0: miss.append(k)
    else:
        tot+=s; bydir[k.split("/")[0]]+=s; bydirN[k.split("/")[0]]+=1
p("distinct image paths %d, resolved %d, missing %d, bytes %d"%(len(files),len(files)-len(miss),len(miss),tot))
p("by dir: "+", ".join("%s %d files %d B"%(d,bydirN[d],bydir[d]) for d in sorted(bydir,key=lambda x:-bydir[x])))
p("missing: "+", ".join(sorted(miss)[:40]))
st=0; sm=[]
for k,v in snd.items():
    s=size(k)
    if s<0: sm.append(k)
    else: st+=s
p("distinct sound paths %d resolved %d missing %d bytes %d"%(len(snd),len(snd)-len(sm),len(sm),st))
p("sound missing: "+", ".join(sorted(sm)[:20]))
open(os.path.join(W,"_m3_out8.txt"),"w",encoding="utf-8").write("\n".join(L))
print("\n".join(L))
