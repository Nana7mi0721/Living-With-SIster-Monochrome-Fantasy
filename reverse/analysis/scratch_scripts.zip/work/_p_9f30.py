import json
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
hits=[]
for ev in ce:
    for i,c in enumerate(ev['cmds']):
        if c['c']!=250: continue
        a=c['a']
        if len(a)>2 and a[0]==18 and a[2]==22: hits.append((ev['id'],i,a))
        if len(a)>2 and a[0]==18 and a[2]==24: pass
print('18/x/22 sites:', hits[:10], 'count', len(hits))
# also count all 18/x/* column histogram
import collections
col=collections.Counter()
for ev in ce:
    for c in ev['cmds']:
        if c['c']==250 and len(c['a'])>2 and c['a'][0]==18: col[(c['a'][1],c['a'][2])]+=1
print('db18 (row,col) histogram:', col.most_common(12))
