import io, os
for path, pairs in [
    ("crates/wolf-game/src/game.rs", [
        ("""        // Age the UI state after the VM ran, so a message shown this frame is 0 frames old.
        for message in &mut self.messages {""", """        // One more frame of play time; the save stores this in SavePart2.vars3_21[0].
        self.playtime_frames = self.playtime_frames.saturating_add(1);
        // Age the UI state after the VM ran, so a message shown this frame is 0 frames old.
        for message in &mut self.messages {"""),
    ]),
    ("crates/wolf-game/src/savegame.rs", [
        ("""    // Playtime is the first word of SavePart2's variable tail.
    loaded.playtime_frames = save.part2.vars3_21.first().copied().unwrap_or(0);""", """    // Playtime is the first word of SavePart2's variable tail.
    loaded.playtime_frames = save.part2.vars3_21.first().copied().unwrap_or(0);
    game.set_playtime_frames(loaded.playtime_frames);"""),
    ]),
]:
    t = io.open(path, encoding="utf-8", newline="").read()
    for a, b in pairs:
        assert t.count(a) == 1, (path, a, t.count(a))
        t = t.replace(a, b)
    io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
    os.replace(path + ".new", path)
print("patched")
