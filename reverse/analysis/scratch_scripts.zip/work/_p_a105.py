import json, io, os
p='docs/BASELINE.json'
d=json.load(io.open(p,encoding='utf-8'))
pe=d['picture_erase']
pe['total_sites']=2835
pe['short_form']=1798
pe['stray_short_tail']=85
pe['long_range_form']=952
pe['argc_histogram']={'3':1798,'4':85,'6':952}
pe['earlier_note']='an earlier note quoted 1,115 / 751 / 329 / 35: that scan only counted erases whose endpoints bracket a picture that is actually drawn somewhere, which is a narrower filter than "every erase in the 550 common events"'
io.open(p+'.new','w',encoding='utf-8',newline='').write(json.dumps(d,ensure_ascii=False,indent=1)+chr(10))
os.replace(p+'.new',p)
print(json.dumps(pe,ensure_ascii=False,indent=1))
