import json, io, collections
ce = json.load(io.open("work/_ce_full.json", encoding="utf-8"))
flags = collections.Counter()
argc4 = []
fifth_literal = []
for e in ce:
    for i, c in enumerate(e["cmds"]):
        if c["c"] != 250:
            continue
        a = c["a"]
        flags[a[3] if len(a) > 3 else None] += 1
        if len(a) == 4:
            argc4.append((e["id"], i, a))
        if len(a) >= 5 and a[4] < 1000000 and a[4] >= 0:
            fifth_literal.append((e["id"], i, a))
print("flags", {hex(k) if isinstance(k, int) else k: v for k, v in flags.most_common(12)})
print("argc4", len(argc4))
for s in argc4[:16]:
    print("  ", s)
print("fifth literal", len(fifth_literal))
for s in fifth_literal[:16]:
    print("  ", s)