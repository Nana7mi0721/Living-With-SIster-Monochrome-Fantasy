
import zipfile, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')
def dump(a, b):
    s = data[a:b].decode('utf-16-le', errors='replace')
    return ''.join(ch if (ch in '\r\n\t' or 0x20 <= ord(ch) < 0xfffd) else '·' for ch in s)
a, b = 0xa8e180, 0xa8f400
step = 700
for off in range(a, b, step):
    print('--- %x' % off)
    print(dump(off, min(off+step, b)))
