
import json, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))
retid = {int(k): v['retid'] for k, v in meta.items()}
for e in ce:
    if 'ズーム' in e['title'] or 'Zoom' in e['title'].lower() or 'zoom' in e['title'].lower():
        print(e['id'], repr(e['title']), 'retid=', hex(retid[e['id']]), 'retname=', meta[str(e['id'])]['retname'])

