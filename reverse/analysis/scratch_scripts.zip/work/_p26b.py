# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
allsites = []
by_id = {}
for ev in ce:
    by_id[ev['id']] = ev
    for pc, c in enumerate(ev['cmds']):
        code,a,s = norm(c); allsites.append(('ce', ev['id'], pc, code, a, s))
for mn, mp in maps.items():
    if not isinstance(mp, dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc, c in enumerate(ev['cmds']):
            code,a,s = norm(c); allsites.append(('map:'+mn, ev.get('id'), pc, code, a, s))

def bits(a):
    v = a[1] & 0xFFFFFFFF if len(a)>1 else 0
    num = v & 0xF; st = (v>>4)&0xF
    en = [(v>>(12+i))&1 for i in range(5)]
    rv = (v>>24)&1
    return num, st, en, rv

calls = [x for x in allsites if x[3] in (210,211,300)]
print('== cross-tab code / strc / len(s) / enabled-count ==')
ct = collections.Counter()
for x in calls:
    num, st, en, rv = bits(x[4])
    ct[(x[3], st, len(x[5]), sum(en))] += 1
for k in sorted(ct):
    print(' code=%d strc=%d len(s)=%d enabled=%d : %d' % (k[0],k[1],k[2],k[3],ct[k]))
print()
print('== 210 only: does len(s) == strc? ==')
n = collections.Counter()
for x in calls:
    if x[3]!=210: continue
    num, st, en, rv = bits(x[4])
    n[(st, len(x[5])-st)] += 1
for k in sorted(n): print('  strc=%d  len-strc=%d : %d' % (k[0],k[1],n[k]))
print()
print('== 300 only: len(s) vs strc vs enabled ==')
n = collections.Counter()
for x in calls:
    if x[3]!=300: continue
    num, st, en, rv = bits(x[4])
    n[(st, len(x[5]), sum(en))] += 1
for k in sorted(n): print('  strc=%d len=%d en=%d : %d' % (k[0],k[1],k[2],n[k]))
