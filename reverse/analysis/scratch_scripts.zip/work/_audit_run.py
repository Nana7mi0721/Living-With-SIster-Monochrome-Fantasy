
import json,io,collections
OUT=io.StringIO()
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
cl=json.load(open('work/_audit_closure.json',encoding='utf-8'))
live=set(int(x) for x in cl['gcreach'])
c=collections.Counter(e.get('run') for e in lst)
OUT.write('run flag distribution over 550 common events: %s\n'%c.most_common())
byrun=collections.defaultdict(list)
for e in lst: byrun[e.get('run')].append(e['id'])
for k in sorted(byrun):
    ids=byrun[k]
    OUT.write('run=%s n=%d live=%d dead=%d\n'%(k,len(ids),len([i for i in ids if i in live]),len([i for i in ids if i not in live])))
    OUT.write('   ids: %s\n'%ids[:40])
# also op field
OUT.write('\nop flag distribution: %s\n'%collections.Counter(e.get('op') for e in lst).most_common())
# dead events with run!=0
deadrun=[e['id'] for e in lst if e['id'] not in live and e.get('run')]
OUT.write('\ndead events with run!=0: %s\n'%deadrun)
# what calls ev522 / ev523 ?
def norm(cmds):
    out=[]
    for c in cmds:
        if 'c' in c: out.append((int(c['c']),[int(x) for x in c.get('a') or []],list(c.get('s') or [])))
        else: out.append((int(c.get('code',0)),[int(x) for x in (c.get('ints') or [])],list(c.get('strs') or [])))
    return out
by_title={}
for e in lst: by_title.setdefault(e['title'],e['id'])
for tgt in (522,523):
    t=lst[tgt]['title'] if tgt<len(lst) else None
    callers=[]
    for e in lst:
        for op,a,s in norm(e['cmds']):
            if op==210 and a and a[0] in (500000+tgt,600000+tgt): callers.append(('c',e['id']))
            elif op==300 and s and s[0]==t: callers.append(('c',e['id']))
    OUT.write('\nev%d title=%r callers=%s\n'%(tgt,t,callers))
open('work/_audit_out11.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
