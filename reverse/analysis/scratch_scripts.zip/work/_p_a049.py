p = "crates/wolf-game/src/savegame.rs"
t = open(p, encoding="utf-8").read()
a = """    } else {
        if name.is_empty() {
            return None;
        }
        picture.kind = if record.var6 == 1 {
            PictureKind::WindowFile
        } else {
            PictureKind::File
        };
        picture.file = name;
    }"""
b = """    } else {
        // A FileString / WindowString picture takes its name from a string variable;
        // when that variable is empty the record carries an empty name. Keep the
        // record anyway: it is an invisible slot, but dropping it would change the
        // live picture count on a save/load round trip. The renderer skips an empty
        // file, and a window with an empty name falls back to the engine skin.
        picture.kind = if record.var6 == 1 {
            PictureKind::WindowFile
        } else {
            PictureKind::File
        };
        picture.file = name;
    }"""
assert t.count(a) == 1
t = t.replace(a, b)
a2 = "    picture.scale = if v[9] == 0 { 100 } else { v[9] as i32 };"
b2 = """    // A zero scale is a real hidden picture (the HUD action-bar fill is stored as
    // 0 when empty), not a missing field. Retail SaveData01 records picture 6233
    // with [9] = 62 and [10] = 100; a freshly written save must preserve 0 as 0.
    picture.scale = v[9] as i32;"""
assert t.count(a2) == 1
t = t.replace(a2, b2)
open(p, "w", encoding="utf-8", newline="").write(t)

p = "crates/wolf-game/tests/opening.rs"
t = open(p, encoding="utf-8").read()
old = """    let before_screen: Vec<_> = game
        .screen
        .iter()
        .map(|p| (p.number, p.kind, p.file.clone(), p.x, p.y, p.anchor, p.scale, p.split, p.pattern_index))
        .collect();"""
new = """    fn visible_pictures(screen: &wolf_game::picture::Screen) -> Vec<(i32, String, i32, i32, u8, i32, (u32, u32), u32)> {
        screen
            .iter()
            .filter(|p| !p.file.is_empty() || !p.text.is_empty())
            .map(|p| {
                let content = if p.kind.is_text() { format!("text:{}", p.text) } else { p.file.clone() };
                (p.number, content, p.x, p.y, p.anchor, p.scale, p.split, p.pattern_index)
            })
            .collect()
    }
    let before_screen = visible_pictures(&game.screen);"""
assert t.count(old) == 1
t = t.replace(old, new)
old2 = """    let after_screen: Vec<_> = reloaded
        .screen
        .iter()
        .map(|p| (p.number, p.kind, p.file.clone(), p.x, p.y, p.anchor, p.scale, p.split, p.pattern_index))
        .collect();"""
new2 = "    let after_screen = visible_pictures(&reloaded.screen);"
assert t.count(old2) == 1
t = t.replace(old2, new2)
old3 = """    if before_screen != after_screen {
        for (index, (before, after)) in before_screen.iter().zip(after_screen.iter()).enumerate() {
            if before != after {
                eprintln!("picture {index} before {before:?} after {after:?}");
            }
        }
        panic!("the picture layer changed");
    }"""
new3 = "    assert_eq!(before_screen, after_screen, \"the visible picture layer changed\");"
if t.count(old3) == 1:
    t = t.replace(old3, new3)
open(p, "w", encoding="utf-8", newline="").write(t)
print("patched")