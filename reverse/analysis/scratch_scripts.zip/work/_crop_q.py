
from PIL import Image
src=r'C:/Users/REISEN/.dsh/attachments/v1/objects/48/48b03b8df72d48b419b159869356953a31eef9a3fc8e754e0d287e7a0c687e28'
im=Image.open(src); w,h=im.size
out=r'work/out'
# 4 bands x 2 halves, scaled 1.6x
bands=[(0,300),(290,600),(590,900),(890,1183)]
for bi,(a,b) in enumerate(bands):
    for hi,(x0,x1) in enumerate([(0,940),(930,1877)]):
        c=im.crop((x0,a,x1,b))
        c=c.resize((int((x1-x0)*1.6),int((b-a)*1.6)),Image.LANCZOS)
        c.save(f'{out}/q{bi}{hi}.png')
        print(bi,hi,c.size)
