
import json,io,collections
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
cl=json.load(open('work/_audit_closure.json',encoding='utf-8'))
W('keys: %s'%list(cl.keys()))
for k,v in cl.items():
    if isinstance(v,list): W('  %s list %d sample %s'%(k,len(v),v[:4]))
    elif isinstance(v,dict): W('  %s dict %d sample %s'%(k,len(v),list(v.items())[:2]))
    else: W('  %s = %s'%(k,v))
open('work/_audit_out31.txt','w',encoding='utf-8').write(OUT.getvalue()); print('ok')
