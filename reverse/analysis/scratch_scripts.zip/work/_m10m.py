import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
t2i={}
for e in ces: t2i.setdefault(e['title'],[]).append(e['id'])
for t in ['X[戦]基本状態取得','X[戦]戦闘変数初期化','X[移]パーティー情報計算','X[戦]一時ステ計算<初期化>']:
    print(repr(t),'->',t2i.get(t))
def dump(eid, hi=200):
    e=by[eid]; print(f"=== CE{eid} {e['title']!r} ncmds={len(e['cmds'])} ===")
    for i,c in enumerate(e['cmds']):
        if i>hi: continue
        if c['c'] in (111,121,124,125,172,179,210,300,250,401,420,499,180,190,191):
            print("pc",i,c['c'],c.get('a'),c.get('s'))
for eid in [226,216]:
    if eid in by: dump(eid)

