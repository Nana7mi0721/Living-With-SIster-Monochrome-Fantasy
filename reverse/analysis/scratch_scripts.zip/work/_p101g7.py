
import json,io,collections,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
tgt=collections.Counter()
for e in ce:
    for c in e['cmds']:
        op,a,s=norm(c)
        if op==210 and a: tgt[a[0]]+=1
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
for m in mp.values():
    for ev in m.get('events',[]):
        for c in ev.get('cmds',[]):
            op,a,s=norm(c)
            if op==210 and a: tgt[a[0]]+=1
print('min target',min(tgt),'max',max(tgt))
print('500000 calls',tgt.get(500000,0),' 500001 calls',tgt.get(500001,0),' 500002',tgt.get(500002,0))
print('top10 targets',tgt.most_common(10))
byid={e['id']:e['title'] for e in ce}
for t in (500000,500001,500002,500063):
    n=t-500000
    print(t,'->',byid.get(n),' calls',tgt.get(t,0))
