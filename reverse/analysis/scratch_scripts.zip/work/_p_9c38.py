import io, os
p = "crates/wolf-game/tests/opening.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = """    game.auto_advance = true;
    game.auto_choice = true;"""
b = """    // Messages dismiss themselves, but the opening prompt is HELD: dice the choice and
    // the script walks on into the character creation loop, which spins without a frame
    // wait (measured: 103 million instructions over 600 frames). Holding it is what the
    // retail player sees at the end of the cutscene and what `wolf-cli capture` photographs.
    game.auto_advance = true;"""
assert t.count(a) == 1
t = t.replace(a, b)
open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("ok")