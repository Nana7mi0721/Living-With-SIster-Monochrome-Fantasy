import io, os

def sub(path, a, b):
    t = io.open(path, encoding="utf-8", newline="").read()
    assert t.count(a) == 1, ("count", t.count(a), a[:60])
    open(path + ".new", "w", encoding="utf-8", newline="").write(t.replace(a, b))
    os.replace(path + ".new", path)

p = "crates/wolf-cli/src/main.rs"
a = """    match &game.choices {
        Some(choices) => println!(
            "  choice    : HELD on prompt with {} option(s) {:?}, cursor {}",
            choices.options.len(),
            choices.options,
            game.choice_cursor()
        ),"""
b = """    match &game.choices {
        Some(choices) => {
            let (x, y) = game.choice_anchor();
            let anchored = choice::layout_at(&choices.options, game.choice_cursor(), x, y);
            println!(
                "  choice    : HELD on prompt with {} option(s) {:?}, cursor {} at anchor ({x}, {y})",
                choices.options.len(),
                choices.options,
                game.choice_cursor()
            );
            match anchored {
                Some(panel) => println!(
                    "            : engine rect {:?}, {} row(s), {:?}",
                    panel.rect,
                    panel.lines.len(),
                    panel.lines.first().copied()
                ),
                None => println!("            : anchor is off screen, engine draws nothing"),
            }
        }"""
sub(p, a, b)
print("ok")