
import json,io
OUT=io.StringIO()
ts=json.load(open('work/fs_ts.json',encoding='utf-8'))
# read raw bytes from TileSetData.dat for tileset5 names
raw=open('work/all/BasicData/TileSetData.dat','rb').read()
print('file bytes',len(raw),file=OUT)
# find the byte sequence of one name
t5=ts[5]
names=[a for a in t5['autos'] if a]
for n in names[:4]:
    b=n.encode('utf-8',errors='surrogateescape')
    print('name repr',repr(n),file=OUT)
    print('  utf8 bytes',b.hex(),file=OUT)
    idx=raw.find(b)
    print('  found at',idx,file=OUT)
    if idx>=0:
        seg=raw[idx:idx+len(b)]
        print('  seg',seg.hex(),file=OUT)
        for enc in ['cp932','shift_jis','euc_jp']:
            try:
                print('   ',enc,'->',seg.decode(enc),file=OUT)
            except Exception as e:
                print('   ',enc,'fail',file=OUT)
open('work/_audit_ts5raw.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
