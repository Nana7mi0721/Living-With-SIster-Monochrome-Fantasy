# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
by_id = {ev['id']: ev for ev in ce}
allsites = []
for ev in ce:
    for pc, c in enumerate(ev['cmds']):
        code,a,s = norm(c); allsites.append(('ce', ev['id'], pc, code, a, s))
for mn, mp in maps.items():
    if not isinstance(mp, dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc, c in enumerate(ev['cmds']):
            code,a,s = norm(c); allsites.append(('map:'+mn, ev.get('id'), pc, code, a, s))
def bits(a):
    v = a[1] & 0xFFFFFFFF if len(a)>1 else 0
    return (v & 0xF, (v>>4)&0xF, [(v>>(12+i))&1 for i in range(5)], (v>>24)&1, v)
byname = {}
for ev in ce: byname.setdefault(ev['title'], ev['id'])
def target_of(x):
    if x[3]==300: return byname.get(x[5][0]) if x[5] else None
    raw = x[4][0]
    if 500000 <= raw <= 599999: return raw-500000
    if 600000 <= raw <= 699999: return raw-600000
    return None

# for each site with strc>0, dump the callee's CSelf5..8 read contexts
CTX = {}
def ctx_of(evid):
    if evid in CTX: return CTX[evid]
    ev = by_id.get(evid)
    if ev is None: CTX[evid]=None; return None
    d = collections.defaultdict(list)  # slot -> list of (opcode, pc)
    for pc, c in enumerate(ev['cmds']):
        code,a,s = norm(c)
        for v in a:
            u = v & 0xFFFFFFFF
            if 1600000 <= u <= 1600999:
                d[u-1600000].append((code, pc))
    CTX[evid]=d; return d

sites = [x for x in allsites if x[3] in (210,300) and bits(x[4])[1] > 0]
# histogram of callee opcodes touching slots 5..8
op = collections.Counter()
slotops = collections.Counter()
for x in sites:
    tgt = target_of(x)
    d = ctx_of(tgt) if tgt is not None else None
    if not d: continue
    for k in (5,6,7,8):
        for (code, pc) in d.get(k, []):
            op[code] += 1
            slotops[(k,code)] += 1
print('== opcodes that touch CSelf5..8 in callees ==')
for c,n in op.most_common(): print('  opcode %d : %d' % (c,n))
print()
print('== per slot ==')
for k in (5,6,7,8):
    s = collections.Counter()
    for (kk,c),n in slotops.items():
        if kk==k: s[c]+=n
    print('  slot',k, dict(s.most_common()))
print()
# now: for the biggest family (210 strc=2), print distinct callee ids
fam = [x for x in sites if x[3]==210 and bits(x[4])[1]==2]
print('210 strc=2 sites:', len(fam))
ids = collections.Counter(target_of(x) for x in fam)
print('callees:', ids.most_common(10))
x0 = fam[0]
d = ctx_of(target_of(x0))
print('example site:', x0[1], x0[2], 'a=',x0[4], 's=',x0[5], '-> callee', target_of(x0))
print('callee CSelf map:', {k:v for k,v in sorted(d.items()) if 0<=k<=12})
