
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
T=[338,340,341,343,346,350,351,353,354,357,358,365,367,372,407,410,445]
L=[]
def p(s=""): L.append(s)

p("## TITLES + run_condition")
for t in T:
    e=idx[t]
    p("ev%-4d run=%d op=%d slots=%-5d title=%s"%(t,e["run"],e["op"],len(e["cmds"]),e["title"]))

p("")
p("## all 300-by-name call sites -> resolved id")
allnames=set()
for e in ce:
    for i,c in enumerate(e["cmds"]):
        if c["c"]==300 and c.get("s"):
            allnames.add(c["s"][0])
p("distinct 300 names: %d"%len(allnames))
for t in T:
    nm=idx[t]["title"]
    hit=[n for n in allnames if n==nm]
    p("ev%d name-in-300: %s"%(t,"YES" if hit else "no"))

p("")
p("## 210 with non-literal / self-var args, resolved to targets?")
for e in ce:
    for i,c in enumerate(e["cmds"]):
        if c["c"]==210 and c.get("a"):
            raw=c["a"][0]
            if not (0<=raw<500000 or 500000<=raw<=599999 or 600000<=raw<=699999):
                p("ce%-4d pc%-5d raw=%d"%(e["id"],i,raw))

p("")
p("## which events have run=2 (auto) among ALL 550")
auto=[e["id"] for e in ce if e["run"]==2]
p("count=%d"%len(auto))
p(str(auto))
open(os.path.join(W,"_m3_out3.txt"),"w",encoding="utf-8").write("\n".join(L))
print("lines",len(L))
