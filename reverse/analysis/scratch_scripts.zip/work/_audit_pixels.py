
import json,io,os,collections
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
live=set(fin['live']); sizes=fin['sizes']
IMG={'.png','.jpg','.jpeg','.bmp','.webp','.gif'}
AUD={'.mp3','.ogg','.wav','.m4a','.mid','.wma'}
def ext(p): return os.path.splitext(p)[1].lower()
imgs=[p for p in live if ext(p) in IMG]
auds=[p for p in live if ext(p) in AUD]
W('live assets: %d files / %d B'%(len(live),sum(sizes[p] for p in live)))
W('  images: %d files / %d B'%(len(imgs),sum(sizes[p] for p in imgs)))
W('  audio : %d files / %d B'%(len(auds),sum(sizes[p] for p in auds)))
W('  other : %d files / %d B'%(len(live)-len(imgs)-len(auds),sum(sizes[p] for p in live if ext(p) not in IMG|AUD)))

tot_px=0; bad=0; maxpx=[]
for p in imgs:
    try:
        with Image.open(os.path.join('work/all',p)) as im:
            w,h=im.size
            tot_px+=w*h; maxpx.append((w*h,p,w,h))
    except Exception as e:
        bad+=1
W('\nimage pixels: total %d px (%.2f Gpx) across %d readable images, %d unreadable'%(tot_px,tot_px/1e9,len(imgs)-bad,bad))
for cap in (1024,2048,4096,8192,16384):
    W('  %5d^2 atlas = %8d px  -> needs %6.1f sheets'%(cap,cap*cap,tot_px/(cap*cap)))
W('\nbiggest images by pixels:')
for px,p,w,h in sorted(maxpx,reverse=True)[:10]:
    W('  %8d px (%dx%d) %s'%(px,w,h,p))
json.dump({'total_px':tot_px,'images':len(imgs)},open('work/_audit_px.json','w',encoding='utf-8'))
open('work/_audit_out20.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
