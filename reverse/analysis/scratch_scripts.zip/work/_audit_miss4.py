
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
miss=refs['missing']
mp=collections.Counter()
for p,sites in miss.items():
    for s in sites:
        if s[0]=='map':
            mp[s[1].split(' ev')[0].split('.')[0]]+=1
W('== Picture/any missing by map ==')
for k,v in mp.most_common(): W('  %-16s %d'%(k,v))
# names per map
W('\n== SampleMapA_1 missing names (unique) ==')
seen=set()
for p,sites in miss.items():
    if any(s[0]=='map' and s[1].startswith('SampleMapA_1') for s in sites):
        if p not in seen: seen.add(p); W('  %s'%p)
W('  total %d'%len(seen))
W('\n== Map002 missing names ==')
seen2=set()
for p,sites in miss.items():
    if any(s[0]=='map' and s[1].startswith('Map002') for s in sites):
        if p not in seen2: seen2.add(p); W('  %s'%p)
W('  total %d'%len(seen2))
open('work/_audit_out25.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
