
import json
d = json.load(open('work/maps_full.json', encoding='utf-8'))
m = d['TitleMap.mps']
for ev in m['events']:
    print('event', ev['id'], 'name?', 'pages', ev['npg'], 'trig', ev['trig'], 'cmds', ev['cmds'])
    for i, c in enumerate(ev['commands'] if 'commands' in ev else []):
        pass
print(json.dumps(list(m.keys()), ensure_ascii=False))
