import json
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
ev=[e for e in ce if e['id']==63][0]
for i,c in enumerate(ev['cmds'][20:56], start=20):
    if c['c']==121 or c['c']==250 or c['c']==150 or c['c']==213:
        print(i, c['c'], c['a'], c['s'])
