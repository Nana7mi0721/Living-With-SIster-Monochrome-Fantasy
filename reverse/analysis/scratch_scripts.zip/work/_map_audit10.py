# -*- coding: utf-8 -*-
import json, sys, io, struct, os, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base = r'work\full\MapData'

def parse_mps(p):
    b=open(p,'rb').read(); st={'o':0}
    def u1():
        v=b[st['o']]; st['o']+=1; return v
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        return s.split(b'\x00')[0].decode('utf-8','replace')
    st['o']=16; u1(); st['o']+=3; u4(); u1(); tstr()
    ts=u4(); w=u4(); h=u4(); ec=u4(); fp=u4()
    if fp!=0xFFFFFFFF: st['o'] += w*h*3*4 - 4
    events=[]
    while b[st['o']]==0x6F:
        u1(); u4(); eid=u4(); name=tstr(); x=u4(); y=u4(); pc=u4(); u4()
        pages=[]
        for _ in range(pc):
            u1(); chip=u4(); gfx=tstr()
            direction=u1(); frame=u1(); op=u1(); disp=u1(); trig=u1()
            sw=[u1() for _ in range(4)]; vn=[u4() for _ in range(4)]; vv=[s4() for _ in range(4)]
            [u1() for _ in range(6)]
            rl=u4()
            for _ in range(rl):
                u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
            ncmd=u4(); cmds=[]
            for _ in range(ncmd):
                cnt=u1()
                if cnt>0: o=u4(); a=[s4() for _ in range(cnt-1)]
                else: o=0; a=[]
                d=u1(); sc=u1()
                strs=[tstr() for _ in range(sc)]
                hr=u1()
                if hr!=0:
                    st['o']+=6; rl2=u4()
                    for _ in range(rl2):
                        u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
                cmds.append({'op':o,'args':a,'strings':strs})
            u4(); shadow=u1(); rex=u1(); rey=u1(); footer=u1()
            pages.append({'trigger':trig,'cmds':cmds,'gfx':gfx,'chip':chip,'footer':footer,
                          'sw':sw,'vn':vn,'vv':vv})
        u1()
        events.append({'id':eid,'name':name,'x':x,'y':y,'pages':pages})
    return {'ts':ts,'w':w,'h':h,'events':events}

REG = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps']
CTL = ['SampleMapB.mps']
maps = {f: parse_mps(os.path.join(base, f)) for f in REG + CTL + ['Dungeon.mps','Map002.mps']}

def walk(f):
    for e in maps[f]['events']:
        for pi, p in enumerate(e['pages']):
            for ci, c in enumerate(p['cmds']):
                yield e, pi, c, ci

for label, files in (('registered 6', REG), ('control SampleMapB', CTL)):
    op = collections.Counter(); sub124 = collections.Counter(); f8 = 0; f8ops = []
    for f in files:
        for e, pi, c, ci in walk(f):
            op[c['op']] += 1
            if c['op'] == 124 and len(c['args']) >= 3:
                sub124[c['args'][1]] += 1
                if c['args'][1] == 0x4000 and len(c['args']) >= 4 and c['args'][3] == 8:
                    f8 += 1; f8ops.append((f, e['id'], pi, ci, c['args']))
    print('%s: slots=%d op150=%d op124=%d op201=%d op123=%d' % (label, sum(op.values()), op[150], op[124], op[201], op[123]))
    print('  124 subs:', {hex(k): v for k, v in sorted(sub124.items())})
    print('  124 sub=0x4000 field=8 hover reads:', f8)
    print('  histogram:', dict(sorted(op.items())))
print()
print('=== hover-read sites ===')
for f, eid, pi, ci, a in f8ops:
    print('%-16s ev%-3d page%d pc%-4d dst=%d sub=0x%X obj=%d field=%d' % (f, eid, pi, ci, a[0], a[1], a[2], a[3]))
print()
print('=== op150 per registered map ===')
for f in REG:
    n = 0; sample = []
    for e, pi, c, ci in walk(f):
        if c['op'] == 150:
            n += 1
            if len(sample) < 5:
                sample.append((e['id'], e['name'], pi, ci, c['args'], c['strings']))
    print('%-16s op150=%d' % (f, n))
    for s in sample:
        print('    ev%-3d %-22r page%d pc%-5d args=%s strs=%s' % (s[0], s[1], s[2], s[3], s[4], s[5]))
