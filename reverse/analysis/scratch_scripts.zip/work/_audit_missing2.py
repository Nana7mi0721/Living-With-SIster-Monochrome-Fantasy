
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
miss=refs['missing']
# Picture missing: which sources?
src=collections.Counter()
for p,sites in miss.items():
    if p.startswith('Picture/'):
        for s in sites: src[(s[0],s[1].split('#')[0].split('[')[0])]+=1
W('== Picture missing sources (top) ==')
for k,v in src.most_common(15): W('  %s %s  x%d'%(k[0],k[1],v))
W('\n== Picture missing sample 20 ==')
pl=sorted(p for p in miss if p.startswith('Picture/'))
W('  count %d'%len(pl))
for p in pl[:25]: W('   %s <- %s'%(p,'; '.join('%s %s'%(s[0],s[1]) for s in miss[p][:2])))
# CharaChip on disk
ch=[f for f in os.listdir('work/all/CharaChip')]
W('\n== CharaChip on disk: %d files =='%len(ch))
W('  %s'%sorted(ch))
open('work/_audit_out18.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
