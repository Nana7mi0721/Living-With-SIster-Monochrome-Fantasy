
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(open('work/wolftl/dump/db/CDataBase.json',encoding='utf-8'))['types']
for i,t in enumerate(d):
    data=t.get('data',[])
    print('type%-3d %-24s rows=%-4d fields=%d'%(i,t.get('name',''),len(data),len(data[0]) if data and isinstance(data[0],list) else -1))
