import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
title=by[172]['title']
print("CE172 title raw repr:", repr(title))
names=set()
for e in ces:
    for i,cm in enumerate(e['cmds']):
        if cm['c']==300 and cm.get('s') and cm['s'] and cm['s'][0]==title:
            print(f"CALLER CE{e['id']} pc{i} op300 {cm.get('a')} name={cm['s'][0]!r}")
# also print a few op300 names that contain same ascii fragment around 'X'

