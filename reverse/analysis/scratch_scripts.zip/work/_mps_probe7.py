
import struct, os, collections
base = r'work\full\MapData'
h2s=collections.Counter(); seps=collections.Counter(); feats=collections.Counter(); pf=collections.Counter()
evf=collections.Counter(); pstart=collections.Counter(); trig=collections.Counter()
magic=set()
for f in sorted(os.listdir(base)):
    if not f.endswith('.mps'): continue
    b=open(os.path.join(base,f),'rb').read()
    magic.add(b[:16])
    o=16; o+=1+3+4+1
    n=struct.unpack_from('<I',b,o)[0]; o+=4+n
    ts,w,h,ec=struct.unpack_from('<IIII',b,o); o+=16
    fp=struct.unpack_from('<I',b,o)[0]
    o += 4 if fp==0xFFFFFFFF else w*h*3*4
    for e in range(ec):
        assert b[o]==0x6f; o+=1
        h2=struct.unpack_from('<I',b,o)[0]; o+=4; h2s[h2]+=1
        o+=4
        ln=struct.unpack_from('<I',b,o)[0]; o+=4+ln
        o+=8
        pc=struct.unpack_from('<I',b,o)[0]; o+=4
        sep=struct.unpack_from('<I',b,o)[0]; o+=4; seps[sep]+=1
        for p in range(pc):
            pstart[b[o]]+=1; o+=1+4
            ln=struct.unpack_from('<I',b,o)[0]; o+=4+ln
            o+=4
            trig[b[o]]+=1; o+=1
            o+=4+16+16
            o+=6
            rl=struct.unpack_from('<I',b,o)[0]; o+=4
            for _ in range(rl):
                o+=1; n1=b[o]; o+=1+n1*4; n2=b[o]; o+=1+n2
            cc=struct.unpack_from('<I',b,o)[0]; o+=4
            for _ in range(cc):
                pcn=b[o]; o+=1
                if pcn>0: o+=4+(pcn-1)*4
                o+=1; sc=b[o]; o+=1
                for _ in range(sc):
                    ln=struct.unpack_from('<I',b,o)[0]; o+=4+ln
                hr=b[o]; o+=1
                if hr!=0:
                    o+=6; rl2=struct.unpack_from('<I',b,o)[0]; o+=4
                    for _ in range(rl2):
                        o+=1; n1=b[o]; o+=1+n1*4; n2=b[o]; o+=1+n2
            fe=struct.unpack_from('<I',b,o)[0]; o+=4; feats[fe]+=1
            o+=3
            pf[b[o]]+=1; o+=1
        evf[b[o]]+=1; o+=1
print('magic variants:', len(magic), [m.hex() for m in magic])
print('event h2:', dict(h2s))
print('event sep:', dict(seps))
print('page start:', dict(pstart))
print('triggers:', dict(trig))
print('features:', dict(feats))
print('page footers:', dict(pf))
print('event footers:', dict(evf))
