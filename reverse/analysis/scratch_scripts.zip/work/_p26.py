
import json, sys, unicodedata
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))
retid = {int(k): v['retid'] for k, v in meta.items()}
def norm(s):
    s = unicodedata.normalize('NFKC', s)
    return ''.join(ch for ch in s if ch.isalnum())
cands = [e for e in ce if ('位置' in e['title'] and 'イベント' in e['title']) or 'ズ' in e['title']]
for e in cands:
    print(e['id'], repr(e['title']), hex(retid[e['id']]))
print('---')
nm = norm('○◆マップをズーム')
print('norm target', nm)
for e in cands:
    print(e['id'], norm(e['title'])[:40])

