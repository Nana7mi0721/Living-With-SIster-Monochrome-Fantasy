import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
for e in ev:
    for i,c in enumerate(e['cmds']):
        for s in c['s']:
            if 'Button01' in s:
                print(f"ev{e['id']} {e['title'][:24]} pc{i} op{c['c']} a={c['a']} s={c['s'][:2]}")
