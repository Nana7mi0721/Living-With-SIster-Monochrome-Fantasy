
import io,sys,re,html
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
b=open('work/_yado_effect.html','rb').read()
print('charset',re.search(rb'charset=["\']?([\w-]+)',b,re.I))
txt=None
for enc in ('utf-8','cp932','euc-jp'):
    try:
        t=b.decode(enc)
        if 'エフェクト' in t: txt=t; print('enc',enc); break
    except Exception: pass
t=re.sub(r'<script.*?</script>','',txt,flags=re.S|re.I)
t=re.sub(r'<style.*?</style>','',t,flags=re.S|re.I)
t=re.sub(r'<br\s*/?>','\n',t,flags=re.I)
t=re.sub(r'</(p|div|tr|td|th|li|h\d|table)>','\n',t,flags=re.I)
t=re.sub(r'<[^>]+>','',t)
t=html.unescape(t)
lines=[l.strip() for l in t.split('\n')]
lines=[l for l in lines if l]
open('work/_yado_effect.txt','w',encoding='utf-8').write('\n'.join(lines))
print('lines',len(lines))
for i,l in enumerate(lines):
    if re.search(r'シェイク|点滅|パターン切替|ズーム|描画座標|拡大縮小|Zオーダー|フラッシュ',l):
        print('%4d %s'%(i,l[:160]))
