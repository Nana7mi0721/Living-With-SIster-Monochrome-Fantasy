
import json,io,collections
OUT=io.StringIO()
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure.json',encoding='utf-8'))
live=set(int(x) for x in cl['gcreach'])
for probe in ['cg/ending12.jpg','cg/event01.jpg','hscene/','hword/']:
    if probe.endswith('/'):
        hits=[(p,s) for p,s in refs['referenced'].items() if p.startswith(probe)]
        OUT.write('\n== %s : %d files ==\n'%(probe,len(hits)))
        for p,s in hits[:5]:
            OUT.write('  %s\n'%p)
            for x in s[:6]: OUT.write('     %s %s %s\n'%(x[0],x[1],x[2]))
    else:
        s=refs['referenced'].get(probe)
        OUT.write('\n== %s ==\n'%probe)
        for x in (s or []): OUT.write('   %s %s %s\n'%(x[0],x[1],x[2]))
# 130 teleports
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
def norm(cmds):
    out=[]
    for c in cmds:
        if 'c' in c: out.append((int(c['c']),[int(x) for x in c.get('a') or []],list(c.get('s') or [])))
        else: out.append((int(c.get('code',0)),[int(x) for x in (c.get('ints') or [])],list(c.get('strs') or [])))
    return out
c130=collections.Counter()
for e in lst:
    for op,a,s in norm(e['cmds']):
        if op==130 and a: c130[a[0]]+=1
OUT.write('\n== 130 teleport map ids in common events: %s\n'%c130.most_common(20))
mf=json.load(open('work/maps_full.json',encoding='utf-8'))
c130m=collections.Counter()
for k,v in mf.items():
    for e in v['events']:
        for op,a,s in norm(e['cmds']):
            if op==130 and a: c130m[(k,a[0])]+=1
OUT.write('== 130 in map events: %s\n'%c130m.most_common(20))
open('work/_audit_out10.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
