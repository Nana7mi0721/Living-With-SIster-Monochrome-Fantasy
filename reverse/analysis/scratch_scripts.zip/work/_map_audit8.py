# -*- coding: utf-8 -*-
import sys, io, struct, os, json, itertools
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

BASE = r'work\full\MapData'
REGISTERED = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps']
CONTROL = ['SampleMapB.mps']
ORPHAN = ['Dungeon.mps','Map002.mps']
ALL = REGISTERED + CONTROL + ORPHAN

OPS = {0:'blank',103:'comment',111:'varcond',121:'setvar',122:'setstr',123:'inputkey',124:'setvarex',
       130:'teleport',140:'sound',150:'picture',160:'settrans',170:'loopstart',171:'breakloop',
       174:'returntitle',175:'endgame',179:'looptimes',180:'wait',201:'move',210:'commonevent',
       211:'cereserve',212:'setlabel',213:'jumplabel',220:'saveload',221:'loadgame',222:'savegame',
       250:'database',270:'party',280:'mapeffect',281:'scroll',290:'effect',300:'cebyname',
       401:'choicecase',402:'specialcase',420:'elsecase',421:'cancelcase',498:'loopend',499:'branchend',
       101:'message',102:'choices',105:'forcestop',106:'dbgmsg',111:'varcond'}

def parse(p):
    b=open(p,'rb').read(); st={'o':0}
    def u1():
        v=b[st['o']]; st['o']+=1; return v
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        return s.split(b'\x00')[0].decode('utf-8','replace')
    st['o']=16; vh=u1(); st['o']+=3; st['o']+=4; ver=u1(); title=tstr()
    ts=u4(); w=u4(); h=u4(); ec=u4(); fp=u4()
    has_tiles = fp!=0xFFFFFFFF
    if has_tiles: st['o'] += w*h*3*4 - 4
    events=[]
    while b[st['o']]==0x6F:
        u1(); u4(); eid=u4(); name=tstr(); x=u4(); y=u4(); pc=u4(); u4()
        pages=[]
        for _ in range(pc):
            u1(); chip=u4(); gfx=tstr()
            direction=u1(); frame=u1(); opa=u1(); disp=u1(); trig=u1()
            sw=[u1() for _ in range(4)]; vn=[u4() for _ in range(4)]; vv=[s4() for _ in range(4)]
            [u1() for _ in range(6)]
            rl=u4()
            for _ in range(rl):
                u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
            ncmd=u4(); cmds=[]
            for _ in range(ncmd):
                cnt=u1()
                if cnt>0: o=u4(); a=[s4() for _ in range(cnt-1)]
                else: o=0; a=[]
                d=u1(); sc=u1()
                strs=[tstr() for _ in range(sc)]
                hr=u1()
                if hr!=0:
                    st['o']+=6; rl2=u4()
                    for _ in range(rl2):
                        u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
                cmds.append({'op':o,'args':a,'strings':strs})
            u4(); shadow=u1(); rex=u1(); rey=u1(); footer=u1()
            pages.append({'trigger':trig,'cmds':cmds,'gfx':gfx,'chip':chip,'footer':footer,
                          'sw':sw,'vn':vn,'vv':vv,'direction':direction,'frame':frame,'opacity':opa,'display':disp})
        u1()
        events.append({'id':eid,'name':name,'x':x,'y':y,'pages':pages})
    return {'file':os.path.basename(p),'title':title,'version_header':vh,'version':ver,
            'tileset':ts,'w':w,'h':h,'events':events,'has_tiles':has_tiles,
            'layers': 3 if has_tiles else 0, 'consumed':st['o'],'size':len(b)}

def var_name(v):
    if 1000000 <= v < 2000000: return 'self%d' % (v-1000000)
    if 2000000 <= v < 3000000: return 'v%d' % (v-2000000)
    if 9000000 <= v < 10000000: return 'sys%d' % (v-9000000)
    return 'raw%d' % v

OPN = {0:'>',1:'>=',2:'==',3:'<=',4:'<',5:'!=',6:'&'}
def conds(page):
    out=[]
    for i in range(4):
        flag=page['sw'][i]
        if (flag & 0x0F) != 1: continue
        op = flag >> 4
        out.append({'slot':i,'op':op,'var':page['vn'][i],'value':page['vv'][i],
                    'var_name':var_name(page['vn'][i]),'op_name':OPN.get(op,'?')})
    return out

def matches(c, val):
    op=c['op']; t=c['value']
    if op==0: return val > t
    if op==1: return val >= t
    if op==2: return val == t
    if op==3: return val <= t
    if op==4: return val < t
    if op==5: return val != t
    if op==6: return (val & t) != 0
    return False

def active_index(pages, getv):
    for i in range(len(pages)-1, -1, -1):
        cs = conds(pages[i])
        if all(matches(c, getv(c['var'])) for c in cs):
            return i
    return None

def breakpoints(pages):
    cand = {}
    for p in pages:
        for c in conds(p):
            s = cand.setdefault(c['var'], {0})
            t = c['value']
            s.update({t-1, t, t+1, t^1, t|1})
    return cand

def analyse(ev):
    pages = ev['pages']
    cand = breakpoints(pages)
    keys = sorted(cand)
    live = set()
    combos = 0
    if not keys:
        a = active_index(pages, lambda v: 0)
        if a is not None: live.add(a)
        combos = 1
    else:
        vals = [sorted(cand[k]) for k in keys]
        for combo in itertools.product(*vals):
            combos += 1
            m = dict(zip(keys, combo))
            a = active_index(pages, lambda v: m[v])
            if a is not None: live.add(a)
    dead = [i for i in range(len(pages)) if i not in live]
    return live, dead, combos

result = {'maps':{}, 'totals':{}}
tot_ev=tot_pg=tot_slot=tot_blank=0
opcode_hist={}
trig_hist={}
flag_hist={}
teleports=[]
dead_report=[]
linemap={}

for f in ALL:
    m = parse(os.path.join(BASE,f))
    rows=[]
    nslots=0; nblank=0
    for ev in m['events']:
        live, dead, combos = analyse(ev)
        fresh = active_index(ev['pages'], lambda v: 0)
        pg_rows=[]
        for pi,p in enumerate(ev['pages']):
            trig_hist[p['trigger']] = trig_hist.get(p['trigger'],0)+1
            for i in range(4):
                flag_hist[p['sw'][i]] = flag_hist.get(p['sw'][i],0)+1
            for c in p['cmds']:
                opcode_hist[c['op']] = opcode_hist.get(c['op'],0)+1
                if c['op']==130:
                    teleports.append({'file':f,'event':ev['id'],'name':ev['name'],'page':pi,
                                      'pc':p['cmds'].index(c),'args':c['args']})
            pg_rows.append({'page':pi,'trigger':p['trigger'],'conds':conds(p),
                            'cmds':len(p['cmds']),'fresh':(fresh==pi),'dead':(pi in dead)})
        nslots += sum(len(p['cmds']) for p in ev['pages'])
        rows.append({'id':ev['id'],'name':ev['name'],'x':ev['x'],'y':ev['y'],'pages':pg_rows,
                     'fresh':fresh,'live':sorted(live),'dead':dead,'combos':combos})
        if dead and len(ev['pages'])>1:
            dead_report.append((f,ev['id'],ev['name'],len(ev['pages']),sorted(live),dead))
    result['maps'][f]={'w':m['w'],'h':m['h'],'tileset':m['tileset'],'has_tiles':m['has_tiles'],
                       'layers':m['layers'],'title':m['title'],'events':rows,'slots':nslots}
    tot_ev += len(m['events']); tot_pg += sum(len(e['pages']) for e in m['events'])
    tot_slot += nslots

result['totals']={'events':tot_ev,'pages':tot_pg,'slots':tot_slot,
                  'opcodes':opcode_hist,'triggers':trig_hist,'flags':flag_hist}
result['teleports']=teleports
json.dump(result, open('work/_map_audit_data.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)

print('TOTALS events=%d pages=%d slots=%d' % (tot_ev,tot_pg,tot_slot))
print('triggers', dict(sorted(trig_hist.items())))
print('flags', {hex(k):v for k,v in sorted(flag_hist.items())})
print('opcodes', sorted(((OPS.get(k,'op%d'%k),k,v) for k,v in opcode_hist.items()), key=lambda t:-t[2])[:14])
print()
print('TELEPORTS (%d)' % len(teleports))
for t in teleports:
    print('  %-16s ev=%d %-18r page=%d pc=%d args=%s' % (t['file'],t['event'],t['name'],t['page'],t['pc'],t['args']))
print()
print('DEAD-PAGE EVENTS: %d' % len(dead_report))
for f,eid,name,np_,live,dead in dead_report:
    print('  %-16s ev=%-3d %-24r pages=%d live=%s dead=%s' % (f,eid,name,np_,live,dead))
print()
print('PER MAP:')
for f in ALL:
    d=result['maps'][f]
    print('  %-16s %dx%d ts=%d tiles=%d layers=%d ev=%d slots=%d' % (f,d['w'],d['h'],d['tileset'],d['has_tiles'],d['layers'],len(d['events']),d['slots']))
