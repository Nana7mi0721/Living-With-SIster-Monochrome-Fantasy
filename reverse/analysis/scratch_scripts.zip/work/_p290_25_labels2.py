
import zipfile, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
ed = z.read('Editor.exe')
def lits(lo, hi):
    out = []; i = lo
    while i < hi - 2:
        n = int.from_bytes(ed[i:i+2], 'little')
        if 2 <= n <= 60:
            try: s = ed[i+2:i+2+2*n].decode('utf-16-le')
            except Exception: i += 2; continue
            if all(0x20 <= ord(ch) < 0x10000 for ch in s):
                out.append((i, s)); i += 2 + 2*n; continue
        i += 2
    return out
for anchor, name in ((0xa81c54, 'A'), (0xa8394a, 'B')):
    print('### cluster around plain ピクチャ at 0x%x (%s)' % (anchor, name))
    for off, s in lits(anchor - 0x120, anchor + 0x1a0):
        mark = ' <<<' if abs(off - anchor) < 40 else ''
        print('  0x%x  %s%s' % (off, s, mark))
    print()
