# -*- coding: utf-8 -*-
import io, os, sys, itertools
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
src = open('work/_map_audit10.py', encoding='utf-8').read()
head = src.split('\nREG = [')[0]
head = '\n'.join(l for l in head.splitlines() if 'sys.stdout =' not in l)
ns = {}
exec(compile(head, 'h', 'exec'), ns)
parse_mps, base = ns['parse_mps'], ns['base']
FILES = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps','SampleMapB.mps','Dungeon.mps','Map002.mps']
def dom(vals):
    s = {0}
    for t in vals:
        s |= {t-1, t, t+1, t ^ 1, t | 1, -1}
    return sorted(s)
worst = []
for f in FILES:
    m = parse_mps(os.path.join(base, f))
    for e in m['events']:
        if len(e['pages']) < 2:
            continue
        per = {}
        for p in e['pages']:
            for i in range(4):
                if (p['sw'][i] & 0x0F) == 1:
                    per.setdefault(p['vn'][i], []).append(p['vv'][i])
        sizes = [len(dom(v)) for v in per.values()]
        prod = 1
        for s in sizes:
            prod *= s
        worst.append((prod, f, e['id'], e['name'], len(e['pages']), len(per), sizes))
worst.sort(reverse=True)
for w in worst[:8]:
    print(w[0], w[1], 'ev%d' % w[2], w[3], 'pages=%d' % w[4], 'vars=%d' % w[5], 'domains=%s' % w[6])
print('total multi-page events:', len(worst))
print('sum of products:', sum(w[0] for w in worst))
