import struct, os
src=open('work/_dw2.py').read()
exec(src.split("names=[]")[0])
def name_of(na):
    n=struct.unpack_from('<H', hb, na)[0]
    start=na+n*4+4
    end=hb.find(bytes([0]), start)
    return hb[start:end].decode('cp932', errors='replace')
res=[]
def walk(rel,prefix):
    daddr,pdir,num,faddr=d_at(rel)
    for i in range(num):
        na,attr,da,ds,ps=f_at(FileStart+faddr+i*64)
        nm=name_of(na)
        if attr & 0x10: walk(DirStart+da, prefix+nm+'/')
        else: res.append((prefix+nm,da,ds,ps))
walk(DirStart,'')
comp=[r for r in res if r[3]!=0xffffffffffffffff]
print('compressed entries:',len(comp))
for nm,da,ds,ps in comp: print('  %-46s size %8d press %8d' % (nm,ds,ps))