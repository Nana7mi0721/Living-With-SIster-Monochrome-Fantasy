
import json,io,collections
OUT=io.StringIO()
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
def norm(cmds):
    out=[]
    for c in cmds:
        if 'c' in c: out.append((int(c['c']),[int(x) for x in c.get('a') or []],list(c.get('s') or [])))
        else: out.append((int(c.get('code',0)),[int(x) for x in (c.get('ints') or [])],list(c.get('strs') or [])))
    return out
# 210 with args outside 500000..699999  => dynamic / unresolvable
dyn=[]; lit=0; weird=[]
for e in lst:
    for op,a,s in norm(e['cmds']):
        if op==210 and a:
            raw=a[0]
            if 500000<=raw<=599999 or 600000<=raw<=699999: lit+=1
            else: dyn.append((e['id'],raw))
OUT.write('210 calls: literal %d, non-literal %d\n'%(lit,len(dyn)))
for d in dyn[:30]: OUT.write('   ev%d raw=%d\n'%(d[0],d[1]))
# 300 calls
n300=0; miss300=collections.Counter()
by_title={}
for e in lst: by_title.setdefault(e['title'],e['id'])
for e in lst:
    for op,a,s in norm(e['cmds']):
        if op==300 and s:
            n300+=1
            if s[0] not in by_title: miss300[s[0]]+=1
OUT.write('300 calls: %d, unresolved titles: %d\n'%(n300,len(miss300)))
for t,n in miss300.most_common(10): OUT.write('   %r x%d\n'%(t,n))
# 998/999? check what opcodes exist for calling by number in map events too
mf=json.load(open('work/maps_full.json',encoding='utf-8'))
c=collections.Counter()
for k,v in mf.items():
    for e in v['events']:
        for op,a,s in norm(e['cmds']):
            if op in (210,300): c[op]+=1
OUT.write('map events 210=%d 300=%d\n'%(c[210],c[300]))
open('work/_audit_out8.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
