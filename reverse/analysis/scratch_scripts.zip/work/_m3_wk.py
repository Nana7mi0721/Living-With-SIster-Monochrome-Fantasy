
import json,sys
sys.stdout.reconfigure(encoding="utf-8")
ce=json.load(open("work/_ce_full.json",encoding="utf-8"))
for target,name in ((2000006,"weekday"),(2000008,"weekend flag")):
    print("==== ",name,target)
    for e in ce:
        for i,c in enumerate(e["cmds"]):
            if c["c"]==121 and c["a"] and c["a"][0]==target:
                print("  ev%-5d %-16s pc%-5d a=%s"%(e["id"],e["title"],i,c["a"]))
