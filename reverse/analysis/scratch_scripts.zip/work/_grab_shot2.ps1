
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class N3 {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, int extra);
}
"@
function Press($vk, $scan) { [N3]::keybd_event($vk, $scan, 0, 0); Start-Sleep -Milliseconds 70; [N3]::keybd_event($vk, $scan, 2, 0) }
$gameDir = 'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
$p = Start-Process -FilePath (Join-Path $gameDir 'Game.exe') -WorkingDirectory $gameDir -PassThru
Start-Sleep -Seconds 6
$h = $p.MainWindowHandle
Write-Output ("hwnd=" + $h)
[void][N3]::ShowWindow($h, 9)
[void][N3]::SetForegroundWindow($h)
Start-Sleep -Milliseconds 800
for ($i = 0; $i -lt 40; $i++) {
  Press 0x2C 0x37       # PrintScreen -> in-game screenshot
  Start-Sleep -Milliseconds 900
  Press 0x0D 0x1C       # Enter
  Start-Sleep -Milliseconds 1600
}
Start-Sleep -Seconds 1
[void]$p.CloseMainWindow()
Start-Sleep -Seconds 1
if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force }
Write-Output "done"
