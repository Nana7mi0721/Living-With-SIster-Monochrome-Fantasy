import struct, os, json, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base = r'work\full\MapData'
def parse_mps(p):
    b=open(p,'rb').read()
    st={'o':0}
    def u1():
        v=b[st['o']]; st['o']+=1; return v
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        return s.split(b'\x00')[0].decode('utf-8','replace')
    out={}
    st['o']=16
    out['version_header']=u1(); st['o']+=3
    out['unk_20']=u4(); out['version']=u1()
    out['title']=tstr(); out['tileset']=u4()
    out['width']=u4(); out['height']=u4(); out['event_count']=u4()
    fp=u4()
    if fp==0xFFFFFFFF:
        out['no_tiles']=True
    else:
        st['o'] += out['width']*out['height']*3*4 - 4
        out['no_tiles']=False
    events=[]; pages_tot=0; cmds_tot=0; codes={}
    while b[st['o']]==0x6F:
        ev={}
        u1(); u4(); ev['id']=u4(); ev['name']=tstr()
        ev['x']=u4(); ev['y']=u4(); npg=u4(); u4()
        pages=[]
        for pi in range(npg):
            pg={}
            pg['h']=u1(); pg['chipid']=u4(); pg['graphic']=tstr()
            pg['dir']=u1(); pg['frame']=u1(); pg['op']=u1(); pg['disp']=u1()
            pg['trigger']=u1(); pg['sw']=[u1() for _ in range(4)]
            pg['tv']=[u4() for _ in range(4)]; pg['tval']=[s4() for _ in range(4)]
            pg['ri']=[u1() for _ in range(6)]
            rl=u4()
            for _ in range(rl):
                u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
            ncmd=u4(); pg['ncmd']=ncmd; cmds_tot+=ncmd
            for _ in range(ncmd):
                pc=u1()
                if pc>0:
                    op=u4(); codes[str(op)]=codes.get(str(op),0)+1
                    st['o']+=(pc-1)*4
                u1()
                sc=u1()
                for _ in range(sc): tstr()
                hr=u1()
                if hr!=0:
                    st['o']+=6
                    rl2=u4()
                    for _ in range(rl2):
                        u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
            pg['feat']=u4()
            if pg['feat']>3: pg['xfer']=u1()
            pg['shadow']=u1(); pg['rex']=u1(); pg['rey']=u1()
            pg['footer']=u1()
            pages.append(pg)
        ev['pages']=pages; pages_tot+=npg
        u1()
        events.append(ev)
    out['events']=events; out['pages_tot']=pages_tot; out['cmds_tot']=cmds_tot
    out['codes']=codes
    out['end']=st['o']; out['last']=b[-1]
    return out
res={}
tot_ev=tot_pg=tot_cmd=0
for f in sorted(os.listdir(base)):
    if not f.endswith('.mps'): continue
    r=parse_mps(os.path.join(base,f))
    res[f]=r
    tot_ev+=len(r['events']); tot_pg+=r['pages_tot']; tot_cmd+=r['cmds_tot']
    print('%-18s ev=%2d pg=%2d cmd=%5d no_tiles=%s end=%d last=0x%02x' % (f,len(r['events']),r['pages_tot'],r['cmds_tot'],r['no_tiles'],r['end'],r['last']))
print('TOTAL ev=%d pages=%d cmds=%d' % (tot_ev,tot_pg,tot_cmd))
# feat values
feats=set()
for f,r in res.items():
    for ev in r['events']:
        for pg in ev['pages']:
            feats.add(pg['feat'])
print('feature values seen:', sorted(feats))
# page footer bytes
footers={}
for f,r in res.items():
    for ev in r['events']:
        for pg in ev['pages']:
            footers[pg['footer']]=footers.get(pg['footer'],0)+1
print('page footer bytes:', footers)
# total distinct opcodes
allcodes={}
for f,r in res.items():
    for k,v in r['codes'].items(): allcodes[k]=allcodes.get(k,0)+v
print('distinct opcodes:', len([k for k in allcodes if k!='0']), 'total opcode entries', len(allcodes))
json.dump(res, open('work/_mps_detail.json','w',encoding='utf-8'), ensure_ascii=False)
