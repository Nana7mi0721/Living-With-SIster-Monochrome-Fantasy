# -*- coding: utf-8 -*-
"""Closure from TitleMap map event 2 (what PLAN.md's M1 claim is anchored to).

PLAN.md line 305 says: TitleMap 事件 2 -> 4 个事件 / 671 条指令 / 26 种 opcode.
This script recomputes it from the WolfTL JSON dump and reports the delta, plus
the route by which the map event reaches common event 42.

Inputs : work/wolftl/dump/mps/TitleMap.json, work/_ce_full.json
Output : stdout
"""
import io
import json

tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
print('TitleMap keys:', list(tm.keys()))
evs = tm.get('events') or tm.get('eventList')
print('events in TitleMap:', len(evs))
for e in evs[:6]:
    print('  id=%s pages=%d' % (e.get('id'), len(e.get('pages', []))))
ev2 = [e for e in evs if e.get('id') == 2][0]
page = ev2['pages'][0]
print('ev2 page keys:', list(page.keys()))
cmds = page['list']
print('ev2 commands:', len(cmds))
for i, c in enumerate(cmds):
    print('  %2d code=%d intArgs=%s strArgs=%s' % (i, c.get('code'), c.get('intArgs'), c.get('strArgs')))
