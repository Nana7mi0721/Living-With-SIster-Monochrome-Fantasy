
/// The first cell of the database whose config entry says "numeric".
fn first_numeric_cell(db: &wolf_save::vardb::VariableDatabase) -> Option<(usize, usize, usize)> {
    for (type_index, kind) in db.types.iter().enumerate() {
        let Some(field_index) = kind.config.iter().position(|def| *def < 2000) else {
            continue;
        };
        for (row_index, row) in kind.rows.iter().enumerate() {
            if row.number(field_index as u32).is_some() {
                return Some((type_index, row_index, field_index));
            }
        }
    }
    None
}

/// The first cell of the database whose config entry says "textual".
fn first_text_cell(db: &wolf_save::vardb::VariableDatabase) -> Option<(usize, usize, usize)> {
    for (type_index, kind) in db.types.iter().enumerate() {
        let Some(field_index) = kind.config.iter().position(|def| *def >= 2000) else {
            continue;
        };
        for (row_index, row) in kind.rows.iter().enumerate() {
            if row.string(field_index as u32).is_some() {
                return Some((type_index, row_index, field_index));
            }
        }
    }
    None
}

/// A hand-built database covering the three shapes `m_unknown` can take.
///
/// The retail saves all store -2, so the positive and -1 forms are never
/// exercised by them; this test is the only thing that pins those branches.
fn synthetic_database() -> wolf_save::vardb::VariableDatabase {
    use wolf_save::vardb::{VariableDatabase, VariableField, VariableRow, VariableType, VariableValue};

    fn row(index: u32, values: &[(u32, VariableValue)]) -> VariableRow {
        let mut fields: Vec<VariableField> = values
            .iter()
            .map(|(id, value)| VariableField {
                id: *id,
                value: value.clone(),
            })
            .collect();
        fields.sort_by_key(|field| field.id);
        VariableRow { index, fields }
    }

    let text = |body: &str| {
        let mut bytes = body.as_bytes().to_vec();
        bytes.push(0);
        VariableValue::String(bytes)
    };
    let empty_text = || VariableValue::String(vec![0]);

    // Shape 1: m_unknown positive -- it is the field count, no m_dis, no
    // m_fieldCount on disk. 2 numeric fields then 1 textual.
    let positive = VariableType {
        unknown: 3,
        dis: 0,
        field_count: 0,
        config: vec![0, 1, 2000],
        row_count: 1,
        rows: vec![row(
            0,
            &[
                (0, VariableValue::Number(7)),
                (1, VariableValue::Number(-9)),
                (2, text("あ")),
            ],
        )],
    };

    // Shape 2: m_unknown == -1 -- m_fieldCount is present, m_dis is not.
    let minus_one = VariableType {
        unknown: -1,
        dis: 0,
        field_count: 2,
        config: vec![1, 2001],
        row_count: 2,
        rows: vec![
            row(
                0,
                &[
                    (0, VariableValue::Number(11)),
                    (1, text("one")),
                ],
            ),
            row(
                1,
                &[
                    (0, VariableValue::Number(-11)),
                    (1, text("two")),
                ],
            ),
        ],
    };

    // Shape 3: m_unknown == -2 -- both m_dis and m_fieldCount, no fields at all.
    let minus_two = VariableType {
        unknown: -2,
        dis: 7,
        field_count: 0,
        config: Vec::new(),
        row_count: 2,
        rows: vec![
            row(0, &[]),
            row(1, &[]),
        ],
    };

    // Shape 4: -3 with a mixture, and an empty textual body.
    let minus_three = VariableType {
        unknown: -3,
        dis: 42,
        field_count: 4,
        config: vec![0, 2002, 3, 2003],
        row_count: 1,
        rows: vec![row(
            0,
            &[
                (0, VariableValue::Number(i32::MIN)),
                (1, empty_text()),
                (2, VariableValue::Number(i32::MAX)),
                (3, text("")),
            ],
        )],
    };

    VariableDatabase {
        unknown: 0x6F,
        type_count: 4,
        types: vec![positive, minus_one, minus_two, minus_three],
    }
}

/// `to_bytes` -> `parse` must reproduce the value it started from, for every
/// shape of `m_unknown`.
#[test]
fn a_synthetic_variable_database_round_trips_through_to_bytes() {
    let original = synthetic_database();
    let bytes = original.to_bytes().expect("encode synthetic database");
    let parsed = wolf_save::vardb::parse_bytes(&bytes).expect("reparse synthetic database");
    assert_eq!(parsed, original, "synthetic database did not round-trip");
    assert_eq!(
        parsed.to_bytes().expect("re-encode"),
        bytes,
        "re-encoding the reparsed value must be stable"
    );
}

/// A numeric cell edit reaches the file, and reverting it restores the file.
#[test]
fn a_mutated_vardb_number_survives_a_full_rebuild() {
    let saves = all_saves();
    if saves.is_empty() {
        return;
    }
    let (name, original, base) = &saves[0];
    let Some((type_index, row_index, field_index)) = first_numeric_cell(&base.vardb) else {
        panic!("{name}: the variable database has no numeric cell");
    };
    let before = base
        .vardb
        .number(type_index, row_index, field_index)
        .expect("cell");
    let edited = before.wrapping_add(1);

    let mut save = base.clone();
    assert!(
        save.set_vardb_num(type_index, row_index, field_index, edited)
            .expect("set_vardb_num"),
        "{name}: type {type_index} row {row_index} field {field_index} must be writable"
    );
    assert_eq!(
        save.vardb.number(type_index, row_index, field_index),
        Some(edited),
        "{name}: in-memory view"
    );
    let bytes = save.to_bytes_rebuilt().expect("rebuild after vardb edit");
    let fresh = SaveFile::parse(&bytes).expect("reparse after vardb edit");
    assert_eq!(
        fresh.vardb.number(type_index, row_index, field_index),
        Some(edited),
        "{name}: edited cell type {type_index} row {row_index} field {field_index}"
    );
    assert_eq!(fresh.vardb.type_count, base.vardb.type_count, "{name}: types");
    assert!(fresh.checksum_ok(), "{name}: checksum after vardb edit");

    // Revert: the encoder must have no hidden state, so the file comes back.
    let mut reverted = fresh;
    assert!(
        reverted
            .set_vardb_num(type_index, row_index, field_index, before)
            .expect("revert"),
        "{name}: revert"
    );
    let bytes = reverted.to_bytes_rebuilt().expect("rebuild after revert");
    if let Some(at) = first_difference(original, &bytes) {
        panic!("{name}: revert differs at offset {at:#X}");
    }
}

/// A textual cell edit survives a write, NUL terminator included.
#[test]
fn a_mutated_vardb_text_survives_a_full_rebuild() {
    let saves = all_saves();
    if saves.is_empty() {
        return;
    }
    let (name, _original, base) = &saves[0];
    let Some((type_index, row_index, field_index)) = first_text_cell(&base.vardb) else {
        panic!("{name}: the variable database has no textual cell");
    };
    let before = base
        .vardb
        .string(type_index, row_index, field_index)
        .expect("cell")
        .to_vec();

    let mut save = base.clone();
    assert!(
        save.set_vardb_text(type_index, row_index, field_index, "書き込みテスト")
            .expect("set_vardb_text"),
        "{name}: type {type_index} row {row_index} field {field_index} must be writable"
    );
    let bytes = save.to_bytes_rebuilt().expect("rebuild after vardb text");
    let fresh = SaveFile::parse(&bytes).expect("reparse after vardb text");
    assert_eq!(
        fresh.vardb.text(type_index, row_index, field_index).as_deref(),
        Some("書き込みテスト"),
        "{name}: edited text"
    );
    assert!(fresh.checksum_ok(), "{name}: checksum after vardb text");

    let mut reverted = fresh;
    assert!(
        reverted
            .set_vardb_string(type_index, row_index, field_index, &before)
            .expect("revert text"),
        "{name}: revert"
    );
    let bytes = reverted.to_bytes_rebuilt().expect("rebuild after revert");
    let back = SaveFile::parse(&bytes).expect("reparse after revert");
    assert_eq!(
        back.vardb.string(type_index, row_index, field_index),
        Some(before.as_slice()),
        "{name}: reverted text"
    );
}

/// Wrong-kind writes and out-of-range indexes are refused, not silently dropped.
#[test]
fn vardb_setters_refuse_what_they_cannot_encode() {
    let original = synthetic_database();
    let mut db = original.clone();

    // Field 2 of type 0 is textual; a numeric write there must fail.
    assert!(!db.set_num(0, 0, 2, 5));
    // Field 0 of type 0 is numeric; a textual write there must fail.
    assert!(!db.set_string(0, 0, 0, &[0]));
    // Out of range on every axis.
    assert!(!db.set_num(9, 0, 0, 5));
    assert!(!db.set_num(0, 9, 0, 5));
    assert!(!db.set_num(0, 0, 9, 5));
    // None of the refusals touched anything.
    assert_eq!(db, original);

    // A valid write does land, and encodes back out.
    assert!(db.set_num(0, 0, 1, -1));
    let bytes = db.to_bytes().expect("encode");
    let parsed = wolf_save::vardb::parse_bytes(&bytes).expect("reparse");
    assert_eq!(parsed.number(0, 0, 1), Some(-1));
}
