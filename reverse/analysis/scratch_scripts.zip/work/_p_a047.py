p = "crates/wolf-game/tests/opening.rs"
raw = open(p, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13)+chr(10), chr(10))
add = """
/// The M2 everyday chain: start a new game, answer the opening prompts, reach the
/// story HUD, write a save and load it back into a fresh Game. Everything the
/// player sees (the picture layer) and the state that changes during play (normal
/// variables, play time, choice anchor) must survive the round trip.
#[test]
fn a_new_game_can_be_saved_and_reloaded_after_the_opening() {
    let root = data_root();
    let mut game = match Game::new(&root) {
        Ok(game) => game,
        Err(err) => {
            eprintln!("skipping: {err}");
            return;
        }
    };
    let template = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("work/retail_backup/Save/System.sav");
    let Ok(bytes) = std::fs::read(&template) else {
        eprintln!("skipping: no retail System.sav at {}", template.display());
        return;
    };
    game.base_save = Some(wolf_save::SaveFile::parse(&bytes).expect("template parses"));

    game.auto_advance = true;
    game.auto_choice = true;
    game.auto_choice_delay = 1;
    game.set_choice_cursor(0);
    if let Err(err) = game.start_map_event_by_name("Map003", 1) {
        eprintln!("skipping: cannot start new-game processing: {err}");
        return;
    }
    for _ in 0..1200 {
        let _ = game.frame();
    }
    assert!(
        game.screen.len() > 40,
        "the new game did not reach the story scene: {} pictures",
        game.screen.len()
    );
    assert_eq!(game.stats.warnings, 0, "the new-game run produced warnings");

    let before_screen: Vec<_> = game
        .screen
        .iter()
        .map(|p| (p.number, p.kind, p.file.clone(), p.x, p.y, p.anchor, p.scale, p.split, p.pattern_index))
        .collect();
    let before_vars: Vec<i32> = (0..800).map(|index| game.vm.vars.get(index)).collect();
    let before_playtime = game.playtime_frames();
    assert!(before_playtime > 0, "play time did not advance");

    let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("target")
        .join("test-scratch");
    std::fs::create_dir_all(&dir).expect("scratch dir");
    let path = dir.join("m2-newgame-roundtrip.sav");
    let written = game.save_to(&path).expect("save the new game");
    assert!(written > 300_000, "{written} bytes");

    let mut reloaded = Game::new(&root).expect("fresh game");
    reloaded.load_save(&path).expect("load the new game");
    let after_screen: Vec<_> = reloaded
        .screen
        .iter()
        .map(|p| (p.number, p.kind, p.file.clone(), p.x, p.y, p.anchor, p.scale, p.split, p.pattern_index))
        .collect();
    assert_eq!(before_screen, after_screen, "the picture layer changed");
    assert_eq!(reloaded.playtime_frames(), before_playtime, "play time changed");
    for index in 0..800 {
        assert_eq!(
            reloaded.vm.vars.get(index),
            before_vars[index],
            "normal variable {index} changed"
        );
    }
    assert_eq!(
        reloaded.vm.vars.get_sys(3),
        game.vm.vars.get_sys(3),
        "Sys3 changed"
    );
    assert_eq!(
        reloaded.vm.vars.get_sys(4),
        game.vm.vars.get_sys(4),
        "Sys4 changed"
    );
}
"""
assert t.count("fn the_title_menu_starts_a_new_game") == 1
t = t.rstrip() + chr(10) + chr(10) + add
if crlf: t = t.replace(chr(10), chr(13)+chr(10))
open(p, "wb").write(t.encode("utf-8"))
print("ok")