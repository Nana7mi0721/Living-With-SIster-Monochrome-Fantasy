# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
by_id = {ev['id']: ev for ev in ce}
def dump(evid, lo, hi):
    ev = by_id[evid]
    print('--- event', evid, repr(ev['title']), 'cmds', len(ev['cmds']))
    for pc in range(lo, min(hi, len(ev['cmds']))):
        code,a,s = norm(ev['cmds'][pc])
        if code == 0: continue
        print('  pc%-4d %-4d a=%s s=%s' % (pc, code, a, s))
dump(264, 40, 60)
print()
# who consumes slot5 with 112
for evid in (264,):
    pass
# find a callee that reads 1600005 via 112
for ev in ce:
    for pc,c in enumerate(ev['cmds']):
        code,a,s = norm(c)
        if code==112 and a and (a[0] & 0xFFFFFFFF)==1600005:
            print('=== consumer candidate event', ev['id'], repr(ev['title']), 'pc', pc, 'a=',a, 's=',s)
            dump(ev['id'], max(0,pc-6), pc+8)
            break
    else:
        continue
    break
