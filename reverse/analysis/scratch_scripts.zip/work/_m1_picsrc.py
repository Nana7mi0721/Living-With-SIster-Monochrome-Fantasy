# -*- coding: utf-8 -*-
"""For each picture number the M1 trace touches, find the 150 instructions that
target it, with their owning event + slot + raw args.

Inputs : work/_m1_closure2.json (closure rows), work/_ce_full.json,
         work/wolftl/dump/mps/TitleMap.json
Output : stdout + work/_m1_picsrc.json
"""
import collections, io, json

events = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
map_evs = {e['id']: e for e in tm['events']}
clos = json.load(io.open('work/_m1_closure2.json', encoding='utf-8'))
rows = clos['from_map_event2']['reached']

def norm(cmds):
    out = []
    for c in cmds:
        if 'c' in c:
            out.append({'c': c['c'], 'a': [int(x) for x in c['a']], 's': list(c.get('s') or [])})
        else:
            out.append({'c': c.get('code', 0),
                        'a': [int(x) for x in (c.get('intArgs') or [])],
                        's': list(c.get('stringArgs') or [])})
    return out

UNCHANGED = -1000000
def flagbit(raw):
    return (int(raw) & 0x0F000000) != 0

pics = collections.defaultdict(list)
for r in rows:
    if r['kind'] == 'c':
        cmds = norm(by_id[r['id']]['cmds'])
    else:
        cmds = []
        for p in map_evs[r['id']]['pages']:
            cmds.extend(norm(p['list']))
    for i, c in enumerate(cmds):
        if c['c'] != 150 or len(c['a']) < 2:
            continue
        head, num = c['a'][0], c['a'][1]
        # num may be a self/var reference; only literals are attributable statically
        kind = (head >> 4) & 0x07
        action = {0: 'Draw', 1: 'Move', 2: 'Erase'}.get(head & 0x0F, 'Set')
        if 0 <= num < 200000:
            pics[num].append({'event': ('c%d' % r['id']) if r['kind'] == 'c' else ('m%d' % r['id']),
                              'slot': i, 'action': action, 'kind': kind,
                              'head': head, 'args': c['a'][2:], 'strs': c['s']})

for num in sorted(pics):
    lst = pics[num]
    evs = collections.Counter(x['event'] for x in lst)
    print('#%-6d %d site(s) in %d event(s): %s' % (num, len(lst), len(evs), dict(evs)))
    for x in lst:
        print('    %s slot %-4d %-5s kind=%d args=%s strs=%s'
              % (x['event'], x['slot'], x['action'], x['kind'], x['args'], x['strs']))
    print('')
json.dump({str(k): v for k, v in pics.items()},
          io.open('work/_m1_picsrc.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
