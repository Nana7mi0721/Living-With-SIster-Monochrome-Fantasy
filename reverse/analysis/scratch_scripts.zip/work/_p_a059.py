p = "docs/M2_SLICE.md"
raw = open(p, "rb").read()
crlf = raw.find(bytes([13,10])) >= 0
t = raw.decode("utf-8").replace(chr(13)+chr(10), chr(10))
a = "| git HEAD | `107205e`（新游戏→存档→读档往返；此前 `ba761be` 为 `130` 地图传送与标题→新游戏链） |"
b = "| git HEAD | `0faa1da`（标题→新游戏→存档→读档；此前 `ba761be` 为 `130` 地图传送与标题→新游戏链） |"
assert t.count(a) == 1
t = t.replace(a, b)
if crlf: t = t.replace(chr(10), chr(13)+chr(10))
open(p, "wb").write(t.encode("utf-8"))
print("ok")