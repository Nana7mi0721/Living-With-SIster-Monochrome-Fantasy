import io, os
path = "docs/SAVE_SPEC.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """## 8. SavePart5 — 公共事件运行时状态（**已验证**）

`docs/vendor/WolfSave/SavePart5.h:661`（外层）与 `:44`（`SavePart5_1`）。"""
b = """## 8. SavePart5 — 当前画面图片表（**已验证**）

> **修正（已验证）**：本节旧标题「公共事件运行时状态」是错的。SavePart5 记录的是**存档瞬间仍然活着的 `150` 图片**，
> 不是事件协程状态；公共事件的 self 变量/字符串在 SavePart3 里。实测 SaveData01 的 66 条记录对应 66 张活图片。
> 字段语义见下表与 §8.1。

`docs/vendor/WolfSave/SavePart5.h:661`（外层）与 `:44`（`SavePart5_1`）。"""
assert t.count(a) == 1
t = t.replace(a, b)
a2 = """实测 `m_var1` = 58..84（各文件不同），bit 15 从未置位，所以总能读到 `m_var1` 个条目。
**这就是「哪些公共事件当前有运行时状态」的列表** —— 与公共事件总数 550 无关。"""
b2 = """实测 `m_var1` = 58..84（各文件不同），bit 15 从未置位，所以总能读到 `m_var1` 个条目。
**这就是「存档瞬间哪些图片还活着」的列表** —— 与公共事件总数 550 无关。"""
assert t.count(a2) == 1
t = t.replace(a2, b2)
a3 = """| `m_var1` | u32 | 事件 id。实测第一条是 `0xFFFFFFF6`（= -10） |
| `m_var2` / `m_var3` | u8 ×2 | |
| `m_var4` | u16 | |
| `m_var5` / `m_var6` | u8 ×2 | |
| `m_md1` | MemData<u16> | 实测第一条是 22 字节 ASCII：`cg/bg_14_sunset_a.jpg` |
| `m_vars7_18` | u32 ×12 | |"""
b3 = """| `m_var1` | u32 | 图片编号（按 i32 解释；负数是整屏层/引擎层） |
| `m_var2` / `m_var3` | u8 ×2 | 未用（实测全 0） |
| `m_var4` | u16 | anchor：0 左上 / 1 中心 / 2 左下 / 3 右上 / 4 右下 |
| `m_var5` / `m_var6` | u8 ×2 | 类型：m_var5=1 → Text；m_var6=1 → WindowFile；两者 0 → 普通文件图（无 var5=2） |
| `m_md1` | MemData<u16> | 文件名（含结尾 NUL）或文本图片的转义流 |
| `m_vars7_18` | u32 ×12 | `[x, y, 分割列/窗口宽, 分割行/窗口高, pattern(1 基), opacity, blend, -1, fade, scaleX%, scaleY%, 0]` |"""
assert t.count(a3) == 1
t = t.replace(a3, b3)
a4 = """`m_var90` 的子表在参考实现里是「先读一个 u32，再读那么多个 u32」，与 §6 的 `m_var5` 同构。

---

## 9. VariableDatabase — 变量库（**已验证**）"""
b4 = """`m_var90` 的子表在参考实现里是「先读一个 u32，再读那么多个 u32」，与 §6 的 `m_var5` 同构。

### 8.1 记录语义（实测，220 mode 0 / `--load-save` 共用）

- **普通文件图**（m_var5=0、m_var6=0）：m_md1 是文件名，`m_vars7_18[2]/[3]` 是**精灵表分割列/行**（1x1 = 整图），
  `[4]` 是 **1 基** pattern 单元号；picture 90 `Picture/stand_imouto_paja2.png` = `[600,80,6,2,2,255,0,-1,1,100,100,0]` 就是 6x2 表第 2 格。
- **窗口图**（m_var6=1）：`[2]/[3]` 是窗口宽高；picture 19500 = 960x168。
- **文本图**（m_var5=1）：m_md1 是 `01 <总长> <payload>` 的转义流，实测只出现 02→`\E`、04→带字距字体、
  05→字体（payload[2] = 字号+14）、06→颜色（payload[3] = 颜色号+14，0x0f 特判 `\c[0]`）；
  例如 pic 6200 = `01 05 03 0e 26 01 "21:40" 00` → `\f[24]21:40`。
- **fade 字段 [8] 在载入时必须置 0**：它是历史上一次淡入的时长，不是「还要再淡入」；零售 save1 的面板记录 fade=10 却已经 100% 显示。
- 写回侧：`crate::savegame::part5_from_screen` / `picture_to_record` 是读入的逆过程；`encode_picture_text` 把 `\E`/`\f[n]`/`\c[n]`
  重新编码成 02/05/06 字节流。唯一语义等价但非字节等价的是 retail 的 04（带字距字体）记录：读成 `\f[n]`，写回成 05。
- 测试：`a_saved_game_reloads_its_live_picture_layer`、`every_retail_text_picture_survives_re_encoding`、
  `a_text_picture_round_trips_through_its_save_record`、`a_file_picture_keeps_its_sprite_grid_in_the_record`。

---

## 9. VariableDatabase — 变量库（**已验证**）"""
assert t.count(a4) == 1
t = t.replace(a4, b4)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")