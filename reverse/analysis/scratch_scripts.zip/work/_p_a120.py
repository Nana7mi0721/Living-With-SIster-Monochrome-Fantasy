import json
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
for ev in ce:
    r=ev['run']&0x0F
    if r in (2,3):
        print(ev['id'], r, ev['title'][:34], 'cmds', ev['cmds'] if isinstance(ev['cmds'],int) else len(ev['cmds']))
