import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
anchor = """        assert_eq!(save.part2.vars3_21[9], 111);
        assert_eq!(save.part2.vars3_21[10], 222);
    }

    #[test]
    fn a_missing_data_root_is_an_error_not_a_panic() {"""
new = """        assert_eq!(save.part2.vars3_21[9], 111);
        assert_eq!(save.part2.vars3_21[10], 222);
    }

    #[test]
    fn a_saved_game_reloads_its_live_picture_layer() {
        let Some(root) = have_data() else { return };
        let mut template = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        template.pop();
        template.pop();
        template.push("work");
        template.push("retail_backup");
        template.push("Save");
        template.push("SaveData01.sav");
        let Ok(bytes) = std::fs::read(&template) else { return };
        let mut game = Game::new(&root).expect("game");
        game.base_save = Some(wolf_save::SaveFile::parse(&bytes).expect("template parses"));
        let loaded = game.load_save(&template).expect("load");
        assert!(loaded.pictures > 10, "{} pictures", loaded.pictures);
        let before: Vec<_> = game
            .screen
            .iter()
            .map(|p| (p.number, p.kind, p.file.clone(), p.x, p.y, p.anchor, p.scale, p.split, p.pattern_index))
            .collect();
        let mut out = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        out.push("..");
        out.push("..");
        out.push("target");
        out.push("test-scratch");
        std::fs::create_dir_all(&out).expect("scratch dir");
        out.push("savegame-pictures.sav");
        game.save_to(&out).expect("save");

        let mut refreshed = Game::new(&root).expect("game");
        refreshed.load_save(&out).expect("reload");
        let after: Vec<_> = refreshed
            .screen
            .iter()
            .map(|p| (p.number, p.kind, p.file.clone(), p.x, p.y, p.anchor, p.scale, p.split, p.pattern_index))
            .collect();
        assert_eq!(before, after);
    }

    #[test]
    fn a_missing_data_root_is_an_error_not_a_panic() {"""
assert t.count(anchor) == 1
t = t.replace(anchor, new)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")