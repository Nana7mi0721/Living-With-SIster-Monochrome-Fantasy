import io, json
d = json.load(io.open(r"E:\Study\github program\imoto life\docs\BASELINE.json", encoding="utf-8"))
print(list(d.keys()))
print("boot:", d["boot_screen"]["hint_banner"]["placed_rect"], d["boot_screen"]["pixel_diff_vs_retail"]["mean_abs"])
print("title:", d["title_screen"]["instructions"])
print("verify:", d["verify"]["checks"], d["verify"]["pending"])