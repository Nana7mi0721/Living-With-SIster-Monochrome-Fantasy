import io, os, sys
sys.stdout.reconfigure(encoding='utf-8')
spec = 'docs/SAVE_SPEC.md'
text = io.open(spec, encoding='utf-8', newline='').read()
ins61 = io.open('work/_ins61.md', encoding='utf-8', newline='').read()
ins11 = io.open('work/_ins11.md', encoding='utf-8', newline='').read()
ins13 = io.open('work/_ins13.md', encoding='utf-8', newline='').read()
anchor = '上层按计数切片即可还原嵌套结构。\n\n---\n\n## 7. SavePart4'
assert text.count(anchor) == 1, ('anchor61', text.count(anchor))
text = text.replace(anchor, '上层按计数切片即可还原嵌套结构。\n\n---\n\n' + ins61 + '## 7. SavePart4')
a11 = '实测输出 `checked 9 save file(s)`，1 passed。'
assert text.count(a11) == 1, ('anchor11', text.count(a11))
text = text.replace(a11, a11 + '\n\n' + ins11.rstrip('\n'))
text = text.rstrip('\n') + '\n' + ins13
io.open(spec + '.new', 'w', encoding='utf-8', newline='').write(text)
os.replace(spec + '.new', spec)
print('ok', len(text))