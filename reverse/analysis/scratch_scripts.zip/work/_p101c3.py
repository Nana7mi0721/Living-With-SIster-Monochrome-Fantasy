
import json,io,collections,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
items=[(e['id'],e.get('run'),norm(c)) for e in ce for c in e['cmds']]
items+=[('M',None,norm(c)) for m in mp.values() for ev in m.get('events',[]) for c in ev.get('cmds',[])]
for base in (52,53,54,55,56,57,74,11,115,116,117,118,119,125):
    w=[(eid,a[:4]) for eid,run,(op,a,s) in items if op in (121,124) and a and a[0]==9000000+base]
    print('Sys%-4d writers %3d %s'%(base,len(w),w[:2]))
# 101 by run_condition of owner event (CE only)
cnt=collections.Counter()
for e in ce:
    cnt[e.get('run')]+=sum(1 for c in e['cmds'] if norm(c)[0]==101)
print('101 in CE by owner run_condition',dict(cnt))
# indent distribution of 101
ind=collections.Counter()
def ind(c): return c.get('bd',-1)
for e in ce:
    for c in e['cmds']:
        if norm(c)[0]==101: ind[ind(c)]+=1
print('101 branch_depth histogram(top6)',ind.most_common(6))
# how many 101 are the first cmd / last cmd
first=0;last=0
for e in ce:
    cm=e['cmds']
    if cm and norm(cm[0])[0]==101: first+=1
    if cm and norm(cm[-1])[0]==101: last+=1
print('events whose first cmd is 101:',first,' last cmd 101:',last)
