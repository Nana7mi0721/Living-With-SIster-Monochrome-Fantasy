import io,os,sys
root=r'E:/Study/github program/imoto life/work/imouto/Data'
kws=['警戒','好感','性興味','行動力','精力','所持金','日数','時間','状態','アルバム','エンディング','周回','相册','体力','気力','お金','経験','スキル','アイテム']
def strs(b):
    out=[];cur=bytearray()
    for ch in b:
        if 0x20<=ch<=0x7e or 0x81<=ch<=0x9f or 0xe0<=ch<=0xfc:
            cur.append(ch)
        else:
            if len(cur)>=3:
                try: out.append(cur.decode('cp932'))
                except Exception: pass
            cur=bytearray()
    if len(cur)>=3:
        try: out.append(cur.decode('cp932'))
        except Exception: pass
    return out
for name in sorted(os.listdir(root)):
    if not name.endswith('.dat'): continue
    p=os.path.join(root,name)
    b=open(p,'rb').read()
    ss=strs(b)
    hits=[s for s in ss if any(k in s for k in kws)]
    if not hits: continue
    uniq=[];seen=set()
    for h in hits:
        if h not in seen:
            seen.add(h);uniq.append(h)
    print('==',name,len(b),'strs',len(ss),'hits',len(uniq))
    print(' | '.join(uniq[:60]))