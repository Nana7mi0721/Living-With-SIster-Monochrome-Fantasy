
import json,collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
OPEN={111,112,102,179,170,176}; CLOSE={499,498}
strays=collections.Counter(); unm=collections.Counter(); kinds=collections.Counter(); pairs=0
for ev in d:
    stack=[]
    for i,c in enumerate(ev['cmds']):
        o=c['c']; b=c['bd']
        if o in OPEN: stack.append((b,i,o))
        elif o in CLOSE:
            if stack and stack[-1][0]==b:
                ob,oi,oo=stack.pop(); pairs+=1; kinds[(oo,o)]+=1
            else: strays[(o,b)]+=1
    for b,i,o in stack: unm[(o,b)]+=1
print('pairs',pairs,kinds)
print('strays',sum(strays.values()),dict(strays))
print('unmatched openers',sum(unm.values()),dict(unm))
