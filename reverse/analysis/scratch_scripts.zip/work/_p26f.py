# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
by_id = {ev['id']: ev for ev in ce}
def dump(evid, lo=0, hi=999):
    ev = by_id[evid]
    print('--- event', evid, repr(ev['title']), 'cmds', len(ev['cmds']))
    for pc in range(lo, min(hi, len(ev['cmds']))):
        code,a,s = norm(ev['cmds'][pc])
        if code == 0: continue
        print('  pc%-4d %-4d a=%s s=%s' % (pc, code, a, s))
dump(104)
print()
dump(103, 0, 30)
