
import struct, sys

path = r"E:\Study\github program\imoto life\work\retail_backup\Save\SaveData08.sav"
buf = bytearray(open(path,"rb").read())
seeds = [buf[0], buf[3], buf[9]]
for pass_i, step in ((0,1),(1,2),(2,5)):
    state = seeds[pass_i]
    at = 0x14
    while at < len(buf):
        state = (state*214013 + 2531011) & 0xFFFFFFFF
        r = (state >> 16) & 0x7FFF
        buf[at] ^= (r >> 12) & 0xFF
        at += step
data = bytes(buf)
fv = struct.unpack_from("<H", data, 0x15 + 2 + 43)[0]
print("fileVersion", hex(fv), "len", len(data))

def sc(x):
    return 0 if x >= 0x80000000 else x

def parse_rec(d, o, fv):
    o0 = o
    var1 = struct.unpack_from("<I", d, o)[0]; o += 4
    var2 = d[o]; o += 1
    var3 = d[o]; o += 1
    var4 = struct.unpack_from("<H", d, o)[0]; o += 2
    var5 = d[o]; o += 1
    var6 = d[o]; o += 1
    n = struct.unpack_from("<H", d, o)[0]; o += 2
    if n > 4000: raise ValueError("md1")
    md1 = d[o:o+n]; o += n
    vars7_18 = list(struct.unpack_from("<12I", d, o)); o += 48
    o += 24  # vals1
    if fv >= 0x69: o += 72
    if fv >= 0x6B: o += 1
    if fv >= 0x72: o += 2 + 32
    if fv >= 0x73:
        o += 16
        if fv >= 0x74: o += 20
        if fv >= 0x75: o += 24
        o += 24
    if fv >= 0x76: o += 12
    if fv >= 0x81:
        o += 84
        if fv >= 0x87: o += 20
        if fv >= 0x89:
            var90 = struct.unpack_from("<I", d, o)[0]; o += 4
            c = sc(var90)
            if c > 64: raise ValueError("subcount")
            for _ in range(c):
                ln = sc(struct.unpack_from("<I", d, o)[0]); o += 4
                if ln > 4096: raise ValueError("sublen")
                o += 4*ln
            o += 28
    return var1,var2,var3,var4,var5,var6,md1,vars7_18,o

# find candidate: u16 count == 84 followed by 84 parseable records
hits = []
for p in range(0x44, len(data)-2):
    if data[p] == 84 and data[p+1] == 0:
        o = p+2
        try:
            nums = []
            for _ in range(84):
                rec = parse_rec(data, o, fv)
                nums.append(rec[0])
                o = rec[8]
            hits.append((p, o, nums))
        except Exception:
            continue
print("candidates", len(hits))
for p,o,nums in hits[:4]:
    print(hex(p), "end", hex(o), "n_unique", len(set(nums)))
if hits:
    p,o,nums = hits[0]

    with open(r"E:\Study\github program\imoto life\work\_m3_sd08_recs.txt","w",encoding="utf-8") as f:
        q = p+2
        for _ in range(84):
            rec = parse_rec(data, q, fv)
            f.write("%d\tx=%d y=%d split=%dx%d pat=%d op=%d blend=%d var5=%d var6=%d w=%d h=%d file=%r\n" % (
                rec[0], rec[7][0], rec[7][1], rec[7][2], rec[7][3], rec[7][4], rec[7][5], rec[7][6], rec[4], rec[5],
                rec[7][2], rec[7][3], rec[6][:40]))
            q = rec[8]
    print("wrote recs")
