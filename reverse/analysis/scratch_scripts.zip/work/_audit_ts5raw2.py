
import json,io
OUT=io.StringIO()
raw=open('work/all/BasicData/TileSetData.dat','rb').read()
start=raw.find(b'MapChip/b_05')  # first good name found at 52132 (inside name)
# walk backwards to find beginning of the t_str block: strings are len-prefixed? print 400 bytes before
seg=raw[51500:52600]
print('hexdump 51500..52600',file=OUT)
print(seg.hex(),file=OUT)
# try cp932 decode of whole seg
for enc in ['cp932','utf-8']:
    try:
        print(enc,'->',seg.decode(enc,errors='replace'),file=OUT)
    except Exception as e: print(enc,'fail',e,file=OUT)
open('work/_audit_ts5raw2.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
