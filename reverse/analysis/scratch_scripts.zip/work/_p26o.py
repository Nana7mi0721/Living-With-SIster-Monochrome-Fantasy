import io, os
p = 'E:/Study/github program/imoto life/docs/OPCODE_210_RETURN.md'
s = io.open(p, encoding='utf-8', newline='').read()
old = 'CSelf4 是编辑器的空档，本作也没有任何站点读 ' + chr(96) + '1_600_004' + chr(96) + '。'
new = ('CSelf4 是编辑器的空档：**引擎不往它投递实参**（数值实参只到 CSelf3）。本作有 107 处操作数引用\n'
       + chr(96) + '1_600_004' + chr(96) + '，但全是事件内部当作普通局部槽在用（ev90 的 ' + chr(96) + '121 [1600020, 1600001, 1600004, ...]' + chr(96) + ' 之类），\n'
       '没有任何调用点期待它带进实参。')
assert old in s, 'anchor missing'
s = s.replace(old, new)
io.open(p + '.new', 'w', encoding='utf-8', newline='').write(s)
os.replace(p + '.new', p)
print('patched')