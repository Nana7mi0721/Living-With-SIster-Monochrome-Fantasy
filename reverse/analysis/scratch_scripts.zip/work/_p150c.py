
import json, collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
forms=collections.defaultdict(list)
for ev in d:
    for i,c in enumerate(ev['cmds']):
        if c['c']!=150: continue
        a=c['a']
        forms[len(a)].append((ev['id'],i,a,c['s']))
print("argc -> count")
for k in sorted(forms): print(" ",k,len(forms[k]))
print()
for k in sorted(forms):
    if k<12: continue
    print("=== argc",k,"examples (max 3) ===")
    for evid,i,a,s in forms[k][:3]:
        print("  ev",evid,"pc",i,"args",a,"strs",s)
    # per-index distinct value summary
    n=k
    for idx in range(n):
        vals=collections.Counter(t[2][idx] for t in forms[k])
        top=vals.most_common(4)
        print("   idx%2d distinct=%d top=%s"%(idx,len(vals),top))
