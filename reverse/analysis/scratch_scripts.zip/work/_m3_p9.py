
import json,os,re,collections,io
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=sorted(json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"])
out=io.open(os.path.join(W,"_m3_texts.txt"),"w",encoding="utf-8")
esc=collections.Counter(); per=collections.defaultdict(collections.Counter); texts=[]
for i in H:
    for k,c in enumerate(idx[i]["cmds"]):
        if c["c"]!=150: continue
        head=c["a"][0]; kind=(head>>4)&7
        per[i][kind]+=1
        if kind in (2,4) and c["s"]:
            t=c["s"][0]
            for m in re.findall(r"\\[a-zA-Z]+",t): esc[m]+=1
            texts.append((i,k,t,c["a"]))
out.write("escapes: %s\n\n"%dict(esc))
for i in H:
    out.write("%d\t%s\t%s\n"%(i,idx[i]["title"],dict(per[i])))
out.write("\n=== all text pictures (%d) ===\n"%len(texts))
for i,k,t,a in texts:
    out.write("ev%d pc%d a=%s %r\n"%(i,k,a,t))
out.write("\n=== distinct %d ===\n"%len(set(t for _,_,t,_ in texts)))
for t in sorted(set(t for _,_,t,_ in texts)):
    out.write(repr(t)+"\n")
out.close()
print("written")
