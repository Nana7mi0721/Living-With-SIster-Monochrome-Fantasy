p = "crates/wolf-game/tests/opening.rs"
t = open(p, encoding="utf-8").read()
a = "    assert_eq!(before_screen, after_screen, "the picture layer changed");"
b = """    if before_screen != after_screen {
        for (index, (before, after)) in before_screen.iter().zip(after_screen.iter()).enumerate() {
            if before != after {
                eprintln!("picture {index} before {before:?} after {after:?}");
            }
        }
        panic!("the picture layer changed");
    }"""
assert t.count(a) == 1
t = t.replace(a, b)
open(p, "w", encoding="utf-8", newline="").write(t)
print("ok")