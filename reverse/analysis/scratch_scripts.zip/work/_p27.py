
import json, sys, collections, unicodedata
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))
retid = {int(k): v['retid'] for k, v in meta.items()}
titles = {}
for e in ce: titles.setdefault(e['title'], e['id'])
def norm(s):
    s = unicodedata.normalize('NFKC', s)
    return ''.join(ch for ch in s if ch.isalnum())
ntitles = {}
for t, i in titles.items(): ntitles.setdefault(norm(t), i)

tot = ex = nx = un = 0
unres = collections.Counter()
for e in ce:
    for c in e['cmds']:
        if c['c'] != 300: continue
        tot += 1
        name = c['s'][0] if c['s'] else ''
        if name in titles: ex += 1
        elif norm(name) in ntitles: nx += 1
        else:
            un += 1
            unres[name] += 1
print('300 sites', tot, 'exact', ex, 'normalized-only', nx, 'unresolved', un)
for k, v in unres.most_common(20): print('  ', v, repr(k), '-> retid of a same-ish event?', end=' ')
print()

