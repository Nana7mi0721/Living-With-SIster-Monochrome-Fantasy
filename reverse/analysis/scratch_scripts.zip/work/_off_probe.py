import struct
b = open('work/full/MapData/TitleMap.mps','rb').read()
o = 25
n = struct.unpack_from('<I', b, o)[0]
raw = b[o+4:o+4+n]
print('title len word', n, 'payload', raw)
o = 25 + 4 + n
print('tileset at', o, struct.unpack_from('<I', b, o)[0])
print('width', struct.unpack_from('<I', b, o+4)[0], 'height', struct.unpack_from('<I', b, o+8)[0])
print('events', struct.unpack_from('<I', b, o+12)[0])
print('first_pixel at', o+16, hex(struct.unpack_from('<I', b, o+16)[0]))
