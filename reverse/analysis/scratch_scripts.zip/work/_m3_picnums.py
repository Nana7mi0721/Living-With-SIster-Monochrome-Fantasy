
import json,os,collections,re
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"]
L=[]
def p(s=""): L.append(s)

# picture numbers used per event: 150 arg[1]
p("## 150 picture numbers per H-closure event")
for i in sorted(H):
    e=idx[i]
    nums=collections.Counter(); acts=collections.Counter(); kinds=collections.Counter()
    for c in e["cmds"]:
        if c["c"]!=150: continue
        a=c.get("a") or []
        if len(a)<2: continue
        head=a[0]; num=a[1]
        kind=(head>>4)&0x07
        act=head&0x0F
        nums[num]+=1
        acts[act]+=1
        kinds[kind]+=1
    p("ev%-4d %-24s nums=%s kinds=%s acts=%s"%(i,e["title"][:22],
      sorted(nums), dict(kinds), dict(acts)))
open(os.path.join(W,"_m3_out6.txt"),"w",encoding="utf-8").write("\n".join(L))
print("lines",len(L))
