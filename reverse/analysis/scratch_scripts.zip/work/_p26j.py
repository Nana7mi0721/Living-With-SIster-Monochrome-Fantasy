# -*- coding: utf-8 -*-
import json, sys, collections, re
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
by_id = {ev['id']: ev for ev in ce}
byname = {}
for ev in ce: byname.setdefault(ev['title'], ev['id'])
allsites=[]
for ev in ce:
    for pc,c in enumerate(ev['cmds']):
        code,a,s = norm(c); allsites.append(('ce',ev['id'],pc,code,a,s))
for mn,mp in maps.items():
    if not isinstance(mp,dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc,c in enumerate(ev['cmds']):
            code,a,s = norm(c); allsites.append(('map:'+mn,ev.get('id'),pc,code,a,s))
def bits(a):
    v = a[1] & 0xFFFFFFFF if len(a)>1 else 0
    return (v & 0xF, (v>>4)&0xF, [(v>>(12+i))&1 for i in range(5)], (v>>24)&1, v)

CONSUMERS = set([112, 122, 250, 101, 150, 221, 111, 121, 124])

def refs(evid):
    """slots 5..8 -> list of opcodes referencing them, and forwarded slots"""
    ev = by_id.get(evid)
    if ev is None: return None
    out = collections.defaultdict(list)
    for pc, c in enumerate(ev['cmds']):
        code,a,s = norm(c)
        for v in a:
            u = v & 0xFFFFFFFF
            if 1600000 <= u <= 1600999:
                out[u-1600000].append((code, pc))
        if code == 101:
            for t in s:
                for m in re.finditer(r'\\\\cself\[(\d+)\]', t):
                    n = int(m.group(1))
                    if 1600000 <= 1600000+n <= 1600999:
                        out[n].append((101, pc))
    return out

# classify a callee: does it CONSUME slot k (any non-210/300/211 opcode) or just forward?
def classify(evid, depth=0):
    r = refs(evid)
    if r is None: return None
    res = {}
    for k in (5,6,7,8):
        ops = [c for (c,pc) in r.get(k, [])]
        consume = [c for c in ops if c not in (210,211,300)]
        forward = [c for c in ops if c in (210,211,300)]
        res[k] = (consume, forward)
    return res

sites = [x for x in allsites if x[3] in (210,300) and bits(x[4])[1] > 0]
tab = collections.Counter()
examples = collections.defaultdict(list)
for x in sites:
    num, st, en, rv, raw = bits(x[4])
    if x[3]==300: tgt = byname.get(x[5][0]) if x[5] else None
    else:
        r0 = x[4][0]
        tgt = r0-500000 if 500000<=r0<=599999 else (r0-600000 if 600000<=r0<=699999 else None)
    if tgt is None:
        tab['unresolved'] += 1; continue
    c = classify(tgt)
    if c is None:
        tab['no-program'] += 1; continue
    for k in range(st):
        slot = 5+k
        cons, fwd = c.get(slot, ([],[]))
        if cons: key='consumed'
        elif fwd: key='forwarded'
        else: key='unused'
        tab[(k, slot, key)] += 1
        if len(examples[(k,slot,key)])<4: examples[(k,slot,key)].append((x[1],x[2],tgt))
for k in sorted(tab, key=str): print(' ', k, ':', tab[k])
print()
for k in sorted(examples, key=str):
    print(' ', k, examples[k])
print()
print('== total:', len(sites))
