import json, collections

p = "docs/M2_SLICE.md"
raw = open(p, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
marker = "\n---\n\n## 5. 与 PLAN.md 的偏差（M2 项的作废与替换）"
assert t.count(marker) == 1
add = """
### 4.6 地图传送 `130` 与会话内切图（★已实现）

`130` 全作只有少量站点，arg0 只出现 `-1` 与 `-2`。`-1` / `-2` 不是地图文件名，而是
**SysDatabase 类型 0（マップ設定）行号的有符号编码**：`-1` = 行 1 = `MapData/SampleMapA.mps`，
`-2` = 行 0 = `MapData/TitleMap.mps`；正数按行号直取。证据（三条独立）：

- `SysDatabase` 类型 0 的 50 行里 row 0 = `MapData/TitleMap.mps`、row 1 = `MapData/SampleMapA.mps`、
  row 3 = `MapData/Map003.mps`（标题 `ニューゲーム処理`）。
- `Map003.mps` event 1（新游戏处理图）注释 `ここでサンプルマップに移動`，pc28 = `130 [-1, 62, 38, 1, 1]`。
- `TitleMap.mps` event 2 的 `210 [500042]` 菜单分支里 `130 [-1, 60, 34, 3, 1]`；TitleMap 只有 53x30，
  `(60,34)` 不可能是它自己的格坐标。

实现：`GameHost::teleport` 只排一个 `MapRequest { map, x, y, direction }`（host 不能借 `&mut Game`），
`Game::frame` 在 VM 返回后处理：`runtime.stop_all(&mut vm)` 停掉旧图所有页面协程（含子协程），
`Databases::map_path(id)` 查 SysDatabase，解析 `.mps` 后 `start_pages` 启动新图自动页；
每次切图记一条 `130 Teleport: MapData/SampleMapA.mps at (62, 38) direction 1` 诊断。

**实测两条入口**：

| 入口 | 结果 |
|---|---|
| `capture --map-run Map003 --event 1 --frames 600` | 新游戏处理 → `130` → SampleMapA，停在开场四选一；26,415 指令 / 654 图操作 / 0 警告 |
| `boot` → 标题 → 回车 → 标题菜单第一项 → 900 帧 | `130 Teleport: MapData/SampleMapA.mps at (60, 34) direction 3`，同样停在开场四选一 |

测试：`the_new_game_processing_map_teleports_into_the_opening` 与 `the_title_menu_starts_a_new_game`
（crates/wolf-game/tests/opening.rs，后者走完整 boot → 标题 → 菜单 → 新游戏链）。

---

## 5. 与 PLAN.md 的偏差（M2 项的作废与替换）"""
t = t.replace(marker, add)
a = "15. **存档操作码**：220 读档排队、221 读档内变量、222 写档内变量并落盘；地址映射与存档写回测试见 §4.5。\n"
b = "15. **存档操作码**：220 读档排队、221 读档内变量、222 写档内变量并落盘；地址映射与存档写回测试见 §4.5。\n16. **地图传送与标题新游戏链**：`130` 的 `-1/-2` 解码为 SysDatabase 行号，切图时停旧图协程、启新图自动页；`boot → 标题 → 菜单 → 新游戏 → 开场四选一` 已有集成测试（§4.6）。\n"
assert t.count(a) == 1
t = t.replace(a, b)
if crlf:
    t = t.replace(chr(10), chr(13) + chr(10))
open(p, "wb").write(t.encode("utf-8"))

bp = "docs/BASELINE.json"
d = json.load(open(bp, encoding="utf-8"), object_pairs_hook=collections.OrderedDict)
d["map_teleport"] = collections.OrderedDict([
    ("opcode", 130),
    ("map_id_law", "-1 = SysDatabase type 0 row 1 (MapData/SampleMapA.mps); -2 = row 0 (MapData/TitleMap.mps); positive ids are row numbers"),
    ("evidence", ["SysDatabase type 0 row 0 TitleMap / row 1 SampleMapA / row 3 Map003 (new game processing)", "Map003.mps event 1 pc28 130 [-1, 62, 38, 1, 1] with the comment here is the sample map transition", "TitleMap.mps event 2 menu branch 130 [-1, 60, 34, 3, 1]; TitleMap is 53x30 so 60,34 cannot be its own grid"]),
    ("implementation", "GameHost::teleport queues MapRequest; Game::frame calls MapRuntime::stop_all, Databases::map_path, parses the .mps and start_pages; diagnostics record the path and target"),
    ("tests", ["the_new_game_processing_map_teleports_into_the_opening", "the_title_menu_starts_a_new_game"]),
    ("measured", collections.OrderedDict([
        ("map003_entry", "capture --map-run Map003 --event 1 --frames 600: 26415 instructions / 654 picture ops / 1 choice / 0 warnings, opening prompt reached"),
        ("title_entry", "boot -> title -> confirm -> title menu option 0 -> 900 frames: 130 Teleport: MapData/SampleMapA.mps at (60, 34) direction 3, opening prompt reached"),
    ])),
])
json.dump(d, open(bp, "w", encoding="utf-8", newline="\n"), indent=1, ensure_ascii=False)
print("done")