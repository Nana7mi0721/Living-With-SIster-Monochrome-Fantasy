
import json,io,os,collections
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure2.json',encoding='utf-8'))
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
sizes=fin['sizes']
def nodes(lst):
    out=set()
    for s in lst:
        s=s.strip()
        if s.startswith("('c'"): out.add(('c',int(s.split(',')[1].strip(' )'))))
        elif s.startswith("('m'"):
            parts=s.split(',')
            out.add(('m',parts[1].strip().strip("'\""),int(parts[2].strip(' )'))))
    return out
bootauto=nodes(cl['boot2'])
autoev={k[1] for k in bootauto if k[0]=='c'}
# pure boot: recompute from edges is easier - reuse _audit_boot.py logic minus auto
allc={k[1] for k in bootauto if k[0]=='c'}
W('boot+auto common: %d ; map nodes: %s'%(len(allc),[k for k in bootauto if k[0]=='m']))
def size(p): return sizes.get(p,0)
def assets(evset):
    ps=set()
    for p,sites in refs['referenced'].items():
        for src,loc,op in sites:
            if src=='common':
                ev=int(loc.split('#')[0].replace('ev',''))
                if ev in evset: ps.add(p); break
    return ps
ba=assets(allc)
W('boot+auto assets: %d files / %d B'%(len(ba),sum(size(p) for p in ba)))
agg=collections.defaultdict(lambda:[0,0])
for p in ba:
    d=p.split('/')[0]; agg[d][0]+=1; agg[d][1]+=size(p)
for d,(n,b) in sorted(agg.items(),key=lambda kv:-kv[1][1]):
    W('   %-22s %4d %10d'%(d,n,b))
open('work/_audit_out30.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
