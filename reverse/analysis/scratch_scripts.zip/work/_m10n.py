import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
def magic111(c):
    a=c.get('a',[])
    if not a: return False
    n=a[0]&0xF
    for i in range(n):
        base=1+3*i
        if base+1<len(a):
            val=a[base+1]
            if abs(val)>=1000000: return True
    return False
print("=== all 111 magic-operand sites (event:pc:a) ===")
cnt=0
for e in ces:
    for i,c in enumerate(e['cmds']):
        if c['c']==111 and magic111(c):
            cnt+=1
print("total magic 111 sites:",cnt)
print("=== writers of 2000013/2000014 and callers of CE226 ===")
for e in ces:
    for i,c in enumerate(e['cmds']):
        a=c.get('a',[])
        if c['c']==121 and a and a[0] in (2000013,2000014):
            print(f"CE{e['id']} pc{i} 121 {a}")
        if c['c'] in (210,300) and a:
            # 210 a[0]=500000+id ; 300 name-based skip
            if c['c']==210 and a[0]==500226:
                print(f"CE{e['id']} pc{i} 210 CALL CE226 {a}")
print("=== CE372 callers (op300 name or op210) ===")
t2i={}
for e in ces: t2i.setdefault(e['title'],[]).append(e['id'])
print("CE372 title:",repr(by[372]['title']))
# find callers by op210 500372 or op300 name==title
for e in ces:
    for i,c in enumerate(e['cmds']):
        a=c.get('a',[])
        if c['c']==210 and a and a[0]==500372:
            print(f"CALLER CE{e['id']} pc{i} 210 {a}")
        if c['c']==300 and c.get('s') and c['s'] and c['s'][0]==by[372]['title']:
            print(f"CALLER CE{e['id']} pc{i} 300 {a} name={c['s'][0]!r}")

