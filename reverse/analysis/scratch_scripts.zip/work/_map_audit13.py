# -*- coding: utf-8 -*-
import sys, io, os, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
src = open('work/_map_audit10.py', encoding='utf-8').read()
pre = src.split("REG = [")[0]
pre = '\n'.join(l for l in pre.splitlines() if not l.startswith('import sys') and not l.startswith('sys.stdout'))
g = {}
exec(compile(pre, 'walklib', 'exec'), g)
parse_mps = g['parse_mps']
base = r'work\full\MapData'
ALL = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps','SampleMapB.mps','Dungeon.mps','Map002.mps']
maps = {f: parse_mps(os.path.join(base, f)) for f in ALL}
print('teleport sites (opcode 130), pc from enumerate:')
n = 0
for f in ALL:
    for e in maps[f]['events']:
        for pi, p in enumerate(e['pages']):
            for ci, c in enumerate(p['cmds']):
                if c['op'] == 130:
                    n += 1
                    print('%d|%s|%d|%s|%d|%d|%s|%s|argc=%d' % (n, f, e['id'], e['name'], pi, ci, c['args'], c['strings'], len(c['args']) + 1))
print('total sites:', n)
