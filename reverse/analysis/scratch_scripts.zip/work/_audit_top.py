
import json,io,os
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
never=fin['never']; sizes=fin['sizes']
rows=sorted(never,key=lambda p:-sizes[p])
W('never count %d total %d'%(len(never),sum(sizes[p] for p in never)))
W('--- top 40 never (all) ---')
for p in rows[:40]:
    W('%12d  %s'%(sizes[p],p))
data=[p for p in rows if p.startswith('BasicData/') or p.startswith('MapData/')]
W('\ndata-file entries inside never: %d / %d B'%(len(data),sum(sizes[p] for p in data)))
W('--- top 40 never, assets only (no BasicData/MapData) ---')
n=0
for p in rows:
    if p.startswith('BasicData/') or p.startswith('MapData/'): continue
    W('%12d  %s'%(sizes[p],p)); n+=1
    if n>=40: break
open('work/_audit_out28.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
