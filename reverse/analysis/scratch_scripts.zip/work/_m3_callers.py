
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
T=[338,340,341,343,346,350,351,353,354,357,358,365,367,372,407,410,445]
Ts=set(T)
L=[]
def p(s=""): L.append(s)

# ---------- callers ----------
callers=collections.defaultdict(list)  # target -> list of (src, kind, pc, how)
def scan_cmds(cmds, src):
    for i,c in enumerate(cmds):
        op=c.get("c") if isinstance(c,dict) else c[0]
        ints=c.get("a") if isinstance(c,dict) else c[1]
        strs=c.get("s") if isinstance(c,dict) else c[2]
        if op==210 and ints:
            raw=ints[0]
            tgt=None
            if 500000<=raw<=599999: tgt=raw-500000
            elif 600000<=raw<=699999: tgt=raw-600000
            elif 0<=raw<500000: tgt=raw
            if tgt in Ts: callers[tgt].append((src,"210",i,str(raw)))
        elif op==300 and strs:
            name=strs[0]
            for t in T:
                if idx[t]["title"]==name:
                    callers[t].append((src,"300",i,name))
for e in ce: scan_cmds(e["cmds"],"ce%d"%e["id"])
for mname,m in maps.items():
    for ev in m.get("events",[]):
        scan_cmds(ev.get("cmds",[]),"map:%s#ev%s"%(mname,ev.get("id")))

p("## CALLERS")
for t in T:
    cl=callers.get(t,[])
    p("ev%d (%s): %d caller-site(s)"%(t,idx[t]["title"],len(cl)))
    for s,kind,pc,info in cl[:40]:
        p("    <- %s  op%s pc=%d  %s"%(s,kind,pc,info))

# ---------- opcode histograms ----------
p("")
p("## OPCODE HISTOGRAM")
for t in T:
    e=idx[t]
    hist=collections.Counter(c["c"] for c in e["cmds"] if c["c"])
    p("ev%d run=%s slots=%d instr=%d :: %s"%(t,e["run"],len(e["cmds"]),sum(hist.values()),
      ", ".join("%d:%d"%(k,v) for k,v in sorted(hist.items(),key=lambda x:-x[1]))))
open(os.path.join(W,"_m3_out1.txt"),"w",encoding="utf-8").write("\n".join(L))
print("lines",len(L))
