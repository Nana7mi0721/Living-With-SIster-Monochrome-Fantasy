
import json, io
events = json.load(io.open(r"E:\Study\github program\imoto life\work\_ce_full.json", encoding="utf-8"))
by = {e.get("id"): e for e in events}
out = io.open(r"E:\Study\github program\imoto life\work\_dump123.txt", "w", encoding="utf-8", newline="\n")
def show(eid, lo, hi):
    e = by[eid]
    out.write("=== ev%s  slots=%d\n" % (eid, len(e.get("cmds", []))))
    for i, cm in enumerate(e.get("cmds", [])):
        if lo <= i <= hi:
            out.write("pc%-5d %-5s %s %s\n" % (i, cm.get("c"), cm.get("a"), [s[:40] for s in (cm.get("s") or [])]))
    out.write("\n")
show(108, 20, 60)
show(65, 78, 112)
show(118, 104, 130)
show(523, 405, 425)
show(525, 815, 830)
show(510, 970, 985)
out.close()
print("ok")
