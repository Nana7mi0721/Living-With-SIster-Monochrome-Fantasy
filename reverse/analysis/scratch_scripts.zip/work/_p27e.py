import io, os
spec = 'docs/OPCODE_220_SAVE.md'
text = io.open(spec, encoding='utf-8', newline='').read()

a1 = '### 6.1 SavePart3 的语义定位（本作数据的强证据，但仍标【未验证】整体结论）'
assert text.count(a1) == 1, text.count(a1)
text = text.replace(a1, '### 6.1 SavePart3 的语义定位（**已验证**：组号 = 公共事件 id、槽 = セルフ変数号）')

a2 = '本作数据无法区分——**写出路径因此不实现「按变量号改存档」**，只实现整段替换（§7）。'
assert text.count(a2) == 1, text.count(a2)
text = text.replace(a2, '本作数据无法区分——写出一度因此只做整段替换（§7）。**该结论已于 §6.3 推翻**：漏查了 `row_words`，通常変数就在那里。')

a3 = '## §10 与 `docs/SAVE_SPEC.md` 的出入（需要 Lead 定夺，本文档未改动那份文件）'
assert text.count(a3) == 1, text.count(a3)
text = text.replace(a3, '## §10 与 `docs/SAVE_SPEC.md` 的出入（§6.1 / §6.2 / §11.1 / §13 已同步写入 SAVE_SPEC）')

a4 = '2. SAVE_SPEC 未记录「通常変数 / システム変数 找不到落盘区」这个负面结论，建议把它作为一条明确缺口写进去（§6.2、§8 U1）。'
assert text.count(a4) == 1, text.count(a4)
text = text.replace(a4, '2. ~~SAVE_SPEC 未记录「通常変数 / システム変数 找不到落盘区」~~ —— **已写并已改正**：SAVE_SPEC §6.1 记录「通常変数 = row 0」的三条证据与逐档表值，§13 只保留「システム変数没有落盘区」这一条真缺口。')

io.open(spec + '.new', 'w', encoding='utf-8', newline='').write(text)
os.replace(spec + '.new', spec)
print('ok')