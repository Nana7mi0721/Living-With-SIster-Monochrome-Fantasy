import io, os

def sub(path, a, b):
    t = io.open(path, encoding="utf-8", newline="").read()
    assert t.count(a) == 1, ("count", t.count(a), a[:70])
    open(path + ".new", "w", encoding="utf-8", newline="").write(t.replace(a, b))
    os.replace(path + ".new", path)
    print("sub", path)

main = "crates/wolf-cli/src/main.rs"
a1 = """    // A WOLF script never draws its own choice frame: the engine paints a window skin and
    // moves a cursor over it. Without this overlay a held capture photographs a title
    // screen with no visible menu at all, because the three option strings "1"/"2"/"3"
    // are placeholders the runtime is supposed to replace with the prompt.
    if let Some(choices) = &game.choices {
        let options = choices.options.clone();
        let cursor = game.choice_cursor();
        let (panel, rows) = choice::overlay(&mut atlas, &mut game.assets, &options, cursor);
        sprites.extend(panel);
        texts.extend(rows);
    }"""
b1 = """    // A WOLF script never draws its own choice frame: the engine paints a window skin and
    // moves a cursor over it, at the coordinates system variables 3 (x) and 4 (y) name.
    // There is no centred default (docs/OPCODE_102.md section 4.2), and when the finished
    // rectangle falls outside the 1024x576 viewport the engine paints nothing at all -
    // which is what the title event relies on when it parks the window at y = 1000.
    if let Some(choices) = &game.choices {
        let options = choices.options.clone();
        let cursor = game.choice_cursor();
        let (x, y) = game.choice_anchor();
        if let Some((panel, rows)) =
            choice::overlay_at(&mut atlas, &mut game.assets, &options, cursor, x, y)
        {
            sprites.extend(panel);
            texts.extend(rows);
        }
    }"""
sub(main, a1, b1)

a2 = """            match anchored {
                Some(panel) => println!(
                    "            : engine rect {:?}, {} row(s), {:?}",
                    panel.rect,
                    panel.lines.len(),
                    panel.lines.first().copied()
                ),
                None => println!("            : anchor is off screen, engine draws nothing"),
            }"""
b2 = """            match anchored {
                Some(panel) => println!(
                    "            : engine rect {:?}, {} row(s)",
                    panel.rect,
                    panel.lines.len()
                ),
                None => println!("            : anchor is off screen, engine draws nothing"),
            }"""
sub(main, a2, b2)

play = "crates/wolf-cli/src/play.rs"
a3 = """        if let Some(choices) = &self.game.choices {
            let options = choices.options.clone();
            let cursor = self.game.choice_cursor();
            let (panel, rows) = choice::overlay(
                &mut self.atlas,
                &mut self.game.assets,
                &options,
                cursor,
            );
            sprites.extend(panel.iter().map(Self::tint_instance));
            texts.extend(rows);
        }"""
b3 = """        if let Some(choices) = &self.game.choices {
            let options = choices.options.clone();
            let cursor = self.game.choice_cursor();
            let (x, y) = self.game.choice_anchor();
            if let Some((panel, rows)) = choice::overlay_at(
                &mut self.atlas,
                &mut self.game.assets,
                &options,
                cursor,
                x,
                y,
            ) {
                sprites.extend(panel.iter().map(Self::tint_instance));
                texts.extend(rows);
            }
        }"""
sub(play, a3, b3)