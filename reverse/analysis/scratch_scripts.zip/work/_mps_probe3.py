import struct, os, sys, io, json
from collections import Counter
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base='work/full/MapData'
def head(p):
    b=open(p,'rb').read()
    o=16
    vh=b[o]; o+=1; o+=3
    unk=struct.unpack_from('<I',b,o)[0]; o+=4
    ver=b[o]; o+=1
    n=struct.unpack_from('<I',b,o)[0]; o+=4
    title=b[o:o+n]; o+=n
    ts,w,h,ec=struct.unpack_from('<IIII',b,o); o+=16
    return b,o,vh,unk,ver,title,ts,w,h,ec
for f in sorted(os.listdir(base)):
    if not f.endswith('.mps'): continue
    b,o,vh,unk,ver,title,ts,w,h,ec=head(os.path.join(base,f))
    fp=struct.unpack_from('<I',b,o)[0]
    layerstats=[]
    if fp!=0xFFFFFFFF:
        vals=struct.unpack_from('<%dI'%(w*h*3), b, o)
        c=Counter(vals)
        ffff=c.get(0xFFFFFFFF,0)
        auto=sum(v for k,v in c.items() if k!=0xFFFFFFFF and k//100000>0)
        plain=sum(v for k,v in c.items() if k!=0xFFFFFFFF and k//100000==0)
        layer0=vals[:w*h]
        layerstats=[('layer0 first6',layer0[:6]),('distinct',len(c)),('ffff',ffff),('auto',auto),('plain',plain),('max',max(v for v in vals if v!=0xFFFFFFFF))]
    print('%-18s vh=0x%02x unk=%d ver=0x%02x title=%r ts=%d %dx%d ec=%d fp=%08x %s' % (f,vh,unk,ver,title.decode('utf-8','replace'),ts,w,h,ec,fp,layerstats))
