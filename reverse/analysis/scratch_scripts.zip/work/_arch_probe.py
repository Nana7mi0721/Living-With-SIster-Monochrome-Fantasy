
import json, os, collections
os.chdir(r'E:\Study\github program\imoto life')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))

def cls(v):
    if 0<=v<1000000: return 'imm'
    if 1000000<=v<2000000: return 'self?1M'
    if 2000000<=v<3000000: return 'var?2M'
    if 3000000<=v<4000000: return 'str?3M'
    if 9000000<=v<10000000: return 'sys?9M'
    return 'other:%d'%v

# SetVariable arg0 targets
tgt=collections.Counter()
vals=[]
for e in ev:
    for c in e['cmds']:
        if c['c']==121 and c['a']:
            tgt[cls(c['a'][0])]+=1
            vals.append(c['a'][0])
print('SetVariable arg0 classes:', dict(tgt.most_common()))
import bisect
vals_s=sorted(set(vals))
print('min',vals_s[0],'max',vals_s[-1],'distinct',len(vals_s))
# ranges of self-like
selfs=[v for v in vals if 1000000<=v<2000000]
print('self range', min(selfs), max(selfs), 'n distinct', len(set(selfs)))
print('self sample', sorted(set(selfs))[:20])
vars2=[v for v in vals if 2000000<=v<3000000]
print('var range', min(vars2), max(vars2), 'n distinct', len(set(vars2)))
print('var sample', sorted(set(vars2))[:20])

# 111 VariableCondition layout: arg0=count, then triples (var, value, op)
lay=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==111:
            n=c['a'][0]; lay[(n, len(c['a']))]+=1
print('111 (count,arglen):', dict(lay.most_common(12)))
# verify arglen == 1+3n
bad=[(n,l) for (n,l) in lay if l!=1+3*n]
print('111 mismatches:', bad[:10])

# 111 var classes
vc=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==111:
            n=c['a'][0]
            for k in range(n):
                vc[cls(c['a'][1+3*k])]+=1
print('111 var classes', dict(vc.most_common()))
