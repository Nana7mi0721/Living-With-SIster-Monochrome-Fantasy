import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """    #[test]
    fn a_missing_data_root_is_an_error_not_a_panic() {"""
b = """    #[test]
    fn a_save_written_from_a_retail_template_round_trips() {
        let Some(root) = have_data() else { return };
        let mut template = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        template.pop();
        template.pop();
        template.push("work");
        template.push("retail_backup");
        template.push("Save");
        template.push("SaveData01.sav");
        let Ok(bytes) = std::fs::read(&template) else {
            eprintln!("skipping: no retail save at {}", template.display());
            return;
        };
        let mut game = Game::new(&root).expect("game");
        game.base_save = Some(wolf_save::SaveFile::parse(&bytes).expect("template parses"));
        game.vm.vars.set(7, 4321);
        game.vm.vars.set_sys(3, 111);
        game.vm.vars.set_sys(4, 222);
        game.set_playtime_frames(1234);

        let mut out = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        out.push("..");
        out.push("..");
        out.push("target");
        out.push("test-scratch");
        std::fs::create_dir_all(&out).expect("scratch dir");
        out.push("savegame-roundtrip.sav");
        let written = game.save_to(&out).expect("save");
        assert!(written > 300_000, "{written} bytes");

        let save = crate::savegame::read_save(&out).expect("re-read");
        assert_eq!(save.part3.normal_var(7), Some(4321));
        assert_eq!(save.part2.vars3_21[0], 1234);
        assert_eq!(save.part2.vars3_21[9], 111);
        assert_eq!(save.part2.vars3_21[10], 222);
    }

    #[test]
    fn a_missing_data_root_is_an_error_not_a_panic() {"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("patched")
