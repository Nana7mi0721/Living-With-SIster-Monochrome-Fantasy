import json, io
events = json.load(io.open("work/_ce_full.json", encoding="utf-8"))
ev = [e for e in events if e["id"] == 63][0]
cmds = ev["cmds"]
print("ev63 cmds", len(cmds))
for i in range(84, 120):
    c = cmds[i]
    print(i, c["c"], "a=", c["a"], "s=", c["s"])