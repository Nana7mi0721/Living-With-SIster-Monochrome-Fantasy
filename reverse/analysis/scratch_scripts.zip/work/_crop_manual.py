
from PIL import Image
import os
src='E:/EROGAME/Imouto! Life ~Monochrome~ zh-CN Ver'
out='work/out/manual'
os.makedirs(out, exist_ok=True)
for i in range(1,7):
    im=Image.open(f'{src}/manual0{i}.jpg')
    w,h=im.size
    for k in range(2):
        box=(0, k*h//2, w, min(h,(k+1)*h//2))
        im.crop(box).save(f'{out}/m{i}_{k}.png')
print('ok')
