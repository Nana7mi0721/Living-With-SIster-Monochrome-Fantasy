import os,sys
g=r'E:/EROGAME/Imouto! Life ~Monochrome~ zh-CN Ver'
def strs(b,minlen=2):
    out=[];cur=bytearray()
    for ch in b:
        if 0x20<=ch<=0x7e or 0x81<=ch<=0x9f or 0xe0<=ch<=0xfc:
            cur.append(ch)
        else:
            if len(cur)>=minlen:
                try: out.append(bytes(cur).decode('cp932'))
                except Exception: pass
            cur=bytearray()
    if len(cur)>=minlen:
        try: out.append(bytes(cur).decode('cp932'))
        except Exception: pass
    return out
for name in ['Config.exe','Game.exe']:
    b=open(os.path.join(g,name),'rb').read()
    ss=strs(b)
    jp=[s for s in ss if any('\u3040'<=c<='\u30ff' or '\u4e00'<=c<='\u9fff' for c in s) and 2<=len(s)<=30]
    uniq=[];seen=set()
    for s in jp:
        if s not in seen: seen.add(s);uniq.append(s)
    kw=['設定','音量','画面','ウィンドウ','フル','セーブ','ロード','ゲーム','速度','表示','キー','操作','サウンド','環境','倍','拡大','縮小','スキップ','オート','文字']
    hit=[s for s in uniq if any(k in s for k in kw)]
    print('==',name,len(b),'jp',len(uniq),'kw',len(hit))
    print('|'.join(hit[:200]))
    print()
    print('--- ALL first 160:', '|'.join(uniq[:160]))
    print()