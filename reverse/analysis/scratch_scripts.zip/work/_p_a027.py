import io, os
path = "docs/M2_SLICE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """| C15 | `wolf-cli capture --load-save work/retail_backup/Save/SaveData01.sav --frames 1 --out work/out/save1_load3.png` | 存档载入态（§2.4） |"""
b = """| C15 | `wolf-cli capture --load-save work/retail_backup/Save/SaveData01.sav --frames 1 --out work/out/save1_load3.png` | 存档载入态（§2.4） |
| C16 | `cargo test -q -p wolf-game a_saved_game_reloads_its_live_picture_layer` 与 `a_saved_game_keeps_the_database_cells` | 整档回写（§2.5） |"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")