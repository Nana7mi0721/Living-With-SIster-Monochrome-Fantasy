import io,sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
p = 'docs/OPCODE_250.md'
s = open(p, encoding='utf-8').read()
bs = chr(92)
old = bs*2 + 'cself[9] ' + '\u3092\u7fd2\u5f97\uff01' + bs*2 + 'r' + bs*2 + 'n'
print('old present', s.count(old))
s2 = s.replace(bs*2 + 'cself[9]', bs + 'cself[9]', 2)
cnt = s2.count(bs*2)
print('double-backslash remaining', cnt)
s2 = s2.replace(bs*2 + 'r' + bs*2 + 'n', bs + 'r' + bs + 'n')
open(p,'w',encoding='utf-8',newline='\n').write(s2)
print('double now', s2.count(bs*2))
for i,l in enumerate(s2.split(chr(10)),1):
    if bs*2 in l: print(i, l)