import io, json, sys
sys.stdout.reconfigure(encoding='utf-8')
root = r'E:/Study/github program/imoto life'
d = json.load(io.open(root + '/work/wolftl/dump/db/CDataBase.json', encoding='utf-8'))
for ti in (0, 16, 17, 19):
    t = d['types'][ti]
    print('=== type', ti, t['name'], 'fields', len(t['fields']), 'rows', len(t['data']))
    for i, f in enumerate(t['fields'][:20]):
        print('   pos', i, repr(f.get('name')))
    if len(t['fields']) > 20:
        print('   ...', len(t['fields']) - 20, 'more')
