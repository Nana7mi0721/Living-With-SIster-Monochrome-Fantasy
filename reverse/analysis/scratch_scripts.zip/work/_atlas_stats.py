
import os, struct, json, collections

ROOT = "work/alldata"

def png_size(b):
    if len(b) >= 24 and b[:8] == b"\x89PNG\r\n\x1a\n" and b[12:16] == b"IHDR":
        w, h = struct.unpack(">II", b[16:24])
        return w, h, b[24]  # bit depth
    return None

def jpg_size(b):
    i = 2
    n = len(b)
    while i < n - 9:
        if b[i] != 0xFF:
            i += 1
            continue
        m = b[i+1]
        if m in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF):
            h, w = struct.unpack(">HH", b[i+5:i+9])
            return w, h, 8
        if m in (0xD8,0xD9) or 0xD0 <= m <= 0xD7:
            i += 2
            continue
        seg = struct.unpack(">H", b[i+2:i+4])[0]
        i += 2 + seg
    return None

rows = []
for dirpath, dirnames, filenames in os.walk(ROOT):
    for fn in filenames:
        ext = os.path.splitext(fn)[1].lower()
        if ext not in (".png", ".jpg", ".bmp", ".jpeg", ".webp"):
            continue
        p = os.path.join(dirpath, fn)
        try:
            sz = os.path.getsize(p)
            with open(p, "rb") as f:
                head = f.read(1 << 16)
            d = png_size(head) if ext == ".png" else jpg_size(head)
        except Exception:
            continue
        if not d:
            continue
        w, h, bits = d
        arch = os.path.relpath(dirpath, ROOT).split(os.sep)[0]
        rows.append(dict(arch=arch, path=os.path.relpath(p, ROOT).replace(os.sep,"/"),
                         file_bytes=sz, w=w, h=h, rgba=w*h*4))

def pct(vals, q):
    if not vals: return 0
    vals = sorted(vals)
    return vals[min(len(vals)-1, int(q*(len(vals)-1)+0.5))]

by = collections.defaultdict(list)
for r in rows: by[r["arch"]].append(r)

print("TOTAL images parsed:", len(rows))
print()
hdr = f"{'archive':<20}{'n':>5}{'MB on disk':>12}{'decoded MB':>12}{'median wxh':>14}{'max w':>7}{'max h':>7}{'>2048':>7}{'>=1024x576':>11}"
print(hdr)
print("-"*len(hdr))
for arch in sorted(by, key=lambda a: -sum(r["rgba"] for r in by[a])):
    g = by[arch]
    ws = sorted(r["w"] for r in g); hs = sorted(r["h"] for r in g)
    med = (pct(ws,.5), pct(hs,.5))
    big = sum(1 for r in g if r["w"] > 2048 or r["h"] > 2048)
    fs = sum(1 for r in g if r["w"]*r["h"] >= 1024*576)
    print(f"{arch:<20}{len(g):>5}{sum(r['file_bytes'] for r in g)/2**20:>12.1f}{sum(r['rgba'] for r in g)/2**20:>12.1f}{str(med):>14}{max(ws):>7}{max(hs):>7}{big:>7}{fs:>11}")
print()
allw = [r["w"] for r in rows]; allh = [r["h"] for r in rows]
print("width  percentiles p50/p75/p90/p95/p99/max:", [pct(allw,q) for q in (.5,.75,.9,.95,.99,1.0)])
print("height percentiles p50/p75/p90/p95/p99/max:", [pct(allh,q) for q in (.5,.75,.9,.95,.99,1.0)])
tot = sum(r["rgba"] for r in rows)
print(f"decoded RGBA8 for every image in the game: {tot/2**20:.1f} MiB")
print(f"2048x2048 atlas holds 16.0 MiB => whole game = {tot/2**20/16:.0f} atlases")
print("images exceeding 2048 in a dimension (cannot go in a 2048 atlas):", sum(1 for r in rows if r["w"]>2048 or r["h"]>2048))
print("images >= 1024x576 (full-screen or larger):", sum(1 for r in rows if r["w"]*r["h"] >= 1024*576), " decoded", f"{sum(r['rgba'] for r in rows if r['w']*r['h']>=1024*576)/2**20:.1f} MiB")
# shelf packing efficiency proxy: perfect fit for 1024x576 items
print()
print("biggest 15 images:")
for r in sorted(rows, key=lambda r:-r["rgba"])[:15]:
    print(f"  {r['w']:>5}x{r['h']:<5} {r['rgba']/2**20:>7.2f}MB  {r['path']}")

json.dump(rows, open("work/_atlas_stats.json","w"))
