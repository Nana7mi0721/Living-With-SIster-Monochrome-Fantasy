import json, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
by = {e['id']: e for e in ce}
def norm(c):
    if 'c' in c: return c['c'], c['a'], c['s']
    return c['code'], c['ints'], c['strs']
for eid in (2, 94):
    ev = by[eid]
    idx = [i for i,c in enumerate(ev['cmds']) if norm(c)[0]==221]
    print('### ev', eid, ev['title'], 'cmds', len(ev['cmds']), '221 at', idx)
    for i in idx[:6]:
        for j in range(max(0,i-4), min(len(ev['cmds']), i+5)):
            c,a,s = norm(ev['cmds'][j])
            mark = '>>' if j==i else '  '
            print(f'{mark} {j:4d} {c:4d} a={a} s={[x[:50] for x in s]}')
        print('  ---')

