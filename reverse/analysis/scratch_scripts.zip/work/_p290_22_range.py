
import zipfile, sys, io, json, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
ed = z.read('Editor.exe')
gm = z.read('Game.exe')

def lits(data, lo, hi):
    out = []
    i = lo
    while i < hi - 2:
        n = int.from_bytes(data[i:i+2], 'little')
        if 2 <= n <= 60:
            try:
                s = data[i+2:i+2+2*n].decode('utf-16-le')
            except Exception:
                i += 2; continue
            if all(0x20 <= ord(ch) < 0x10000 and ord(ch) not in (0xfffd,) for ch in s):
                out.append((i, s)); i += 2 + 2*n; continue
        i += 2
    return out

print('### literal cluster right AFTER the param labels (0xa8495c .. 0xa84b00) - looks for picture-number / range labels')
for off, s in lits(ed, 0xa8495c, 0xa84b40):
    print('  0x%x  %s' % (off, s))
print()
print('### literal cluster BEFORE the effect enum (0xa84600 .. 0xa847e0)')
for off, s in lits(ed, 0xa84620, 0xa847e0):
    print('  0x%x  %s' % (off, s))
