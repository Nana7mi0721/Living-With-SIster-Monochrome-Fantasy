import io, os
path = "docs/M2_SLICE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """text      : 7 item(s), 68 glyph(s), 7 line(s), 0 substituted
rendered  : 1024x576, 161282/589824 non-black pixel(s) = 27.3%
stats     : 30619 instruction(s), 2394 picture op(s), 0 sound(s), 98 db access(es) (13 write, 9 label), 1 message(s), 0 choice(s), 0 warning(s)
```"""
b = """text      : 6 item(s), 67 glyph(s), 6 line(s), 0 substituted
rendered  : 1024x576, 157014/589824 non-black pixel(s) = 26.6%
stats     : 30619 instruction(s), 2394 picture op(s), 0 sound(s), 98 db access(es) (13 write, 9 label), 1 message(s), 0 choice(s), 0 warning(s)
```

> 这是 `message::layout_styled` 的输出（`\f[n]` 改字号、`\c[n]` 调色、`\E` 描边、`<C>` 居中）。旧版纯文本 `layout` 给 7 item / 68 glyph / 161282 px（27.3%），现在由带样式的路径取代；行首 `<C>` 让第一行居中，其余行左对齐。"""
assert t.count(a) == 1
t = t.replace(a, b)
a2 = """| 文本来源 | `101` argc 恒 0 / strc 恒 1，全文 12,027 条 | docs/OPCODE_101.md | 已验证 |"""
b2 = """| 文本来源 | `101` argc 恒 0 / strc 恒 1，全文 12,027 条 | docs/OPCODE_101.md | 已验证 |
| 排版 | `layout_styled`: `\f[n]` 改字号，`\c[n]` 从 SysDB 12 调色，`\E` 描边，`<C>` 居中；一个 run 一个 TextQuad | `crates/wolf-game/src/message.rs`（task-29） | 已验证（同一套 `PictureColours` 同时服务 textpic 与 101） |"""
assert t.count(a2) == 1
t = t.replace(a2, b2)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")