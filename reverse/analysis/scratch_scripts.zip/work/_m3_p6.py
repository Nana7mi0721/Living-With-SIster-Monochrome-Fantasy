
import json,os,sys
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
p=os.path.join(W,"_mps_full.json")
print(os.path.exists(p))
d=json.load(open(p,encoding="utf-8"))
print(type(d), list(d)[:10] if isinstance(d,dict) else len(d))
