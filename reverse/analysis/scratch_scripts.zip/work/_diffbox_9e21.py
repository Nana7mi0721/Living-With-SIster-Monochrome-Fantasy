import io, sys
from PIL import Image
a = Image.open('work/out/ab_none.png').convert('RGB')
b = Image.open('work/out/ab_271.png').convert('RGB')
pa, pb = a.load(), b.load()
w,h = a.size
x0,y0,x1,y1 = w,h,-1,-1
n = 0
for y in range(h):
    for x in range(w):
        if pa[x,y] != pb[x,y]:
            n += 1
            if x < x0: x0 = x
            if x > x1: x1 = x
            if y < y0: y0 = y
            if y > y1: y1 = y
print('changed', n, 'bbox', (x0,y0,x1,y1))
if n:
    print('sample a', pa[x0,y0], 'b', pb[x0,y0])
    for y in range(y0, min(y1+1, y0+6)):
        row = ''.join('#' if pa[x,y]!=pb[x,y] else '.' for x in range(x0, min(x1+1, x0+40)))
        print(y, row)