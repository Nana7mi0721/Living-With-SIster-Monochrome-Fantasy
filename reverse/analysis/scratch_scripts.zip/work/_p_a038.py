path = "crates/wolf-game/tests/opening.rs"
raw = open(path, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
a = "use wolf_game::Game;\n"
b = "use wolf_game::key;\nuse wolf_game::Game;\n"
assert t.count(a) == 1
t = t.replace(a, b)
marker = """    assert_eq!(game.stats.warnings, 0, "the new-game path produced warnings");\n}\n"""
assert t.count(marker) == 1
add = """    assert_eq!(game.stats.warnings, 0, "the new-game path produced warnings");\n}\n\n/// The retail entry chain: boot to the title art, confirm opens the title menu,\n/// and its first option starts a new game through opcode 130 map id -1. This is\n/// the chain PLAN.md calls title -> new game; the map-run test above starts one\n/// step later, at Map003 event 1.\n#[test]\nfn the_title_menu_starts_a_new_game() {\n    let root = data_root();\n    let mut game = match Game::new(&root) {\n        Ok(game) => game,\n        Err(err) => {\n            eprintln!("skipping: {err}");\n            return;\n        }\n    };\n    if let Err(err) = game.boot() {\n        eprintln!("skipping: cannot boot: {err}");\n        return;\n    }\n    for _ in 0..800 {\n        game.frame();\n    }\n    assert!(\n        game.screen\n            .iter()\n            .any(|picture| picture.file.contains("title01")),\n        "the boot chain did not reach the title art"\n    );\n    game.key_bits = key::OK;\n    game.frame();\n    game.key_bits = 0;\n    for _ in 0..240 {\n        game.frame();\n    }\n    let menu = game.choices.as_ref().expect("the title menu is open");\n    assert_eq!(menu.options, ["1", "2", "3"], "the title menu changed");\n    game.set_choice_cursor(0);\n    game.auto_choice = true;\n    game.auto_choice_delay = 1;\n    for _ in 0..900 {\n        game.frame();\n    }\n    assert!(\n        game.diagnostics\n            .keys()\n            .any(|line| line.contains("130 Teleport: MapData/SampleMapA.mps")),\n        "the title menu never started a new game: {:?}",\n        game.diagnostics.keys().collect::<Vec<_>>()\n    );\n    let prompt = game.choices.as_ref().expect("the opening prompt is open");\n    assert_eq!(\n        prompt.options,\n        ["广阔的战场", "广袤的森林", "微风吹拂而过的麦田", "有人在等我的家"],\n        "the title menu did not reach the opening prompt"\n    );\n    assert_eq!(game.stats.warnings, 0, "the title path produced warnings");\n}\n"""
t = t.replace(marker, add)
if crlf:
    t = t.replace(chr(10), chr(13) + chr(10))
open(path, "wb").write(t.encode("utf-8"))
print("done")