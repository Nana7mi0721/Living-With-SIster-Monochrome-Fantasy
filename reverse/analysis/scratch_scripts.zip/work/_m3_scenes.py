import json,sys,collections,re
sys.stdout.reconfigure(encoding='utf-8')
d={e['id']:e for e in json.load(open('work/_ce_full.json',encoding='utf-8'))}
H=[217,333,338,340,341,342,343,346,350,351,353,354,357,358,365,367,371,372,374,407,410,445]
bygrp=collections.defaultdict(set)
per_ev=collections.defaultdict(collections.Counter)
for eid in H:
    for c in d[eid]['cmds']:
        if c['c']!=150: continue
        for s in c['s']:
            if s.startswith('hscene/'):
                m=re.match(r'hscene/h_(s\d\d)_',s)
                grp=m.group(1) if m else 'other'
                bygrp[grp].add(s)
                per_ev[eid][grp]+=1
print('scene groups (distinct files):')
for g in sorted(bygrp): print(' ',g, len(bygrp[g]))
print('total', len(set().union(*bygrp.values())))
print()
print('per event refs to hscene by group:')
for eid in H:
    if per_ev[eid]: print(' ',eid, dict(per_ev[eid]))
