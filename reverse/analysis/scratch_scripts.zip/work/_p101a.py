import json, io, re, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
mp = json.load(io.open('work/maps_full.json', encoding='utf-8'))

codes = collections.Counter()      # escape name -> count
bracket = collections.Counter()    # full token text
cmdn = 0
strs = 0
# collect (eventid, pc, strings, prev commands)
samples = []
for ev in ce:
    cmds = ev['cmds']
    for i,c in enumerate(cmds):
        if c['c'] == 101:
            cmdn += 1
            for s in c['s']:
                strs += 1
                # find escapes
                for m in re.finditer(r'\([A-Za-z]+)(\[[^\]]*\])?', s):
                    nm = m.group(1)
                    codes[nm] += 1
                    bracket[m.group(0)] += 1
print('101 commands in ce:', cmdn, 'strings:', strs)
print('escape codes:', codes.most_common())
print('tokens with brackets (top 40):')
for k,v in bracket.most_common(40):
    print('   ', repr(k), v)
