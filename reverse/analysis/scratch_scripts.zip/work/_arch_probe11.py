
import json,collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
# find an event containing 179 and 498, print context
for ev in d:
    cm=ev['cmds']
    idx=[i for i,c in enumerate(cm) if c['c']==179]
    if idx and any(cm[j]['c']==498 for j in range(idx[0],min(len(cm),idx[0]+40))):
        print('event',ev['id'],ev['title'][:20])
        for i,c in enumerate(cm[idx[0]-3:idx[0]+30], start=idx[0]-3):
            print(' ',i,c['c'],'bd',c['bd'],'a',c['a'][:5])
        break
print('=== bd stats per opcode ===')
st=collections.Counter()
for ev in d:
    for c in ev['cmds']:
        st[(c['c'],c['bd'])]+=1
for op in (179,498,420,421,401,499,213,212,170,171,172):
    print(op, dict(sorted((b,n) for (o,b),n in st.items() if o==op)))
