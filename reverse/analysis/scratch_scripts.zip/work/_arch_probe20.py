# -*- coding: utf-8 -*-
import os, struct
G = r"E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy"
D = os.path.join(G, "Data")
b = open(os.path.join(D, "word.wolf"), "rb").read()
print("size 0x%x" % len(b))
for off in [0x30, 0x40, 0x94a4, 0x94a4+0x1478 if 0x94a4+0x1478 < len(b) else 0, 0x3638, 0x1478]:
    print("off 0x%x:" % off, b[off:off+48].hex())
print("--- tail 0xC00 bytes region of tables ---")
for off in [len(b)-0x1000]:
    print("off 0x%x:" % off, b[off:off+64].hex())
