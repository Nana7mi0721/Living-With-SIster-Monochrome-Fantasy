import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
d = json.load(io.open('work/wolftl/dump/db/SysDatabase.json', encoding='utf-8'))
t = d['types'][6]
for i,row in enumerate(t['data'][40:], start=40):
    print('%3d'%i, row.get('name'))
print('=== type 12 rows 0..29 done earlier; type 24 ===')
t24 = d['types'][24]
print(t24['name'], json.dumps(t24['fields'],ensure_ascii=False), len(t24['data']))
for i,row in enumerate(t24['data']):
    print('  %2d'%i, row.get('name'), json.dumps(row.get('data'),ensure_ascii=False)[:120])
