# -*- coding: utf-8 -*-
import sys, io, os, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
src = open('work/_map_audit10.py', encoding='utf-8').read()
pre = src.split("REG = [")[0]
pre = '\n'.join(l for l in pre.splitlines() if not l.startswith('import sys') and not l.startswith('sys.stdout'))
g = {}
exec(compile(pre, 'walklib', 'exec'), g)
parse_mps = g['parse_mps']
base = r'work\full\MapData'
REG = ['TitleMap.mps', 'SampleMapA.mps', 'SampleMapA_1.mps', 'Map003.mps', 'Map024.mps', 'Map031.mps']
ALL = REG + ['SampleMapB.mps', 'Dungeon.mps', 'Map002.mps']
maps = {f: parse_mps(os.path.join(base, f)) for f in ALL}
for label, files in (('registered 6', REG), ('all 9', ALL)):
    h = collections.Counter(); foot = collections.Counter()
    for f in files:
        for e in maps[f]['events']:
            for p in e['pages']:
                foot[p['footer']] += 1
                for b in p['sw']:
                    h[b] += 1
    print('%s raw flag histogram: %s' % (label, {('0x%02X' % k): v for k, v in sorted(h.items())}))
    print('%s page footer histogram: %s' % (label, {('0x%02X' % k): v for k, v in sorted(foot.items())}))
