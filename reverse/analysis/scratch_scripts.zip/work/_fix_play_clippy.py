import io, os
p = "crates/wolf-cli/src/play.rs"
s = io.open(p, encoding="utf-8", newline="").read()
old = "game.boot().map(|()| ()).map_err(|err| err.to_string())"
assert old in s
s = s.replace(old, "game.boot().map_err(|err| err.to_string())")
io.open(p + ".new", "w", encoding="utf-8", newline="").write(s)
os.replace(p + ".new", p)
print("play patched")
