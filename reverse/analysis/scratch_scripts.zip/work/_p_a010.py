import io, os
path = "crates/wolf-cli/src/main.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """        for run in &layout.runs {
            let mut item = TextItem::new(run.text.clone(), run.rect, run.font_px)
                .with_colour(run.colour.unwrap_or(wolf_game::message::DEFAULT_COLOUR));"""
b = """        for run in &layout.runs {
            // Give each run one em of slack: the layout measures with the half-em rule,
            // while cosmic-text shapes with the real font advance, and a box that is a
            // fraction too narrow makes the renderer wrap the last glyph onto a new line.
            let mut rect = run.rect;
            rect[2] += run.font_px;
            let mut item = TextItem::new(run.text.clone(), rect, run.font_px)
                .with_colour(run.colour.unwrap_or(wolf_game::message::DEFAULT_COLOUR));"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")