
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ce}
def show(eid,pc,rad=7):
    e=by[eid]; cm=e['cmds']
    print('='*60); print('CE%d %s pc%d (len %d)'%(eid,e['title'],pc,len(cm)))
    for i in range(max(0,pc-rad),min(len(cm),pc+rad+1)):
        c=cm[i]
        print(('>>' if i==pc else '  ')+'pc%-4d c=%-4d a=%s s=%s bd=%d'%(i,c['c'],c['a'],[x[:30] for x in c['s']],c['bd']))
for eid,pc in [(75,42),(86,89),(112,21),(143,102)]:
    show(eid,pc)
