import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
def show(eid,pcs):
    e=by[eid]
    for i in pcs:
        c=e['cmds'][i]
        print(f"CE{eid} pc{i} {c['c']} {c.get('a')} {c.get('s')}")
show(152,[82]); show(154,[28,70]); show(159,[216]); show(161,[31]); show(163,[215,286,333]); show(65,[160]); show(172,[32,53,92,107]); show(216,[13,42]); show(226,[15]); show(176,list(range(0,40)))

