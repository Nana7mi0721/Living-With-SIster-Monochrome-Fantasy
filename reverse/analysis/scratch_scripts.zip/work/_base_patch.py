
import json
p = 'docs/BASELINE.json'
raw = open(p, encoding='utf-8').read()
lines = raw.split('\n')
idx = max(i for i, ln in enumerate(lines) if ln.strip() == '}')
before = lines[:idx]
if before[-1].rstrip().endswith('}'):
    before[-1] = before[-1] + ','
block = [
 ' "dxarchive_reader": {',
 '  "version": 8,',
 '  "char_code_format": 932,',
 '  "flags": 20578304,',
 '  "crypt_version": 314,',
 '  "huffman_encode_kb": 12,',
 '  "basicdata_entries": 149,',
 '  "archives_total": 23,',
 '  "files_total": 4062,',
 '  "bytes_total": 771585007',
 ' },',
 ' "verify": {',
 '  "checks": 63,',
 '  "pending": 0,',
 '  "sections": ["game", "common_events", "precompile", "maps", "tileset", "databases", "dxarchive", "save"]',
 ' }',
]
out = '\n'.join(before + block + ['}'])
json.loads(out)
open(p, 'w', encoding='utf-8', newline='\n').write(out)
d = json.loads(open(p, encoding='utf-8').read())
print('keys', list(d.keys()))
print('dx files', d['dxarchive_reader']['files_total'], 'verify', d['verify']['checks'])
print('lines', len(out.split(chr(10))))
