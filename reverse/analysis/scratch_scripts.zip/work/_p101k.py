import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
ev = [e for e in ce if e['id']==63][0]
print('ncmds', len(ev['cmds']))
for i,c in enumerate(ev['cmds']):
    print('%3d %3d %s'%(i,c['c'],c['a']), [x[:40] for x in c['s']])