
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
miss=refs['missing']
def cat(p):
    d=p.split('/')[0]
    return d
byc=collections.Counter()
for p,sites in miss.items():
    srcs=set(s[0] for s in sites)
    byc[(cat(p),tuple(sorted(srcs)))]+=1
W('== missing by (dir, source kinds) ==')
for k,v in byc.most_common(): W('  %-40s %d'%(str(k),v))
# do any common/map events reference the sysdb-only missing names directly?
sysdb_only=[p for p,sites in miss.items() if all(s[0]=='sysdb' for s in sites)]
W('\nsysdb-only missing: %d'%len(sysdb_only))
direct=[p for p in sysdb_only if any(s[0] in ('common','map') for s in refs['referenced'].get(p,[]))]
W('  also referenced directly by events: %d'%len(direct))
# CharaChip: 7 live names
ch=[p for p in refs['referenced'] if p.startswith('CharaChip/')]
W('\nCharaChip referenced & present: %s'%ch)
# SystemGraphic [SE] usage: does any event reference SystemGraphic/[SE] ?
se=[p for p in refs['referenced'] if p.startswith('SystemGraphic/[SE]')]
W('\nSystemGraphic/[SE]* referenced: %d %s'%(len(se),se[:5]))
sf=[p for p in refs['referenced'] if p.startswith('SystemFile/[SE]')]
W('SystemFile/[SE]* referenced: %d'%len(sf))
open('work/_audit_out24.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
