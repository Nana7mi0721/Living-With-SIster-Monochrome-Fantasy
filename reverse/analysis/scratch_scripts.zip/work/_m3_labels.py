import json,sys
sys.stdout.reconfigure(encoding='utf-8')
d={e['id']:e for e in json.load(open('work/_ce_full.json',encoding='utf-8'))}
for eid in (333,340,346,371):
    e=d[eid]; cmds=e['cmds']
    labels=[(i,(c['s'][0] if c['s'] else '')) for i,c in enumerate(cmds) if c['c']==212]
    jumps=[(i,(c['s'][0] if c['s'] else '')) for i,c in enumerate(cmds) if c['c']==213]
    print('=== ev',eid,e['title'],'cmds',len(cmds))
    print(' labels',len(labels),labels[:60])
    print(' jumps',len(jumps),jumps[:60])
