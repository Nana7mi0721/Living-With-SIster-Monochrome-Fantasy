
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure2.json',encoding='utf-8'))
boot=set()
for s in cl['boot2']:
    s=s.strip()
    if s.startswith("('c'"): boot.add(int(s.split(',')[1].strip(' )')))
W('boot+auto closure common events: %d'%len(boot))
def size(p):
    try: return os.path.getsize(os.path.join('work/all',p))
    except OSError: return 0
paths=set()
for p,sites in refs['referenced'].items():
    for src,loc,op in sites:
        if src=='common':
            ev=int(loc.split('#')[0].replace('ev',''))
            if ev in boot: paths.add(p); break
W('assets referenced by boot closure: %d files / %d B'%(len(paths),sum(size(p) for p in paths)))
agg=collections.defaultdict(lambda:[0,0])
for p in paths:
    d=p.split('/')[0]; agg[d][0]+=1; agg[d][1]+=size(p)
for d,(n,b) in sorted(agg.items(),key=lambda kv:-kv[1][1]):
    W('  %-20s %4d %10d'%(d,n,b))
W('\nsample 25:')
for p in sorted(paths)[:25]: W('  %s'%p)
json.dump(sorted(paths),open('work/_audit_boot_assets.json','w',encoding='utf-8'),ensure_ascii=False)
open('work/_audit_out22.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
