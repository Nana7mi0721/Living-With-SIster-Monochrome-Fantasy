
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
out=[]
for e in ce:
    cm=e['cmds']
    for i,c in enumerate(cm):
        if c['c']!=250: continue
        a=c['a']
        if not a: continue
        row=a[1]
        if not (isinstance(row,int) and row<0): continue
        # direction
        fl=a[3] if len(a)>3 else 0
        d='R' if fl&0x1000 else 'W'
        cont=(fl>>8)&3
        out.append((e['id'],i,e['title'],a,d,cont,[x for x in c['s'] if x]))
for o in out:
    eid,pc,title,a,d,cont,ss=o
    print('CE%-4d pc%-4d %s type=%-3d row=%-3d col=%-9s flags=0x%-6x dir=%s cont=%d strs=%s'%(eid,pc,title[:26],a[0],a[1],a[2],a[3] if len(a)>3 else 0,d,cont,ss))
print('total',len(out))
