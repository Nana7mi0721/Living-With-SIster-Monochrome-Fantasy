
import json,collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
ev=d[0]
cmds=ev['cmds']
for i,c in enumerate(cmds[:60]):
    print(i, c['c'], 'bd',c['bd'], 'a',c['a'][:6], 's',('T' if c['s'] else ''))
print('=== per-opener bd deltas ===')
# For each command, print bd of next command relative
openers={401,420,421,111,112,102,179,170,176,498,499,213,210,300}
st=collections.Counter()
for ev in d:
    cm=ev['cmds']
    for i,c in enumerate(cm):
        o=c['c']
        if o in openers:
            nb=cm[i+1]['bd'] if i+1<len(cm) else None
            st[(o,c['bd'],None if nb is None else nb-c['bd'])]+=1
for k,v in sorted(st.items()):
    print(k,v)
