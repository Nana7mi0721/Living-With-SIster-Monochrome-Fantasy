# -*- coding: utf-8 -*-
import sys, io, struct, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base = r'work\full\MapData'
def parse(p):
    b=open(p,'rb').read(); st={'o':0}
    def u1():
        v=b[st['o']]; st['o']+=1; return v
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        return s.split(b'\x00')[0].decode('utf-8','replace')
    st['o']=16; u1(); st['o']+=3; u4(); u1(); tstr()
    ts=u4(); w=u4(); h=u4(); ec=u4(); fp=u4()
    if fp!=0xFFFFFFFF: st['o'] += w*h*3*4 - 4
    evs=[]
    while b[st['o']]==0x6F:
        u1(); u4(); eid=u4(); name=tstr(); x=u4(); y=u4(); pc=u4(); u4()
        pages=[]
        for _ in range(pc):
            u1(); chip=u4(); gfx=tstr()
            u1();u1();u1();u1(); trig=u1()
            sw=[u1() for _ in range(4)]; vn=[u4() for _ in range(4)]; vv=[s4() for _ in range(4)]
            [u1() for _ in range(6)]
            rl=u4()
            for _ in range(rl):
                u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
            ncmd=u4(); cmds=[]
            for _ in range(ncmd):
                cnt=u1()
                if cnt>0: o=u4(); a=[s4() for _ in range(cnt-1)]
                else: o=0; a=[]
                u1(); sc=u1()
                strs=[tstr() for _ in range(sc)]
                hr=u1()
                if hr!=0:
                    st['o']+=6; rl2=u4()
                    for _ in range(rl2):
                        u1(); n1=u1(); st['o']+=n1*4; n2=u1(); st['o']+=n2
                cmds.append((o,a,strs))
            u4(); u1(); u1(); u1(); u1()
            pages.append({'trigger':trig,'cmds':cmds,'sw':sw,'vn':vn,'vv':vv})
        u1()
        evs.append({'id':eid,'name':name,'x':x,'y':y,'pages':pages})
    return evs

for f,eid in [('Map003.mps',1),('Map031.mps',0),('Map024.mps',0)]:
    evs=parse(os.path.join(base,f))
    e=[e for e in evs if e['id']==eid][0]
    print('=== %s ev=%d %r at (%d,%d)' % (f,e['id'],e['name'],e['x'],e['y']))
    for pi,p in enumerate(e['pages']):
        print('  page %d trigger=%d flags=%s vars=%s vals=%s' % (pi,p['trigger'],p['sw'],p['vn'],p['vv']))
        for ci,(o,a,strs) in enumerate(p['cmds']):
            print('   pc=%-3d op=%-4d args=%s strs=%s' % (ci,o,a[:5],strs[:1]))
    print()
