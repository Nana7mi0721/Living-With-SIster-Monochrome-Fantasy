
import json
rows = json.load(open("work/_atlas_stats.json"))
listed = {"cg","DLC_data","BattleEffect","hscene","scene","Picture","1.4.0","cutin"}
rest = [r for r in rows if r["arch"] not in listed]
print("rest n=", len(rest), "disk MB", round(sum(r["file_bytes"] for r in rest)/2**20,1),
      "decoded MiB", round(sum(r["rgba"] for r in rest)/2**20,1))
import collections
c = collections.Counter(r["arch"] for r in rest)
print(sorted(c.items(), key=lambda kv:-kv[1]))
print("max w/h:", max(r["w"] for r in rest), max(r["h"] for r in rest))
