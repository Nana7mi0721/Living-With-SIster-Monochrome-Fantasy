import io, os, json, collections
path = "docs/BASELINE.json"
t = io.open(path, encoding="utf-8", newline="").read()
d = json.loads(t, object_pairs_hook=collections.OrderedDict)
d["save_opcodes"]["live_writer"]["tests"] = [
    "wolf-game a_saved_game_reloads_its_live_picture_layer",
    "wolf-game a_saved_game_keeps_the_database_cells",
]
io.open(path + ".new", "w", encoding="utf-8", newline="").write(json.dumps(d, indent=1, ensure_ascii=False) + "\n")
os.replace(path + ".new", path)
print("ok")