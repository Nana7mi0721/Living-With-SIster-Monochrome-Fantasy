
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
e=[x for x in ce if x['id']==328][0]
cmds=e['cmds']
def vname(v):
    return 'v%d'%(v-2000000) if v>=2000000 and v<3000000 else ('self%d'%(v-1000000) if v>=1000000 else str(v))
def fmt(pc):
    c=cmds[pc]; op=c['c']; a=c['a']; s=c['s']
    name={111:'IF',401:'CASE',420:'ELSE',499:'END',102:'CHOICE',421:'CANCEL',172:'BREAK',210:'CALL',211:'CALL?',121:'SET',124:'SETEX',122:'LABEL',212:'SUB?',213:'OP213',126:'OP126'}.get(op,str(op))
    extra=''
    if op==111:
        n=a[0]&0xF; conds=[]
        for i in range(n):
            v=a[1+i*3]; val=a[2+i*3]; o=a[3+i*3]
            conds.append(vname(v)+{1:'>=',2:'==',3:'<=',4:'>',5:'!=',8:'?8'}.get(o,str(o))+str(val))
        extra='['+','.join(conds)+']'
    elif op in (121,124):
        extra=str(a)
    elif op in (210,211):
        extra=str(a)
    elif op==401:
        extra='case'+str(a[0]) if a else ''
    elif op==102:
        extra='n=%d'%(a[0] if a else -1)
    elif s:
        extra=repr(s[0])[:44]
    return 'pc%-4d %-7s %s'%(pc,name,extra)
for pc in range(693,760):
    print(fmt(pc))
