
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
live=set(fin['live']); never=set(fin['never']); sizes=fin['sizes']
W('== SystemGraphic: live 8 ==')
for p in sorted(x for x in live if x.startswith('SystemGraphic/')):
    W('  %9d %s  <- %s'%(sizes[p],p,'; '.join('%s %s'%(s[0],s[1]) for s in refs['referenced'][p][:4])))
W('\n== TitleGraphic1..6 / title01 status ==')
for p in sorted(x for x in refs['referenced'] if 'TitleGraphic' in x or 'title01' in x):
    st='live' if p in live else ('dead' if p not in never else 'never')
    W('  %-40s %-6s %s'%(p,st,'; '.join('%s %s'%(s[0],s[1]) for s in refs['referenced'][p][:3])))
W('\n== Kagura live 4 ==')
for p in sorted(x for x in live if x.startswith('Kagura/')):
    W('  %8d %s <- %s'%(sizes[p],p,'; '.join('%s %s'%(s[0],s[1]) for s in refs['referenced'][p][:4])))
open('work/_audit_out26.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
