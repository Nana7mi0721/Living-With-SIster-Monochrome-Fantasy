import io, os
spec = 'docs/OPCODE_220_SAVE.md'
text = io.open(spec, encoding='utf-8', newline='').read()
ins63 = io.open('work/_ins63.md', encoding='utf-8', newline='').read()
ins75 = io.open('work/_ins75.md', encoding='utf-8', newline='').read()

old_head = '### 6.2 找不到的部分：通常変数 / システム変数の落盤位置【未验证 —— 见 §8 U1】'
old_head = old_head.replace('落盤', '落盘')
assert text.count(old_head) == 1, ('head', text.count(old_head))
text = text.replace(old_head, '### 6.2 早先的误判：通常変数「找不到落盘区」【已推翻 —— 见 §6.3】')

a = '## §7 wolf-save 的写出路径'
assert text.count(a) == 1, ('s7', text.count(a))
text = text.replace(a, ins63 + '---\n\n' + a)

old_api = '    /// 整段替换（id 0..=6），后续段偏移自动平移，校验和重算。\n    pub fn replace_part(&mut self, id: u32, bytes: &[u8]) -> Result<()>;\n}'
assert text.count(old_api) == 1, ('api', text.count(old_api))
new_api = old_api[:-2] + """    /// 用 SavePart3 的 typed 值重新编码整段并替换（视图同步刷新）。
    pub fn set_part3(&mut self, part: &SavePart3) -> Result<()>;
    /// part2 的 vars3_21[0]，段内偏移 2；单位是帧，60fps。
    pub fn playtime_frames(&self) -> Option<u32>;
    pub fn set_playtime_frames(&mut self, frames: u32) -> Result<()>;
    /// 通常変数 2000000+n（n < 800）与セルフ数値 / セルフ文字列（slot 0 = CSelf5）。
    pub fn normal_var(&self, index: usize) -> Option<i32>;
    pub fn set_normal_var(&mut self, index: usize, value: i32) -> Result<bool>;
    pub fn self_var(&self, event: u32, slot: usize) -> Option<i32>;
    pub fn self_string(&self, event: u32, slot: usize) -> Option<&str>;
}"""
text = text.replace(old_api, new_api)

b = '---\n\n## §8 未验证清单'
assert text.count(b) == 1, ('s8', text.count(b))
text = text.replace(b, ins75 + b)

old_u1 = '| U1 | 通常変数（2000000 段）/ システム変数（9000000 段）在存档文件里的落盘位置 | 逐段排查后无候选区；222 写过的三个地址在 9 个样本里全为 0 | 在游戏里手动存一次档，比对 `System.sav` 与 `SaveDataNN.sav` 的 part3 差异 |'
assert text.count(old_u1) == 1, ('u1', text.count(old_u1))
new_u1 = '| U1 | 通常変数（2000000 段）的落盘位置 | **已解决（§6.3）**：= SavePart3 row 0 的 800 个词，`System.sav` row0[0] = 8 = 最后使用槽；システム変数（9000000 段）仍未找到，疑为载入时重算 | —（システム変数部分仍需实机存一次档对比） |'
text = text.replace(old_u1, new_u1)

io.open(spec + '.new', 'w', encoding='utf-8', newline='').write(text)
os.replace(spec + '.new', spec)
print('ok')