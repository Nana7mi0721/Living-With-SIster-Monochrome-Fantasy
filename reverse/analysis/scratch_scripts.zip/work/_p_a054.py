p = "crates/wolf-game/tests/opening.rs"
t = open(p, encoding="utf-8").read()
# Rename the test
a = "fn a_new_game_can_be_saved_and_reloaded_after_the_opening() {"
b = "fn a_title_new_game_can_be_saved_and_reloaded_after_the_opening() {"
assert t.count(a) == 1
t = t.replace(a, b)
# Replace the Map003 entry with the full title menu chain
old = """    game.auto_advance = true;
    game.auto_choice = true;
    game.auto_choice_delay = 1;
    game.set_choice_cursor(0);
    if let Err(err) = game.start_map_event_by_name("Map003", 1) {
        eprintln!("skipping: cannot start new-game processing: {err}");
        return;
    }
    for _ in 0..1200 {
        let _ = game.frame();
    }"""
new = """    // The full PLAN.md chain starts at the title screen: boot, confirm, title menu,
    // first option (new game), then let the opening dialogue and prompts run.
    if let Err(err) = game.boot() {
        eprintln!("skipping: cannot boot: {err}");
        return;
    }
    for _ in 0..800 {
        game.frame();
    }
    assert!(
        game.screen.iter().any(|picture| picture.file.contains("title01")),
        "the boot chain did not reach the title art"
    );
    game.key_bits = key::OK;
    game.frame();
    game.key_bits = 0;
    for _ in 0..240 {
        game.frame();
    }
    let menu = game.choices.as_ref().expect("the title menu is open");
    assert_eq!(menu.options, ["1", "2", "3"], "the title menu changed");
    game.set_choice_cursor(0);
    game.auto_choice = true;
    game.auto_choice_delay = 1;
    for _ in 0..120 {
        game.frame();
        if game.choices.is_none() {
            break;
        }
    }
    game.auto_advance = true;
    for _ in 0..1200 {
        let _ = game.frame();
    }"""
assert t.count(old) == 1
t = t.replace(old, new)
open(p, "w", encoding="utf-8", newline="").write(t)
print("ok")