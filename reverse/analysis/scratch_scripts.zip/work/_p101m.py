import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
d = json.load(io.open('work/wolftl/dump/db/SysDatabase.json', encoding='utf-8'))
for idx in (6,5,12):
    t = d['types'][idx]
    print('=== type', idx, t['name'], 'fields', json.dumps(t['fields'],ensure_ascii=False), 'rows', len(t['data']))
    for i,row in enumerate(t['data'][:40]):
        nm = row.get('name')
        dd = row.get('data')
        print('  %3d'%i, repr(nm), json.dumps(dd,ensure_ascii=False)[:150] if dd else '')
