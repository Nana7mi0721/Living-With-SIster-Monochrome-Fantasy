import io
p = r"E:\Study\github program\imoto life\crates\wolf-vm\src\exec.rs"
s = io.open(p, encoding="utf-8").read()
s = s.replace("            'queries',", '            "queries",')
io.open(p, "w", encoding="utf-8", newline="\n").write(s)
print("ok")
