# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
ev = {e['id']: e for e in ce}[119]
c = ev['cmds'][22]
print('raw cmd:', json.dumps(c, ensure_ascii=False))
a = c['a']; s = c['s']
v = a[1] & 0xFFFFFFFF
print('a[1]=%d hex=%#x num=%d strc=%d en=%s rv=%d' % (v, v, v & 0xF, (v>>4)&0xF,
      [(v>>(12+i))&1 for i in range(5)], (v>>24)&1))
print('len(a)=%d  extra=%d' % (len(a), len(a)-2-(v&0xF)))
print('s=', s)
