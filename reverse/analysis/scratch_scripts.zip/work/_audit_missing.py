
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure2.json',encoding='utf-8'))
live=set(int(x) for x in cl['gcreach2'])
deadmaps={'Dungeon','Map002','SampleMapB'}
def src_live(s):
    src,loc=s[0],s[1]
    if src in ('db','sysdb','tileset'): return True
    if src=='common': return int(loc.split('#')[0].replace('ev','')) in live
    if src=='map': return loc.split(' ev')[0].split('.')[0] not in deadmaps
    return True
miss=refs['missing']
W('== 342 missing: live vs dead source, by dir ==')
cnt=collections.Counter(); livec=collections.Counter()
for p,sites in miss.items():
    d=p.split('/')[0]
    cnt[d]+=1
    if any(src_live(s) for s in sites): livec[d]+=1
for d,n in cnt.most_common():
    W('  %-16s total %3d   live-sourced %3d   dead-only %3d'%(d,n,livec[d],n-livec[d]))
W('  TOTAL %d  live-sourced %d  dead-only %d'%(sum(cnt.values()),sum(livec.values()),sum(cnt.values())-sum(livec.values())))
W('\n== live-sourced missing, full list ==')
for p in sorted(k for k,v in miss.items() if any(src_live(s) for s in v)):
    W('  %s   <- %s'%(p,'; '.join('%s %s'%(s[0],s[1]) for s in miss[p][:3])))
open('work/_audit_out17.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
