import struct, sys, os
sys.stdout.reconfigure(encoding='utf-8')
GAME=r'E:/SteamLibrary/steamapps/common/Living With SIster Monochrome Fantasy/Save'
def decrypt(b):
    b=bytearray(b); seeds=[b[0],b[3],b[9]]
    for pass_,step in enumerate((1,2,5)):
        st=seeds[pass_]; j=0x14
        while j < len(b):
            st=(st*214013+2531011)&0xFFFFFFFF
            r=(st>>16)&0x7FFF
            b[j]^=(r>>12)&0xFF
            j+=step
    return bytes(b)
def find(buf, pat):
    out=[]; i=buf.find(pat)
    while i>=0 and len(out)<12:
        out.append(i); i=buf.find(pat,i+1)
    return out
for name in ('System.sav','SaveData01.sav','SaveData08.sav'):
    raw=open(os.path.join(GAME,name),'rb').read()
    buf=decrypt(raw)
    print('###',name,'len',len(buf))
    for label,vals in (('sys1_6',[64,410,512,192,512,144]),('sys8_10',[20,500,1]),('sys8_10b',[20,120,1]),('sys23_25',[12,0,1])):
        pat=struct.pack('<%di'%len(vals), *vals)
        print('  ',label,vals,'->',find(buf,pat))
    # single value 410 (0x19A) as u32
    pat=struct.pack('<i',410)
    print('   410 hits', find(buf,pat)[:8])

