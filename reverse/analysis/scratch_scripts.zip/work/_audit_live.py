
import json,io,collections,os
OUT=io.StringIO()
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure.json',encoding='utf-8'))
live_common=set(int(x) for x in cl['gcreach'])
dead_maps={'Dungeon','Map002','SampleMapB'}
reg_maps={v[:-4] for v in cl['reg'].values()}   # strip .mps
OUT.write('registered maps: %s\n'%sorted(reg_maps))

def site_live(s):
    src,loc,op=s[0],s[1],s[2]
    if src in ('db','sysdb','tileset'): return True,'data-table'
    if src=='common':
        ev=int(loc.split('#')[0].replace('ev',''))
        return (ev in live_common),'common ev%d'%ev
    if src=='map':
        head=loc.split(' ev')[0]
        base=head.split('.')[0]
        if base in dead_maps: return False,'dead-map %s'%base
        return True,'reg-map %s'%base
    return True,'?'

live={}; dead={}
for path,sites in refs['referenced'].items():
    L=[s for s in sites if site_live(s)[0]]
    if L: live[path]=sites
    else: dead[path]=sites
size=lambda p: os.path.getsize(os.path.join('work/all',p))
lb=sum(size(p) for p in live); db_=sum(size(p) for p in dead)
OUT.write('\nreferenced & reachable (game closure): %d files / %d B\n'%(len(live),lb))
OUT.write('referenced ONLY by dead code: %d files / %d B\n'%(len(dead),db_))
OUT.write('check: %d + %d = %d (expect 2695)\n'%(len(live),len(dead),len(live)+len(dead)))

# per-dir
dirs=collections.defaultdict(lambda:[0,0])
for p in live:
    d=p.split('/')[0]; dirs[d][0]+=1; dirs[d][1]+=size(p)
dd=collections.defaultdict(lambda:[0,0])
for p in dead:
    d=p.split('/')[0]; dd[d][0]+=1; dd[d][1]+=size(p)
OUT.write('\n== live-only refs by dir ==\n')
for d,(n,b) in sorted(dirs.items(),key=lambda kv:-kv[1][1]): OUT.write('%-24s %4d %12d\n'%(d,n,b))
OUT.write('\n== dead-only refs by dir ==\n')
for d,(n,b) in sorted(dd.items(),key=lambda kv:-kv[1][1]): OUT.write('%-24s %4d %12d\n'%(d,n,b))
OUT.write('\n== 25 biggest dead-only refs ==\n')
for p in sorted(dead,key=lambda p:-size(p))[:25]: OUT.write('%12d %s\n'%(size(p),p))
json.dump({'live':sorted(live),'dead':sorted(dead)},open('work/_audit_live.json','w',encoding='utf-8'),ensure_ascii=False)
open('work/_audit_out9.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
