path = "crates/wolf-game/tests/opening.rs"
raw = open(path, "rb").read()
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
a = """    game.auto_choice = false;\n    for _ in 0..900 {\n        game.frame();\n    }\n"""
b = """    game.auto_choice = false;\n    // The opening narration is a 101 message; with auto_advance off it would hold\n    // the script before the prompt (the other tests set this from the start).\n    game.auto_advance = true;\n    for _ in 0..900 {\n        game.frame();\n    }\n"""
assert t.count(a) == 1
t = t.replace(a, b)
open(path, "wb").write(t.encode("utf-8"))
print("done")