from PIL import Image
im = Image.open('work/out/m2story_text.png')
bar = im.crop((0,0,1024,48)).resize((2048,96), Image.LANCZOS)
bar.save('work/out/our_hud_bar.png')
ref = Image.open('work/out/retail_hud_bar.png')
both = Image.new('RGB',(2048,96+96+8),(255,0,255))
both.paste(bar,(0,0)); both.paste(ref.resize((2048,96), Image.LANCZOS),(0,104))
both.save('work/out/hud_compare.png')
print(bar.size, ref.size)