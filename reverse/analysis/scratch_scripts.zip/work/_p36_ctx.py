
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ce}
sites=[(82,4),(86,9),(110,11),(111,11),(112,12),(152,6),(153,11),(154,11),(157,28),(188,195),(189,16),(189,21),(191,30)]
def show(eid,pc,rad=8):
    e=by[eid]; cm=e['cmds']
    print('='*70)
    print('CE%d %s  pc%d'%(eid,e['title'],pc))
    for i in range(max(0,pc-rad), min(len(cm),pc+rad+1)):
        c=cm[i]
        mark='>>' if i==pc else '  '
        print('%s pc%-4d c=%-4d a=%s s=%s bd=%d'%(mark,i,c['c'],c['a'],[x[:40] for x in c['s']],c['bd']))
for eid,pc in sites[:6]:
    show(eid,pc)
