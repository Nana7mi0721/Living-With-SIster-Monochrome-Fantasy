
import json,collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
OPEN={111,102,179,170,176}; CLOSE={499,498}
def dump(ev,i0,i1):
    print('--- event',ev['id'],ev['title'][:16])
    for i in range(i0,i1):
        c=ev['cmds'][i]; print('  ',i,c['c'],'bd',c['bd'],'a',c['a'][:4])
found=0
for ev in d:
    cm=ev['cmds']; stack=[]
    for i,c in enumerate(cm):
        o=c['c']; b=c['bd']
        if o in OPEN: stack.append((b,i,o))
        elif o in CLOSE:
            if stack and stack[-1][0]==b: stack.pop()
            else:
                dump(ev,max(0,i-12),min(len(cm),i+4))
                print('   STRAY at',i,o,'bd',b,'stack',stack[-3:])
                found+=1
                break
    if found>=3: break
