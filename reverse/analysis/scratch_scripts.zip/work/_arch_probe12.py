
import json
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
def find(pred):
    for ev in d:
        cm=ev['cmds']
        for i in range(len(cm)-6):
            if pred(cm,i): return ev,i
    return None,None
# event with 111 followed within 3 by 420 (if/else)
ev,i=find(lambda cm,i: cm[i]['c']==111 and any(cm[j]['c']==420 for j in range(i+1,min(len(cm),i+200))) and cm[i]['bd']==1)
print('if/else event',ev['id'],'at',i,'bd',cm_bd := ev['cmds'][i]['bd'])
cm=ev['cmds']
for j in range(i-1,i+40):
    c=cm[j]; print(' ',j,c['c'],'bd',c['bd'],'a',c['a'][:4])
print('=== for-loop example (179/498) ===')
ev2,i2=find(lambda cm,i: cm[i]['c']==179 and cm[i]['bd']==1)
cm2=ev2['cmds']
for j in range(i2-2,i2+18):
    c=cm2[j]; print(' ',j,c['c'],'bd',c['bd'],'a',c['a'][:4])
