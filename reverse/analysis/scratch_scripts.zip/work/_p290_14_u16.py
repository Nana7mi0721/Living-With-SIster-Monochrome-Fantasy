
import zipfile, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')
def find(w):
    return [m.start() for m in re.finditer(re.escape(w.encode('utf-16-le')), data)]
for w in ['ピクチャエフェクト','フラッシュ','シェイク','点滅Ａ','点滅Ｂ','描画座標シフト','自動パターン切替','ズーム','自動拡大縮小','全エフェクト解除']:
    f = find(w)
    print('---', w, len(f), [hex(x) for x in f[:12]])
