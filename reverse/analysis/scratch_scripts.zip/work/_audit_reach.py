
import json,io,glob,os,collections
OUT=io.StringIO()
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
by_id={e['id']:e for e in lst}
by_title={}
for e in lst: by_title.setdefault(e['title'],e['id'])

def norm(cmds):
    out=[]
    for c in cmds:
        if 'c' in c:
            out.append((int(c['c']), [int(x) for x in c.get('a') or []], list(c.get('s') or [])))
        else:
            out.append((int(c.get('code',0)), [int(x) for x in (c.get('ints') or [])], list(c.get('strs') or [])))
    return out

def decode210(raw):
    if 500000<=raw<=599999: return raw-500000
    if 600000<=raw<=699999: return raw-600000
    return None

edges=collections.defaultdict(set)
def add_edges(key,cmds):
    for op,a,s in norm(cmds):
        if op==210 and a:
            t=decode210(a[0])
            if t is not None and t in by_id: edges[key].add(('c',t))
        elif op==300 and s:
            t=by_title.get(s[0])
            if t is not None: edges[key].add(('c',t))

for e in lst: add_edges(('c',e['id']), e['cmds'])
mf=json.load(open('work/maps_full.json',encoding='utf-8'))
for k,v in mf.items():
    for e in v['events']: add_edges(('m',k,e['id']), e['cmds'])

start=('m','TitleMap.mps',2)
seen=set(); stack=[start]
while stack:
    cur=stack.pop()
    if cur in seen: continue
    seen.add(cur)
    for n in sorted(edges[cur]):
        if n not in seen: stack.append(n)
creach=sorted(k[1] for k in seen if k[0]=='c')
mreach=sorted((k[1],k[2]) for k in seen if k[0]=='m')
OUT.write('common events reachable from TitleMap ev2: %d / %d\n'%(len(creach),len(lst)))
OUT.write('map events reachable: %s\n'%(mreach,))
unreach=sorted(set(e['id'] for e in lst)-set(creach))
OUT.write('unreachable common events: %d\n'%len(unreach))
OUT.write('%s\n'%unreach)

# now: which of the reachable events use which assets? and expand to whole-game coverage
# whole game = all common events + all map events
OUT.write('\n== sanity: edges from TitleMap ev2 ==\n')
OUT.write('%s\n'%(sorted(edges[('m','TitleMap.mps',2)]),))
json.dump({'creach':creach,'mreach':mreach,'unreach':unreach},open('work/_audit_reach.json','w',encoding='utf-8'),ensure_ascii=False)
open('work/_audit_out6.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
