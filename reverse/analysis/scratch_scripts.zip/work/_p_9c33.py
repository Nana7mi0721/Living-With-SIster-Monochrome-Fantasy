import io, os

def rep(text, a, b):
    assert a in text, "missing: " + a[:60]
    assert text.count(a) == 1, "not unique: " + a[:60]
    return text.replace(a, b)

p = "crates/wolf-game/src/picture.rs"
t = io.open(p, encoding="utf-8", newline="").read()

const_anchor = """/// Scale value that means 100 percent, i.e. unscaled.
pub const SCALE_ONE: i32 = 100;"""
const_new = const_anchor + """
/// Which argument slot of the long erase form carries the other end of the range.
///
/// The erase form is `150 [head, number, fade, fade, 0, other]`: after the head word the
/// interpreter hands the picture layer `[fade, fade, 0, other]`, so slot 3 is the second
/// picture number. 329 of the 1,115 erase instructions in this game use that form; the
/// remaining 751 are the short `[fade]` form and 35 carry a stray short tail.
pub const ERASE_SPAN: usize = 3;"""

erase_old = """            PictureAction::Erase => {
                self.pictures.remove(&cmd.number);
            }"""
erase_new = """            PictureAction::Erase => {
                // The long erase form clears a RANGE of slots. Common event 221 parks the
                // whole loading screen with `150 [16777218, 50000, 5, 5, 0, 50003]`: one
                // command removes the black backdrop (50000), the eyecatch (50001), the
                // NOW LOADING text (50002) and the progress bar (50003). Treating it as a
                // single-slot erase is what left the eyecatch and the loading text on
                // screen forever, because no other instruction in the game names them.
                //
                // The two endpoints are not ordered - Map003.mps:ev1 pc24 passes -1 then
                // -2 - so the range is between them, not below and above the first.
                match cmd.args.get(ERASE_SPAN) {
                    Some(other) => {
                        let (lo, hi) = (cmd.number.min(*other), cmd.number.max(*other));
                        self.pictures.retain(|number, _| *number < lo || *number > hi);
                    }
                    None => {
                        self.pictures.remove(&cmd.number);
                    }
                }
            }"""

test_anchor = """    #[test]
    fn opacity_is_clamped_and_transparent_pictures_are_not_drawn() {"""
test_new = """    #[test]
    fn the_long_erase_form_clears_every_slot_between_its_endpoints() {
        let mut screen = Screen::new();
        for number in 50000..=50003 {
            screen.apply(&cmd(number, 0, PictureAction::Draw, "a.png", "", &short_draw_args()));
        }
        screen.apply(&cmd(50004, 0, PictureAction::Draw, "a.png", "", &short_draw_args()));
        // ce221 pc36, verbatim: the pair is 50000 and 50003.
        screen.apply(&cmd(50000, 0, PictureAction::Erase, "", "", &[5, 5, 0, 50003]));
        assert_eq!(screen.len(), 1, "only the picture outside the pair survives");
        assert!(screen.get(50004).is_some());
    }

    #[test]
    fn the_erase_range_is_read_min_to_max_not_in_argument_order() {
        let mut screen = Screen::new();
        for number in -2..=1 {
            screen.apply(&cmd(number, 0, PictureAction::Draw, "a.png", "", &short_draw_args()));
        }
        // Map003.mps:ev1 pc24 passes the endpoints the wrong way round.
        screen.apply(&cmd(-1, 0, PictureAction::Erase, "", "", &[0, 0, 0, -2]));
        assert!(screen.is_empty());
    }

    #[test]
    fn the_short_erase_form_removes_only_its_own_slot() {
        let mut screen = Screen::new();
        for number in [10, 11, 12] {
            screen.apply(&cmd(number, 0, PictureAction::Draw, "a.png", "", &short_draw_args()));
        }
        screen.apply(&cmd(11, 0, PictureAction::Erase, "", "", &[0]));
        assert_eq!(screen.len(), 2);
        assert!(screen.get(10).is_some() && screen.get(12).is_some());
    }

    #[test]
    fn opacity_is_clamped_and_transparent_pictures_are_not_drawn() {"""

helper_anchor = """    #[test]
    fn erase_removes_the_slot_and_is_idempotent() {"""
helper_new = """    /// The shortest argument list that draws a visible 16x16-ish sprite.
    fn short_draw_args() -> [i32; 9] {
        [0, 1, 1, 1, 255, 0, 0, 100, 0]
    }

    #[test]
    fn erase_removes_the_slot_and_is_idempotent() {"""

t = rep(t, const_anchor, const_new)
t = rep(t, erase_old, erase_new)
t = rep(t, helper_anchor, helper_new)
t = rep(t, test_anchor, test_new)
open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("patched", p, len(t))