
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(open('work/wolftl/dump/db/CDataBase.json',encoding='utf-8'))['types']
print('keys of type0:', list(d[0].keys()))
t0=d[0]
for k,v in t0.items():
    if k!='data':
        print(k, json.dumps(v,ensure_ascii=False)[:400])
