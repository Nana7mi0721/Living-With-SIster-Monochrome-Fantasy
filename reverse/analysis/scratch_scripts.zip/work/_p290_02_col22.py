
import io,sys,json,os
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
ROOT=r'E:\Study\github program\imoto life'
CE=json.load(open(os.path.join(ROOT,'work','_ce_full.json'),encoding='utf-8'))
MP=json.load(open(os.path.join(ROOT,'work','maps_full.json'),encoding='utf-8'))
rows=json.load(open(os.path.join(ROOT,'work','_db_rows.json'),encoding='utf-8'))
dbj=json.load(open(os.path.join(ROOT,'work','wolftl','dump','db','DataBase.json'),encoding='utf-8'))

def sites():
    for e in CE:
        for ci,c in enumerate(e['cmds']):
            if c['c']==250: yield ('CE%d'%e['id'],ci,c['a'],c['s'])
    for mk,m in MP.items():
        for evt in m['events']:
            for ci,c in enumerate(evt['cmds']):
                if c['code']==250: yield ('%s/e%d'%(mk,evt['id']),ci,c['ints'],c['strs'])

print('=== all 250 sites whose arg2==22, by arg0/bits89 ===')
from collections import Counter
hits=[(tag,ci,a,s) for tag,ci,a,s in sites() if len(a)>2 and a[2]==22]
print('count',len(hits))
print(Counter((a[0],(a[3]>>8)&3) for tag,ci,a,s in hits))
for tag,ci,a,s in hits:
    print(' ',tag,'pc',ci,'a=',a,'bits89=',(a[3]>>8)&3,'label=',s[1] if len(s)>1 else '','/',s[3] if len(s)>3 else '')

print()
print('=== DataBase#17 (システム設定) field 22 and DataBase#16 (画像/音声設定) field 2 ===')
t17=rows['DataBase'][17]; t16=rows['DataBase'][16]
f17=[f['name'] for f in dbj['types'][17]['fields']]
f16=[f['name'] for f in dbj['types'][16]['fields']]
print('DataBase#17 fields',len(f17),'| fi22 =',f17[22])
print('  props',t17['props'],'nint',t17['nint'],'nstr',t17['nstr'])
ints,strs=t17['rows'][0]
print('  row0 ints',ints)
print('  row0 strings',strs)
print('  => 装備可能欄数 int index', 22,'value',ints[22] if 22<len(ints) else 'N/A')
print()
print('DataBase#16 fields',len(f16),'| fi2 =',f16[2])
s16=t16['rows'][0][1]
print('  row0 strings[2] =',s16[2])
print('  row0 string count',len(s16),'-> arg2=22 out of range:',22>=len(f16))
