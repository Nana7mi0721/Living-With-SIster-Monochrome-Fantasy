import os
root=r'E:/Study/github program/imoto life/work/imouto/Data/BasicData'
def strs(b):
    out=[];cur=bytearray()
    for ch in b:
        if 0x20<=ch<=0x7e or 0x81<=ch<=0x9f or 0xe0<=ch<=0xfc:
            cur.append(ch)
        else:
            if len(cur)>=2:
                try: out.append(bytes(cur).decode('cp932'))
                except Exception: pass
            cur=bytearray()
    if len(cur)>=2:
        try: out.append(bytes(cur).decode('cp932'))
        except Exception: pass
    return out
for name in ['SysDatabase.project','DataBase.project','CDataBase.project']:
    b=open(os.path.join(root,name),'rb').read()
    ss=strs(b);uniq=[];seen=set()
    for s in ss:
        if s not in seen: seen.add(s);uniq.append(s)
    keep=[s for s in uniq if any(c>='\u3040' for c in s) and len(s)<=24]
    print('==',name,len(uniq),'jp',len(keep))
    print('|'.join(keep))
    print()