import json, io
ce = json.load(open("work/_ce_full.json", encoding="utf-8"))
d = {e["id"]: e for e in ce}

def dump(eid, lo, hi, f):
    e = d[eid]
    f.write("### ev%d %s run=%s\n" % (eid, e["title"], e["run"]))
    for i, c in enumerate(e["cmds"]):
        if c["c"] == 0:
            continue
        if i < lo or i > hi:
            continue
        f.write("pc%-4d bd=%s c=%-4s a=%s s=%s\n" % (i, c["bd"], c["c"], c["a"], c["s"]))

f = io.open("work/_m3_time_detail.txt", "w", encoding="utf-8")
dump(317, 110, 140, f)
dump(317, 405, 435, f)
dump(317, 585, 625, f)
dump(317, 900, 930, f)
dump(329, 370, 400, f)
dump(329, 425, 445, f)
f.write("\n### ev317 calls to 217\n")
for i, c in enumerate(d[317]["cmds"]):
    if c["c"] == 210 and c["a"] and c["a"][0] == 500217:
        f.write("pc%d a=%s\n" % (i, c["a"]))
f.write("\n### 329 calls to 317/217\n")
for i, c in enumerate(d[329]["cmds"]):
    if c["c"] == 210 and c["a"] and c["a"][0] in (500317, 500217):
        f.write("pc%d a=%s\n" % (i, c["a"]))
f.close()
print("ok")
