import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
d = json.load(io.open('work/wolftl/dump/db/DataBase.json', encoding='utf-8'))
for idx in (16,17):
    t = d['types'][idx]
    print('=== dump index', idx, t['name'], 'fields', len(t['fields']), 'rows', len(t['data']))
    for fi,f in enumerate(t['fields']):
        print('   f%d'%fi, json.dumps(f, ensure_ascii=False)[:120])
    for ri,row in enumerate(t['data'][:3]):
        print('   row%d'%ri, json.dumps(row, ensure_ascii=False)[:400])
