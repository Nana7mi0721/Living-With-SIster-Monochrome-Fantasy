
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ce}
def show(eid,pc,rad=6):
    e=by[eid]; cm=e['cmds']
    print('='*60); print('CE%d %s pc%d'%(eid,e['title'],pc))
    for i in range(max(0,pc-rad),min(len(cm),pc+rad+1)):
        c=cm[i]
        print(('>>' if i==pc else '  ')+'pc%-4d c=%-4d a=%s s=%s bd=%d'%(i,c['c'],c['a'],[x[:32] for x in c['s']],c['bd']))
show(267,24); show(270,34); show(265,12); show(82,4,4); show(191,30,8); show(157,28,6)
