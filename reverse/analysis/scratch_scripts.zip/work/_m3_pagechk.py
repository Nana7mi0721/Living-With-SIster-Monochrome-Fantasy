
import json,os
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
wt=json.load(open(os.path.join(W,"wolftl","dump","mps","SampleMapA.json"),encoding="utf-8"))
mf={e["id"]:e for e in maps["SampleMapA.mps"]["events"]}
wf={e["id"]:e for e in wt["events"]}
out=[]
for i in sorted(mf):
    a=len(mf[i]["cmds"]); b=sum(len(p["list"]) for p in wf[i]["pages"]) if i in wf else -1
    out.append("ev%-3d maps_full_cmds=%-5d wolftl_all_pages=%-5d npg=%s"%(i,a,b,mf[i]["npg"]))
open(os.path.join(W,"_m3_pagechk.txt"),"w",encoding="utf-8").write("\n".join(out))
print("\n".join(out[:12]))
