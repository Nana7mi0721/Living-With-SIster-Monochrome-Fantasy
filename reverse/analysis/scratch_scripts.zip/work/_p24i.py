import json, io, sys
from collections import Counter
sys.stdout.reconfigure(encoding='utf-8')
CE = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
MP = json.load(io.open('work/maps_full.json', encoding='utf-8'))

def norm_c(c):
    return (c['c'], c.get('a', []), c.get('s', []))

ce_sites = []
for e in CE:
    for k, c in enumerate(e['cmds']):
        if c['c'] in (220, 221, 222):
            ce_sites.append((e['id'], e['title'], k, c['c'], c['a'], c['s']))
mp_sites = []
for name, mp in MP.items():
    for ev in mp['events']:
        for k, c in enumerate(ev['cmds']):
            code = c.get('code', c.get('c'))
            if code in (220, 221, 222):
                mp_sites.append((name, ev['id'], ev.get('name',''), k, code, c.get('ints', c.get('a')), c.get('strs', c.get('s'))))

for code in (220, 221, 222):
    print('== opcode %d: ce=%d map=%d total=%d' % (code, sum(1 for s in ce_sites if s[3]==code), sum(1 for s in mp_sites if s[4]==code), sum(1 for s in ce_sites if s[3]==code)+sum(1 for s in mp_sites if s[4]==code)))
print()
print('argc hist ce:', {code: Counter(len(s[4]) for s in ce_sites if s[3]==code) for code in (220,221,222)})
print('strc hist ce:', {code: Counter(len(s[5]) for s in ce_sites if s[3]==code) for code in (220,221,222)})
print()
print('map sites:')
for s in mp_sites:
    print(' ', s[0], 'ev', s[1], s[2][:20], 'pc', s[3], 'op', s[4], s[5])
print()
print('ce 220 sites:')
for s in ce_sites:
    if s[3]==220: print('  ev%d %-20s pc%d %s' % (s[0], s[1][:20], s[2], s[4]))
print()
print('ce 222 sites:')
for s in ce_sites:
    if s[3]==222: print('  ev%d %-20s pc%d %s' % (s[0], s[1][:20], s[2], s[4]))
print()
# ev131 context around 222 and 1000
e131 = [e for e in CE if e['id']==131][0]
for k, c in enumerate(e131['cmds']):
    if c['c'] in (1000, 220, 221, 222) or (c['c']==122 and k>220 and k<240):
        lo = max(0, k-3)
        print('--- ev131 around pc%d' % k)
        for j in range(lo, min(len(e131['cmds']), k+4)):
            x = e131['cmds'][j]
            print('   %3d %3d %s %s' % (j, x['c'], x['a'], [t[:40] for t in x['s']]))
