import io, os
path = "docs/M2_SLICE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """**仍未实现**：220 mode 0（从 Game 状态构造完整 `SaveFile` 的 part1/part2/part4/part5）只有一条诊断记录；
221 的 `flag=1` 三个站点（ev94 pc335/345/348，地址 `1600062`/`1600064`）语义未验证。"""
b = """**220 mode 0 已实现（本批）**：`Game::save_to` 以「本局载入的存档」或新游戏的 `Save/System.sav` 为模板，写入
playtime、Sys3/Sys4、800 个通常変数、全部活着的公共事件 self 数值变量与 `CSelf5..9` 字符串；
`savegame::part5_from_screen` 把当前图片层反向编码成 SavePart5（文本图转义流 02/05/06），
`Databases::write_into(&mut save.vardb)` 把运行时 CDataBase 改动写进变量库，最后 `to_bytes_rebuilt()`。
测试 `a_saved_game_reloads_its_live_picture_layer`（66 张图逐字段相同）与 `a_saved_game_keeps_the_database_cells`
（(0,12,5)=4242 保存→载入后仍是 4242）已验证。仍只剩 221 的 `flag=1` 三个站点（ev94 pc335/345/348，
地址 `1600062`/`1600064`）和 retail 04 字体记录的字节级写回未验证。"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")