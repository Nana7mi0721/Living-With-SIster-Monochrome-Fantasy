from PIL import Image
sheet = Image.open('work/full/MapChip/[A]Grass1_pipo.png').convert('RGBA')
def compose(raw, frame=0):
    tail = raw % 10000
    codes = [(tail//1000)%10, (tail//100)%10, (tail//10)%10, tail%10]
    cell = Image.new('RGBA', (16,16), (0,0,0,0))
    for qy in range(2):
        for qx in range(2):
            c = codes[qy*2+qx]
            src = (frame*16+qx*8, c*16+qy*8)
            cell.paste(sheet.crop((src[0], src[1], src[0]+8, src[1]+8)), (qx*8, qy*8))
    return cell
rows = [[104444]*6, [100000]*6, [104422, 102244, 104141, 101414, 104434, 101402], [104444, 100000, 104444, 100000, 104444, 100000]]
out = Image.new('RGBA', (6*16, len(rows)*16), (0,0,0,255))
for y, row in enumerate(rows):
    for x, raw in enumerate(row):
        out.paste(compose(raw), (x*16, y*16), compose(raw))
out = out.resize((out.width*7, out.height*7), Image.NEAREST)
out.save('work/out/autotile_test.png')
print('wrote', out.size)
