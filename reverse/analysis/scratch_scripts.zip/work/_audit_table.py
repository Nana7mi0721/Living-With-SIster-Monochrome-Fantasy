
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
live=set(fin['live']); deadref=set(fin['deadref']); never=set(fin['never'])
sizes=fin['sizes']
DATA={'BasicData','MapData'}
dirs=sorted(set(p.split('/')[0] for p in sizes)|{'BasicData','MapData'})
# add missing dirs (files that exist but maybe not in sizes) -> sizes covers all data files
rows=[]
for d in dirs:
    ps=[p for p in sizes if p.split('/')[0]==d]
    b=sum(sizes[p] for p in ps)
    l=sum(sizes[p] for p in ps if p in live)
    dr=sum(sizes[p] for p in ps if p in deadref)
    nv=sum(sizes[p] for p in ps if p in never)
    rows.append((d,len(ps),b,len([p for p in ps if p in live]),l,len([p for p in ps if p in deadref]),dr,len([p for p in ps if p in never]),nv))
W('%-24s %5s %12s %5s %12s %5s %10s %5s %12s'%('dir','files','bytes','live','liveB','dref','drefB','never','neverB'))
tot=[0]*8
for r in sorted(rows,key=lambda r:-r[2]):
    W('%-24s %5d %12d %5d %12d %5d %10d %5d %12d'%r)
    for i in range(1,8): tot[i-1]+=r[i]
W('%-24s %5d %12d %5d %12d %5d %10d %5d %12d'%('TOTAL',*tot))
# missing dirs check
W('\nall top dirs: %s'%dirs)
# never referenced biggest 30 (assets only)
W('\n== 30 biggest never-referenced ASSETS (excl BasicData/MapData) ==')
for p in sorted([p for p in never if p.split('/')[0] not in DATA],key=lambda p:-sizes[p])[:30]:
    W('%12d %s'%(sizes[p],p))
W('\n== dead-code-only referenced (all %d) =='%len(deadref))
for p in sorted(deadref,key=lambda p:-sizes[p]): W('%12d %s'%(sizes[p],p))
open('work/_audit_out15.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
