
import json,os,collections,re
from PIL import Image
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
# all refs to Picture/word_effect or word/
hits=collections.Counter()
for e in ce:
    for c in e["cmds"]:
        for x in (c.get("s") or []):
            if isinstance(x,str) and ("word_effect" in x):
                hits[x]+=1
for mn,m in maps.items():
    for ev in m.get("events",[]):
        for c in ev.get("cmds",[]):
            for x in (c.get("strs") or []):
                if isinstance(x,str) and "word_effect" in x:
                    hits[x]+=1
print("distinct word_effect refs:",len(hits))
pref=collections.Counter(k.rsplit("/",1)[0] if "/" in k else "(none)" for k in hits)
print("prefixes:",dict(pref))
print("sample:",list(hits)[:5])
# compare word/ vs hword/ for 30,36,55,56,57,58,59
for n in ["30","36","55","56","57","58","59"]:
    a=os.path.join(W,"all","word","word_effect%s.png"%n)
    b=os.path.join(W,"all","hword","word_effect%s.png"%n)
    for lbl,pa in (("word",a),("hword",b)):
        if os.path.isfile(pa):
            im=Image.open(pa)
            print(n,lbl,im.size,os.path.getsize(pa))
        else:
            print(n,lbl,"MISSING")
