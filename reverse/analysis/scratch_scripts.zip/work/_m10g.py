import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
def a1(s): return (s.encode('ascii','ignore').decode() if isinstance(s,str) else s)
print("=== all refs to 172 in op210/op300 ===")
for e in ces:
    for i,cm in enumerate(e['cmds']):
        if cm['c'] in (210,300) and cm.get('a'):
            a=cm['a']
            # op210 target a0; op300 name in s[0]
            if cm['c']==210 and a and a[0]-500000==172:
                print(f"CE{e['id']} pc{i} op210 {a}")
            if cm['c']==300:
                nm=[a1(x) for x in cm.get('s',[])]
                if any('勝敗' in (x or '') for x in nm):
                    print(f"CE{e['id']} pc{i} op300 {a} {nm}")
print("=== outgoing calls from CE172 (op210/300) ===")
for i,cm in enumerate(by[172]['cmds']):
    if cm['c'] in (210,300,106):
        print(f"pc{i} op{cm['c']} {cm.get('a')} {[a1(x) for x in cm.get('s',[]) if x]}")

