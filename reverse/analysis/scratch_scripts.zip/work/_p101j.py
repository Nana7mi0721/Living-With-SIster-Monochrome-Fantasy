import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
ev = [e for e in ce if e['id']==63][0]
for i,c in enumerate(ev['cmds']):
    if c['c']!=150: continue
    a=c['a']; s=c['s']
    a0=a[0]
    print('%4d argc=%2d strc=%d  a0=%d=%#x type=%d cmd=%d anchor=%#x  strs=%s'%(i,len(a),len(s),a0,a0,(a0>>4)&7,a0&0xF,a0&0xF000,[x[:50] for x in s]))