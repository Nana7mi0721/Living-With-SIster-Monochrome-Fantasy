import json, io, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
B = chr(92)
c_idx=collections.Counter(); f_idx=collections.Counter(); v_idx=collections.Counter()
cself_idx=collections.Counter(); sp_idx=collections.Counter(); cdb_tok=collections.Counter()
single=collections.Counter(); angle=collections.Counter()

def scan(s, counters):
    i=0
    while i < len(s):
        ch=s[i]
        if ch=='<':
            j=s.find('>', i)
            if j>0 and len(s[i:j+1])<=4:
                angle[s[i:j+1]]+=1
                i=j+1; continue
        if ch==B and i+1<len(s):
            nxt=s[i+1]
            if nxt in '>.^<!~N':
                single[nxt]+=1; i+=2; continue
            if nxt=='[':
                j=s.find(B+']', i+2)
                if j<0: i+=1; continue
                body=s[i+2:j]
                key=body.split(':')[0] if ':' in body else body
                counters.setdefault('br', collections.Counter())[body]+=1
                i=j+2; continue
            # letter escapes
            j=i+1
            while j<len(s) and s[j].isalpha(): j+=1
            name=s[i+1:j]
            arg=None
            if j<len(s) and s[j]==B and j+1<len(s) and s[j+1]=='[':
                k=s.find(B+']', j+2)
                if k>0: arg=s[j+2:k]; j=k+2
            if name=='c': c_idx[arg]+=1
            elif name=='f': f_idx[arg]+=1
            elif name=='v': v_idx[arg]+=1
            elif name=='cself': cself_idx[arg]+=1
            elif name=='sp': sp_idx[arg]+=1
            elif name=='cdb': cdb_tok[arg]+=1
            i=j; continue
        i+=1

br = collections.Counter()
for ev in ce:
    for c in ev['cmds']:
        if c['c'] != 101: continue
        for s in c['s']:
            d={}
            scan(s,d)
            if 'br' in d: br.update(d['br'])
print('single-char:', single.most_common())
print('angle:', angle.most_common())
print('all bracketed bodies:', br.most_common(60))
print('c idx:', c_idx.most_common())
print('f idx:', f_idx.most_common())
print('v idx:', v_idx.most_common())
print('cself idx:', cself_idx.most_common())
print('sp idx:', sp_idx.most_common())
print('cdb:', cdb_tok.most_common())
