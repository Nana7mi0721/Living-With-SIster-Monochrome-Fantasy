import io, os
gp = os.path.join("crates", "wolf-game", "src", "game.rs")
s = io.open(gp, encoding="utf-8", newline="").read()
NL = chr(10)
a = s.index("    /// Starts the title screen event.")
marker = "    /// Fails when this build has no event 42." + NL
b = s.index(marker) + len(marker)
c = s.index("    pub fn start_title(&mut self)")
moved = s[b:c]
assert "pub fn boot" in moved and "fn read" in moved
s = s[:a] + moved + s[a:b] + s[c:]
out = gp + ".new"
io.open(out, "w", encoding="utf-8", newline="").write(s)
os.replace(out, gp)
print("moved", len(moved))
