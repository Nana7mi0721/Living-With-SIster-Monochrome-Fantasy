import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a))
    t = t.replace(a, b)

rep("""    /// The automatic pages of the map the game booted into.
    pub runtime: MapRuntime,""", """    /// The automatic pages of the map the game booted into.
    pub runtime: MapRuntime,
    /// Frames of play time; the save stores this in SavePart2.vars3_21[0].
    pub playtime_frames: u32,""")

rep("""            runtime: MapRuntime::new(),
            mouse: [-1, -1],""", """            runtime: MapRuntime::new(),
            playtime_frames: 0,
            mouse: [-1, -1],""")

rep("""    /// The data root this game was created from.
    #[must_use]
    pub fn root(&self) -> &Path {
        &self.root
    }""", """    /// The data root this game was created from.
    #[must_use]
    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Frames of play time, as a save file stores them.
    #[must_use]
    pub fn playtime_frames(&self) -> u32 {
        self.playtime_frames
    }

    /// Replaces the play-time clock, used when a save is loaded.
    pub fn set_playtime_frames(&mut self, frames: u32) {
        self.playtime_frames = frames;
    }""")
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("patched")
