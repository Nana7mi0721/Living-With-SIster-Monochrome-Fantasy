
import json,collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
for OPEN in ({111,112,102,179,170},{111,112,102,179,170,176},{111,112,102,179,170,176,420,421}):
    CLOSE={499,498}
    strays=0; unm=0; pairs=0; kinds=collections.Counter()
    for ev in d:
        stack=[]
        for i,c in enumerate(ev['cmds']):
            o=c['c']; b=c['bd']
            if o in OPEN: stack.append((b,i,o))
            elif o in CLOSE:
                if stack and stack[-1][0]==b: stack.pop(); pairs+=1
                else: strays+=1
        unm+=len(stack)
    print(sorted(OPEN),'pairs',pairs,'strays',strays,'unmatched',unm)
print('=== event 0 full ===')
cm=d[0]['cmds']
for i,c in enumerate(cm):
    print(i,c['c'],'bd',c['bd'],'a',c['a'][:5])
