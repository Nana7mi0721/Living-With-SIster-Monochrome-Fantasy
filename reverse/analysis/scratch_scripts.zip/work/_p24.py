
import json, sys, collections, unicodedata
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))
retid = {int(k): v['retid'] for k, v in meta.items()}
titles = {e['id']: e['title'] for e in ce}

def norm(s):
    s = unicodedata.normalize('NFKC', s)
    return ''.join(ch for ch in s if ch.isalnum())

want = ['○◆マップをズーム']
nm = norm(want[0])
hits = [(i, t) for i, t in titles.items() if nm in norm(t)]
print('zoom candidates:', hits, [(i, hex(retid[i])) for i, _ in hits])

# check the 8 unresolved call site strings exactly
for e in ce:
    if e['id'] != 270: continue
    for pc in (631, 637, 705, 711, 2065, 2071, 2112, 2119):
        c = e['cmds'][pc]
        print(pc, c['c'], repr(c['s']), c['a'])

