import json, io, collections
d = json.load(io.open('work/maps_full.json', encoding='utf-8'))
names = collections.Counter()
for mk, m in d.items():
    for ev in m.get('events', []):
        for pg in ev.get('pages', []) or []:
            g = pg.get('graphic') or pg.get('graphic_name') or ''
            if g: names[g] += 1
print('maps', len(d), 'distinct graphics', len(names))
for n, c in names.most_common(15): print(c, repr(n))
print('sample page keys', list((list(d.values())[0]['events'][0]['pages'][0]).keys()))