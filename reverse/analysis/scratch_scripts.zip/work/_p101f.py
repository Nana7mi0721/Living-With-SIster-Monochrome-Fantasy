import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
d = json.load(io.open('work/wolftl/dump/db/CDataBase.json', encoding='utf-8'))
print('top', list(d.keys()) if isinstance(d,dict) else type(d))
t = d['types'] if isinstance(d,dict) and 'types' in d else d
for i,x in enumerate(t):
    if isinstance(x,dict):
        print(i, repr(x.get('name'))[:30], 'nf', len(x.get('fields') or []), 'nd', len(x.get('data') or []))
