
import zipfile, sys, io, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
print('entries', len(z.infolist()))
for i in z.infolist()[:30]:
    print(i.filename, i.file_size)
