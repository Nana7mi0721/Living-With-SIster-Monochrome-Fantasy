# -*- coding: utf-8 -*-
import io, json, collections
p = r"E:\Study\github program\imoto life\docs\BASELINE.json"
s = io.open(p, encoding="utf-8").read()
block = ''' "title_screen": {
  "event": 42,
  "event_title": "オリジナルタイトル画面Ａ",
  "instructions": 39,
  "frames_to_park": 16,
  "peak_coroutines": 1,
  "picture_ops": 1,
  "pictures_live": 1,
  "choice_prompt": ["1", "2", "3"],
  "choice_sys3_x": 512,
  "choice_sys4_y": 1000,
  "background": "SystemGraphic/TitleGraphic.jpg",
  "background_picture_number": -2,
  "bgm": "BGM/White_Base.mp3",
  "note": "39 instructions is the whole title: draw one full-screen graphic, start one BGM, open a 3-option prompt. The earlier 39,753-instruction / 3,261-picture capture was the save/load chain reached through the 401 fall-through bug."
 },
'''
i = s.index(' "verify": {')
s = s[:i] + block + s[i:]
io.open(p, "w", encoding="utf-8", newline="\n").write(s)
json.load(io.open(p, encoding="utf-8"))
print("baseline patched ok")
