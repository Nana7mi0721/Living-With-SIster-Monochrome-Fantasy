import json, io, sys
from collections import Counter
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
mp = json.load(io.open('work/maps_full.json', encoding='utf-8'))
def cmds_all():
    for e in ce:
        for c in e['cmds']: yield c
    for mn,m in mp.items():
        for ev in m['events']:
            for c in ev['cmds']: yield c
for grp,name in [(3,'0x3000'),(4,'0x4000'),(5,'0x5000'),(6,'0x6000')]:
    a2=Counter(); a1=Counter(); n=0; samples=[]
    for c in cmds_all():
        if c['c'] not in (121,124): continue
        if len(c['a'])<4: continue
        if (c['a'][3]>>12)&0xF != grp: continue
        n+=1; a2[c['a'][2]]+=1; a1[c['a'][1]]+=1
        if len(samples)<10: samples.append((c['a']))
    print('===', name, 'n=', n)
    print('  arg2 top:', a2.most_common(18))
    print('  arg1 top:', a1.most_common(8))
    for s in samples: print('   ', s)