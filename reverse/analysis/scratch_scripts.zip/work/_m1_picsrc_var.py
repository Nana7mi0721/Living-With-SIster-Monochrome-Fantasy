# -*- coding: utf-8 -*-
"""Every 150 Picture site in the title closure, including those whose picture
number is a variable/self reference (the ones that resolve to 12004/12005/12053
and to picture 0 at runtime)."""
import collections, io, json

events = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
map_evs = {e['id']: e for e in tm['events']}
clos = json.load(io.open('work/_m1_closure2.json', encoding='utf-8'))
rows = clos['from_map_event2']['reached']

def norm(cmds):
    out = []
    for c in cmds:
        if 'c' in c:
            out.append({'c': c['c'], 'a': [int(x) for x in c['a']], 's': list(c.get('s') or [])})
        else:
            out.append({'c': c.get('code', 0),
                        'a': [int(x) for x in (c.get('intArgs') or [])],
                        's': list(c.get('stringArgs') or [])})
    return out

print('%-8s %-6s %-5s %-5s %-6s %s' % ('event', 'slot', 'act', 'kind', 'num', 'strs/args'))
for r in rows:
    if r['kind'] == 'c':
        cmds = norm(by_id[r['id']]['cmds'])
        tag = 'c%d' % r['id']
    else:
        cmds = []
        for p in map_evs[r['id']]['pages']:
            cmds.extend(norm(p['list']))
        tag = 'm%d' % r['id']
    for i, c in enumerate(cmds):
        if c['c'] != 150 or len(c['a']) < 2:
            continue
        head, num = c['a'][0], c['a'][1]
        kind = (head >> 4) & 0x07
        action = {0: 'Draw', 1: 'Move', 2: 'Erase'}.get(head & 0x0F, 'Set')
        if 0 <= num < 200000:
            continue
        print('%-8s %-6d %-5s %-5d %-6d %s  args=%s'
              % (tag, i, action, kind, num, c['s'], c['a'][2:]))
