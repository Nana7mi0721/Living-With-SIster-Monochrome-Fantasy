
import json,io,collections,sys,re
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
def cmds_all():
    for e in ce:
        for c in e['cmds']: yield e['id'],norm(c)
    for m in mp.values():
        for ev in m.get('events',[]):
            for c in ev.get('cmds',[]): yield ('M',norm(c))
esc=collections.Counter(); esc101=collections.Counter(); nl=0; cr=0; tab=0
for eid,(op,a,s) in cmds_all():
    for s1 in s:
        if '\n' in s1: nl+=1
        if '\r' in s1: cr+=1
        if '\t' in s1: tab+=1
        i=0
        while i<len(s1):
            if s1[i]=='\\':
                k=i+1
                while k<len(s1) and (s1[k].isalpha()): k+=1
                key=s1[i+1:k] if k>i+1 else ('\\'+ (s1[k] if k<len(s1) else '?'))
                esc[key]+=1
                if op==101: esc101[key]+=1
                i=max(k,i+1)
            else: i+=1
print('strings containing LF',nl,'CR',cr,'TAB',tab)
print('=== non-alpha / special escapes (all ops) ===')
for k,v in sorted(esc.items()):
    if not k[1:].isalpha(): print('  %-6r %d'%(k,v))
print('=== 101-only escapes top 25 ===')
for k,v in esc101.most_common(25): print('  %-8r %d'%(k,v))
print('=== 101-only non-alpha ===')
for k,v in sorted(esc101.items()):
    if not k[1:].isalpha(): print('  %-6r %d'%(k,v))
