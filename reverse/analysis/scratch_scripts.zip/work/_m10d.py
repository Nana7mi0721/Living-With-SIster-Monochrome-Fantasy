import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
def a1(s): return (s.encode('ascii','ignore').decode() if isinstance(s,str) else s)
def dump(cid):
    e=by[cid]; print(f"### CE{cid} {e.get('title','')!r} ncmds={len(e['cmds'])}")
    for i,cm in enumerate(e['cmds']):
        c=cm['c']; a=cm.get('a',[])
        s=[a1(x) for x in cm.get('s',[]) if x]
        print(f"{i:>4} op{c} {a}{(' '+str(s)) if s else ''}")
dump(216); print(); dump(226)

