
import json,io,os,collections
from PIL import Image
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure.json',encoding='utf-8'))
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
sizes=fin['sizes']
evs=set()
for s in cl['boot']:
    s=s.strip()
    if s.startswith("('c'"): evs.add(int(s.split(',')[1].strip(' )')))
ps=set()
for p,sites in refs['referenced'].items():
    for src,loc,op in sites:
        if src=='common' and int(loc.split('#')[0].replace('ev','')) in evs: ps.add(p); break
        if src=='map' and loc.startswith('TitleMap'): ps.add(p); break
tot=0; img=0; aud=0; other=[]
for p in ps:
    fp=os.path.join('work/all',p)
    if not os.path.exists(fp): continue
    if p.lower().endswith(('.png','.jpg','.jpeg','.bmp','.webp','.gif')):
        try:
            im=Image.open(fp); tot+=im.size[0]*im.size[1]; img+=1
        except Exception as e: W('  unreadable %s'%p)
    elif p.lower().endswith(('.mp3','.ogg','.wav','.m4a')): aud+=1
    else: other.append(p)
W('M1 boot assets: %d files; images %d, pixels %d (%.2f Mpx, %.2f 2048-sheets); audio %d; other %s'%(
    len(ps),img,tot,tot/1e6,tot/4194304,aud,other))
for p in sorted(ps): W('   %9d  %s'%(sizes.get(p,0),p))
open('work/_audit_out36.txt','w',encoding='utf-8').write(OUT.getvalue()); print('ok')
