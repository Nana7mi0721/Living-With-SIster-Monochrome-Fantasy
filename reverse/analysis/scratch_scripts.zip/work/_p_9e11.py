import json, io
events = json.load(io.open("work/_ce_full.json", encoding="utf-8"))
ev = [e for e in events if e["id"] == 63][0]
cmds = ev["cmds"]
def desc(h):
    return "head=0x%08x action=%d type=%d b8_11=0x%x anchor=0x%x high=0x%x" % (h, h & 0xF, (h >> 4) & 7, (h >> 8) & 0xF, (h >> 12) & 7, (h >> 15) & 0x1FFFF)
for i in [90, 93, 94, 101, 102, 103, 114, 115]:
    a = cmds[i]["a"]
    print(i, "argc", len(a) + 1, desc(a[0]), "args:", a[1:6])
print()
# histogram over all 150 in the game: action x type x b8_11 for argc 2 vs long
import collections
hist = collections.Counter()
tot = 0
for e in events:
    for c in e["cmds"]:
        if c["c"] == 150:
            a = c["a"]
            tot += 1
            hist[(len(a) + 1, a[0] & 0xF, (a[0] >> 4) & 7, (a[0] >> 8) & 0xF, (a[0] >> 12) & 7)] += 1
print("total 150:", tot)
for k, n in hist.most_common(24):
    print("argc=%-3d action=%d type=%d b8_11=0x%x anchor=0x%x  x%d" % (k[0], k[1], k[2], k[3], k[4], n))