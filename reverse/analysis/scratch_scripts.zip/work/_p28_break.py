import io, os
p = 'crates/wolf-save/src/part2.rs'
s = io.open(p, encoding='utf-8', newline='').read()
old = 'push_u32(&mut out, self.var51);'
assert old in s
io.open(p + '.bak', 'w', encoding='utf-8', newline='').write(s)
io.open(p + '.new', 'w', encoding='utf-8', newline='').write(s.replace(old, 'push_u32(&mut out, self.var51 ^ 1);', 1))
os.replace(p + '.new', p)
print('broke part2 encoder')