# -*- coding: utf-8 -*-
import io, json, os, sys, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
src = open(os.path.join('work', '_map_audit10.py'), encoding='utf-8').read()
head = src.split('\nREG = [')[0]
head = '\n'.join(l for l in head.splitlines() if 'sys.stdout =' not in l)
ns = {}
exec(compile(head, 'audit_head', 'exec'), ns)
parse_mps, base = ns['parse_mps'], ns['base']
REG = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps']
ALL = REG + ['SampleMapB.mps','Dungeon.mps','Map002.mps']
NAMES = {0:'空槽 / blank',99:'Checkpoint',101:'Message',102:'Choices',103:'Comment',104:'（未命名 104）',
 105:'ForceStopMessage',111:'VariableCondition',112:'StringCondition',121:'SetVariable',122:'SetString',
 123:'InputKey',124:'SetVariableEx',125:'AutoInput',126:'BanInput',130:'Teleport',140:'Sound',150:'Picture',
 151:'ChangeColor',160:'SetTransition',161:'PrepareTransition',162:'ExecuteTransition',170:'StartLoop',
 172:'BreakEvent',174:'ReturnToTitle',175:'EndGame',179:'LoopTimes',180:'Wait',201:'Move',210:'CommonEvent',
 212:'SetLabel',213:'JumpLabel',220:'SaveLoad',221:'LoadGame',222:'SaveGame',250:'Database',270:'Party',
 290:'Effect',300:'CommonEventByName',401:'ChoiceCase',420:'ElseCase',421:'CancelCase',498:'LoopEnd',499:'BranchEnd'}
def hist(files):
    c = collections.Counter()
    for f in files:
        m = parse_mps(os.path.join(base, f))
        for e in m['events']:
            for p in e['pages']:
                for cmd in p['cmds']:
                    c[cmd['op']] += 1
    return c
reg, al = hist(REG), hist(ALL)
rows = []
for op, n in sorted(al.items(), key=lambda kv: (-kv[1], kv[0])):
    rows.append('| %d | %s | %d | %d |' % (op, NAMES.get(op, '？（未在 WolfTL 中查到）'), reg.get(op, 0), n))
open('work/_docA.txt', 'w', encoding='utf-8', newline='\n').write('\n'.join(rows) + '\n')
print('distinct ops:', len(al), '| registered slots:', sum(reg.values()), '| all slots:', sum(al.values()))
print('registered-only blank:', reg.get(0), '| all blank:', al.get(0))
print('\n'.join(rows[:6]))
missing = [o for o in al if o not in NAMES]
print('ops without name:', missing)
