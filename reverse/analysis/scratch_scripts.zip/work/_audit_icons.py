
import json,io,os,glob
OUT=io.StringIO()
bd='work/all/BasicData'
files=sorted(os.listdir(bd))
icons=[f for f in files if f.lower().startswith('icon')]
OUT.write('BasicData: %d files total\n'%len(files))
OUT.write('icons: %d files, %d B\n'%(len(icons),sum(os.path.getsize(os.path.join(bd,f)) for f in icons)))
others=[(f,os.path.getsize(os.path.join(bd,f))) for f in files if f not in icons]
OUT.write('non-icon files (%d):\n'%len(others))
for f,b in sorted(others,key=lambda x:-x[1]): OUT.write('  %10d %s\n'%(b,f))
# is there an icon list referencing names?
print(open('work/all/BasicData/EncodedIconList.xxxxx','rb').read()[:200])
open('work/_audit_out13.txt','w',encoding='utf-8').write(OUT.getvalue())
