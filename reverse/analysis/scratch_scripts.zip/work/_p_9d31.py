import io, os

def read(path):
    with io.open(path, encoding="utf-8", newline="") as fh:
        return fh.read()

def write(path, text):
    tmp = path + ".new"
    with io.open(tmp, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)
    os.replace(tmp, path)

def sub(text, a, b):
    assert a in text, "anchor missing: " + a[:70]
    assert text.count(a) == 1, "anchor not unique: " + a[:70]
    return text.replace(a, b)

p = "crates/wolf-vm/src/exec.rs"
t = read(p)
t = sub(t,
    "    /// Value to write, for the 5-argument form.\n    pub value: Option<i32>,\n}",
    "    /// Destination variable address, for the 5-argument form.\n"
    "    ///\n"
    "    /// All 2,592 `250` instructions in this game are reads and nothing ever\n"
    "    /// writes a database (there is no 251/252/253 anywhere), so the fifth operand\n"
    "    /// is where the answer goes rather than a value to store.\n"
    "    pub destination: Option<i32>,\n"
    "}\n"
    "\n"
    "/// The answer to a [`DbOp`] read.\n"
    "#[derive(Clone, Debug, PartialEq, Eq)]\n"
    "pub enum DbValue {\n"
    "    /// A numeric cell.\n"
    "    Num(i32),\n"
    "    /// A string cell.\n"
    "    Str(String),\n"
    "}")

t = sub(t,
    "    /// `250 DatabaseAccess`. Reads are unimplemented until wolf-game owns a\n"
    "    /// database; until then the host just records the access.\n"
    "    fn database(&mut self, op: &DbOp) {\n"
    "        let _ = op;\n"
    "    }",
    "    /// `250 DatabaseAccess`. Answers the cell the script asked for; `None` leaves\n"
    "    /// the destination variable untouched, exactly like a cell that is empty in\n"
    "    /// the editor.\n"
    "    fn database(&mut self, op: &DbOp) -> Option<DbValue> {\n"
    "        let _ = op;\n"
    "        None\n"
    "    }")

t = sub(t,
    "                let value = if argc(cmd) >= 5 {\n"
    "                    Some(eval_num(arg(cmd, 4), inst, vars))\n"
    "                } else {\n"
    "                    None\n"
    "                };\n"
    "                host.database(&DbOp {\n"
    "                    db_type,\n"
    "                    data_id: arg(cmd, 1),\n"
    "                    item_id: arg(cmd, 2),\n"
    "                    flags: arg(cmd, 3),\n"
    "                    value,\n"
    "                });\n"
    "                inst.pc += 1;",
    "                // argc 5 is [type, row, column, flags, destination]; the 16\n"
    "                // argc-4 sites carry no destination (docs/OPCODE_250.md).\n"
    "                let destination = if argc(cmd) >= 5 {\n"
    "                    Some(arg(cmd, 4))\n"
    "                } else {\n"
    "                    None\n"
    "                };\n"
    "                if let Some(answer) = host.database(&DbOp {\n"
    "                    db_type,\n"
    "                    data_id: arg(cmd, 1),\n"
    "                    item_id: arg(cmd, 2),\n"
    "                    flags: arg(cmd, 3),\n"
    "                    destination,\n"
    "                }) {\n"
    "                    if let Some(target) = destination {\n"
    "                        match answer {\n"
    "                            DbValue::Num(value) => store_num(inst, vars, target, value),\n"
    "                            DbValue::Str(text) => store_str(inst, vars, target, &text),\n"
    "                        }\n"
    "                    }\n"
    "                }\n"
    "                inst.pc += 1;")
write(p, t)

p = "crates/wolf-vm/src/lib.rs"
t = read(p)
t = sub(t, "BlockResult, ChoiceReply, DbOp, Host,", "BlockResult, ChoiceReply, DbOp, DbValue, Host,")
write(p, t)

p = "crates/wolf-game/src/lib.rs"
t = read(p)
t = sub(t, "pub mod choice;\npub mod game;", "pub mod choice;\npub mod db;\npub mod game;")
write(p, t)

p = "crates/wolf-cli/src/main.rs"
t = read(p)
t = sub(t, "    fn database(&mut self, op: &DbOp) {\n        self.databases += 1;",
        "    fn database(&mut self, op: &DbOp) -> Option<DbValue> {\n        self.databases += 1;")
t = sub(t, "op.flags, op.value", "op.flags, op.destination")
t = sub(t, "flags {:#x} value {:?}", "flags {:#x} destination {:?}")
t = sub(t,
    "            op.db_type, op.data_id, op.item_id, op.flags, op.destination\n        ));\n    }",
    "            op.db_type, op.data_id, op.item_id, op.flags, op.destination\n        ));\n        None\n    }")
t = sub(t, "ChoiceReply, DbOp, Host, LogLevel,", "ChoiceReply, DbOp, DbValue, Host, LogLevel,")
write(p, t)
print("patched all four")