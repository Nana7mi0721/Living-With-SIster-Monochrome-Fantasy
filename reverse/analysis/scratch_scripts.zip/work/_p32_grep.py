import io, sys
sys.stdout.reconfigure(encoding='utf-8')
root = r'E:/Study/github program/imoto life'
import os
base = r'E:/SteamLibrary/steamapps/common/Living With SIster Monochrome Fantasy/Data/BasicData'
p = os.path.join(base, 'CDataBase.project')
print('exists', os.path.exists(p), os.path.getsize(p) if os.path.exists(p) else '')
raw = open(p, 'rb').read()
for needle in ['温柔的'.encode(), '尖叫的'.encode(), '莉子'.encode(), 'リコ'.encode(), '内莱斯'.encode(), 'ネーレイス'.encode(), 'SystemFile/charicon.png'.encode()]:
    print(needle.decode(), '->', raw.count(needle))
