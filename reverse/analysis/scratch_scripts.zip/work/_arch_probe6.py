
import json, os, collections
os.chdir(r'E:\Study\github program\imoto life')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
ids=[e['id'] for e in ev]
print('event id min/max', min(ids), max(ids), 'count', len(ids))
print('first ids', sorted(ids)[:8], 'last', sorted(ids)[-8:])
# 210 arg0 set
a210=set()
for e in ev:
    for c in e['cmds']:
        if c['c']==210: a210.add(c['a'][0])
print('210 distinct arg0:', len(a210), sorted(a210)[:5], sorted(a210)[-5:])
missing=[x for x in a210 if x not in set(ids)]
print('210 arg0 not in event ids:', len(missing), sorted(missing)[:5])
# run_condition per id
rc=collections.Counter(e['run'] for e in ev)
print('run dist', rc)
# which ids are parallel
par=[e['id'] for e in ev if e['run'] in (2,3)]
print('parallel count', len(par), par[:10])
# does parallel event have 180 Wait? distribution of waits per parallel event
w=collections.Counter()
for e in ev:
    if e['run'] in (2,3):
        w[sum(1 for c in e['cmds'] if c['c']==180)]+=1
print('waits per parallel event:', w.most_common(10))
# and for call_only
w2=collections.Counter()
for e in ev:
    if e['run']==0:
        w2[sum(1 for c in e['cmds'] if c['c']==180)]+=1
print('waits per call_only event:', w2.most_common(10))
