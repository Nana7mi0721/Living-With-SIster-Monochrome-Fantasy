import io, json, sys
sys.stdout.reconfigure(encoding='utf-8')
evs = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
e = [x for x in evs if x['id'] == 271][0]
print('title', e['title'], 'run', e['run'], 'cmds', e['cmds'])
cmds = e.get('cmd_list')
print('keys', list(e.keys()))