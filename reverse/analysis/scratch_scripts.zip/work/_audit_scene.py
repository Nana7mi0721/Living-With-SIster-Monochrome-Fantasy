
import json,io,glob,os,re,collections
OUT=io.StringIO()
# exact "scene/" not preceded by h ; "word/" not preceded by h
pat_scene=re.compile(r'(?<![A-Za-z0-9_])scene/')
pat_word=re.compile(r'(?<![A-Za-z0-9_])word/')
hits=collections.Counter(); samp=collections.defaultdict(list)
def scan(s,where,code):
    if pat_scene.search(s): hits['scene']+=1; samp['scene'].append((where,code,s[:70]))
    if pat_word.search(s): hits['word']+=1; samp['word'].append((where,code,s[:70]))
for f in sorted(glob.glob('work/wolftl/dump/common/*.json')):
    j=json.load(open(f,encoding='utf-8'))
    for c in j['commands']:
        for s in c.get('stringArgs',[]): scan(s,'ev%d'%j['id'],c['code'])
for f in sorted(glob.glob('work/wolftl/dump/mps/*.json')):
    j=json.load(open(f,encoding='utf-8'))
    for e in j.get('events',[]):
        for pg in e.get('pages',[]):
            for c in pg.get('list',[]):
                for s in c.get('stringArgs',[]): scan(s,os.path.basename(f),c['code'])
for k,v in json.load(open('work/maps_full.json',encoding='utf-8')).items():
    for e in v.get('events',[]):
        for c in e.get('cmds',[]):
            for s in c.get('strs',[]): scan(s,k,c['code'])
for name in ['SysDatabase','DataBase','CDataBase']:
    d=json.load(open('work/wolftl/dump/db/%s.json'%name,encoding='utf-8'))
    for i,t in enumerate(d['types']):
        for r,row in enumerate(t['data']):
            for fld in row['data']:
                v=fld['value']
                if isinstance(v,str): scan(v,'%s t%d'%(name,i),0)
OUT.write('scene/ refs: %d   word/ refs: %d\n'%(hits['scene'],hits['word']))
for k in samp:
    OUT.write('%s samples:\n'%k)
    for s in samp[k][:8]: OUT.write('   %s\n'%(s,))
OUT.write('\n== DataBase enemy graphic fields (type 9) ==\n')
d=json.load(open('work/wolftl/dump/db/DataBase.json',encoding='utf-8'))
t=d['types'][9]
OUT.write('name %s rows %d\n'%(t['name'],len(t['data'])))
for r,row in enumerate(t['data'][:3]):
    OUT.write(' row%d %s\n'%(r,json.dumps(row,ensure_ascii=False)[:400]))
open('work/_audit_out5.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
