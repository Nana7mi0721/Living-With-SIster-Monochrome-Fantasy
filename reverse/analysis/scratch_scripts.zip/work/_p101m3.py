
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
for f in ('UDatabase','SysDatabase','CDataBase'):
    try: d=json.load(io.open('work/wolftl/dump/db/%s.json'%f,encoding='utf-8'))
    except Exception as ex: print(f,'ERR',ex); continue
    T=d.get('types') or []
    print(f,'types',len(T),[ (i,t.get('name')) for i,t in enumerate(T)][:30])
