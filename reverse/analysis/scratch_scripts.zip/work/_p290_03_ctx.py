
import io,sys,json,os
from collections import Counter,defaultdict
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
ROOT=r'E:\Study\github program\imoto life'
CE=json.load(open(os.path.join(ROOT,'work','_ce_full.json'),encoding='utf-8'))
TARGET={3,7,8,9,10}

def fmt(c):
    if c['c']==103: return '103('+(c['s'][0][:34].replace('\r','').replace('\n','|') if c['s'] else '')+')'
    return '%d%s'%(c['c'],c['a'] if c['a'] else '')
def csname(e,val):
    if 1600000<=val<1610000:
        n=val-1600000
        cs=e.get('cself') or []
        return 'self%d(%s)'%(n, cs[n] if n<len(cs) else '?')
    return str(val)

sites=defaultdict(list)
for e in CE:
    for ci,c in enumerate(e['cmds']):
        if c['c']==290 and c['a']:
            t=c['a'][0]>>4
            if t in TARGET: sites[t].append((e,ci,c['a']))

for t in sorted(sites):
    L=sites[t]
    print('='*100)
    print('TYPE %d  n=%d'%(t,len(L)))
    print(' dur:',dict(sorted(Counter(a[1] for e,ci,a in L).items())))
    print(' (v1,v2,v3) top:',Counter((a[4],a[5],a[6]) for e,ci,a in L).most_common(12))
    print(' picA literal set:',sorted(set(a[2] for e,ci,a in L))[:24])
    print(' events:',Counter('ev%d'%e['id'] for e,ci,a in L).most_common(8))
    # self-var names referenced in v1..v3 and pic
    nm=Counter()
    for e,ci,a in L:
        for k in (2,3,4,5,6):
            v=a[k]
            if 1600000<=v<1610000:
                cs=e.get('cself') or []; n=v-1600000
                nm[cs[n] if n<len(cs) else ('self%d'%n)]+=1
    print(' self-var names in args:',nm.most_common(10))
    print(' --- representative sites (grouped by (v1,v2,v3), up to 6 groups) ---')
    seen=set(); shown=0
    for e,ci,a in L:
        key=(a[2],a[3],a[4],a[5],a[6])
        if key in seen: continue
        seen.add(key); shown+=1
        if shown>6: break
        cmds=e['cmds']
        print('  ev%d "%s" pc%d args=%s'%(e['id'],e['title'],ci,a))
        print('     = %s'%(' '.join('%s=%s'%(['dur','picA','picB','v1','v2','v3'][i],csname(e,a[i+1])) for i in range(6))))
        for k in range(max(0,ci-2),min(len(cmds),ci+4)):
            mark='>>' if k==ci else '  '
            print('     %s pc%-5d %s'%(mark,k,fmt(cmds[k])))
