import io, os
path = "crates/wolf-game/src/savegame.rs"
t = io.open(path, encoding="utf-8", newline="").read()
anchor = """    #[test]
    fn a_saved_picture_keeps_its_window_box_scale_and_anchor() {"""
new = """    #[test]
    fn every_retail_text_picture_re_encodes_to_the_same_bytes() {
        let mut path = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        path.pop();
        path.pop();
        path.push("work");
        path.push("retail_backup");
        path.push("Save");
        path.push("SaveData01.sav");
        let Ok(save) = read_save(&path) else { return };
        let mut checked = 0;
        for record in &save.part5.events {
            if record.var5 != 1 {
                continue;
            }
            let text = decode_picture_text(&record.md1);
            assert_eq!(encode_picture_text(&text), record.md1, "picture {}", record.var1);
            checked += 1;
        }
        assert!(checked > 20, "checked {checked} text records");
    }

    #[test]
    fn a_saved_picture_keeps_its_window_box_scale_and_anchor() {"""
assert t.count(anchor) == 1
t = t.replace(anchor, new)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")