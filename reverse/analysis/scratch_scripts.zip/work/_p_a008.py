import io, os
path = "crates/wolf-cli/src/play.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """        let newest = self
            .game
            .messages
            .last()
            .map(|m| (m.text.clone(), m.frames));
        if let Some((text, frames)) = newest {
            let vars = self.game.message_vars();
            let layout = wolf_game::message::layout(&text, &vars, frames);
            if let Some(at) = layout.cursor {"""
b = """        let newest = self.game.messages.last().map(|m| m.frames);
        if let Some(frames) = newest {
            let Some(layout) = self.game.message_layout() else {
                unreachable!("the newest message has a layout");
            };
            if let Some(at) = layout.cursor {"""
assert t.count(a) == 1
t = t.replace(a, b)
a2 = """        if let Some(message) = self.game.messages.last() {
            let vars = self.game.message_vars();
            let layout = wolf_game::message::layout(&message.text, &vars, message.frames);
            for row in &layout.rows {
                items.push(TextItem::new(row.text.clone(), row.rect, layout.font_px));
            }
        }"""
b2 = """        if let Some(layout) = self.game.message_layout() {
            for run in &layout.runs {
                let mut item = TextItem::new(run.text.clone(), run.rect, run.font_px)
                    .with_colour(run.colour.unwrap_or(wolf_game::message::DEFAULT_COLOUR));
                if run.outline {
                    item = item.with_outline(2, [0, 0, 0]);
                }
                items.push(item);
            }
        }"""
assert t.count(a2) == 1
t = t.replace(a2, b2)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")