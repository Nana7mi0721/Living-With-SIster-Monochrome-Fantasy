import io, os
path = "crates/wolf-cli/src/main.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """        println!("    text    : {preview:?}");
        for run in &layout.runs {"""
b = """        println!("    text    : {preview:?}");
        if std::env::var_os("WOLF_DEBUG_MSG").is_some() {
            for row in &layout.rows {
                eprintln!("row {:?} rect {:?}", row.text, row.rect);
            }
            for run in &layout.runs {
                eprintln!("run {:?} rect {:?} font {} outline {}", run.text, run.rect, run.font_px, run.outline);
            }
        }
        for run in &layout.runs {"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")