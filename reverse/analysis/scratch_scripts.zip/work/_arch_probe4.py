
import os, collections
os.chdir(r'E:\Study\github program\imoto life')
gd=r'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
sv=os.path.join(gd,'Save')
print('Save dir:', os.listdir(sv)[:20] if os.path.isdir(sv) else 'none')
if os.path.isdir(sv):
    for f in sorted(os.listdir(sv))[:6]:
        p=os.path.join(sv,f); print('  ',f, os.path.getsize(p))
# loop markers in BGM names
import re
bgm='work/alldata/BGM'
names=os.listdir(bgm)
print('BGM count', len(names))
print('with Loop marker:', sum(1 for n in names if 'loop' in n.lower()))
print([n for n in names if 'loop' in n.lower()][:6])
exts=collections.Counter(os.path.splitext(n)[1].lower() for n in names)
print('BGM exts', exts)
se='work/alldata/SE'
sen=os.listdir(se)
print('SE count', len(sen), collections.Counter(os.path.splitext(n)[1].lower() for n in sen))
# total audio files across all dirs
tot=collections.Counter()
for dp,dn,fn in os.walk('work/alldata'):
    for f in fn:
        e=os.path.splitext(f)[1].lower()
        if e in ('.mp3','.ogg','.wav'): tot[e]+=1
print('total audio', tot)
