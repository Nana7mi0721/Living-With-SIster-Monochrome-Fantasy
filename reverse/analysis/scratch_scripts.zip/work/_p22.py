
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))

def kind(v):
    if 1000000 <= v < 2000000: return 'self'
    if 2000000 <= v < 3000000: return 'var'
    if 3000000 <= v < 4000000: return 'str'
    if 9000000 <= v < 10000000: return 'sys'
    if 0 <= v < 1000000: return 'lit'
    return 'other'

sites = []   # (eid, title, pc, code, a, s)
for e in ce:
    for pc, c in enumerate(e['cmds']):
        if c['c'] in (210, 300, 211) and len(c['a']) >= 2:
            sites.append((e['id'], e['title'], pc, c['c'], c['a'], c['s']))

rv = [s for s in sites if (s[4][1] >> 24) & 1]
sc_pos = [s for s in rv if ((s[4][1] >> 4) & 0xF) > 0]
print('sites', len(sites), 'rv', len(rv), 'rv&sc>0', len(sc_pos))
print('by code all:', collections.Counter(s[3] for s in sites))
print('by code rv :', collections.Counter(s[3] for s in rv))
print()
print('=== the 22 sites with string params + return value ===')
for eid, title, pc, code, a, s in sc_pos:
    num = a[1] & 0xF; sc = (a[1] >> 4) & 0xF
    total = num + sc
    good = 2 + total < len(a)
    dest_total = a[2+total] if good else None
    dest_naive = a[2+num] if 2+num < len(a) else None
    print(f'ev{eid:>3} pc{pc:>4} {code} num={num} sc={sc} len(a)={len(a)} | dest(2+total)={dest_total}[{kind(dest_total) if dest_total is not None else "-"}] naive(2+num)={dest_naive}[{kind(dest_naive) if dest_naive is not None else "-"}] | a={a} s={s[:1]}')

print()
dest_kinds = collections.Counter(kind(a[2 + ((a[1]>>0)&0xF) + ((a[1]>>4)&0xF)]) for _,_,_,_,a,_ in rv if 2+((a[1])&0xF)+((a[1]>>4)&0xF) < len(a))
print('dest kind histogram (rv sites):', dest_kinds)
groups = collections.Counter()
for _,_,_,_,a,_ in rv:
    i = 2 + (a[1]&0xF) + ((a[1]>>4)&0xF)
    if i < len(a):
        d = a[i]
        if 1000000 <= d < 2000000:
            groups[(d - 1000000)//100] += 1
print('self group histogram:', dict(sorted(groups.items())))
print()
# ---- return_value_id side ----
retid = {int(k): v['retid'] for k, v in meta.items()}
decl = {e: r for e, r in retid.items() if r != 0xFFFFFFFF}
print('events with declared retid:', len(decl), 'hist:', collections.Counter(decl.values()))
byid = {e['id']: e for e in ce}
def writes_slot(e, slot):
    hits = []
    for pc, c in enumerate(e['cmds']):
        code, a = c['c'], c['a']
        if code in (121, 122, 124, 150, 240) and a and a[0] == slot:
            hits.append((pc, code, 'arg0'))
        if code in (210, 300, 211) and len(a) >= 2 and (a[1] >> 24) & 1:
            i = 2 + (a[1]&0xF) + ((a[1]>>4)&0xF)
            if i < len(a) and a[i] == slot:
                hits.append((pc, code, 'return_to'))
        if code == 250 and len(a) >= 5 and a[4] == slot:
            hits.append((pc, code, 'arg4'))
    return hits
missing = []
for e, r in sorted(decl.items()):
    if e not in byid: continue
    slot = 1600000 + r
    h = writes_slot(byid[e], slot)
    if not h:
        missing.append((e, r, byid[e]['title'][:30]))
print('declared but never writing 1600000+retid:', missing)
print('write rate: %d/%d' % (len(decl) - len(missing), len(decl)))

