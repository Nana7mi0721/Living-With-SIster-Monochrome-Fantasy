from PIL import Image
import os
os.makedirs('work/out', exist_ok=True)
def crop(src, out, scale=8):
    im = Image.open(src).convert('RGBA')
    im = im.resize((im.width*scale, im.height*scale), Image.NEAREST)
    im.save(out)
    print(out, im.size)
crop('work/full/MapChip/[A]Grass1_pipo.png', 'work/out/at_grass1.png', 10)
crop('work/full/MapChip/[A]WaterFall1_pipo.png', 'work/out/at_waterfall1.png', 6)
im = Image.open('work/full/MapChip/kiri_project.png').convert('RGBA')
im.resize((im.width*4, im.height*4), Image.NEAREST).save('work/out/kiri_sheet.png')
print('kiri_sheet', (im.width*4, im.height*4))
