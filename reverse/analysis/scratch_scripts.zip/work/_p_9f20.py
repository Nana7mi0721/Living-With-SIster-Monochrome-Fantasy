import json
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
ev=[e for e in ce if e['id']==63][0]
for i,c in enumerate(ev['cmds'][85:112], start=85):
    print(i, c['c'], c['a'], c['s'])
