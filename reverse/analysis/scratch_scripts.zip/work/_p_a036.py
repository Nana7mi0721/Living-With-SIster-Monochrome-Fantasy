import os

def edit(path, a, b):
    raw = open(path, "rb").read()
    crlf = raw.find(bytes([13, 10])) >= 0
    t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
    if b in t:
        print("skip", path)
        return
    assert t.count(a) == 1, (path, t.count(a), a[:80])
    t = t.replace(a, b)
    if crlf:
        t = t.replace(chr(10), chr(13) + chr(10))
    open(path, "wb").write(t.encode("utf-8"))

edit("crates/wolf-game/src/game.rs",
"""    /// Start one event of a named map""",
"""    /// Switches to the map at `path` and starts its automatic pages.\n    ///\n    /// `130 Teleport` runs on the same VM, so the current map coroutines are stopped\n    /// first: leaving them alive would keep a previous map parallel events\n    /// drawing into the new map. Engine events are session-wide and keep running.\n    fn switch_map(&mut self, path: &str) -> Result<(), GameError> {\n        self.runtime.stop_all(&mut self.vm);\n        let bytes = self.read(path)?;\n        let map = Map::parse(&bytes).map_err(GameError::Format)?;\n        self.start_pages(&map, None);\n        Ok(())\n    }\n\n    /// Start one event of a named map""")

edit("crates/wolf-game/src/game.rs",
"""    save_requests: &\u0027a mut Vec<crate::savegame::SaveRequest>,\n}\n""",
"""    save_requests: &\u0027a mut Vec<crate::savegame::SaveRequest>,\n    map_requests: &\u0027a mut Vec<MapRequest>,\n}\n""")

edit("crates/wolf-game/src/game.rs",
"""            save_requests: &mut self.save_requests,\n        });\n""",
"""            save_requests: &mut self.save_requests,\n            map_requests: &mut self.map_requests,\n        });\n""")

edit("crates/wolf-game/src/game.rs",
"""        // One more frame of play time; the save stores this in SavePart2.vars3_21[0].\n""",
"""        // A `130` teleport queues a map switch for the same reason a `220` load does:\n        // the host cannot borrow Game while the VM is inside `step_frame`.\n        let map_requests = std::mem::take(&mut self.map_requests);\n        for request in map_requests {\n            let map_id = match request.map {\n                -1 => 1,\n                -2 => 0,\n                id => id,\n            };\n            let path = self\n                .databases\n                .map_path(map_id)\n                .map(str::to_owned);\n            let Some(path) = path else {\n                self.diagnostics.insert(\n                    format!(\"130 Teleport: no map registered for id {}\", request.map),\n                    1,\n                );\n                continue;\n            };\n            match self.switch_map(&path) {\n                Ok(()) => {\n                    self.diagnostics.insert(\n                        format!(\n                            \"130 Teleport: {} at ({}, {}) direction {}\",\n                            path, request.x, request.y, request.direction\n                        ),\n                        1,\n                    );\n                }\n                Err(err) => {\n                    self.diagnostics\n                        .insert(format!(\"130 Teleport: {err}\"), 1);\n                }\n            }\n        }\n        // One more frame of play time; the save stores this in SavePart2.vars3_21[0].\n""")

edit("crates/wolf-game/src/game.rs",
"""    fn teleport(&mut self, map: i32, x: i32, y: i32, direction: i32) {\n        self.note(format!(\n            \"130 Teleport: map {map} at ({x},{y}) direction {direction} - map layer arrives in M2\"\n        ));\n    }\n""",
"""    fn teleport(&mut self, map: i32, x: i32, y: i32, direction: i32) {\n        self.map_requests.push(MapRequest {\n            map,\n            x,\n            y,\n            direction,\n        });\n    }\n""")
print("done")