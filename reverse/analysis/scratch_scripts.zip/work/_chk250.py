import io,sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
p = 'docs/OPCODE_250.md'
lines = open(p, encoding='utf-8').read().split(chr(10))
fixes = []
for i,l in enumerate(lines):
    if i == 0: continue
    need = l.startswith('#') or l.strip() == '---'
    if need and lines[i-1].strip() != '':
        fixes.append((i+1, lines[i-1][:40], l[:40]))
print('needs blank before:', len(fixes))
for f in fixes: print(f)