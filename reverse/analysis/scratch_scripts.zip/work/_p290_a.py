import json,sys,collections
sys.stdout.reconfigure(encoding='utf-8')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
print("events",len(ev))
cnt=0
rows=[]
for e in ev:
    for i,c in enumerate(e['cmds']):
        if c['c']==290:
            cnt+=1
            rows.append((e['id'],e['title'],i,c['a'],c['s'],c['bd']))
print("total 290 =",cnt)
for r in rows:
    print(f"ev{r[0]:<4} pc{r[2]:<6} bd{r[5]} a={r[3]} s={r[4]}  {r[1][:40]}")
