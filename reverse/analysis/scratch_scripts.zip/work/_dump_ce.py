# -*- coding: utf-8 -*-
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(open('E:/Study/github program/imoto life/work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in d}
def dump(i, lo=0, hi=10**9):
    e=by.get(i)
    print("=== CE",i,"run",e['run'],"op",e['op'],"condvar",e['condvar'],"condval",e['condval'],"args",e['args'],"argn",e['argn'],"ncmds",len(e['cmds']),"===")
    print("argnames", e.get('argnames'), "cself", e.get('cself'))
    for pc,cmd in enumerate(e['cmds']):
        if pc<lo or pc>hi: continue
        c=cmd['c'];a=cmd['a'];s=cmd.get('s') or []
        line="pc%4d c%d a=%s"%(pc,c,a)
        if s: line+=" s="+repr(s)
        print(line)
dump(157)
