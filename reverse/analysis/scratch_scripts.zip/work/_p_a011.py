import io, os
path = "crates/wolf-cli/src/play.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """            for run in &layout.runs {
                let mut item = TextItem::new(run.text.clone(), run.rect, run.font_px)
                    .with_colour(run.colour.unwrap_or(wolf_game::message::DEFAULT_COLOUR));"""
b = """            for run in &layout.runs {
                // One em of slack keeps cosmic-text from wrapping the last glyph: the
                // layout measures with the half-em rule, the shaper uses the real advance.
                let mut rect = run.rect;
                rect[2] += run.font_px;
                let mut item = TextItem::new(run.text.clone(), rect, run.font_px)
                    .with_colour(run.colour.unwrap_or(wolf_game::message::DEFAULT_COLOUR));"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")