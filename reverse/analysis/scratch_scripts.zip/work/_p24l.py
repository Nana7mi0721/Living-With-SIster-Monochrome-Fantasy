import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
CE = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by = {e['id']: e for e in CE}
for eid in (48, 94, 131, 436):
    pcs = [k for k, c in enumerate(by[eid]['cmds']) if c['c'] == 221]
    print('ev%d 221 pcs: %s (n=%d)' % (eid, pcs, len(pcs)))
e94 = by[94]
print('ev94 221 detail:')
for k in [k for k, c in enumerate(e94['cmds']) if c['c'] == 221]:
    print('  pc%-4d %s' % (k, e94['cmds'][k]['a']))
