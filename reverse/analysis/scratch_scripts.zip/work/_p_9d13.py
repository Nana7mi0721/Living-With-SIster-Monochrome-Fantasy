import io, os
def rep(path, a, b):
    t = io.open(path, encoding='utf-8', newline='').read()
    assert t.count(a) == 1, (path, a[:60], t.count(a))
    t = t.replace(a, b)
    tmp = path + '.new'
    w = io.open(tmp, 'w', encoding='utf-8', newline='')
    w.write(t); w.close()
    os.replace(tmp, path)

E = 'crates/wolf-vm/src/exec.rs'
anchor = '    #[test]\n    fn operator_0x6000_is_a_random_range() {'
test = '\n'.join([
  '    #[test]',
  '    fn cself_reads_the_self_bank_of_the_running_event() {',
  '        // ev63 returns to its caller with a 213 whose label ends in cself[40]',
  '        // after storing 2 in slot 40. Slot 40 of a common event is magic',
  '        // 1_600_040, so the escape must read bank 640; reading bank 40 expanded',
  '        // to a label nobody defines and killed the message-window coroutine.',
  '        let commands = vec![',
  '            cmd(121, &[1_600_040, 2, 0, 0], &[]),',
  '            cmd(213, &[], &[r"m\cself[40]"]),',
  '            // Wrong path: bank 40 reads 0, so the name would be m0.',
  '            cmd(121, &[2_000_000, 99, 0, 0], &[]),',
  '            cmd(212, &[], &["m1"]),',
  '            cmd(121, &[2_000_001, 1, 0, 0], &[]),',
  '            cmd(212, &[], &["m2"]),',
  '            cmd(121, &[2_000_002, 3, 0, 0], &[]),',
  '        ];',
  '        let mut vm = vm_with(vec![event(1, "jump", commands)]);',
  '        vm.start_event(1);',
  '        let mut host = Recorder::default();',
  '        vm.step_frame(&mut host);',
  '        assert_eq!(vm.vars.get(0), 0, "the wrong label must not be reached");',
  '        assert_eq!(vm.vars.get(1), 1, "skipped past the first label");',
  '        assert_eq!(vm.vars.get(2), 3, "landed after the second label");',
  '    }',
  '',
])
rep(E, anchor, test + anchor)
print('patched')