
import json,io,glob,os,collections
OUT=io.StringIO()
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
lst=ce['list'] if isinstance(ce,dict) else ce
by_id={e['id']:e for e in lst}
by_title={}
for e in lst: by_title.setdefault(e['title'],e['id'])
def norm(cmds):
    out=[]
    for c in cmds:
        if 'c' in c: out.append((int(c['c']),[int(x) for x in c.get('a') or []],list(c.get('s') or [])))
        else: out.append((int(c.get('code',0)),[int(x) for x in (c.get('ints') or [])],list(c.get('strs') or [])))
    return out
def d210(raw):
    if 500000<=raw<=599999: return raw-500000
    if 600000<=raw<=699999: return raw-600000
    return None
edges=collections.defaultdict(set)
for e in lst:
    for op,a,s in norm(e['cmds']):
        if op==210 and a:
            t=d210(a[0])
            if t is not None and t in by_id: edges[('c',e['id'])].add(('c',t))
        elif op==300 and s:
            t=by_title.get(s[0])
            if t is not None: edges[('c',e['id'])].add(('c',t))
mf=json.load(open('work/maps_full.json',encoding='utf-8'))
for k,v in mf.items():
    for e in v['events']:
        for op,a,s in norm(e['cmds']):
            if op==210 and a:
                t=d210(a[0])
                if t is not None and t in by_id: edges[('m',k,e['id'])].add(('c',t))
            elif op==300 and s:
                t=by_title.get(s[0])
                if t is not None: edges[('m',k,e['id'])].add(('c',t))

sd=json.load(open('work/wolftl/dump/db/SysDatabase.json',encoding='utf-8'))
reg={}
for i,row in enumerate(sd['types'][0]['data']):
    f=[x for x in row['data'] if x['name']=='マップファイル名']
    if f and f[0]['value']: reg[i]=f[0]['value'].split('/')[-1]

def closure(seeds):
    seen=set(); stack=list(seeds)
    while stack:
        cur=stack.pop()
        if cur in seen: continue
        seen.add(cur)
        for n in edges[cur]:
            if n not in seen: stack.append(n)
    return seen

boot=closure([('m','TitleMap.mps',2)])
OUT.write('boot closure (TitleMap ev2): %d nodes (%d common, %d map)\n'%(
    len(boot),len([k for k in boot if k[0]=='c']),len([k for k in boot if k[0]=='m'])))

# all registered maps, all events, all pages
seeds=[]
for idx,f in reg.items():
    if f in mf:
        for e in mf[f]['events']: seeds.append(('m',f,e['id']))
    else:
        OUT.write('  registered map %s (%s) NOT in maps_full.json -> unparsed\n'%(idx,f))
OUT.write('seeds from 6 registered maps: %d map events\n'%len(seeds))
game=closure(seeds)
gcreach=sorted(k[1] for k in game if k[0]=='c')
OUT.write('whole-game closure: %d nodes (%d common, %d map)\n'%(len(game),len(gcreach),len([k for k in game if k[0]=='m'])))
OUT.write('common events NOT reachable from any registered map: %d\n'%(550-len(gcreach)))
dead=sorted(set(e['id'] for e in lst)-set(gcreach))
OUT.write('dead common events: %d\n%s\n'%(len(dead),dead[:60]))
json.dump({'boot':sorted(str(k) for k in boot),'game':sorted(str(k) for k in game),
           'gcreach':gcreach,'dead':dead,'reg':reg},
          open('work/_audit_closure.json','w',encoding='utf-8'),ensure_ascii=False)
open('work/_audit_out7.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
