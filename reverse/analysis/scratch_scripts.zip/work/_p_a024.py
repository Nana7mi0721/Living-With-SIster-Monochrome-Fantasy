import io, os
path = "docs/SAVE_SPEC.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """task-30 之后，剩下的唯一缺口是**引擎侧还没接线**：`Game::save_to` 目前仍原样搬运模板的 vardb 字节，
所以 opcode 250 对 CDataBase 的写入要等 `Databases::write_into(&mut save.vardb)` 被调用后才会落盘。
存档库这一侧的接口已经备好，见 §14.5。"""
b = """task-30 + 引擎侧接线之后，这条链已完整：`Game::save_to` 在 `set_part5` 之后调用
`Databases::write_into(&mut save.vardb)`，把运行时的 CData 单元格写进变量库再 `to_bytes_rebuilt()`；
`missed > 0` 时会写一条 `220 SaveLoad` 诊断而不是静默丢弃。测试 `a_saved_game_keeps_the_database_cells`
（CData (0,12,5)=4242 → 保存 → 载入后仍为 4242）覆盖了这条接线。存档库这一侧的接口见 §14.5。"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")