
import sys, io, json, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
if isinstance(ce, dict): ce = list(ce.values())
maps = json.load(open('work/maps_full.json', encoding='utf-8'))
PIC = {}
def add(tag, code, a, s):
    if code != 150: return
    if len(a) < 2: return
    PIC.setdefault(a[1], []).append((tag, a, s))
for ev in ce:
    for i, c in enumerate(ev.get('cmds') or []):
        add('CE%s' % ev.get('id'), c.get('c'), c.get('a') or [], c.get('s') or [])
for mk, mv in maps.items():
    for ev in mv.get('events') or []:
        for i, c in enumerate(ev.get('cmds') or []):
            add('%s:ev%s' % (mk, ev.get('id')), c.get('code'), c.get('ints') or [], c.get('strs') or [])

def show(nums):
    for n in nums:
        v = PIC.get(n) or []
        files = collections.Counter((x[2][0] if x[2] else '') for x in v)
        print('  pic %-6d 150draws=%-3d files=%s' % (n, len(v), dict(list(files.items())[:4])))

print('### type 4 zoom pairs: are BOTH pictures of each pair drawn by 150?')
show([1200,1201,1202,1203,1204,1205,1206,1207,1208,1209,1210,1211,1212,1213])
print()
print('### type 5 range (390,500): which pictures are drawn in 390..500?')
used = sorted(k for k in PIC if 390 <= k <= 500)
print('  distinct 150-drawn pic numbers in [390,500]:', used)
show([390, 500])
print()
print('### CE85 range (self21,self26): NOT literal - skip')
print('### type 2 ranges (800,801),(3610,3611),(1600040,1600041):')
show([800,801,802,3610,3611,3612])
print()
print('### how many pictures does the game use at all? 150 distinct:', len(PIC))
