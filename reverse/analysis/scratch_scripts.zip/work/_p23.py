
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))
byid = {e['id']: e for e in ce}
retid = {int(k): v['retid'] for k, v in meta.items()}
names = collections.defaultdict(list)
for e in ce: names[e['title']].append(e['id'])
for t in ['▲文字列数値判定', '▲先頭空白削除', '○◆マップをズーム', '▲アイテム所持数取得']:
    print(t, names.get(t), [(i, hex(retid[i]) if retid.get(i) is not None else None) for i in names.get(t, [])])

bad = []
for e in ce:
    for pc, c in enumerate(e['cmds']):
        a = c['a']
        if c['c'] in (210, 300, 211) and len(a) >= 2 and (a[1] >> 24) & 1:
            i = 2 + (a[1] & 0xF) + ((a[1] >> 4) & 0xF)
            dest = a[i] if i < len(a) else None
            tgt = a[0]
            if c['c'] in (210, 211) and tgt >= 500000:
                callee = tgt - (500000 if tgt < 600000 else 600000)
            elif c['c'] == 300 and c['s']:
                nm = c['s'][0]
                callee = names[nm][0] if names.get(nm) else None
            else:
                callee = None
            if callee is None:
                bad.append((e['id'], pc, c['c'], None, 'unresolved', dest)); continue
            r = retid.get(callee)
            if r is None or r == 0xFFFFFFFF:
                bad.append((e['id'], pc, c['c'], callee, hex(r) if r is not None else None, dest))
print()
print('rv sites pointing at events with no declared return value:', len(bad))
for b in bad: print('  caller ev%d pc%d %d -> callee %s retid=%s dest=%s' % b)

