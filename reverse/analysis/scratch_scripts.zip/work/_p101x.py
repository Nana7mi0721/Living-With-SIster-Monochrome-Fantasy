
import json,io,collections,sys,re
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
def cmds_all():
    for e in ce:
        for c in e['cmds']: yield e['id'],norm(c)
    for m in mp.values():
        for ev in m.get('events',[]):
            for c in ev.get('cmds',[]): yield ('M',norm(c))
esc=collections.Counter(); nstr=0; maxcp=0; sur=0
allmsgs=[]
for eid,(op,a,s) in cmds_all():
    for s1 in s:
        nstr+=1; allmsgs.append((eid,op,s1))
        for ch in s1:
            o=ord(ch)
            if o>maxcp: maxcp=o
            if o>0xFFFF: sur+=1
        i=0
        while i<len(s1):
            if s1[i]=='\\':
                k=i+1
                while k<len(s1) and s1[k].isalpha(): k+=1
                esc[s1[i+1:k]]+=1
                i=k
            else: i+=1
print('strings total',nstr,'max codepoint',hex(maxcp),'non-BMP chars',sur)
print('escape histogram:')
for k,v in esc.most_common(50): print('   %-8r %d'%(k,v))
ch=collections.Counter()
for eid,op,s1 in allmsgs:
    for m in re.finditer(r'\\c\[(-?\d+)\]',s1): ch[int(m.group(1))]+=1
print('c[n] histogram:',dict(sorted(ch.items())))
for name,base in (('Sys73',9000073),('Sys74',9000074),('Sys75',9000075),('Sys76',9000076),('Sys39',9000039),('Sys22',9000022),('Sys21',9000021)):
    hits=[(eid,op,a[:4]) for eid,(op,a,s) in cmds_all() if op in (121,124,122) and a and a[0]==base]
    print(name,'writers',len(hits),hits[:4])
print('101 count',sum(1 for eid,c in cmds_all() if c[0]==101),'102 count',sum(1 for eid,c in cmds_all() if c[0]==102))
h=collections.Counter(tuple(c[1][:1]) for eid,c in cmds_all() if c[0]==101)
print('101 a[0] histogram',dict(h.most_common(12)))
for eid,(op,a,s) in list((x for x in cmds_all() if x[1][0]==102))[:3]: print('102 sample',a,s)
