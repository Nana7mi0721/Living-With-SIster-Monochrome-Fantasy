
import json,os,collections,re
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=sorted(json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"])
for i in H:
    for k,c in enumerate(idx[i]["cmds"]):
        for x in (c.get("s") or []):
            if isinstance(x,str) and x.startswith("Picture/word_effect"):
                print("ev%d pc%d op%d %r a=%s"%(i,k,c["c"],x,c.get("a")))
