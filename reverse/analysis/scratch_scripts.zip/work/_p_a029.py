import io, os
path = "docs/M2_SLICE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """| git HEAD | `51bd7a3` + **第二批 M2 提交**（250 写路径 / 移动插值 / 离屏裁剪 / 引擎事件 12 个 / `.project` 名字）+ **第三批**（`112` 开块 / `290` 十一种效果 / `blocks` 诊断命令 / `--answer-delay`）+ **第四批**（`69d7b9c`：暂停光标贴图 / 鼠标选项命中 / `210` 字符串实参 / **`121` 运算符表纠错** / 消息原点 410）+ **第五批**（`8825723` 存档 220/221/222 与精灵表 pattern；`ea96c1f` 290 效果实参求值） |"""
b = """| git HEAD | `5e26bec` + **本批**（styled 101 message `layout_styled` / SavePart5 图片表写回 / vardb `write_into` 接线 / 220 mode 0 整档保存） |"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")