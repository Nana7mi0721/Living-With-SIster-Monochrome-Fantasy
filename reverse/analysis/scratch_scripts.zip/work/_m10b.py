import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
MAGIC=[2000014,2000218,1600020,1600023,1600024,1600033,1600034,1600035,1600036,1600010,1600099]
def asc1(s): return (s.encode('ascii','ignore').decode() if isinstance(s,str) else s)
# Writers: op121 target a[0]; op124 a[0]; op250 dst last arg; op300 range
def scan(tag):
    print('==== WRITE sites for',tag,'====')
    for e in ces:
        for i,cm in enumerate(e['cmds']):
            c=cm['c']; a=cm.get('a',[])
            hit=False
            if c in (121,124) and a and a[0]==tag: hit=True
            if c==250 and a and a[-1]==tag: hit=True
            if hit:
                print(f"CE{e['id']:<4} pc{i:<4} op{c} {a}  {[asc1(x) for x in cm.get('s',[]) if x]}")
for t in [1600020,1600023,1600024,1600033,1600034,1600035,1600036,1600099,2000014,2000218]:
    scan(t); print()

print('==== op210 calls to 172/144/147/372 ====')
for e in ces:
    for i,cm in enumerate(e['cmds']):
        if cm['c']==210 and cm.get('a') and 500000+0 < cm['a'][0] < 500500:
            tgt=cm['a'][0]-500000
            if tgt in (172,144,147,372,173,168,169,170,171,174,175,176,177,178,179,180):
                print(f"CE{e['id']} pc{i} -> CE{tgt} a={cm['a']}")

