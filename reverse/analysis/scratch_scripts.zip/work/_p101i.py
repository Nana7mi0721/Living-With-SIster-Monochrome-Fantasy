import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
ev = [e for e in ce if e['id']==63][0]
print('title:', ev['title'], 'run', ev['run'], 'ncmds', len(ev['cmds']))
def dec(v):
    if v >= 9000000: return 'Sys%d'%(v-9000000)
    if 1600000 <= v < 1700000: return 'self[%d]'%(v-1600000)
    if 2000000 <= v < 3000000: return 'V%d'%(v-2000000)
    if 1000000 <= v < 2000000: return 'eself[%d]'%(v-1000000)
    return str(v)
for i,c in enumerate(ev['cmds']):
    op=c['c']; a=c['a']; s=c['s']
    if op==103:
        print('%4d 103  // %s'%(i, s[0] if s else ''))
        continue
    if op in (121,124):
        print('%4d %3d   %s %s op=%#x  (a=%s)'%(i,op,dec(a[0]),dec(a[1]),a[3],a))
        continue
    if op==150:
        print('%4d 150   a=%s'%(i,a))
        continue
    print('%4d %3d   a=%s s=%s'%(i,op,a,[x[:40] for x in s]))