path = "crates/wolf-game/tests/opening.rs"
raw = open(path, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
a = """    game.set_choice_cursor(0);\n    game.auto_choice = true;\n    game.auto_choice_delay = 1;\n    for _ in 0..900 {\n        game.frame();\n    }\n"""
b = """    game.set_choice_cursor(0);\n    game.auto_choice = true;\n    game.auto_choice_delay = 1;\n    // Answer ONLY the title menu: leave auto_choice on until the menu closes, then\n    // turn it off so the opening prompt downstream is held like the retail player\n    // sees it (and like the other two tests).\n    for _ in 0..120 {\n        game.frame();\n        if game.choices.is_none() {\n            break;\n        }\n    }\n    game.auto_choice = false;\n    for _ in 0..900 {\n        game.frame();\n    }\n"""
assert t.count(a) == 1
t = t.replace(a, b)
if crlf:
    t = t.replace(chr(10), chr(13) + chr(10))
open(path, "wb").write(t.encode("utf-8"))
print("done")