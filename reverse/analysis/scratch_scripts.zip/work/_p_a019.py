import io, os
path = "docs/OPCODE_220_SAVE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """- **变量库已经可以写了（task-30）**：`SaveFile::set_vardb(&VariableDatabase)` 会调用 `VariableDatabase::to_bytes()` 重编码第六段，
  按格写有 `set_vardb_num` / `set_vardb_string` / `set_vardb_text`（越界或字段类型不符时返回 `Ok(false)` 且不动任何字节）。
  `SaveFile::rebuild()` 现在编码 vardb 而不是复制模板字节，所以只要先把运行中的 CDataBase 写进 `save.vardb`，
  220 mode 0 写出的存档就带上了 opcode 250 的改动。剩下的是引擎侧接线：
  **Lead 要把 `Databases::write_into(&mut save.vardb)` 接到 `Game::save_to` 的模板克隆之后**（目前 `Game::save_to` 仍搬运模板的 vardb 字节）。
  详见 SAVE_SPEC §14.4 / §14.5。"""
b = """- **变量库已经可以写了（task-30 + 已接线）**：`SaveFile::set_vardb(&VariableDatabase)` 会调用 `VariableDatabase::to_bytes()` 重编码第六段，
  按格写有 `set_vardb_num` / `set_vardb_string` / `set_vardb_text`（越界或字段类型不符时返回 `Ok(false)` 且不动任何字节）。
  `SaveFile::rebuild()` 现在编码 vardb 而不是复制模板字节；`Game::save_to` 在 `set_part5` 之后调用
  `let (written, missed) = self.databases.write_into(&mut save.vardb);`，`missed > 0` 时写一条 `220 SaveLoad` 诊断（不静默丢格）。
  因此 opcode 250 对 CDataBase 的运行时写入会随整档保存落盘。详见 SAVE_SPEC §14.4 / §14.5。
- **画面图片表也会重建（已接线）**：`savegame::part5_from_screen(&self.screen)` 把当前活着的每张 `150` 图片
  反向编码成 `SavePart5_1`（`picture_to_record`），文本图用 `encode_picture_text` 把 `\E`/`\f[n]`/`\c[n]` 写回转义流。
  读入侧 `picture_from_record` 是它的逆过程；`a_saved_game_reloads_its_live_picture_layer` 逐字段比较 66 张图。
  唯一语义等价但非字节等价的是 retail 的 04（带字距字体）记录：读成 `\f[n]`，写回成 05。"""
assert t.count(a) == 1
t = t.replace(a, b)
a2 = """| wolf-game | `a_save_written_from_a_retail_template_round_trips` | 用 SaveData01 当模板写盘，normal var 7 / playtime / Sys3 / Sys4 都能读回 |"""
b2 = """| wolf-game | `a_save_written_from_a_retail_template_round_trips` | 用 SaveData01 当模板写盘，normal var 7 / playtime / Sys3 / Sys4 都能读回 |
| wolf-game | `a_saved_game_reloads_its_live_picture_layer` | 载入 SaveData01 → `Game::save_to` → 重新载入，66 张图的 number/kind/file/x/y/anchor/scale/split/pattern 全部相同 |
| wolf-game | `a_saved_game_keeps_the_database_cells` | CData (0,12,5)=4242 → 保存 → 重新载入仍读回 4242（`write_into` 接线） |"""
assert t.count(a2) == 1
t = t.replace(a2, b2)
a3 = """复现：`cargo test -q -p wolf-vm`（79）、`cargo test -q -p wolf-game`（162 + 3 + 1）、`cargo test -q -p wolf-save`（21）。"""
b3 = """复现：`cargo test -q -p wolf-vm`（81）、`cargo test -q -p wolf-game`（187 + 3 + 1）、`cargo test -q -p wolf-save`（21）。"""
assert t.count(a3) == 1
t = t.replace(a3, b3)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")