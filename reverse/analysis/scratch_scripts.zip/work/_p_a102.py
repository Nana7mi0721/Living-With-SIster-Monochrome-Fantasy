import json, collections
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
act=collections.Counter(); typ=collections.Counter(); n=0
for ev in ce:
    for c in ev['cmds']:
        if c['c']!=150: continue
        n+=1; h=c['a'][0] if c['a'] else 0
        act[h & 0x0F]+=1; typ[(h>>4)&0x07]+=1
print('total',n); print('action',sorted(act.items())); print('type',sorted(typ.items()))
