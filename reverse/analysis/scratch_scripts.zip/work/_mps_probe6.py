
import struct, os
base = r'work\full\MapData'
def load(f):
    b = open(os.path.join(base,f),'rb').read()
    o=16; o+=1+3; o+=4; o+=1
    n=struct.unpack_from('<I',b,o)[0]; o+=4+n
    ts,w,h,ec=struct.unpack_from('<IIII',b,o); o+=16
    fp=struct.unpack_from('<I',b,o)[0]
    vals=struct.unpack_from('<%dI'%(w*h*3),b,o)
    return w,h,vals
def grid(cells,w,h,mark):
    out=[]
    for y in range(h):
        row=''.join(mark if cells[y*w+x] else '.' for x in range(w))
        out.append(row)
    return out

for f,lay,val in [('SampleMapB.mps',0,292),('Dungeon.mps',2,104444),('Map003.mps',0,2)]:
    w,h,vals=load(f)
    nc=w*h
    L=[vals[0:nc],vals[nc:2*nc],vals[2*nc:]]
    P=[[vals[i*3+k] for i in range(nc)] for k in range(3)]
    for name,X in (('layer-major',L),('pixel-major',P)):
        cells=[v==val for v in X[lay]]
        print('==',f,name,'layer',lay,'value',val,'count',sum(cells))
        for row in grid(cells,w,h,'#'):
            print('   ',row)
