
import json, os, io, glob, re, collections

ROOT = 'work/all'
OUT = io.StringIO()

EXT = ('.png','.jpg','.jpeg','.bmp','.webp','.gif','.mp3','.ogg','.wav','.m4a','.mid','.wma','.mp4','.webm','.ttf','.otf')

def is_asset(s):
    t = s.strip()
    if not t: return False
    if t.startswith('<') and t.endswith('>'): return False
    if '\n' in t or '\r' in t: 
        t = t.split('\n')[0].split('\r')[0].strip()
        if not t: return False
    return t.lower().endswith(EXT)

# ---------- collect reference sites ----------
sites = collections.defaultdict(list)   # normalized path -> [(source, locator, opcode)]

def add(path, source, locator, opcode):
    p = path.strip().replace('\\','/')
    if p.startswith('/'): p = p[1:]
    sites[p].append((source, locator, opcode))

# 1) common events (UTF-8 dump)
for f in sorted(glob.glob('work/wolftl/dump/common/*.json')):
    j = json.load(open(f, encoding='utf-8'))
    eid = j['id']
    for c in j['commands']:
        for s in c.get('stringArgs', []):
            if is_asset(s): add(s, 'common', 'ev%d#%d' % (eid, c['index']), c['code'])

# 2) map events (UTF-8 dump, 7 maps)
for f in sorted(glob.glob('work/wolftl/dump/mps/*.json')):
    j = json.load(open(f, encoding='utf-8'))
    mname = os.path.basename(f)
    for e in j.get('events', []):
        for pg in e.get('pages', []):
            for c in pg.get('list', []):
                for s in c.get('stringArgs', []):
                    if is_asset(s): add(s, 'map', '%s ev%d#%d' % (mname, e['id'], c['index']), c['code'])

# 3) map events from maps_full.json (9 maps incl. Dungeon/Map024; strings verified UTF-8)
mf = json.load(open('work/maps_full.json', encoding='utf-8'))
for mname, mv in mf.items():
    for e in mv.get('events', []):
        for c in e.get('cmds', []):
            for s in c.get('strs', []):
                if is_asset(s): add(s, 'map', '%s ev%d' % (mname, e['id']), c['code'])

# 4) SysDatabase asset-valued fields
sd = json.load(open('work/wolftl/dump/db/SysDatabase.json', encoding='utf-8'))
SYSDB_ASSET_TYPES = [1,3,8,9,10,13,24]
for idx in SYSDB_ASSET_TYPES:
    t = sd['types'][idx]
    for r, row in enumerate(t['data']):
        for fld in row['data']:
            if isinstance(fld['value'], str) and is_asset(fld['value']):
                add(fld['value'], 'sysdb', 'type%d[%s] row%d' % (idx, t['name'], r), 0)

# 5) DataBase asset-valued fields
db = json.load(open('work/wolftl/dump/db/DataBase.json', encoding='utf-8'))
for idx, t in enumerate(db['types']):
    for r, row in enumerate(t['data']):
        for fld in row['data']:
            v = fld['value']
            if isinstance(v, str):
                for line in v.replace('\r\n','\n').split('\n'):
                    if is_asset(line): add(line, 'db', 'type%d[%s] row%d' % (idx, t['name'], r), 0)

# 6) TileSetData base + autotiles
ts = json.load(open('work/fs_ts.json', encoding='utf-8'))
for i, t in enumerate(ts):
    if is_asset(t['base']): add(t['base'], 'tileset', 'tileset%d base' % i, 0)
    for a in t['autos']:
        if is_asset(a): add(a, 'tileset', 'tileset%d auto' % i, 0)

# ---------- index the disk ----------
disk = {}
for r, d, fs in os.walk(ROOT):
    for f2 in fs:
        p = os.path.relpath(os.path.join(r, f2), ROOT).replace('\\','/')
        disk[p] = os.path.getsize(os.path.join(r, f2))
lower = {p.lower(): p for p in disk}

def resolve(p):
    if p in disk: return p
    if p.lower() in lower: return lower[p.lower()]
    return None

referenced = {}
missing = {}
for p, locs in sites.items():
    hit = resolve(p)
    if hit: referenced[hit] = locs
    else: missing[p] = locs

OUT.write('total refs distinct=%d  resolved=%d  missing=%d\n' % (len(sites), len(referenced), len(missing)))
json.dump({'referenced': {k: v for k, v in referenced.items()},
           'missing': {k: v for k, v in missing.items()}},
          open('work/_audit_refs.json','w',encoding='utf-8'), ensure_ascii=False)

# ---------- totals ----------
wolf_files = [p for p in disk if p.endswith('.wolf')]
data_files = [p for p in disk if not p.endswith('.wolf')]
OUT.write('\n== totals ==\n')
OUT.write('all files %d (data %d + archives %d)\n' % (len(disk), len(data_files), len(wolf_files)))
OUT.write('all bytes %d (data %d + archives %d)\n' % (
    sum(disk.values()), sum(disk[p] for p in data_files), sum(disk[p] for p in wolf_files)))
OUT.write('referenced files %d bytes %d\n' % (len(referenced), sum(disk[p] for p in referenced)))
unref = [p for p in data_files if p not in referenced]
OUT.write('unreferenced data files %d bytes %d\n' % (len(unref), sum(disk[p] for p in unref)))
OUT.write('missing refs %d\n' % len(missing))

# ---------- per top dir ----------
OUT.write('\n== per directory ==\n')
OUT.write('%-24s %6s %14s %6s %6s %14s %7s\n' % ('dir','files','bytes','ref','unref','refbytes','ref%'))
tops = collections.defaultdict(lambda: [0,0,0,0,0])
for p in data_files:
    top = p.split('/')[0] if '/' in p else '(root)'
    s = disk[p]
    tops[top][0] += 1; tops[top][1] += s
    if p in referenced: tops[top][2] += 1; tops[top][4] += s
    else: tops[top][3] += 1
for top in sorted(tops, key=lambda k: -tops[k][1]):
    f, b, r, u, rb = tops[top]
    OUT.write('%-24s %6d %14d %6d %6d %14d %6.1f%%\n' % (top, f, b, r, u, rb, 100.0*rb/b if b else 0))

# ---------- biggest unreferenced ----------
OUT.write('\n== 30 biggest unreferenced ==\n')
for p in sorted(unref, key=lambda x: -disk[x])[:30]:
    OUT.write('%12d  %s\n' % (disk[p], p))

# ---------- biggest referenced ----------
OUT.write('\n== 15 biggest referenced ==\n')
for p in sorted(referenced, key=lambda x: -disk[x])[:15]:
    OUT.write('%12d  %s  (%s)\n' % (disk[p], p, referenced[p][0][0]))

# ---------- unreferenced by dir ----------
OUT.write('\n== unreferenced bytes by dir ==\n')
ub = collections.defaultdict(int); ubn = collections.defaultdict(int)
for p in unref:
    top = p.split('/')[0] if '/' in p else '(root)'
    ub[top] += disk[p]; ubn[top] += 1
for top in sorted(ub, key=lambda k: -ub[k]):
    OUT.write('%-24s %6d files %14d bytes\n' % (top, ubn[top], ub[top]))

open('work/_audit_out1.txt','w',encoding='utf-8').write(OUT.getvalue())
print('done', len(OUT.getvalue()))
