
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=sorted(json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"])
for i in H:
    for k,c in enumerate(idx[i]["cmds"]):
        op=c["c"]
        if op in (123,125,104,105,99,170,171,172,179,212,213,420,498,103) and (op!=103 or True):
            print("ev%-4d pc%-5d op%-4d bd%d a=%s s=%s"%(i,k,op,c["bd"],c["a"],(c["s"] or [])[:1]))
