import io, os
def load(p):
    return io.open(p, encoding="utf-8", newline="").read()
def save(p, t):
    io.open(p + ".new", "w", encoding="utf-8", newline="").write(t)
    os.replace(p + ".new", p)

p = "crates/wolf-game/src/message.rs"
t = load(p)
a = "/// Gap between the last glyph of the text and an auto-placed pause cursor, in pixels."
assert t.count(a) == 1
k = "/// Picture slot common event 63 keeps the message-window frame in (its self[20]).\n///\n/// The event draws the nine-slice skin there and erases it when Sys12 drops, so when the\n/// slot is live its width is the box the text must wrap inside.\npub const FRAME_PICTURE: i32 = 19500;\n\n"
t = t.replace(a, k + a)
save(p, t)

p = "crates/wolf-game/src/game.rs"
t = load(p)
a = "    /// Preselects an option of the current choice prompt."
assert t.count(a) == 1
snip = io.open("work/_snip_9d66.txt", encoding="utf-8", newline="").read()
t = t.replace(a, snip + a)
save(p, t)
print("patched")