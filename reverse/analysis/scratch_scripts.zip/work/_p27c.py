import io, os, sys
spec = 'docs/SAVE_SPEC.md'
text = io.open(spec, encoding='utf-8', newline='').read()
ins = io.open('work/_ins12.md', encoding='utf-8', newline='').read()
a = '   任何一段读错都会在这条断言上暴露 —— 建议照抄这条断言，不要只信任段长。\n'
assert text.count(a) == 1, text.count(a)
text = text.replace(a, a + ins)
io.open(spec + '.new', 'w', encoding='utf-8', newline='').write(text)
os.replace(spec + '.new', spec)
print('ok')