import io, os
p = "crates/wolf-game/src/choice.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = "\nfn advance(ch: char) -> f32 {\n    advance_at(ch, TEXT_PX)\n}\n"
assert t.count(a) == 1, t.count(a)
t = t.replace(a, "")
io.open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
p2 = "crates/wolf-game/src/lib.rs"
t2 = io.open(p2, encoding="utf-8", newline="").read()
b = "pub mod map_runtime;\n"
assert t2.count(b) == 1
t2 = t2.replace(b, b + "pub mod message;\n")
io.open(p2 + ".new", "w", encoding="utf-8", newline="").write(t2)
os.replace(p2 + ".new", p2)
print("trimmed + lib patched")