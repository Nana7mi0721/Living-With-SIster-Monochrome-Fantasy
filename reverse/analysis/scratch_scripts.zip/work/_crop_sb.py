
from PIL import Image
src=r'C:/Users/REISEN/.dsh/attachments/v1/objects/48/48b03b8df72d48b419b159869356953a31eef9a3fc8e754e0d287e7a0c687e28'
im=Image.open(src); w,h=im.size
out=r'work/out'
# bands: 0-200, 200-420, 420-640, 640-800
for i,(a,b) in enumerate([(0,210),(200,420),(410,640),(630,800)]):
    c=im.crop((0,a,w,b))
    c=c.resize((int(w*1.5),int((b-a)*1.5)),Image.LANCZOS)
    c.save(f'{out}/sb{i}.png')
    print(i,c.size)
