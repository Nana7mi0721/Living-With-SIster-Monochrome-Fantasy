import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
ev=[e for e in ce if e['id']==48][0]
for i,c in enumerate(ev['cmds']):
    if i>130: break
    print('%3d %3d %s'%(i,c['c'],c['a']), [x[:34] for x in c['s']])