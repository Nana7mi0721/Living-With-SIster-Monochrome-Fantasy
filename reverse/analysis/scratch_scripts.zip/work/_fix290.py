import io, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
p = 'docs/OPCODE_290.md'
s = io.open(p, encoding='utf-8').read()
# 1) blank line after every horizontal rule that is immediately followed by a heading
n1 = s.count('---\n## ')
s = s.replace('---\n## ', '---\n\n## ')
# 2) marker convention sentence right after the v2 revision table header line 12 block
anchor = '## v2 修订摘要（本轮相对 vm-spec 初版）'
assert s.count(anchor) == 1
note = ('> 证据标记约定：**已验证** = 已对着真实文件/真实二进制/官方原文逐字节或全量统计核对过；'
        '**未验证**（正文中同一含义亦写作「未确认」/「高置信推断」）= 只能从用法或常识推出，尚未拿到直证。'
        '复现脚本见 §8。\n\n')
s = s.replace(anchor, note + anchor, 1)
io.open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('blank-line fixes:', n1)
print('bytes', len(s.encode('utf-8')), 'lines', s.count('\n'))