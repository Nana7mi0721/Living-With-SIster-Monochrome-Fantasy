
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
ma=json.load(open('work/_map_audit.json',encoding='utf-8'))
ev1=[e for e in ma['SampleMapA.mps']['events'] if e['id']==1][0]
for p in ev1['pages']:
    conds=[]
    for c in p['conds']:
        v=c['var']; vn='v%d'%(v-2000000) if v>=2000000 else str(v)
        conds.append(vn+{1:'>=',2:'==',3:'<=',5:'!='}.get(c['op'],str(c['op']))+str(c['value']))
    print('page%d trig=%d conds=[%s] ncmds=%d ops=%s'%(p['index'],p['trigger'],','.join(conds),p['cmds'],p['ops']))
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={x['id']:x for x in ce}
def vname(v): return 'v%d'%(v-2000000) if 2000000<=v<3000000 else ('self%d'%(v-1000000) if 1000000<=v<2000000 else str(v))
def show(cid,lo,hi):
    print('=== CE%d pc%d-%d ==='%(cid,lo,hi))
    cmds=by[cid]['cmds']
    for pc in range(lo,min(hi,len(cmds))):
        c=cmds[pc]; op=c['c']; a=c['a']; s=c['s']
        nm={111:'IF',401:'CASE',420:'ELSE',499:'END',102:'CHOICE',421:'CANCEL',172:'BREAK',210:'CALL',121:'SET',124:'SETEX',122:'LABEL',212:'SUB212',213:'SUB213'}.get(op,str(op))
        ex=''
        if op==111:
            n=a[0]&0xF; cs=[]
            for i in range(n):
                cs.append(vname(a[1+i*3])+{1:'>=',2:'==',3:'<=',5:'!='}.get(a[3+i*3],'?'+str(a[3+i*3]))+str(a[2+i*3]))
            ex='['+','.join(cs)+']'
        elif op in (121,124,210): ex=str(a)
        elif op==401: ex='case'+str(a[0]) if a else ''
        elif op==102: ex='n=%d'%(a[0] if a else -1)
        elif s: ex=repr(s[0])[:40]
        print('pc%-4d %-6s %s'%(pc,nm,ex))
show(245,764,826)
show(290,390,442)
show(327,0,33)
