
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
e=[x for x in ce if x['id']==63][0]
for i,c in enumerate(e['cmds']):
    if c['c']==250:
        print(i,'a=',c['a'],'s=',c['s'])
print('--- 150s strings')
for i,c in enumerate(e['cmds']):
    if c['c']==150 and c['s']: print(i,c['a'],c['s'])
