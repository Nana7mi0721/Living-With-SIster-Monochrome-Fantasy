
import json,sys
sys.stdout.reconfigure(encoding="utf-8")
ce=json.load(open("work/_ce_full.json",encoding="utf-8"))
hits=[]
for e in ce:
    for i,c in enumerate(e["cmds"]):
        if c["c"]==121 and c["a"] and c["a"][0] in (2000004,2000005):
            hits.append((e["id"],e["title"],i,c["a"]))
print("total writes to hour/minute:",len(hits))
for h in hits:
    print("ev%-5d %-16s pc%-5d a=%s"%h)
