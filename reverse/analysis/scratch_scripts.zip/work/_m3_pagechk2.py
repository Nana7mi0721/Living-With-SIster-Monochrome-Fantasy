
import json,os
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
wt=json.load(open(os.path.join(W,"wolftl","dump","mps","SampleMapA.json"),encoding="utf-8"))
mf={e["id"]:e for e in maps["SampleMapA.mps"]["events"]}
wf={e["id"]:e for e in wt["events"]}
out=[]
for i in sorted(mf)[:6]:
    ne=sum(1 for c in mf[i]["cmds"] if c["c"])
    per=[len(p["list"]) for p in wf[i]["pages"]]
    out.append("ev%-3d full_slots=%-5d nonempty=%-5d wolftl_pages=%s sum=%d"%(i,len(mf[i]["cmds"]),ne,per,sum(per)))
open(os.path.join(W,"_m3_pagechk2.txt"),"w",encoding="utf-8").write("\n".join(out))
print("\n".join(out))
