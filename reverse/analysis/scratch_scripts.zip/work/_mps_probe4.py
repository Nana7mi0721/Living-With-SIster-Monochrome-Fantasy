
import struct, os
base = r'work\full\MapData'
files = sorted(f for f in os.listdir(base) if f.endswith('.mps'))
for f in files:
    b = open(os.path.join(base,f),'rb').read()
    o = 16
    vh = b[o]; o+=1
    o+=3
    u1_ = struct.unpack_from('<I',b,o)[0]; o+=4
    ver = b[o]; o+=1
    n = struct.unpack_from('<I',b,o)[0]; o+=4+n
    ts,w,h,ec = struct.unpack_from('<IIII',b,o); o+=16
    fp = struct.unpack_from('<I',b,o)[0]
    info = '%s vh=0x%02x u1=%d ver=0x%02x ts=%d %dx%d ev=%d fp=0x%08x' % (f,vh,u1_,ver,ts,w,h,ec,fp)
    if fp == 0xFFFFFFFF:
        print(info, 'NO-TILES', 'next=0x%02x' % b[o+4]); continue
    vals = struct.unpack_from('<%dI' % (w*h*3), b, o)
    n_cells = w*h
    # layer-major interpretation
    L = [vals[0:n_cells], vals[n_cells:2*n_cells], vals[2*n_cells:]]
    lm = ['%d/%d non-empty, distinct=%d' % (sum(1 for v in l if v!=0xFFFFFFFF), len(set(l)), len(set(l))) for l in L]
    # pixel-major interpretation
    P = [[vals[i*3+k] for i in range(n_cells)] for k in range(3)]
    pm = ['%d/%d distinct=%d' % (sum(1 for v in l if v!=0xFFFFFFFF), len(set(l)), len(set(l))) for l in P]
    print(info)
    print('   layer-major: ', ' | '.join(lm))
    print('   pixel-major: ', ' | '.join(pm))
    print('   L0 first 6:', L[0][:6], ' L1 first 6:', L[1][:6], ' L2 first 6:', L[2][:6])
    print('   pixel-major first 6 cells:', [(vals[i*3],vals[i*3+1],vals[i*3+2]) for i in range(6)])
    print('   next after tiles = 0x%02x (expect 0x6f)' % b[o+n_cells*12])
    # event separators
    oo = o + n_cells*12
    for e in range(ec):
        assert b[oo]==0x6f, (f, e, hex(b[oo]))
        oo+=1
        m = struct.unpack_from('<I',b,oo)[0]; oo+=4
        eid = struct.unpack_from('<I',b,oo)[0]; oo+=4
        ln = struct.unpack_from('<I',b,oo)[0]; oo+=4+ln
        x,y,pc,sep = struct.unpack_from('<IIII',b,oo); oo+=16
        if sep != 0: print('   EVENT', e, 'separator =', sep)
        # skip pages via fs_mps logic
        for p in range(pc):
            assert b[oo]==0x79, (f,e,p,hex(b[oo]))
            oo+=1+4
            ln = struct.unpack_from('<I',b,oo)[0]; oo+=4+ln
            oo+=4+37+4+1+1
            rl = struct.unpack_from('<I',b,oo)[0]; oo+=4
            for _ in range(rl):
                oo+=1; n1=b[oo]; oo+=1+n1*4; n2=b[oo]; oo+=1+n2
            cc = struct.unpack_from('<I',b,oo)[0]; oo+=4
            for _ in range(cc):
                pcn=b[oo]; oo+=1
                if pcn>0: oo+=4+(pcn-1)*4
                oo+=1; sc=b[oo]; oo+=1
                for _ in range(sc):
                    ln=struct.unpack_from('<I',b,oo)[0]; oo+=4+ln
                hr=b[oo]; oo+=1
                if hr!=0:
                    oo+=6; rl2=struct.unpack_from('<I',b,oo)[0]; oo+=4
                    for _ in range(rl2):
                        oo+=1; n1=b[oo]; oo+=1+n1*4; n2=b[oo]; oo+=1+n2
            feat = struct.unpack_from('<I',b,oo)[0]; oo+=4+3
            pf = b[oo]; oo+=1
            if feat != 3: print('   EVENT',e,'page',p,'features=',feat)
            if pf != 0x7A: print('   EVENT',e,'page',p,'page footer=0x%02x at %d' % (pf, oo-1))
        ef = b[oo]; oo+=1
        if ef != 0x70: print('   EVENT',e,'footer=0x%02x' % ef)
    print('   events end at %d, terminator=0x%02x, len=%d' % (oo, b[oo], len(b)))
