import json, io
ce = json.load(open("work/_ce_full.json", encoding="utf-8"))
d = {e["id"]: e for e in ce}
f = io.open("work/_m3_329b.txt", "w", encoding="utf-8")
e = d[329]
f.write("### ev329 %s\n" % e["title"])
for i, c in enumerate(e["cmds"]):
    if c["c"] == 0:
        continue
    if 400 <= i <= 445:
        f.write("pc%-4d bd=%s c=%-4s a=%s s=%s\n" % (i, c["bd"], c["c"], c["a"], c["s"]))
f.write("\n### ev317 use of 1600000\n")
for i, c in enumerate(d[317]["cmds"]):
    if 1600000 in c["a"]:
        f.write("pc%-4d bd=%s c=%-4s a=%s s=%s\n" % (i, c["bd"], c["c"], c["a"], c["s"]))
f.write("\n### ev317 pc600-640\n")
for i, c in enumerate(d[317]["cmds"]):
    if c["c"] == 0:
        continue
    if 600 <= i <= 645:
        f.write("pc%-4d bd=%s c=%-4s a=%s s=%s\n" % (i, c["bd"], c["c"], c["a"], c["s"]))
f.close()
print("ok")
