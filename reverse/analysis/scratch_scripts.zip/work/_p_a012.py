import io, os
path = "crates/wolf-cli/src/main.rs"
t = io.open(path, encoding="utf-8", newline="").read()
start = t.index("        if std::env::var_os("WOLF_DEBUG_MSG").is_some() {")
end = t.index("        for run in &layout.runs {", start)
t = t[:start] + t[end:]
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")