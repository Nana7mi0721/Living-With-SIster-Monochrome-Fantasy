# -*- coding: utf-8 -*-
import struct, os, json, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base = r'work\full\MapData'

def parse_mps(p):
    b=open(p,'rb').read()
    st={'o':0}
    def u1():
        v=b[st['o']]; st['o']+=1; return v
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        return s.split(b'\x00')[0].decode('utf-8','replace')
    out={}
    st['o']=16
    out['version_header']=u1(); st['o']+=3
    out['unk_20']=u4(); out['version']=u1(); out['title']=tstr()
    out['tileset']=u4(); out['width']=u4(); out['height']=u4(); out['event_count']=u4()
    fp=u4(); out['first_pixel']=fp
    if fp!=0xFFFFFFFF:
        st['o'] += out['width']*out['height']*3*4 - 4
        out['no_tiles']=False
    else:
        out['no_tiles']=True
    events=[]
    while b[st['o']]==0x6F:
        ev={}
        u1(); u4(); ev['id']=u4(); ev['name']=tstr()
        ev['x']=u4(); ev['y']=u4(); pc=u4(); u4()
        pages=[]
        for _ in range(pc):
            pg={}
            u1(); pg['chipid']=u4(); pg['graphic']=tstr()
            pg['direction']=u1(); pg['frame']=u1(); pg['opacity']=u1(); pg['display']=u1()
            pg['trigger']=u1()
            pg['sw']=[u1() for _ in range(4)]
            pg['varn']=[u4() for _ in range(4)]
            pg['varv']=[s4() for _ in range(4)]
            pg['move']=[u1() for _ in range(6)]
            rl=u4()
            routes=[]
            for _ in range(rl):
                t=u1(); n1=u1(); a1=[u4() for _ in range(n1)]; n2=u1(); a2=[u1() for _ in range(n2)]
                routes.append([t,a1,a2])
            pg['route_len']=rl
            ncmd=u4(); pg['cmd_count']=ncmd
            cmds=[]
            for _ in range(ncmd):
                cnt=u1()
                if cnt>0:
                    op=u4(); args=[u4() for _ in range(cnt-1)]
                else:
                    op=0; args=[]
                depth=u1(); sc=u1()
                strs=[tstr() for _ in range(sc)]
                hr=u1()
                tail=None
                if hr!=0:
                    hdr=[u1() for _ in range(6)]
                    rl2=u4()
                    steps=[]
                    for _ in range(rl2):
                        t=u1(); n1=u1(); a1=[u4() for _ in range(n1)]; n2=u1(); a2=[u1() for _ in range(n2)]
                        steps.append([t,a1,a2])
                    tail=[hdr,rl2,steps]
                cmds.append({'op':op,'args':args,'depth':depth,'strings':strs,'tail':tail})
            pg['commands']=cmds
            u4(); pg['shadow']=u1(); pg['rex']=u1(); pg['rey']=u1(); pg['footer']=u1()
            pages.append(pg)
        ev['pages']=pages
        ev['footer']=u1()
        events.append(ev)
    out['events']=events
    return out

def signed(v):
    return v-0x100000000 if v>=0x80000000 else v

maps={}
for f in sorted(os.listdir(base)):
    if not f.endswith('.mps'): continue
    maps[f]=parse_mps(os.path.join(base,f))

# conditions decode
def conds(pg):
    out=[]
    for i in range(4):
        sw=pg['sw'][i]
        out.append({'slot':i,'enabled':(sw & 0x0F)==1,'op':sw>>4,'raw':sw,
                    'var':pg['varn'][i],'value':signed(pg['varv'][i])})
    return out

summary={}
for f,m in maps.items():
    evs=[]
    for ev in m['events']:
        pages=[]
        for pi,pg in enumerate(ev['pages']):
            pages.append({'index':pi,'trigger':pg['trigger'],
                          'conds':conds(pg),'cmds':pg['cmd_count'],
                          'graphic':pg['graphic'],'chipid':pg['chipid'],
                          'footer':pg['footer'],
                          'ops':[c['op'] for c in pg['commands']]})
        evs.append({'id':ev['id'],'name':ev['name'],'x':ev['x'],'y':ev['y'],'pages':pages})
    summary[f]={'w':m['width'],'h':m['height'],'tileset':m['tileset'],
                'no_tiles':m['no_tiles'],'title':m['title'],'events':evs}

json.dump(summary, open('work/_map_audit.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)

# quick stats
tot_ev=sum(len(m['events']) for m in summary.values())
tot_pg=sum(len(e['pages']) for m in summary.values() for e in m['events'])
trig={}
ops={}
for m in summary.values():
    for e in m['events']:
        for p in e['pages']:
            trig[p['trigger']]=trig.get(p['trigger'],0)+1
            for o in p['ops']:
                ops[o]=ops.get(o,0)+1
print('maps',len(summary),'events',tot_ev,'pages',tot_pg)
print('triggers',sorted(trig.items()))
print('opcodes in map pages',sorted(ops.items()))
tp=[(f,e['id'],p['index']) for f,m in summary.items() for e in m['events'] for p in e['pages']]
print('first teleport sites:', [x for x in tp][:3])
