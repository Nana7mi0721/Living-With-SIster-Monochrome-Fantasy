
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(io.open('work/wolftl/dump/db/CDataBase.json',encoding='utf-8'))
T=d['types']
t=T[18]
print('name',t.get('name'),'fields',[f.get('name') for f in (t.get('fields') or [])])
for i in (0,1,2,3,5,6,7,96,97,98,99):
    row=t['data'][i]
    print('%3d'%i, json.dumps(row.get('data'),ensure_ascii=False)[:160])
t19=T[19]
print('--- type19',t19.get('name'),[f.get('name') for f in (t19.get('fields') or [])])
row=t19['data'][0]
for j,v in enumerate(row.get('data') or []):
    print('   f%d'%j, json.dumps(v.get('value'),ensure_ascii=False)[:80])
