from PIL import Image
sheet = Image.open('work/full/MapChip/[A]Grass1_pipo.png').convert('RGBA')
print('sheet', sheet.size, sheet.mode)
def quadrant(code, qx, qy, frame=0):
    src = (frame*16 + qx*8, code*16 + qy*8, frame*16 + qx*8 + 8, code*16 + qy*8 + 8)
    print('crop', src)
    return sheet.crop(src)
def compose(raw, frame=0):
    idv = raw // 100000
    tail = raw % 10000
    codes = [(tail//1000)%10, (tail//100)%10, (tail//10)%10, tail%10]
    cell = Image.new('RGBA', (16,16), (0,0,0,0))
    for qy in range(2):
        for qx in range(2):
            c = codes[qy*2+qx]
            cell.paste(quadrant(c, qx, qy, frame), (qx*8, qy*8))
    return cell
im = compose(104444)
print('composed', im.size)
