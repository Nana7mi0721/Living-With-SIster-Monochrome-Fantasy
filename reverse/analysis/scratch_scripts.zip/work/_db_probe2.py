import struct, os, sys, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

def parse(p):
    b=open(p,'rb').read()
    st={'o':0}
    def u1():
        v=b[st['o']]; st['o']+=1; return v
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr_raw():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        i=s.find(b'\x00')
        return s if i<0 else s[:i]
    out={}
    st['o']=6
    out['version_header']=u1()
    magic2=b[st['o']:st['o']+3]; st['o']+=3
    out['version']=u1(); out['type_count']=u4()
    types=[]
    for ti in range(out['type_count']):
        t={'_start':st['o']}
        t['sub']=b[st['o']:st['o']+4]; st['o']+=4
        t['dm']=u4(); pc=u4()
        raw=[u4() for _ in range(pc)]
        t['raw']=raw
        nb=sum(1 for x in raw if 1000<=x<2000)
        sb=sum(1 for x in raw if x>=2000)
        other=[x for x in raw if x<1000]
        t['nb']=nb; t['sb']=sb; t['other']=other
        t['rows']=u4()
        for _ in range(t['rows']):
            st['o']+=4*nb
            for _ in range(sb):
                n=u4(); st['o']+=n
        t['_end']=st['o']
        types.append(t)
    out['types']=types
    out['footer']=u1(); out['end']=st['o']; out['len']=len(b); out['trailing']=len(b)-st['o']
    return out

for name in ['DataBase.dat','CDataBase.dat','SysDatabase.dat']:
    r=parse('work/full/BasicData/'+name)
    print('%s len=%d vh=0x%02x ver=0x%02x types=%d footer=0x%02x end=%d trailing=%d' % (name,r['len'],r['version_header'],r['version'],r['type_count'],r['footer'],r['end'],r['trailing']))
    subs=set(); dms=set(); others=set()
    for i,t in enumerate(r['types']):
        subs.add(t['sub'].hex()); dms.add(t['dm'])
        if t['other']: others.add((i,tuple(sorted(set(t['other'])))))
        if i<3:
            print('  type%d dm=%d fields=%d num=%d str=%d rows=%d raw=%s' % (i,t['dm'],len(t['raw']),t['nb'],t['sb'],t['rows'],t['raw'][:24]))
    print('  sub_headers:',subs,' dm values:',dms,' other-raw:',others)

# map settings
def dump_mapsettings():
    b=open('work/full/BasicData/SysDatabase.dat','rb').read()
    st={'o':11}
    def u4():
        v=struct.unpack_from('<I',b,st['o'])[0]; st['o']+=4; return v
    def s4():
        v=struct.unpack_from('<i',b,st['o'])[0]; st['o']+=4; return v
    def tstr():
        n=u4(); s=b[st['o']:st['o']+n]; st['o']+=n
        i=s.find(b'\x00'); s=s if i<0 else s[:i]
        return s.decode('utf-8','replace')
    n=u4()
    for ti in range(n):
        st['o']+=4; dm=u4(); pc=u4()
        raw=[u4() for _ in range(pc)]
        nb=sum(1 for x in raw if 1000<=x<2000); sb=pc-nb
        rows=u4()
        if ti==0:
            print('SysDatabase type0 dm=%d fields=%d num=%d str=%d rows=%d raw=%s' % (dm,pc,nb,sb,rows,raw))
            for ri in range(rows):
                nums=[s4() for _ in range(nb)]
                strs=[tstr() for _ in range(sb)]
                print('  row%02d %r %r' % (ri,nums,strs))
        else:
            for _ in range(rows):
                st['o']+=4*nb
                for _ in range(sb):
                    ln=u4(); st['o']+=ln
dump_mapsettings()
