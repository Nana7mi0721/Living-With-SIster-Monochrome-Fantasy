import struct, sys, io, os
sys.stdout.reconfigure(encoding='utf-8')
base = r'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy\Save'
def jpeg_size(path):
    with open(path,'rb') as f:
        data = f.read()
    i = 2
    while i < len(data):
        if data[i] != 0xFF:
            i += 1; continue
        marker = data[i+1]
        if marker in (0xC0,0xC1,0xC2):
            h, w = struct.unpack('>HH', data[i+5:i+9])
            return w, h, marker
        if marker in (0xD8,0xD9) or 0xD0 <= marker <= 0xD7:
            i += 2; continue
        seglen = struct.unpack('>H', data[i+2:i+4])[0]
        i += 2 + seglen
    return None
for n in range(1,9):
    p = os.path.join(base, 'save%d.jpg' % n)
    print('save%d.jpg' % n, jpeg_size(p), os.path.getsize(p))
