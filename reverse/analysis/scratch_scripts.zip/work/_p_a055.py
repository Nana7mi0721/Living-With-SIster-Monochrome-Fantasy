import json, collections
p = "docs/M2_SLICE.md"
raw = open(p, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13)+chr(10), chr(10))
a = "| git HEAD | `ba761be`（`130` 地图传送与标题→新游戏链；此前 `dc85636` 为 styled 101 message / SavePart5 图片表写回 / vardb `write_into` / 220 mode 0） |"
b = "| git HEAD | `107205e`（新游戏→存档→读档往返；此前 `ba761be` 为 `130` 地图传送与标题→新游戏链） |"
assert t.count(a) == 1
t = t.replace(a, b)
a = "| C16 | `cargo test -q -p wolf-game a_saved_game_reloads_its_live_picture_layer` 与 `a_saved_game_keeps_the_database_cells` | 整档回写（§2.5） |"
b = """| C16 | `cargo test -q -p wolf-game a_saved_game_reloads_its_live_picture_layer` 与 `a_saved_game_keeps_the_database_cells` | 整档回写（§2.5） |
| C17 | `cargo test -q -p wolf-game --test opening a_title_new_game_can_be_saved_and_reloaded_after_the_opening` | 标题→新游戏→存档→读档整条链（§2.5） |"""
assert t.count(a) == 1
t = t.replace(a, b)
a = """唯一非字节等价的写回是 retail 文本图 escape 04（带字距字体）：语义上仍是 `\f[n]`，写回成 05。"""
b = """唯一非字节等价的写回是 retail 文本图 escape 04（带字距字体）：语义上仍是 `\f[n]`，写回成 05。

**端到端（本批新增）**：`a_title_new_game_can_be_saved_and_reloaded_after_the_opening` 从 boot 走标题菜单第一项 →
开场对话/选择 → 1200 帧 → `Game::save_to`（>300,000 字节）→ 新 `Game::load_save`。断言：屏幕上**可见**图片层逐字段相同、
800 个通常変数全等、playtime 与 Sys3/Sys4 全等。该测试同时暴露并修复了两个 SavePart5 往返缺陷：
空文件名的 `FileString` / `WindowString` 槽位不再被丢弃；`scale = 0` 不再被当成 `100`（零售 6233 的 [9]=62 / [10]=100
说明 0 是真实的「隐藏」，不是缺省值）。"""
assert t.count(a) == 1
t = t.replace(a, b)
a = "16. **地图传送与标题新游戏链**：`130` 的 `-1/-2` 解码为 SysDatabase 行号，切图时停旧图协程、启新图自动页；`boot → 标题 → 菜单 → 新游戏 → 开场四选一` 已有集成测试（§4.6）。\n"
b = """16. **地图传送与标题新游戏链**：`130` 的 `-1/-2` 解码为 SysDatabase 行号，切图时停旧图协程、启新图自动页；`boot → 标题 → 菜单 → 新游戏 → 开场四选一` 已有集成测试（§4.6）。
17. **端到端日常链**：标题 → 新游戏 → 开场对话/选择 → 1200 帧剧情态 → `save_to` → 新 Game `load_save`，可见图片层 / 800 通常変数 / playtime / Sys3-4 全部一致（§2.5，C17）。
"""
assert t.count(a) == 1
t = t.replace(a, b)
a = "剩 221 flag=1 站点与 retail 04 字体记录的字节级写回未验证 |"
b = "剩 221 flag=1 站点、retail 04 字体记录的字节级写回，以及「Rust 写出的 .sav 被官方游戏读回」未验证 |"
assert t.count(a) == 1
t = t.replace(a, b)
if crlf: t = t.replace(chr(10), chr(13)+chr(10))
open(p, "wb").write(t.encode("utf-8"))

bp = "docs/BASELINE.json"
d = json.load(open(bp, encoding="utf-8"), object_pairs_hook=collections.OrderedDict)
s = d["save_opcodes"]
s["tests"].append("wolf-game a_title_new_game_can_be_saved_and_reloaded_after_the_opening")
lw = s["live_writer"]
lw["tests"].append("wolf-game a_title_new_game_can_be_saved_and_reloaded_after_the_opening")
lw["picture_roundtrip"] = "empty FileString/WindowString slots are kept as invisible pictures; scale 0 is preserved (retail picture 6233 has [9]=62 / [10]=100, so 0 means hidden, not missing)"
lw["end_to_end"] = "a_title_new_game_can_be_saved_and_reloaded_after_the_opening: boot -> title menu -> new game -> 1200 frames -> save >300000 bytes -> fresh Game load; visible picture layer, 800 normal variables, playtime and Sys3/Sys4 equal"
s["partial"] = "220 mode 0 is implemented (see live_writer); 221 flag=1 sites ev94 pc335/345/348 remain unverified; retail escape 04 in SavePart5 text records is semantically but not byte-identically re-encoded; reading a Rust-written .sav back into the official game is not yet demonstrated"
json.dump(d, open(bp, "w", encoding="utf-8", newline="\n"), indent=1, ensure_ascii=False)
print("ok")