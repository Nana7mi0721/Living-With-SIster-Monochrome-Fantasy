from pathlib import Path
p = Path("crates/wolf-game/src/db.rs")
s = p.read_text(encoding="utf-8")
anchor = "    fn retail_save() -> Option<wolf_save::SaveFile> {"
test = """    #[test]
    fn the_party_label_resolves_onto_the_player_row() {
        // CE105 asks for the member of party position 0 and labels the table
        // パーティー情報, member 1. The numeric type 3 is 属性耐性, so only the label
        // route reaches the row that says the party leader is status row 12.
        let Some(root) = have_data() else { return };
        let databases = Databases::load(&root.join("BasicData"), DEFAULT_SCREEN);
        let (db_type, column) = databases.resolve_labels(
            Container::CData,
            3,
            1,
            Some("パーティー情報"),
            Some("メンバー1"),
        );
        assert_eq!((db_type, column), (6, 1));
        assert_eq!(databases.num(Container::CData, db_type, 0, column), Some(12));
    }

"""
assert anchor in s
s = s.replace(anchor, test + anchor, 1)
p.write_text(s, encoding="utf-8", newline="")
print("test added")
