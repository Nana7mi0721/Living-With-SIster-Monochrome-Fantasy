
import json, os, collections
os.chdir(r'E:\Study\github program\imoto life')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
# 140: split by whether string is SE/ or BGM/ or DLC
cat=collections.defaultdict(collections.Counter)
for e in ev:
    for c in e['cmds']:
        if c['c']==140 and c['s']:
            s=c['s'][0]
            k='BGM' if s.lower().startswith(('bgm/','dlc_data/bgm')) else ('SE' if s.lower().startswith('se/') else 'other')
            cat[k][(c['a'][0], c['a'][1] if len(c['a'])>1 else None)]+=1
for k in cat: print(k, cat[k].most_common(8))
print()
# 150: dump a few full arg vectors by type
seen=collections.defaultdict(list)
for e in ev:
    for c in e['cmds']:
        if c['c']==150:
            t=(c['a'][0]>>4)&0x07
            if len(seen[t])<4: seen[t].append((c['a'], c['s']))
for t in sorted(seen):
    print('--- type',t)
    for a,s in seen[t]: print('   ', a, s[:1])
