$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class W3 {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
}
"@
$gameDir = 'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
$proc = Start-Process -FilePath (Join-Path $gameDir 'Game.exe') -WorkingDirectory $gameDir -PassThru
Start-Sleep -Seconds 18
$proc.Refresh()
$h = $proc.MainWindowHandle
[void][W3]::SetForegroundWindow($h)
$c = New-Object W3+RECT
[void][W3]::GetClientRect($h, [ref]$c)
$p = New-Object W3+POINT
[void][W3]::ClientToScreen($h, [ref]$p)
$w = $c.Right - $c.Left; $hh = $c.Bottom - $c.Top
$i = 0
foreach ($wait in @(0, 3, 3, 3, 4, 4, 5, 5)) {
  Start-Sleep -Seconds $wait
  [void][W3]::SetForegroundWindow($h)
  [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
  Start-Sleep -Milliseconds 700
  $bmp = New-Object System.Drawing.Bitmap $w, $hh
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.CopyFromScreen($p.X, $p.Y, 0, 0, (New-Object System.Drawing.Size $w, $hh))
  $out = 'E:\Study\github program\imoto life\work\out\orig_' + $i + '.png'
  $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
  $g.Dispose(); $bmp.Dispose()
  Write-Output ("saved " + $i + " at +" + $wait + "s")
  $i++
}
try { Stop-Process -Id $proc.Id -Force } catch {}
Write-Output 'done'
