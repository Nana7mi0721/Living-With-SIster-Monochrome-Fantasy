import io, os

def rep(text, a, b):
    assert a in text, "missing: " + a[:60]
    assert text.count(a) == 1, "not unique: " + a[:60]
    return text.replace(a, b)

p = "crates/wolf-cli/src/main.rs"
t = io.open(p, encoding="utf-8", newline="").read()
dead = """/// Runs the title screen headlessly for N frames and writes the logical framebuffer to PNG.
///
/// This is the M1 acceptance artifact: 1024x576 of pixels produced by the real event
/// script through the real picture stack, comparable side by side with a screenshot of
/// the original game. The messages the interpreter reports are printed too, because a
/// capture that looks right but logged forty warnings is not actually right.
/// Default font size for text pictures, in logical pixels.
///
/// WOLF does not store a font size in the picture command; the runtime uses the Game.dat
/// font (Lolita) at the size set in the editor text settings. 22 px matches the CN
/// notice measured 7 lines in a 300x200 window.
const TEXT_PX: f32 = 22.0;"""
t = rep(t, dead, "")
usage = ".map(|text| TextItem::new(text.text.clone(), text.rect, TEXT_PX).with_alpha(text.alpha))"
t = rep(t, usage, ".map(|text| {\n            TextItem::new(text.text.clone(), text.rect, choice::TEXT_PX).with_alpha(text.alpha)\n        })")
open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("patched", p)

p2 = "crates/wolf-cli/src/play.rs"
t2 = io.open(p2, encoding="utf-8", newline="").read()
dead2 = """/// Glyph size for text pictures and the runtime choice panel, in logical pixels.
///
/// WOLF default font is a 24 px bitmap glyph set and the title screens are laid out
/// for it, so anything much smaller renders a menu that looks empty at 1x.
const TEXT_PX: f32 = 22.0;"""
open("work/_playhead.txt", "w").write(t2[:1200])
print("head written")