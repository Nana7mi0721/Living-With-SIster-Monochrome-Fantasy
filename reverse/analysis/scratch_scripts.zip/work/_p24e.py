import struct, sys, os
sys.stdout.reconfigure(encoding='utf-8')
GAME=r'E:/SteamLibrary/steamapps/common/Living With SIster Monochrome Fantasy/Save'
def decrypt(b):
    b=bytearray(b); seeds=[b[0],b[3],b[9]]
    for pass_,step in enumerate((1,2,5)):
        st=seeds[pass_]; j=0x14
        while j < len(b):
            st=(st*214013+2531011)&0xFFFFFFFF
            r=(st>>16)&0x7FFF
            b[j]^=(r>>12)&0xFF
            j+=step
    return bytes(b)
raw=open(os.path.join(GAME,'System.sav'),'rb').read()
buf=decrypt(raw)
start=126700
print('hex dump around', start)
for off in range(start, start+0x140, 16):
    chunk=buf[off:off+16]
    print(f'{off:7d}  {chunk.hex(" ")}')

