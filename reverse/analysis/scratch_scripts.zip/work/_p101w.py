
import json,io,collections,sys,re
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def cmds_all():
    for e in ce:
        for c in e['cmds']: yield e['id'],c
    for m in mp.values():
        for ev in m.get('events',[]):
            for c in ev['cmds']: yield ('M',c)
esc=collections.Counter(); nstr=0; maxcp=0; sur=0
allmsgs=[]
for eid,c in cmds_all():
    for s in c['s']:
        nstr+=1; allmsgs.append((eid,c['c'],s))
        for ch in s:
            o=ord(ch)
            if o>maxcp: maxcp=o
            if o>0xFFFF: sur+=1
        i=0
        while i<len(s):
            if s[i]=='\\':
                k=i+1
                while k<len(s) and s[k].isalpha(): k+=1
                esc[s[i+1:k]]+=1
                i=k
            else: i+=1
print('strings total',nstr,'max codepoint',hex(maxcp),'non-BMP chars',sur)
print('escape histogram:')
for k,v in esc.most_common(50): print('   %-8r %d'%(k,v))
ch=collections.Counter()
for eid,op,s in allmsgs:
    for m in re.finditer(r'\\c\[(-?\d+)\]',s): ch[int(m.group(1))]+=1
print('c[n] histogram:',dict(sorted(ch.items())))
for name,base in (('Sys73',9000073),('Sys74',9000074),('Sys75',9000075),('Sys76',9000076),('Sys39',9000039),('Sys22',9000022)):
    hits=[(eid,c['c'],c['a'][:4]) for eid,c in cmds_all() if c['c'] in (121,124,122) and c['a'] and c['a'][0]==base]
    print(name,'writers',len(hits),hits[:4])
print('101 count',sum(1 for eid,c in cmds_all() if c['c']==101),'102 count',sum(1 for eid,c in cmds_all() if c['c']==102))
# 101 arg1 (附加显示模式) histogram
h=collections.Counter()
for eid,c in cmds_all():
    if c['c']==101: h[tuple(c['a'][:1])]+=1
print('101 a[0] histogram',dict(h.most_common(12)))
# 102 two strings?
s2=[(eid,c['a'],c['s']) for eid,c in cmds_all() if c['c']==102][:3]
for x in s2: print('102 sample',x)
