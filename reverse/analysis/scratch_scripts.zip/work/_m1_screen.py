# -*- coding: utf-8 -*-
"""Replay work/_m1_trace2.txt through the Screen::apply semantics and dump the
frame-200 title screen state.

The trace is produced by:
  cargo run -q -p wolf-cli -- run --event 42 --frames 200 --trace > work/_m1_trace2.txt

Mirrored rules (crates/wolf-game/src/picture.rs):
  * Erase   -> remove the slot
  * Draw/Set-> fresh slot, UNCHANGED fields take defaults
  * Move    -> patch an existing slot (creates it when missing); file/text replaced only
               when the command carries a non-empty one
  * UNCHANGED (-1000000) never overwrites
  * window (w,h) only set when both > 0
  * draw order = ascending slot number
  * opacity <= 0 -> not drawn
  * number < 0  -> whole-screen layer: dst = [0,0,1024,576], src = real texture size
  * text kinds  -> dst = [x, y, window_w, window_h], src = [0,0,0,0]
  * other kinds -> dst = [x, y, w*scale/100, h*scale/100], src = [0,0,w,h]

Outputs work/_m1_screen.json (final slots + quads) and a stdout report.
"""
import io
import json
import os
import re

from PIL import Image

ROOT = 'work/full'
UNCHANGED = -1000000
SCREEN_W, SCREEN_H = 1024, 576
PROBE_EXT = ['png', 'jpg', 'bmp', 'jpeg', 'webp']
TEXT_KINDS = (2, 4)

_size_cache = {}


def resolve(name):
    """Case-insensitive, extension-probing resolve, like wolf-game's Assets."""
    if not name:
        return None
    name = name.replace('\\', '/')
    direct = os.path.join(ROOT, *name.split('/'))
    for candidate in [direct] + [direct + '.' + e for e in PROBE_EXT]:
        if os.path.isfile(candidate):
            return candidate
    # segment-by-segment case-insensitive walk
    parts = name.split('/')
    cur = ROOT
    for i, part in enumerate(parts):
        if not os.path.isdir(cur):
            return None
        entries = {e.lower(): e for e in os.listdir(cur)}
        if part.lower() in entries:
            cur = os.path.join(cur, entries[part.lower()])
        else:
            stem, dot, ext = part.rpartition('.')
            base = entries.get(part.lower())
            if base:
                cur = os.path.join(cur, base)
                continue
            if not dot:
                found = None
                for e in PROBE_EXT:
                    if (part + '.' + e).lower() in entries:
                        found = entries[(part + '.' + e).lower()]
                        break
                if found is None:
                    return None
                cur = os.path.join(cur, found)
            else:
                return None
    return cur if os.path.isfile(cur) else None


def tex_size(name):
    if name in _size_cache:
        return _size_cache[name]
    path = resolve(name)
    size = None
    if path:
        try:
            with Image.open(path) as im:
                size = (im.width, im.height)
        except Exception:
            size = None
    _size_cache[name] = size
    return size


LINE = re.compile(r'^  150 picture  #(-?\d+) kind (\d+) (\w+) file=(.*?) text=(.*?) args=\[(.*?)\]$')


def parse_trace(path):
    ops = []
    with io.open(path, encoding='utf-8') as fh:
        for lineno, raw in enumerate(fh, 1):
            line = raw.rstrip('\n')
            if not line.startswith('  150 picture'):
                continue
            m = LINE.match(line)
            if not m:
                raise SystemExit('unparsed 150 line %d: %s' % (lineno, line))
            number = int(m.group(1))
            kind = int(m.group(2))
            action = m.group(3)
            file_ = m.group(4)
            text_ = m.group(5)
            args = [int(x) for x in m.group(6).split(',') if x.strip()]
            ops.append({'line': lineno, 'number': number, 'kind': kind,
                        'action': action, 'file': file_, 'text': text_, 'args': args})
    return ops


def take(args, idx):
    if idx < len(args) and args[idx] != UNCHANGED:
        return args[idx]
    return None


def merge(slot, args):
    for idx, key in ((4, 'opacity'), (5, 'x'), (6, 'y'), (7, 'scale'), (8, 'blend')):
        value = take(args, idx)
        if value is not None:
            slot[key] = max(0, min(255, value)) if key == 'opacity' else value
    w, h = take(args, 1), take(args, 2)
    if w is not None and h is not None and w > 0 and h > 0:
        slot['window'] = [w, h]
    if len(args) > 9:
        slot['extras'] = args[9:]


def fresh(number, kind):
    return {'number': number, 'kind': kind, 'file': '', 'text': '', 'x': 0, 'y': 0,
            'scale': 100, 'opacity': 255, 'blend': 0, 'window': None, 'extras': [],
            'age': 0, 'birth_line': None, 'ops': 0}


def apply_ops(ops):
    slots = {}
    for op in ops:
        n = op['number']
        if op['action'] == 'Erase':
            slots.pop(n, None)
            continue
        if op['action'] in ('Draw', 'Set'):
            slot = fresh(n, op['kind'])
            slot['file'] = op['file']
            slot['text'] = op['text']
            slot['birth_line'] = op['line']
            merge(slot, op['args'])
            slots[n] = slot
        elif op['action'] == 'Move':
            slot = slots.get(n)
            if slot is None:
                slot = fresh(n, op['kind'])
                slot['birth_line'] = op['line']
                slots[n] = slot
            if op['file']:
                slot['file'] = op['file']
            if op['text']:
                slot['text'] = op['text']
            merge(slot, op['args'])
        else:
            raise SystemExit('unknown action ' + op['action'])
        slot['ops'] += 1
    return slots


def quads(slots):
    out = []
    for n in sorted(slots):
        p = slots[n]
        if p['opacity'] <= 0:
            continue
        kind = p['kind']
        if n < 0:
            size = tex_size(p['file'])
            src = [0, 0, size[0], size[1]] if size else [0, 0, SCREEN_W, SCREEN_H]
            dst = [0.0, 0.0, float(SCREEN_W), float(SCREEN_H)]
        elif kind in TEXT_KINDS:
            w, h = p['window'] if p['window'] else (0, 0)
            src = [0, 0, 0, 0]
            dst = [float(p['x']), float(p['y']), float(max(0, w)), float(max(0, h))]
        else:
            size = tex_size(p['file'])
            if not size:
                out.append({'number': n, 'skipped': 'missing asset', 'file': p['file']})
                continue
            w, h = size
            scale = max(0, p['scale']) / 100.0
            src = [0, 0, w, h]
            dst = [float(p['x']), float(p['y']), w * scale, h * scale]
        out.append({'number': n, 'kind': kind, 'file': p['file'], 'text': p['text'],
                    'src': src, 'dst': dst, 'alpha': round(max(0, min(255, p['opacity'])) / 255.0, 4),
                    'blend': p['blend']})
    return out


ops = parse_trace('work/_m1_trace2.txt')
slots = apply_ops(ops)
qs = quads(slots)

print('picture ops replayed : %d' % len(ops))
print('slots live at frame 200: %d' % len(slots))
print('quads emitted         : %d' % len([q for q in qs if 'skipped' not in q]))
print()
print('=== live slots at frame 200 (ascending = draw order) ===')
for n in sorted(slots):
    p = slots[n]
    print('  #%-7d kind %d ops=%-4d file=%-42s text=%-28s x=%-5d y=%-5d scale=%-4d opacity=%-3d blend=%-6d window=%s'
          % (n, p['kind'], p['ops'], (p['file'] or '-')[:42], (p['text'] or '-')[:28],
             p['x'], p['y'], p['scale'], p['opacity'], p['blend'], p['window']))
print()
print('=== quads (draw order) ===')
for q in qs:
    if 'skipped' in q:
        print('  #%-7d SKIPPED (%s): %s' % (q['number'], q['skipped'], q['file']))
    else:
        print('  #%-7d kind %d src=%s dst=%s alpha=%s blend=%d file=%s text=%s'
              % (q['number'], q['kind'], q['src'], [round(v, 1) for v in q['dst']],
                 q['alpha'], q['blend'], q['file'] or '-', (q['text'] or '-')[:40]))

json.dump({'ops': len(ops), 'slots': slots, 'quads': qs},
          io.open('work/_m1_screen.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
