
import json
rows = json.load(open("work/_atlas_stats.json"))
disk = sum(r["file_bytes"] for r in rows); dec = sum(r["rgba"] for r in rows)
print("images", len(rows), "disk MB", round(disk/2**20,1), "decoded MiB", round(dec/2**20,1), "amplification", round(dec/disk,1))
print("median decoded KiB", round(sorted(r["rgba"] for r in rows)[len(rows)//2]/1024,1))
print(">512 in a dim:", sum(1 for r in rows if r["w"]>512 or r["h"]>512))
print(">256 in a dim:", sum(1 for r in rows if r["w"]>256 or r["h"]>256))
print("<=256 both dims (atlas-friendly):", sum(1 for r in rows if r["w"]<=256 and r["h"]<=256),
      " decoded MiB", round(sum(r["rgba"] for r in rows if r["w"]<=256 and r["h"]<=256)/2**20,1))
print("<=256 both dims disk KiB", round(sum(r["file_bytes"] for r in rows if r["w"]<=256 and r["h"]<=256)/1024,1))
