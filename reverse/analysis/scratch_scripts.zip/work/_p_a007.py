import io, os
path = "crates/wolf-cli/src/main.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """        let message = game.messages.last().expect("layout implies a message");
        let preview: String = message.text.chars().take(60).collect();"""
b = """        let message = game.messages.last().expect("layout implies a message");
        let vars = game.message_vars();
        let preview: String = message.text.chars().take(60).collect();"""
assert t.count(a) == 1
t = t.replace(a, b)
a2 = """            layout.font_px,
            layout.rows.first().map_or(0.0, |row| row.rect[0]),
            layout.rows.first().map_or(0.0, |row| row.rect[1]),
            layout.rows.first().map_or(0.0, |row| row.rect[2]),"""
b2 = """            layout.font_px,
            vars.x,
            vars.y,
            vars.wrap_width(),"""
assert t.count(a2) == 1
t = t.replace(a2, b2)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")