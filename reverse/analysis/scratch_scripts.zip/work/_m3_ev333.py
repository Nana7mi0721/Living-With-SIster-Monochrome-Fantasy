import json,sys
sys.stdout.reconfigure(encoding='utf-8')
d={e['id']:e for e in json.load(open('work/_ce_full.json',encoding='utf-8'))}
e=d[333]
cmds=e['cmds']
print('ev333 first 40 real cmds:')
n=0
for i,c in enumerate(cmds):
    if c['c']==0: continue
    print(i, c['c'], c['a'][:8], c['s'][:2], 'depth',c['bd'])
    n+=1
    if n>=40: break
print()
print('ev333 150 head values (first 30 distinct arg0):')
import collections
cnt=collections.Counter()
for i,c in enumerate(cmds):
    if c['c']==150: cnt[c['a'][0]]+=1
print(cnt.most_common(20))
