import io, os
root = r'E:/Study/github program/imoto life'
def read(p):
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()
def write(p, s):
    with io.open(p + '.new', 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    os.replace(p + '.new', p)
p = os.path.join(root, 'crates/wolf-save/tests/rebuild.rs')
s = read(p)
add = read(os.path.join(root, 'work/_add_rebuild_tests.rs'))
s = s.rstrip() + chr(10) + add
old = '//! * SaveFile::rebuild re-encodes SavePart1/2/3/4/5 from their typed views and' + chr(10) + '//!   copies only VariableDatabase and SavePart7, which have no writer yet.'
new = '//! * SaveFile::rebuild re-encodes SavePart1/2/3/4/5 and the VariableDatabase from' + chr(10) + '//!   their typed views and copies only SavePart7, which has no writer yet.'
assert old in s, 'header comment anchor missing'
s = s.replace(old, new, 1)
write(p, s)
print('ok lines', len(s.split(chr(10))))