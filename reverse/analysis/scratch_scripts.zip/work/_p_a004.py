import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
anchor = """        crate::message::Vars {
            x: sys(1) as f32,
            y: sys(2) as f32,
            font_px: sys(8) as f32,
            chars_per_second: sys(9),
            preroll: sys(10),
            width,
            cursor_offset,
            screen_w: crate::picture::SCREEN_W as f32,
        }
    }

    /// Preselects an option of the current choice prompt."""
new = """        crate::message::Vars {
            x: sys(1) as f32,
            y: sys(2) as f32,
            font_px: sys(8) as f32,
            chars_per_second: sys(9),
            preroll: sys(10),
            width,
            cursor_offset,
            screen_w: crate::picture::SCREEN_W as f32,
        }
    }

    /// The newest 101 message, laid out with its inline styling.
    ///
    /// Colour escapes resolve through the SysDatabase palette the same way text
    /// pictures do; the plain [crate::message::layout] would drop the colour and
    /// outline escapes and fold every glyph into one Sys8-sized run.
    #[must_use]
    pub fn message_layout(&self) -> Option<crate::message::Layout> {
        let message = self.messages.last()?;
        let vars = self.message_vars();
        let colours = PictureColours {
            databases: &self.databases,
        };
        Some(crate::message::layout_styled(
            &message.text,
            &vars,
            message.frames,
            &colours,
        ))
    }

    /// Preselects an option of the current choice prompt."""
assert t.count(anchor) == 1
t = t.replace(anchor, new)
anchor2 = "impl crate::textpic::Colours for PictureColours<'_> {"
assert t.count(anchor2) == 1
new2 = anchor2 + "\n\nimpl crate::message::Colours for PictureColours<'_> {\n    fn colour(&self, index: u32) -> Option<[u8; 3]> {\n        self.databases.colour(index as i32)\n    }\n}"
t = t.replace(anchor2, new2)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")