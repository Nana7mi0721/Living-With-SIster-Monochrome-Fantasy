import io, os
root = r'E:/Study/github program/imoto life'
def read(p):
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()
def write(p, s):
    with io.open(p + '.new', 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    os.replace(p + '.new', p)
spec = read(os.path.join(root, 'work/_p30_spec112.md'))
extra = read(os.path.join(root, 'work/_p30_spec145.md'))
p = os.path.join(root, 'docs/SAVE_SPEC.md')
s = read(p)
start = s.index('### 11.2 全文件 rebuild 与逐段编码器')
end = s.index('## 12. 实现坑点汇总')
s = s[:start] + spec.rstrip() + chr(10) + chr(10) + '---' + chr(10) + chr(10) + s[end:]
start = s.index('### 14.4 与「opcode 220 mode 0（运行中整档保存）」的关系')
s = s[:start] + extra.rstrip() + chr(10)
write(p, s)
print('spec lines', len(s.split(chr(10))))
t = read(os.path.join(root, 'work/_p30_220112.md'))
p2 = os.path.join(root, 'docs/OPCODE_220_SAVE.md')
s2 = read(p2)
start2 = s2.index('### 11.2 游戏层')
end2 = s2.index('### 11.3 测试')
s2 = s2[:start2] + t.rstrip() + chr(10) + chr(10) + s2[end2:]
write(p2, s2)
print('220 lines', len(s2.split(chr(10))))