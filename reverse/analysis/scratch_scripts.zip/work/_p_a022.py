import io, os
path = "docs/M2_SLICE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """| 存档/读档（220/221/222） | **读侧与 221/222 已落地**：`--load-save` 重建画面（Part3 通常变量 / セルフ変数 / 指文字列、Part2 时间与 Sys3/4、Part5 图片表）；221/222 经 `SaveOp` 读写并落盘，9 档 9/9 逐字节可逆。**220 mode 0 的整档保存仍未实现**（见 §4.5） |"""
b = """| 存档/读档（220/221/222） | **读侧、221/222 与 220 mode 0 均已落地**：`--load-save` 重建画面（Part3 通常变量 / セルフ変数 / 指文字列、Part2 时间与 Sys3/4、Part5 图片表）；221/222 经 `SaveOp` 读写并落盘，9 档 9/9 逐字节可逆；`Game::save_to` 从模板 + 运行时状态重建 Part2/3/5 与 vardb（见 §4.5）。剩 221 flag=1 站点与 retail 04 字体记录的字节级写回未验证 |"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")