$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
$src = @"
using System;
using System.Runtime.InteropServices;
public class Win32 {
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
}
"@
Add-Type -TypeDefinition $src
$gameDir = 'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
$exe = Join-Path $gameDir 'Game.exe'
$proc = Start-Process -FilePath $exe -WorkingDirectory $gameDir -PassThru
Start-Sleep -Seconds 15
$proc.Refresh()
$h = $proc.MainWindowHandle
if ($h -eq [IntPtr]::Zero) { Write-Output 'no main window handle'; $p2 = Get-Process | Where-Object { $_.MainWindowTitle -ne '' } | Select-Object -First 5; $p2 | ForEach-Object { Write-Output ("win: " + $_.ProcessName + " | " + $_.MainWindowTitle) }; }
[void][Win32]::SetForegroundWindow($h)
Start-Sleep -Milliseconds 800
$r = New-Object Win32+RECT
[void][Win32]::GetWindowRect($h, [ref]$r)
Write-Output ("rect: " + $r.Left + "," + $r.Top + " " + ($r.Right-$r.Left) + "x" + ($r.Bottom-$r.Top))
$w = $r.Right - $r.Left
$hh = $r.Bottom - $r.Top
if ($w -le 0 -or $hh -le 0) { $w = 1024; $hh = 576; $r.Left = 0; $r.Top = 0 }
$bmp = New-Object System.Drawing.Bitmap $w, $hh
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($r.Left, $r.Top, 0, 0, (New-Object System.Drawing.Size $w, $hh))
$out = 'E:\Study\github program\imoto life\work\out\original_title.png'
$bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Output ("saved: " + $out)
try { Stop-Process -Id $proc.Id -Force } catch { Write-Output 'process already gone' }
Write-Output 'done'
