import io, os
def patch(path, pairs):
    t = io.open(path, encoding="utf-8", newline="").read()
    for a, b in pairs:
        assert t.count(a) == 1, (path, a, t.count(a))
        t = t.replace(a, b)
    io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
    os.replace(path + ".new", path)

patch("crates/wolf-game/src/game.rs", [
("""    fn show_message(&mut self, text: &str, face: Option<i32>) {
        self.messages.push(Message {
            text: text.to_owned(),
            face,
            frames: 0,
        });
        self.stats.messages += 1;
    }""",
"""    fn show_message(&mut self, text: &str, face: Option<i32>) {
        // The engine keeps at most one message window: a new 101 replaces the old
        // text rather than stacking behind it.
        self.messages.clear();
        self.messages.push(Message {
            text: text.to_owned(),
            face,
            frames: 0,
        });
        self.stats.messages += 1;
    }"""),
])
print("patched")