
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class N2 {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, int extra);
}
"@
$gameDir = 'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
$before = Get-ChildItem -Path $gameDir -Recurse -Include *.png,*.bmp -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
$p = Start-Process -FilePath (Join-Path $gameDir 'Game.exe') -WorkingDirectory $gameDir -PassThru
Start-Sleep -Seconds 8
$h = $p.MainWindowHandle
Write-Output ("hwnd=" + $h)
[void][N2]::ShowWindow($h, 9)
[void][N2]::SetForegroundWindow($h)
Start-Sleep -Milliseconds 900
for ($i = 0; $i -lt 8; $i++) {
  [N2]::keybd_event(0x2C, 0x37, 0, 0)
  Start-Sleep -Milliseconds 80
  [N2]::keybd_event(0x2C, 0x37, 2, 0)
  Start-Sleep -Milliseconds 1200
  [N2]::keybd_event(0x0D, 0x1C, 0, 0)
  Start-Sleep -Milliseconds 80
  [N2]::keybd_event(0x0D, 0x1C, 2, 0)
  Start-Sleep -Seconds 2
}
Start-Sleep -Seconds 1
$after = Get-ChildItem -Path $gameDir -Recurse -Include *.png,*.bmp -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
$new = Compare-Object $before $after | Where-Object { $_.SideIndicator -eq '=>' } | Select-Object -ExpandProperty InputObject
Write-Output ("new files: " + ($new -join ', '))
[void]$p.CloseMainWindow()
Start-Sleep -Seconds 1
if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force }
Write-Output "done"
