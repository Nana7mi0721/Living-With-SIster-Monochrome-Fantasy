# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
allsites=[]
for ev in ce:
    for pc,c in enumerate(ev['cmds']):
        code,a,s = norm(c); allsites.append(('ce',ev['id'],pc,code,a,s))
for mn,mp in maps.items():
    if not isinstance(mp,dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc,c in enumerate(ev['cmds']):
            code,a,s = norm(c); allsites.append(('map:'+mn,ev.get('id'),pc,code,a,s))
def bits(a):
    v = a[1] & 0xFFFFFFFF if len(a)>1 else 0
    return (v & 0xF, (v>>4)&0xF, [(v>>(12+i))&1 for i in range(5)], (v>>24)&1, v)
byname={}
for ev in ce: byname.setdefault(ev['title'], ev['id'])
def target_of(x):
    if x[3]==300: return byname.get(x[5][0]) if x[5] else None
    raw = x[4][0]
    if 500000 <= raw <= 599999: return raw-500000
    if 600000 <= raw <= 699999: return raw-600000
    return None

print('== sites with strc>0: literal-count vs var-count ==')
tab = collections.Counter()
varword = collections.Counter()
for x in allsites:
    if x[3] not in (210,300): continue
    num, st, en, rv, raw = bits(x[4])
    if st == 0: continue
    lit = sum(en[:st])
    var = st - lit
    tab[(x[3], st, lit, var)] += 1
    for k in range(st):
        w = x[4][2+num+k]
        if not en[k]: varword[w]+=1
for k in sorted(tab): print('  code=%d strc=%d literal=%d var=%d : %d' % (k[0],k[1],k[2],k[3],tab[k]))
print()
print('== nonzero string-arg words (variable args) ==')
for w,n in varword.most_common(): print('   %-10d : %d' % (w,n))
print()
print('== do callees read CSelf5..8 as STRINGS? ==')
# callee string-slot readers: 112 a[0], 122 a[0], 250 dest, 101 \cself
readers = collections.defaultdict(set)
for ev in ce:
    for c in ev['cmds']:
        code,a,s = norm(c)
        tgt_idx = {112:0, 122:0}
        if code in (112,122) and a:
            u = a[0] & 0xFFFFFFFF
            if 1600000 <= u <= 1600999: readers[ev['id']].add(u-1600000)
        if code == 101:
            for st_ in s:
                import re
                for m in re.finditer(r'\\\\cself\[(\d+)\]', st_):
                    n = int(m.group(1))
                    if 5 <= n <= 8: readers[ev['id']].add(n)
res = collections.Counter()
for x in allsites:
    if x[3] not in (210,300): continue
    num, st, en, rv, raw = bits(x[4])
    if st == 0: continue
    tgt = target_of(x)
    if tgt is None: continue
    r = readers.get(tgt, set())
    for k in range(st):
        slot = 5 + k
        res[(k, slot, slot in r)] += 1
for k in sorted(res): print('   arg#%d -> CSelf%d  callee reads it: %s : %d' % (k[0],k[1],k[2],res[k]))
