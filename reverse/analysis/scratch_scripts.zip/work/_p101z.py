
import json,io,sys
sys.stdout.reconfigure(encoding='utf-8')
d=json.load(io.open('work/wolftl/dump/db/SysDatabase.json',encoding='utf-8'))
T=d['types']
for ti in (6,12,16,17,18,24):
    t=T[ti]
    print('=== type',ti,t['name'],'fields=',json.dumps(t['fields'],ensure_ascii=False),'rows=',len(t['data']))
    for i,row in enumerate(t['data']):
        if ti==6:
            print('  %3d %s'%(i,row.get('name')))
        else:
            print('  %2d %-24s %s'%(i,row.get('name'),json.dumps(row.get('data'),ensure_ascii=False)[:110]))
