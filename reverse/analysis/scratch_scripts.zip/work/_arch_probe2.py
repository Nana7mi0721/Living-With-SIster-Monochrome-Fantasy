
import os, collections, struct, glob
os.chdir(r'E:\Study\github program\imoto life')
root='work/alldata'
ext=collections.Counter(); size=collections.Counter()
for dp,dn,fn in os.walk(root):
    for f in fn:
        e=os.path.splitext(f)[1].lower(); ext[e]+=1
        try: size[e]+=os.path.getsize(os.path.join(dp,f))
        except: pass
print('ext counts:', ext.most_common(20))
print('ext bytes MB:', {k:round(v/1048576,1) for k,v in size.most_common(20)})

# PNG header analysis: bit depth, color type, palette
pn=collections.Counter()
for dp,dn,fn in os.walk(root):
    for f in fn:
        if f.lower().endswith('.png'):
            p=os.path.join(dp,f)
            try:
                b=open(p,'rb').read(33)
                if b[:8]==b'\x89PNG\r\n\x1a\n':
                    w,h=struct.unpack('>II',b[16:24]); bd=b[24]; ct=b[25]
                    pn[(bd,ct)]+=1
            except: pass
print('PNG (bitdepth,colortype) counts:', pn.most_common())
print('colortype meaning: 0=gray 2=rgb 3=palette 4=gray+a 6=rgba')
