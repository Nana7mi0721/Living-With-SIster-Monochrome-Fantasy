import json, io, sys
from collections import Counter
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
mp = json.load(io.open('work/maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'], c['a']
    return c['code'], c['ints']
def cmds_all():
    for e in ce:
        for c in e['cmds']: yield norm(c)
    for mn,m in mp.items():
        for ev in m['events']:
            for c in ev['cmds']: yield norm(c)
for grp,name in [(2,'0x2000'),(3,'0x3000'),(4,'0x4000'),(6,'0x6000')]:
    a2=Counter(); n=0; samples=[]
    for code,a in cmds_all():
        if code not in (121,124): continue
        if len(a)<4: continue
        if (a[3]>>12)&0xF != grp: continue
        n+=1; a2[a[2]]+=1
        if len(samples)<12: samples.append(tuple(a))
    print('===', name, 'n=', n)
    print('  arg2 top:', a2.most_common(20))
    for s in samples: print('   ', s)