import json, io, os
p = "docs/BASELINE.json"
d = json.load(io.open(p, encoding="utf-8"))
acc = d["boot_screens"]["acceptance_vs_retail_printscreen"]
for entry in acc:
    if entry.get("screen", "").startswith("Picture/title01.jpg"):
        entry["frame"] = 716
        entry["mean_abs"] = 0.012
        entry["max_abs"] = 1
        entry["psnr_db"] = 67.20
        entry["within_2_pct"] = 100.0
        entry["residual"] = "packed: 100% of pixels within 2; the last 1-byte difference is the blink phase (see picture_tone)"
        entry["phase_note"] = "frame 700 sits on blink phase 6 (tone byte 153) and measures 0.587; frame 716 sits on phase 22 (tone byte 221) and matches retail's 222 to within 1"
d["picture_tone"] = {
 "source": "290 Effect kind 5 (blink B / auto flash), e.g. TitleMap event 2 pc91 [80, 30, 12001, 12001, -50, -50, -50]",
 "law": "period = duration frames; percent ramps from 100+target to 100; byte = round(255*percent/100); colour = round(src*byte/255) per channel; alpha untouched (DxLib SetDrawBright semantics)",
 "measured": "byte = 128 + 127*(age % 30)/30 for the title banner, so it flashes twice per second; retail frame 21_21_35 caught byte 222 and another capture caught 188",
 "unreachable": "222 is not exactly reachable with a 30 frame period (step ~4.23); 221 is the nearest phase and leaves a 1-byte residual",
 "baseline_frame": 716,
 "note": "pixel comparisons against the retail PrintScreen must be taken at frame % 30 == 26 while the title menu is parked, or the phase, not the renderer, decides the score"
}
tmp = p + ".new"
io.open(tmp, "w", encoding="utf-8", newline="").write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")
os.replace(tmp, p)
print("keys", len(d), "title frame", [e.get("frame") for e in acc])
