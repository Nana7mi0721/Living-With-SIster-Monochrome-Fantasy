import json,collections
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
def a1(s): return (s.encode('ascii','ignore').decode() if isinstance(s,str) else s)
for typ in (13,21,10):
    evs=collections.defaultdict(list)
    for e in ces:
        for i,cm in enumerate(e['cmds']):
            if cm['c']==250 and cm.get('a') and cm['a'][0]==typ:
                a=cm['a']; flags=a[3] if len(a)>3 else 0
                bit16 = bool(flags & 0x10000)
                evs[e['id']].append((i,len(a),hex(flags) if isinstance(flags,int) else flags,bit16))
    print(f"=== DB type {typ}: {len(evs)} events, {sum(len(v) for v in evs.values())} sites ===")
    for cid,lst in sorted(evs.items()):
        print(f"  CE{cid:<4} {len(lst)} sites; first: pc{lst[0][0]} argc{lst[0][1]} flags{lst[0][2]} bit16={lst[0][3]}")

