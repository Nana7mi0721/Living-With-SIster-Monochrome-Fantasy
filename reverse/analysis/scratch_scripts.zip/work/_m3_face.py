import json,sys,collections
sys.stdout.reconfigure(encoding='utf-8')
d={e['id']:e for e in json.load(open('work/_ce_full.json',encoding='utf-8'))}
for eid in (333,340,341,365,410,445):
    e=d[eid]
    print('=== ev',eid)
    for i,c in enumerate(e['cmds']):
        if c['c']!=150: continue
        a=c['a']
        if len(a)>=2 and a[1] in (1100,1110,1120,1020,1184,1210,1220,2104,1901,1000):
            print(' pc',i,'arg0',a[0],'args',a,'s',c['s'][:1])
