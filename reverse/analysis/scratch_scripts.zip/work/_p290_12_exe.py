
import zipfile, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')
print('Editor.exe bytes', len(data))
s = data.decode('cp932', errors='replace')
for pat in ['ピクチャエフェクト', 'シェイク', '点滅Ａ', '描画座標シフト']:
    idxs = [m.start() for m in re.finditer(re.escape(pat), s)]
    print('---', pat, 'count', len(idxs), idxs[:20])
# dump context around every フラッシュ occurrence
for m in re.finditer('フラッシュ', s):
    i = m.start()
    print('===== off', hex(i), repr(s[max(0,i-120):i+220]))
