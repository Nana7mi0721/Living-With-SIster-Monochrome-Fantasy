
import json, os, collections
os.chdir(r'E:\Study\github program\imoto life')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
# 140 Sound: args[0] = channel?, sample the tuples
c140=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==140:
            c140[tuple(c['a'][:3])]+=1
print('140 arg0..2 top:', c140.most_common(15))
# strings used
s140=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==140 and c['s']: s140[c['s'][0]]+=1
print('140 strings top:', s140.most_common(8))
# 150 picture: arg0 types
c150=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==150:
            c150[(c['a'][0]>>4)&0x07]+=1
print('150 arg0 type bits:', c150.most_common())
# 250 database arg0 (db type)
c250=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==250: c250[(c['a'][0], len(c['s']))]+=1
print('250 (dbtype,strcount):', c250.most_common(12))
# 102 Choices: how many options
c102=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==102: c102[(c['a'][0], len(c['s']))]+=1
print('102 (arg0,strcount):', c102.most_common(8))
# 210 CommonEvent arg layouts: what is arg0?
c210=collections.Counter()
for e in ev:
    for c in e['cmds']:
        if c['c']==210 and len(c['a'])>=2:
            c210[(c['a'][0], c['a'][1])]+=1
print('210 (arg0,arg1) top:', c210.most_common(10))
