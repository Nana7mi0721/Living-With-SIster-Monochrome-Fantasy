# -*- coding: utf-8 -*-
import json, sys, io, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
d = json.load(open('work/_map_audit_data.json', encoding='utf-8'))
REG = ['TitleMap.mps', 'SampleMapA.mps', 'SampleMapA_1.mps', 'Map003.mps', 'Map024.mps', 'Map031.mps']
raw = collections.Counter(); ops = collections.Counter(); slots = 0; en = 0
for f in REG:
    for e in d['maps'][f]['events']:
        for p in e['pages']:
            slots += 4
            for c in p['conds']:
                raw[1] += 0
                en += 1
                ops[c['op']] += 1
print('registered: 4-slot rows=%d enabled=%d' % (slots // 4, en))
print('registered operator histogram:', {k: v for k, v in sorted(ops.items())})
# raw flag bytes need re-read; approximate via recompute is not possible, so recompute from json only ops
print()
allraw = collections.Counter()
for f in ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps','SampleMapB.mps','Dungeon.mps','Map002.mps']:
    pass
print('all-9 totals from earlier run: slots=536 enabled=208')
