import io, os
def patch(path, pairs):
    t = io.open(path, encoding="utf-8", newline="").read()
    for a, b in pairs:
        assert t.count(a) == 1, (path, a, t.count(a))
        t = t.replace(a, b)
    io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
    os.replace(path + ".new", path)

patch("docs/OPCODE_220_SAVE.md", [
("""- 220 `mode=0` is **still a diagnostic note** (`full save ... not modelled yet`): building a complete part1 map snapshot, event runtime state and variable database from our live `Game` is not implemented yet. This is the one remaining piece of the 220 story.""",
"""- 220 `mode=0` queues `SaveRequest::Save(path)`; `Game::frame` calls `Game::save_to`, which clones the save the game was loaded from (or `Save/System.sav` for a new game) as the map template, copies play time, Sys3/Sys4, the 800 normal variables and every live common-event self variable / self string into `SavePart2`/`SavePart3`, then writes `to_bytes_rebuilt()`. The template supplies `SavePart1`（含 map_tiles）and the raw `vardb`/`part7` bytes; variable-database writes made through opcode 250 are not yet persisted into the save. See SAVE_SPEC §14.4."""),
("""| wolf-game | `a_save_file_round_trips_through_the_writer` | `write_save` 后 `read_save` 的 `to_bytes()` 与原件逐字节相等 |""",
"""| wolf-game | `a_save_file_round_trips_through_the_writer` | `write_save` 后 `read_save` 的 `to_bytes()` 与原件逐字节相等 |
| wolf-game | `a_save_written_from_a_retail_template_round_trips` | 用 SaveData01 当模板写盘，normal var 7 / playtime / Sys3 / Sys4 都能读回 |"""),
])

patch("docs/SAVE_SPEC.md", [
("""现在这条链已经通了：VM 侧持有 `SavePart1..5` 的 typed 值 → `set_partX` 或直接改字段 →
`to_bytes_rebuilt()` → 写到 `Save/SaveData%02d.sav`。仍然缺的两块：

- **VariableDatabase 没有编码器**：可変DB 的写入（opcode 250 写 CDataBase）目前只能靠
  `replace_part(VARDB_ID, 新字节)`，而「按 type/row/field 改一格」还没有 API。
- **SavePart1 的地图快照**：`map_tiles` 是 64×36×3 的 u32 快照，谁在什么时候填它仍未确认
  （§13）；写出侧只保证「原样搬运改过的别的字段时不动它」。""",
"""现在这条链已经通了：VM 侧持有 `SavePart1..5` 的 typed 值 → `set_partX` 或直接改字段 →
`to_bytes_rebuilt()` → 写到 `Save/SaveData%02d.sav`。`crates/wolf-game/src/game.rs` 的
`Game::save_to` 已经把运行中的 `Game` 接上这条链：以「本局载入的存档」或新游戏的
`Save/System.sav` 为模板，写入 playtime、Sys3/Sys4、800 个通常変数、全部活着的公共事件
`self` 数值变量（0..99）与 `CSelf5..9` 字符串。仍然缺的两块：

- **VariableDatabase 没有编码器/单元格写入 API**：`SaveFile::rebuild()` 原样复制模板的
  `vardb` 字节，所以 opcode 250 对 CDataBase 的写入不会进入 220 mode 0 写出的存档。
  可用 `replace_part(VARDB_ID, 新字节)` 整体替换，但没有「按 type/row/field 改一格」的接口。
- **SavePart1 的地图快照**：`map_tiles` 是 64×36×3 的 u32 快照，由模板原样搬运；谁在什么
  时候填它仍未确认（§13）。"""),
])
print("patched")