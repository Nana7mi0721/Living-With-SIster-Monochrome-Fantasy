# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
allsites = []
by_id = {}
for ev in ce:
    by_id[ev['id']] = ev
    for pc, c in enumerate(ev['cmds']):
        code,a,s = norm(c); allsites.append(('ce', ev['id'], pc, code, a, s))
for mn, mp in maps.items():
    if not isinstance(mp, dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc, c in enumerate(ev['cmds']):
            code,a,s = norm(c); allsites.append(('map:'+mn, ev.get('id'), pc, code, a, s))
def bits(a):
    v = a[1] & 0xFFFFFFFF if len(a)>1 else 0
    return (v & 0xF, (v>>4)&0xF, [(v>>(12+i))&1 for i in range(5)], (v>>24)&1, v)

# s[0] content for 210
e0 = collections.Counter()
for x in allsites:
    if x[3]==210 and x[5]:
        e0[x[5][0]] += 1
print('210 s[0] distinct:', len(e0), 'top:', e0.most_common(5))

# enabled bit patterns
print()
pat = collections.Counter()
for x in allsites:
    if x[3] in (210,300) and bits(x[4])[1] > 0:
        pat[(x[3], bits(x[4])[1], tuple(bits(x[4])[2]))] += 1
for k in sorted(pat): print('  code=%d strc=%d en=%s : %d' % (k[0],k[1],k[2],pat[k]))

# callee index
byname = {}
for ev in ce: byname.setdefault(ev['title'], ev['id'])

def target_of(x):
    code, a, s = x[3], x[4], x[5]
    if code == 300:
        return byname.get(s[0]) if s else None
    raw = a[0]
    if 500000 <= raw <= 599999: return raw-500000
    if 600000 <= raw <= 699999: return raw-600000
    return None

def reads_self(evid, slots):
    """set of self slots (0..999) referenced as 1600000+n anywhere in callee."""
    ev = by_id.get(evid)
    if ev is None: return None
    got = set()
    for c in ev['cmds']:
        code,a,s = norm(c)
        for v in a:
            u = v & 0xFFFFFFFF
            if 1600000 <= u <= 1600999:
                got.add(u - 1600000)
    return got

# sites with string args (strc>0)
sites = [x for x in allsites if x[3] in (210,300) and bits(x[4])[1] > 0]
print()
print('sites with strc>0:', len(sites))
res = collections.Counter()
detail = []
for x in sites:
    num, st, en, rv, raw = bits(x[4])
    tgt = target_of(x)
    got = reads_self(tgt, None) if tgt is not None else None
    hit5 = (5 in got) if got is not None else None
    hit8 = any(k in got for k in (5,6,7,8)) if got is not None else None
    res[(x[3], st, tgt is not None, hit5, hit8)] += 1
    detail.append((x, tgt, got))
for k in sorted(res, key=str):
    print('  code=%d strc=%d resolved=%s reads5=%s reads5..8=%s : %d' % (k[0],k[1],k[2],k[3],k[4],res[k]))

print()
print('== which of 5..8 read (only sites with strc>0, resolved callee) ==')
sl = collections.Counter()
for x, tgt, got in detail:
    if got is None: continue
    for k in (5,6,7,8):
        if k in got: sl[k] += 1
print('  slot5:', sl[5], ' slot6:', sl[6], ' slot7:', sl[7], ' slot8:', sl[8], ' total sites:', len(detail))
