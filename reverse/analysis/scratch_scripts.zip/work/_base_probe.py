
import json, io, os
p = 'docs/BASELINE.json'
raw = open(p, encoding='utf-8').read()
print('crlf', raw.count('\r\n'), 'lf', raw.count('\n'))
d = json.loads(raw)
print('keys', list(d.keys()))
