
import json,io,collections,sys
sys.stdout.reconfigure(encoding='utf-8')
ce=json.load(io.open('work/_ce_full.json',encoding='utf-8'))
mp=json.load(io.open('work/maps_full.json',encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'],c['a'],c['s']
    return c.get('code',0),c.get('ints',[]),c.get('strs',[])
cec=[(e['id'],norm(c)) for e in ce for c in e['cmds']]
mpc=[('M',norm(c)) for m in mp.values() for ev in m.get('events',[]) for c in ev.get('cmds',[])]
print('101 in CE',sum(1 for _,c in cec if c[0]==101),'in maps',sum(1 for _,c in mpc if c[0]==101))
print('101 empty-text',sum(1 for _,c in cec+mpc if c[0]==101 and (not c[2] or c[2][0]=='')))
for base,name in ((9000000,'Sys0 顔番号'),(9000012,'Sys12 表示中'),(9000013,'Sys13 実行中'),(9000014,'Sys14 選択肢表示'),(9000020,'Sys20 カーソル位置'),(9000137,'Sys137 拡大率'),(9000073,'Sys73 マウス入力'),(9000009,'Sys9 速度'),(9000010,'Sys10 ウェイト'),(9000008,'Sys8 フォント'),(9000021,'Sys21 影'),(9000023,'Sys23 ルビ')):
    w=[(eid,op,a[:4]) for eid,(op,a,s) in cec+mpc if op in (121,124) and a and a[0]==base]
    print('%-16s writers %4d  %s'%(name,len(w),w[:3]))
# face idiom: 101 preceded within 6 cmds by write to Sys0
cev={e['id']:[norm(c) for c in e['cmds']] for e in ce}
cnt=0; tot=0; samples=[]
for eid,cmds in cev.items():
    for i,(op,a,s) in enumerate(cmds):
        if op!=101: continue
        tot+=1
        for j in range(max(0,i-6),i):
            o2,a2,s2=cmds[j]
            if o2 in (121,124,250) and a2:
                tgt=a2[0] if o2 in (121,124) else (a2[4] if len(a2)>4 else -1)
                if tgt==9000000:
                    cnt+=1
                    if len(samples)<5: samples.append((eid,i,cmds[j]))
                    break
print('101 with Sys0 write within 6 preceding cmds: %d / %d'%(cnt,tot))
for x in samples: print('   ',x)
