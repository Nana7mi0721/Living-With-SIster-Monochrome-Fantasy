import io, os
p = "crates/wolf-game/src/picture.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = """                        if std::env::var_os("WOLF_DEBUG_ERASE").is_some() {
                            let before: Vec<i32> = self.pictures.keys().copied().collect();
                            eprintln!("erase span {lo}..{hi} (args {:?}) live {:?}", cmd.args, before);
                        }
"""
assert t.count(a) == 1
t = t.replace(a, "")
open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("removed trace")