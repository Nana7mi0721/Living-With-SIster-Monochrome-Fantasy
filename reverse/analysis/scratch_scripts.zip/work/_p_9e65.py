import io, os
path = "crates/wolf-game/src/savegame.rs"
t = io.open(path, encoding="utf-8", newline="").read()
lines = t.split("\n")
start = next(i for i, line in enumerate(lines) if "The inverse of [`decode_picture_text`]" in line)
end = None
for i in range(start, len(lines)):
    if lines[i].startswith("fn encode_escape"):
        depth = 0
        for j in range(i, len(lines)):
            depth += lines[j].count("{") - lines[j].count("}")
            if depth == 0 and j > i:
                end = j
                break
        break
assert end is not None, "encode_escape end not found"
new = r"""/// The inverse of [`decode_picture_text`] for the escapes the retail saves use:
/// `\E` (outline), `\f[n]` (font size) and `\c[n]` (palette index). Other escapes are
/// left literal, which is harmless: the save is a snapshot of already-expanded text.
#[must_use]
pub fn encode_picture_text(text: &str) -> Vec<u8> {
    let chars: Vec<char> = text.chars().collect();
    let mut out = Vec::new();
    let mut index = 0;
    while index < chars.len() {
        if chars[index] == '\\' {
            if let Some((consumed, bytes)) = encode_escape(&chars[index..]) {
                out.extend_from_slice(&bytes);
                index += consumed;
                continue;
            }
        }
        let mut buffer = [0u8; 4];
        out.extend_from_slice(chars[index].encode_utf8(&mut buffer).as_bytes());
        index += 1;
    }
    out.push(0);
    out
}

fn encode_escape(chars: &[char]) -> Option<(usize, Vec<u8>)> {
    if chars.get(1) == Some(&'E') {
        return Some((2, vec![1, 2, 5]));
    }
    let kind = *chars.get(1)?;
    if (kind == 'f' || kind == 'c') && chars.get(2) == Some(&'[') {
        let mut end = 3;
        let mut value: i32 = 0;
        while let Some(digit) = chars.get(end).and_then(|ch| ch.to_digit(10)) {
            value = value.saturating_mul(10).saturating_add(digit as i32);
            end += 1;
        }
        if end == 3 || chars.get(end) != Some(&']') {
            return None;
        }
        let code = if kind == 'c' && value == 0 { 0x0f } else { value + 14 };
        if !(1..=255).contains(&code) {
            return None;
        }
        let bytes = if kind == 'f' {
            vec![1, 5, 3, 0x0e, code as u8, 1]
        } else {
            vec![1, 6, 2, 0x0e, 0x0e, code as u8, 1]
        };
        return Some((end + 1, bytes));
    }
    None
}"""
lines[start:end+1] = new.split("\n")
io.open(path + ".new", "w", encoding="utf-8", newline="").write("\n".join(lines))
os.replace(path + ".new", path)
print("ok")