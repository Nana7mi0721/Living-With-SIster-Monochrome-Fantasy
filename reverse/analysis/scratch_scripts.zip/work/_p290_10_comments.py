
import json, io, sys, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
if isinstance(ce, dict): ce = list(ce.values())
# build per-type list of nearby comments
want = {3,7,8,9,10,0,1,2,4,5}
res = collections.defaultdict(list)
for ev in ce:
    cmds = ev.get('cmds') or []
    for i,c in enumerate(cmds):
        if c.get('c') != 290: continue
        a = c.get('a') or []
        if len(a) < 2: continue
        head = a[0]; t = (head>>4)&0xF
        if t not in want: continue
        comments=[]
        for j in range(max(0,i-10), i):
            cc = cmds[j]
            if cc.get('c')==103:
                s = (cc.get('s') or [''])
                comments.append(s[0] if s else '')
        # also the following command code (to see if a 150 follows later)
        nxt = [cmds[k].get('c') for k in range(i+1, min(len(cmds), i+4))]
        res[t].append((ev.get('id'), i, a[:7], comments[-2:], nxt))
for t in sorted(res):
    rows = res[t]
    print('==== type', t, 'n=', len(rows))
    seen=set()
    for (eid, pc, a, com, nxt) in rows:
        key = tuple(com)
        if key in seen and len(rows)>40: continue
        seen.add(key)
        print('  ev%-4s pc%-5d a=%s  com=%s next=%s' % (eid, pc, a, com, nxt))
