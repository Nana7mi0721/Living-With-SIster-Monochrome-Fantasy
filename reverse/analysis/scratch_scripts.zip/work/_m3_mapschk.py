
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
for mn,m in maps.items():
    evs=m.get("events",[])
    npg=[e.get("npg") for e in evs]
    p2=sum(1 for n in npg if n and n>1)
    print(mn,"events",len(evs),"npg>1",p2,"sum cmds",sum(len(e.get("cmds",[])) for e in evs))
    for e in evs[:2]:
        print("   sample event keys:",list(e.keys()),"npg",e.get("npg"),"cmds",len(e.get("cmds",[])))
