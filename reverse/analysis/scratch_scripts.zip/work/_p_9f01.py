import json
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
kinds={0:[],1:[],3:[],4:[]}
for ev in ce:
    for c in ev['cmds']:
        if c['c']!=150: continue
        a=c['a']
        h=a[0];
        act=h&0xF; typ=(h>>4)&7
        if act in (0,) and typ in kinds:
            kinds[typ].append((ev['id'],len(a),a,c['s']))
for t,rows in kinds.items():
    print('kind',t,'count',len(rows))
    for r in rows[:6]: print('   ev',r[0],'argc',r[1],r[2],'strs',r[3])
print()
print('kind4 argc histogram', __import__('collections').Counter(r[1] for r in kinds[4]))
print('kind3 argc histogram', __import__('collections').Counter(r[1] for r in kinds[3]))
print('kind1 argc histogram', __import__('collections').Counter(r[1] for r in kinds[1]))
print('kind0 argc histogram', __import__('collections').Counter(r[1] for r in kinds[0]).most_common(8))
