# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
allsites=[]
for ev in ce:
    for pc,c in enumerate(ev['cmds']):
        code,a,s = norm(c); allsites.append(('ce',ev['id'],pc,code,a,s))
for mn,mp in maps.items():
    if not isinstance(mp,dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc,c in enumerate(ev['cmds']):
            code,a,s = norm(c); allsites.append(('map:'+mn,ev.get('id'),pc,code,a,s))
def bits(a):
    v = a[1] & 0xFFFFFFFF if len(a)>1 else 0
    return (v & 0xF, (v>>4)&0xF, [(v>>(12+i))&1 for i in range(5)], (v>>24)&1, v)

print('== len(a) - 2 - num  vs  strc / en-count ==')
tab = collections.Counter()
for x in allsites:
    if x[3] not in (210,300): continue
    num, st, en, rv, raw = bits(x[4])
    extra = len(x[4]) - 2 - num
    tab[(x[3], num, st, sum(en[:st]), rv, extra)] += 1
for k in sorted(tab)[:40]:
    print('  code=%d num=%d strc=%d en=%d rv=%d extra=%d : %d' % (k+(tab[k],)))
print('  ... total keys', len(tab))
print()
print('== does extra == strc always hold? ==')
ok=bad=0
badset=collections.Counter()
for x in allsites:
    if x[3] not in (210,300): continue
    num, st, en, rv, raw = bits(x[4])
    extra = len(x[4]) - 2 - num
    want = st + (1 if rv else 0)
    if extra == want: ok+=1
    else:
        bad+=1
        badset[(x[3], num, st, rv, extra)] += 1
print('  match:', ok, ' mismatch:', bad)
for k in badset.most_common(15): print('    ', k, badset[k])
