# -*- coding: utf-8 -*-
"""Asset availability table for the M1 title screen.

Collects every asset path referenced by the M1 trace (150 picture file=, 140 sound,
270 party CharaChip) plus the assets the title event 42 draws by name, then resolves
each against the two extraction roots:
  work/full    - the partial extraction the CLI currently uses (--root default)
  work/alldata - the full 1.5 GB extraction (contains BGM/, Picture/, cg/ ...)

Reports: path, which roots contain it, file size, and pixel size for images (PIL).
Output: work/_m1_assets.json + stdout table.
"""
import io
import json
import os
import re
from collections import OrderedDict

ROOTS = [('work/full', 'full'), ('work/alldata', 'alldata')]

# --- collect from the trace -------------------------------------------------
PIC = re.compile(r'^  150 picture  #(-?\d+) kind (\d+) (\w+) file=(.*?) text=')
SND = re.compile(r'^  140 sound    (.*)$')
PTY = re.compile(r'^  270 party    (.*)$')

refs = OrderedDict()   # path -> set of sources


def add(path, source):
    if not path:
        return
    refs.setdefault(path, OrderedDict())
    refs[path][source] = refs[path].get(source, 0) + 1


with io.open('work/_m1_trace2.txt', encoding='utf-8') as fh:
    for raw in fh:
        line = raw.rstrip('\n')
        m = PIC.match(line)
        if m:
            add(m.group(4), '150 file')
            continue
        m = SND.match(line)
        if m:
            rest = m.group(1)
            print('# 140 raw:', rest)
            continue
        m = PTY.match(line)
        if m:
            print('# 270 raw:', m.group(1))

# --- resolve ---------------------------------------------------------------
def locate(path):
    found = []
    for root, tag in ROOTS:
        candidate = os.path.join(root, path.replace('\\', '/'))
        if os.path.isfile(candidate):
            found.append((tag, candidate, os.path.getsize(candidate)))
    return found


def pixel_size(candidate):
    try:
        from PIL import Image
        with Image.open(candidate) as im:
            return list(im.size)
    except Exception as exc:  # noqa: BLE001 - report, never raise
        return 'ERR:%s' % exc


table = []
for path, sources in refs.items():
    hits = locate(path)
    row = {'path': path, 'sources': dict(sources), 'hits': []}
    for tag, candidate, size in hits:
        row['hits'].append({'root': tag, 'bytes': size,
                            'pixels': pixel_size(candidate) if re.search(
                                r'\.(png|jpg|jpeg|bmp|webp)$', path, re.I) else None})
    table.append(row)

print('')
print('=== asset availability ===')
print('%-44s %-8s %-28s %s' % ('path', 'refs', 'roots', 'size'))
for row in table:
    roots = ','.join(h['root'] for h in row['hits']) or 'MISSING'
    detail = ''
    for h in row['hits']:
        detail += '%s:%dB%s ' % (h['root'], h['bytes'],
                                 (' %s' % (h['pixels'],)) if h['pixels'] else '')
    print('%-44s %-8d %-28s %s' % (row['path'][:44], sum(row['sources'].values()),
                                   roots, detail))

json.dump(table, io.open('work/_m1_assets.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
