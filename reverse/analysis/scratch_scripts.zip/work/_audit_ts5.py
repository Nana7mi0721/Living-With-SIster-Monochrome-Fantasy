
import json,os,io,glob
OUT=io.StringIO()
ts=json.load(open('work/fs_ts.json',encoding='utf-8'))
t5=ts[5]
OUT.write('tileset5 title=%r base=%r\n'%(t5['title'],t5['base']))
autos=[a for a in t5['autos'] if a]
OUT.write('nonempty autos %d\n'%len(autos))
disk=set()
for r,d,fs in os.walk('work/all/MapChip'):
    for f in fs: disk.add(f)
for a in autos:
    nm=a.split('/')[-1]
    OUT.write('%-30s in_disk=%s\n'%(repr(nm), nm in disk))
OUT.write('\n--- disk MapChip files matching b_ or base\n')
for f in sorted(disk):
    if f.startswith('b_') or 'at' in f:
        OUT.write('  %s\n'%f)
open('work/_audit_ts5.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
