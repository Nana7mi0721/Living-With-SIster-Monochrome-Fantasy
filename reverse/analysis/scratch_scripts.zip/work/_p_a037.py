import io, os
path = "crates/wolf-game/tests/opening.rs"
raw = open(path, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
marker = """    assert!(game.stats.messages > 0, "the opening narration never arrived");\n}\n"""
assert t.count(marker) == 1
add = """    assert!(game.stats.messages > 0, "the opening narration never arrived");\n}\n\n/// The new-game processing map (Map003 event 1) is the path the title menu takes:\n/// it draws its pre-game screen and then runs opcode 130 with map id -1. The\n/// measured meaning of -1 is MapData row 1, SampleMapA, and -2 is row 0, TitleMap\n/// (docs/ASSET_AUDIT.md section 3.6); the new game must land on the opening story.\n#[test]\nfn the_new_game_processing_map_teleports_into_the_opening() {\n    let root = data_root();\n    let mut game = match Game::new(&root) {\n        Ok(game) => game,\n        Err(err) => {\n            eprintln!("skipping: {err}");\n            return;\n        }\n    };\n    game.auto_advance = true;\n    if let Err(err) = game.start_map_event_by_name("Map003", 1) {\n        eprintln!("skipping: cannot start new-game processing: {err}");\n        return;\n    }\n    for _ in 0..600 {\n        let _ = game.frame();\n    }\n    assert!(\n        game.diagnostics\n            .keys()\n            .any(|line| line.contains("130 Teleport: MapData/SampleMapA.mps")),\n        "the new-game map never teleported: {:?}",\n        game.diagnostics.keys().collect::<Vec<_>>()\n    );\n    let prompt = game.choices.as_ref().expect("the opening prompt is open");\n    assert_eq!(\n        prompt.options,\n        ["广阔的战场", "广袤的森林", "微风吹拂而过的麦田", "有人在等我的家"],\n        "the teleport did not reach the opening prompt"\n    );\n    assert_eq!(game.stats.warnings, 0, "the new-game path produced warnings");\n}\n"""
t = t.replace(marker, add)
if crlf:
    t = t.replace(chr(10), chr(13) + chr(10))
open(path, "wb").write(t.encode("utf-8"))
print("done")