
from PIL import Image
src=r'C:/Users/REISEN/.dsh/attachments/v1/objects/48/48b03b8df72d48b419b159869356953a31eef9a3fc8e754e0d287e7a0c687e28'
im=Image.open(src); w,h=im.size
out=r'work/out'
# 6 rows x 2 cols at 2x, rows of 200px
rows=[(0,200),(195,395),(390,590),(585,785),(780,980),(975,1183)]
for ri,(a,b) in enumerate(rows):
    for ci,(x0,x1) in enumerate([(0,940),(930,1877)]):
        c=im.crop((x0,a,x1,b)).resize(((x1-x0)*2,(b-a)*2),Image.LANCZOS)
        c.save(f'{out}/t{ri}{ci}.png'); print(ri,ci,c.size)
