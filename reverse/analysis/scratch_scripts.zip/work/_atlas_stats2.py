
import json, collections
rows = json.load(open("work/_atlas_stats.json"))
for a in ("scene","hscene"):
    g = [r for r in rows if r["arch"]==a]
    print(a, "n=", len(g), "disk MB=", round(sum(r["file_bytes"] for r in g)/2**20,2), "rgba MB=", round(sum(r["rgba"] for r in g)/2**20,1))
    for r in sorted(g, key=lambda r:-r["rgba"])[:5]:
        print("   ", r["w"], "x", r["h"], r["path"], r["file_bytes"])
print()
print("distinct paths:", len({r["path"] for r in rows}))
