path = "crates/wolf-game/tests/opening.rs"
raw = open(path, "rb").read()
crlf = raw.find(bytes([13, 10])) >= 0
t = raw.decode("utf-8").replace(chr(13) + chr(10), chr(10))
lines = t.split(chr(10))
assert "title path choices" in lines[253], lines[253]
assert "title path diagnostics" in lines[254], lines[254]
assert "title path stats" in lines[255], lines[255]
del lines[253:256]
t = chr(10).join(lines)
if crlf:
    t = t.replace(chr(10), chr(13) + chr(10))
open(path, "wb").write(t.encode("utf-8"))
print("done")