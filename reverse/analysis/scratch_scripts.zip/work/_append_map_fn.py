import io, os
path = r"E:\Study\github program\imoto life\crates\wolf-cli\src\main.rs"
tmp = path + ".new"
src = io.open(path, "r", encoding="utf-8", newline="").read()
extra = io.open(r"E:\Study\github program\imoto life\work\_capture_map_fn.rs", "r", encoding="utf-8", newline="").read()
io.open(tmp, "w", encoding="utf-8", newline="").write(src + extra)
os.replace(tmp, path)
print("appended", len(extra))
