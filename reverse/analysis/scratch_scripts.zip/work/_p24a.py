import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
mp = json.load(open('work/maps_full.json', encoding='utf-8'))

def norm(c):
    if 'c' in c: return c['c'], c['a'], c['s'], c.get('bd',0)
    return c['code'], c['ints'], c['strs'], c.get('bd',0)

targets = {220,221,222,105,175,174}
sites = collections.defaultdict(list)
for ev in ce:
    for i,c in enumerate(ev['cmds']):
        code,a,s,bd = norm(c)
        if code in targets:
            sites[code].append(('ce', ev['id'], ev['title'], i, a, s, ev['run']))
for name,m in mp.items():
    for ev in m['events']:
        for i,c in enumerate(ev['cmds']):
            code,a,s,bd = norm(c)
            if code in targets:
                sites[code].append(('map:'+name, ev['id'], ev['name'], i, a, s, ev['trig']))

for code in sorted(sites):
    rows = sites[code]
    print('=== opcode', code, 'sites', len(rows))
    argc = collections.Counter(len(r[4]) for r in rows)
    strc = collections.Counter(len(r[5]) for r in rows)
    print('  argc', dict(sorted(argc.items())))
    print('  strc', dict(sorted(strc.items())))
    evs = collections.Counter(r[1] for r in rows)
    print('  events', dict(evs))
    for r in rows[:12]:
        print('   ', r[0], 'ev', r[1], r[2][:24], 'pc', r[3], 'a=', r[4], 's=', [x[:30] for x in r[5]])

