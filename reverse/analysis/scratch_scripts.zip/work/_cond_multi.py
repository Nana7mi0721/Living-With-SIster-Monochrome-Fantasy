import json, collections
pages=json.load(open("work/_sw3.json"))
byev=collections.defaultdict(list)
for p in pages: byev[(p["map"],p["eid"])].append(p)
multi=[(k,v) for k,v in byev.items() if len(v)>1]
print("events",len(byev),"multi",len(multi))
print("max pages", max(len(v) for v in byev.values()))
