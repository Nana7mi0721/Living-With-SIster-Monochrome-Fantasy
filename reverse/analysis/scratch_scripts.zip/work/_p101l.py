import io,os,struct,sys
sys.stdout.reconfigure(encoding='utf-8')
def pngsize(p):
    d=open(p,'rb').read(33)
    w,h=struct.unpack('>II', d[16:24]); return w,h
for f in ['ScreenShot_2026_1028_21_21_28.png','ScreenShot_2026_1028_21_21_32.png','ScreenShot_2026_1028_21_21_35.png','m2msg600.png','m2msg600b.png','m2probe.png','title_window.png','opening.png','opening600.png','text_lolita.png','late_0.png','boot_480.png']:
    p='work/out/'+f
    print(f, pngsize(p) if os.path.exists(p) else 'MISSING')
print('--- WindowBase ---')
for p in ['work/full/SystemFile/WindowBase.png','work/full/SystemFile/WindowBase_amania.png','work/full/SystemFile/CursorBase.png','work/full/SystemFile/Button01.png']:
    print(p, pngsize(p) if os.path.exists(p) else 'MISSING')