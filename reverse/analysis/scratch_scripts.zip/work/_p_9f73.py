import io, os
path = "crates/wolf-game/src/savegame.rs"
t = io.open(path, encoding="utf-8", newline="").read()
start = t.index("    #[test]\n    fn every_retail_text_picture_survives_re_encoding()")
end = t.index("    #[test]\n    fn a_saved_picture_keeps_its_window_box_scale_and_anchor()", start)
new = """    #[test]
    fn every_retail_text_picture_survives_re_encoding() {
        let mut path = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        path.pop();
        path.pop();
        path.push("work");
        path.push("retail_backup");
        path.push("Save");
        path.push("SaveData01.sav");
        let Ok(save) = read_save(&path) else { return };
        let mut checked = 0;
        for record in &save.part5.events {
            if record.var5 != 1 {
                continue;
            }
            let text = decode_picture_text(&record.md1);
            let reencoded = encode_picture_text(&text);
            // Escape 04 is a font-plus-letter-spacing variant; it decodes to the same
            // \f[n] text and re-encodes as the plain 05 font, so compare decoded text.
            assert_eq!(decode_picture_text(&reencoded), text, "picture {}", record.var1);
            checked += 1;
        }
        assert!(checked > 20, "checked {checked} text records");
    }

"""
t = t[:start] + new + t[end:]
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")