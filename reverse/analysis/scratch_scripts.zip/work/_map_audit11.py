# -*- coding: utf-8 -*-
import sys, io, os, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
src = open('work/_map_audit10.py', encoding='utf-8').read()
pre = src.split("REG = [")[0]
pre = '\n'.join(l for l in pre.splitlines() if not l.startswith('import sys') and not l.startswith('sys.stdout'))
g = {}
exec(compile(pre, 'walklib', 'exec'), g)
parse_mps = g['parse_mps']
base = r'work\full\MapData'
REG = ['TitleMap.mps','SampleMapA.mps','SampleMapA_1.mps','Map003.mps','Map024.mps','Map031.mps']
CTL = ['SampleMapB.mps']
maps = {f: parse_mps(os.path.join(base, f)) for f in REG + CTL}
per = collections.defaultdict(int); sites = []
for f in REG:
    for e in maps[f]['events']:
        for pi, p in enumerate(e['pages']):
            for ci, c in enumerate(p['cmds']):
                a = c['args']
                if c['op'] == 124 and len(a) >= 4 and a[1] == 0x4000 and a[3] == 8:
                    per[f] += 1
                    sites.append((f, e['id'], e['name'], pi, ci, a[0], a[2]))
print('hover reads per registered map:', dict(per), 'total', sum(per.values()))
print()
for s in sites[:25]:
    print('%-16s ev%-3d %-24r page%d pc%-5d dst=%d picture=%d' % s)
print('... (showing first 25 of %d)' % len(sites))
print()
print('distinct pictures passed to the hover read:', len({s[6] for s in sites}), 'values; sample:', sorted({s[6] for s in sites})[:12])
print('distinct dst slots:', len({s[5] for s in sites}))
