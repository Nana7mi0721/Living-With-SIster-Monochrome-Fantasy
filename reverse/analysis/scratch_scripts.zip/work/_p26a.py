# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')

ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))

def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])

# gather all commands: (owner_kind, owner_name, pc, code, ints, strs)
allsites = []
by_id = {}
for ev in ce:
    by_id[ev['id']] = ev
    for pc, c in enumerate(ev['cmds']):
        code, a, s = norm(c)
        allsites.append(('ce', ev['id'], pc, code, a, s))
for mname, mp in maps.items():
    if not isinstance(mp, dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc, c in enumerate(ev['cmds']):
            code, a, s = norm(c)
            allsites.append(('map:'+mname, ev.get('id'), pc, code, a, s))

# title index for 300
byname = {}
for ev in ce:
    byname.setdefault(ev['title'], ev['id'])

def ps(a):
    if len(a) < 2: return (0,0,False)
    v = a[1] & 0xFFFFFFFF
    return (v & 0xF, (v >> 4) & 0xF, bool((v >> 24) & 1))

calls = [x for x in allsites if x[3] in (210,211,300)]
print('total call sites 210/211/300:', len(calls), collections.Counter(x[3] for x in calls))

# string_count histogram per code
for code in (210,211,300):
    h = collections.Counter()
    for x in calls:
        if x[3]==code:
            h[ps(x[4])[1]] += 1
    print('code',code,'string_count hist',dict(sorted(h.items())))

# sites with string_count>0
withs = [x for x in calls if ps(x[4])[1] > 0]
print('sites with string_count>0:', len(withs), collections.Counter(x[3] for x in withs))
print('their strc hist:', dict(sorted(collections.Counter(ps(x[4])[1] for x in withs).items())))
print('their len(s) hist:', dict(sorted(collections.Counter(len(x[5]) for x in withs).items())))

print()
print('=== per-code detail ===')
for code in (210,211,300):
    sub = [x for x in withs if x[3]==code]
    print('--- code',code,'count',len(sub))
    print('  len(s) hist:', dict(sorted(collections.Counter(len(x[5]) for x in sub).items())))
    print('  number_count hist:', dict(sorted(collections.Counter(ps(x[4])[0] for x in sub).items())))
    for x in sub[:15]:
        print('   ', x[0], 'ev', x[1], 'pc', x[2], 'a=', x[4], 's=', x[5])
