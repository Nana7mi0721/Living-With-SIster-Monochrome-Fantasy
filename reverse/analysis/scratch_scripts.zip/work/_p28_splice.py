import io, os
root = r'E:/Study/github program/imoto life'
def read(p):
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()
def write(p, s):
    tmp = p + '.new'
    with io.open(tmp, 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    os.replace(tmp, p)
pairs = [
    ('crates/wolf-save/src/part1.rs', 'work/_add_part1.rs'),
    ('crates/wolf-save/src/part2.rs', 'work/_add_part2.rs'),
    ('crates/wolf-save/src/part4.rs', 'work/_add_part4.rs'),
    ('crates/wolf-save/src/part5.rs', 'work/_add_part5.rs'),
]
for target, snippet in pairs:
    tp = os.path.join(root, target)
    sp = os.path.join(root, snippet)
    body = read(tp)
    add = read(sp)
    assert 'pub fn to_bytes' not in body, target + ' already patched'
    write(tp, body.rstrip() + chr(10) + add)
lp = os.path.join(root, 'crates/wolf-save/src/lib.rs')
lib = read(lp)
anchor = '/// Read one ' + chr(96) + 'MemData<T>' + chr(96) + ' body: a length whose width is ' + chr(96) + 'size' + chr(96) + ', then the bytes.'
assert anchor in lib, 'anchor missing'
add = read(os.path.join(root, 'work/_add_lib.rs'))
lib = lib.replace(anchor, add.strip() + chr(10) + chr(10) + anchor, 1)
write(lp, lib)
print('ok', len(lib))