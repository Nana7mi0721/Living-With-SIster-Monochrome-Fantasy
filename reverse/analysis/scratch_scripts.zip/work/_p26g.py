# -*- coding: utf-8 -*-
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'E:/Study/github program/imoto life/work/'
ce = json.load(open(ROOT + '_ce_full.json', encoding='utf-8'))
maps = json.load(open(ROOT + 'maps_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return (c['c'], c['a'], c['s'])
    return (c['code'], c['ints'], c['strs'])
allsites=[]
for ev in ce:
    for pc,c in enumerate(ev['cmds']):
        code,a,s = norm(c); allsites.append(('ce',ev['id'],pc,code,a,s))
for mn,mp in maps.items():
    if not isinstance(mp,dict) or 'events' not in mp: continue
    for ev in mp['events']:
        for pc,c in enumerate(ev['cmds']):
            code,a,s = norm(c); allsites.append(('map:'+mn,ev.get('id'),pc,code,a,s))
def bits(a):
    v = a[1] & 0xFFFFFFFF if len(a)>1 else 0
    return (v & 0xF, (v>>4)&0xF, [(v>>(12+i))&1 for i in range(5)], (v>>24)&1, v)

print('== string-parameter arg words histogram (210 & 300, strc>0) ==')
h = collections.Counter()
for x in allsites:
    if x[3] not in (210,300): continue
    num, st, en, rv, raw = bits(x[4])
    if st == 0: continue
    for k in range(st):
        w = x[4][2+num+k]
        h[w] += 1
for w,n in h.most_common(20): print('   %-10d : %d' % (w,n))
print('  distinct:', len(h))

print()
print('== sample of 300 strc>0 with arg words + literal strings ==')
n=0
for x in allsites:
    if x[3]!=300: continue
    num, st, en, rv, raw = bits(x[4])
    if st==0: continue
    print('  ev%-4s pc%-4s num=%d strc=%d en=%s rv=%d' % (x[1],x[2],num,st,en,rv))
    print('     a=%s' % (x[4],))
    print('     s=%s' % (x[5],))
    n+=1
    if n>=12: break
