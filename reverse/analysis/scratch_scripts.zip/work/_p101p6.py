
import sys,os,collections
sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image
hits=[]
d='work/all/Picture'
for f in sorted(os.listdir(d)):
    if not f.lower().endswith('.png'): continue
    p=os.path.join(d,f)
    try:
        im=Image.open(p).convert('RGBA'); w,h=im.size
        if w*h>400000: continue
        px=im.load()
        cols=set()
        for y in range(h):
            for x in range(w):
                c=px[x,y]
                if c[3]>0: cols.add(c[:3])
        if (17,30,104) in cols or (5,6,63) in cols or (11,20,87) in cols:
            hits.append((f,w,h,len(cols)))
    except Exception as e:
        pass
print('hits',len(hits))
for x in hits[:20]: print('  ',x)
