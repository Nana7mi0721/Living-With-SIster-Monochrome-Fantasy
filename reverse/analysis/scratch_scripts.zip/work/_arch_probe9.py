
import json,collections
d=json.load(open('work/_ce_full.json',encoding='utf-8'))
uv=collections.Counter(); sv=collections.Counter(); sysv=collections.Counter()
bd=collections.Counter(); n=0
def scan(cmds):
    global n
    for c in cmds:
        n+=1
        bd[c.get('bd')]+=1
        for a in c.get('a') or []:
            if not isinstance(a,int): continue
            if 2000000<=a<3000000: uv[a-2000000]+=1
            elif 3000000<=a<4000000: sv[a-3000000]+=1
            elif 9000000<=a<9100000: sysv[a-9000000]+=1
for ev in d: scan(ev['cmds'])
ks=sorted(uv); print('user vars distinct',len(ks),'min',ks[0],'max',ks[-1])
print('groups(//100000)',dict(sorted(collections.Counter(k//100000 for k in ks).items())))
print('slot top15',collections.Counter(k%100000 for k in ks).most_common(15))
print('slot max',max(k%100000 for k in ks))
sk=sorted(sv); print('str vars distinct',len(sk),'min',sk[0],'max',sk[-1])
print('str groups',dict(sorted(collections.Counter(k//100000 for k in sk).items())))
print('str slot max',max(k%100000 for k in sk))
yy=sorted(sysv); print('sys vars distinct',len(yy),'min',yy[0],'max',yy[-1], yy[:20])
print('bd counts',dict(sorted(bd.items())))
print('total cmds',n)
