
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
H=set(json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"])
title2id={}
for e in ce: title2id.setdefault(e["title"],e["id"])
L=[]
def p(s=""): L.append(s)

def edges_ce(eid):
    out=set()
    for c in idx[eid]["cmds"]:
        op=c["c"]; a=c.get("a") or []; s=c.get("s") or []
        if op==210 and a:
            raw=a[0]
            if 500000<=raw<=599999: out.add(raw-500000)
            elif 600000<=raw<=699999: out.add(raw-600000)
            elif 0<=raw<500000: out.add(raw)
        elif op==300 and s and s[0] in title2id: out.add(title2id[s[0]])
    return out
def edges_map(ev):
    out=set()
    for c in ev.get("cmds",[]):
        op=c["code"]; a=c.get("ints") or []; s=c.get("strs") or []
        if op==210 and a:
            raw=a[0]
            if 500000<=raw<=599999: out.add(raw-500000)
            elif 600000<=raw<=699999: out.add(raw-600000)
            elif 0<=raw<500000: out.add(raw)
        elif op==300 and s and s[0] in title2id: out.add(title2id[s[0]])
    return out

p("## which MAP events reach the H closure")
for mn,m in maps.items():
    for ev in m.get("events",[]):
        d=edges_map(ev)
        hit=d&H
        if hit:
            p("%s ev%-3d trig=%s cmds=%-5d -> %s"%(mn,ev["id"],ev.get("trig"),len(ev.get("cmds",[])),
              ["ev%d"%x for x in sorted(hit)]))

p("")
p("## which non-H common events call straight into H closure")
for e in ce:
    if e["id"] in H: continue
    d=edges_ce(e["id"])&H
    if d: p("ce%-4d %-24s -> %s"%(e["id"],e["title"][:22],["ev%d"%x for x in sorted(d)]))
open(os.path.join(W,"_m3_out7.txt"),"w",encoding="utf-8").write("\n".join(L))
print("lines",len(L))
