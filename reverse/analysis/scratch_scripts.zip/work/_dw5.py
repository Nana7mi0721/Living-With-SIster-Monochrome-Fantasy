import struct, os
src=open('work/_dw2.py').read()
exec(src.split("names=[]")[0])
ROOT='E:/Study/github program/imoto life/work/imouto/Data'
def name_of(na):
    n=struct.unpack_from('<H', hb, na)[0]
    start=na+n*4+4
    end=hb.find(bytes([0]), start)
    return hb[start:end].decode('cp932', errors='replace')
res=[]
def walk(rel,prefix):
    daddr,pdir,num,faddr=d_at(rel)
    for i in range(num):
        na,attr,da,ds,ps=f_at(FileStart+faddr+i*64)
        nm=name_of(na)
        if attr & 0x10: walk(DirStart+da, prefix+nm+'/')
        else: res.append((prefix+nm,da,ds,ps))
walk(DirStart,'')
print('entries',len(res))
def xorat(buf,pos):
    off=pos%12
    return bytes(b^KEY[(off+i)%12] for i,b in enumerate(buf))
uncomp=[r for r in res if r[3]==0xffffffffffffffff]
print('uncompressed entries:',len(uncomp))
ok=0;bad=0;skip=[]
for nm,da,ds,ps in uncomp:
    p=os.path.join(ROOT, nm.replace('/', os.sep))
    if ds==0: continue
    if not os.path.exists(p): skip.append(nm); continue
    f.seek(DataStart+da); raw=f.read(ds)
    dec=xorat(raw, ds)
    orig=open(p,'rb').read()
    if dec==orig: ok+=1
    else:
        bad+=1
        if bad<=3: print('MISMATCH', nm, len(orig), dec[:8].hex(' '), orig[:8].hex(' '))
print('ok',ok,'bad',bad,'missing',len(skip), skip[:3])