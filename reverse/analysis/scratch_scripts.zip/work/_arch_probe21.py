# -*- coding: utf-8 -*-
import os, struct
G = r"E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy"
D = os.path.join(G, "Data")

def keycreate(src):
    if src is None:
        k = bytearray(b"\xaa"*12)
    else:
        bb = src.encode("latin1")
        k = bytearray()
        while len(k) < 12: k += bb
        k = k[:12]
    r = bytearray(k)
    r[0] = (~k[0]) & 0xff
    r[1] = ((k[1] >> 4) | (k[1] << 4)) & 0xff
    r[2] = k[2] ^ 0x8a
    r[3] = (~(((k[3] >> 4) | (k[3] << 4)) & 0xff)) & 0xff
    r[4] = (~k[4]) & 0xff
    r[5] = k[5] ^ 0xac
    r[6] = (~k[6]) & 0xff
    r[7] = (~(((k[7] >> 3) | (k[7] << 5)) & 0xff)) & 0xff
    r[8] = ((k[8] >> 5) | (k[8] << 3)) & 0xff
    r[9] = k[9] ^ 0x7f
    r[10] = ((((k[10] >> 4) | (k[10] << 4)) & 0xff) ^ 0xd6)
    r[11] = k[11] ^ 0xcc
    return bytes(r)

def unxor(buf, key, startpos=0):
    out = bytearray(buf)
    j = startpos % 12
    for i in range(len(out)):
        out[i] ^= key[j]; j = (j+1) % 12
    return bytes(out)

fname = "word.wolf"
raw = open(os.path.join(D, fname), "rb").read()
print("cmp word.wolf vs work/alldata copy:", end=" ")
alt = r"E:\Study\github program\imoto life\work\alldata\word.wolf"
if os.path.exists(alt):
    a = open(alt,"rb").read()
    print("alldata size", len(a), "same bytes:", a == raw, "first48 same:", a[:48]==raw[:48])
else:
    print("no alldata copy")

for name, src in [("NULL", None), ("gamedat", "WLFRPrO!p(;s5((8P@((UFWlu$#5(=")]:
    k = keycreate(src)
    for skip in [False, True]:
        buf = raw[:48] if skip else unxor(raw, k, 0)
        try:
            H, V, HS, DS, NT, FT, DT, CP = struct.unpack("<HHIQQQQQ", buf[:48])
        except Exception as e:
            print(name, skip, e); continue
        print("%-8s skip_head=%s -> Head=%04x Ver=%d HeadSize=0x%x DataStart=0x%x NT=0x%x FT=0x%x DT=0x%x CP=0x%x" % (name, skip, H,V,HS,DS,NT,FT,DT,CP))
        if H == 0x5844:
            full = raw[:48] + unxor(raw[48:], k, 48)
            # try directory table at NT+DT
            for base_label, base in [("NT+DT", NT+DT), ("NT+FT", NT+FT), ("DT", DT), ("abs DT", DT)]:
                if base+32 <= len(full):
                    d = struct.unpack("<QQQQ", full[base:base+32])
                    if d[2] < 100000 and d[3] < len(full):
                        print("    dir@%s(0x%x): %s" % (base_label, base, d))
