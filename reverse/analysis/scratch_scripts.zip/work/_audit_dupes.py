
import os,io,hashlib,collections,json
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
sc=sorted(os.listdir('work/all/scene')); hs=sorted(os.listdir('work/all/hscene'))
W('scene files %d, hscene files %d'%(len(sc),len(hs)))
W('basename overlap: %d'%len(set(sc)&set(hs)))
W('scene-only sample: %s'%[x for x in sc if x not in hs][:10])
W('hscene-only sample: %s'%[x for x in hs if x not in sc][:10])
# content hash match
def h(p):
    return hashlib.md5(open(p,'rb').read()).hexdigest()
sm={h('work/all/scene/'+f):f for f in sc}
hm={h('work/all/hscene/'+f):f for f in hs}
common=set(sm)&set(hm)
W('identical content pairs: %d'%len(common))
W('  e.g. %s'%[(sm[k],hm[k]) for k in list(common)[:6]])
# word vs hword
wd=sorted(os.listdir('work/all/word')); hw=sorted(os.listdir('work/all/hword'))
W('\nword %d hword %d overlap %d'%(len(wd),len(hw),len(set(wd)&set(hw))))
wm={h('work/all/word/'+f):f for f in wd}; hm2={h('work/all/hword/'+f):f for f in hw}
W('word/hword identical content pairs: %d'%len(set(wm)&set(hm2)))
W('  e.g. %s'%[(wm[k],hm2[k]) for k in list(set(wm)&set(hm2))[:6]])
open('work/_audit_out27.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
