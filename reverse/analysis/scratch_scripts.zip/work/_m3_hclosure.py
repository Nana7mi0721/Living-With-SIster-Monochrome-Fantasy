
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
T=[338,340,341,343,346,350,351,353,354,357,358,365,367,372,407,410,445]
title2id={}
for e in ce: title2id.setdefault(e["title"],e["id"])

def edges(eid):
    out=set()
    for c in idx[eid]["cmds"]:
        op=c["c"]; a=c.get("a") or []; s=c.get("s") or []
        if op==210 and a:
            raw=a[0]
            if 500000<=raw<=599999: out.add(raw-500000)
            elif 600000<=raw<=699999: out.add(raw-600000)
            elif 0<=raw<500000: out.add(raw)
        elif op==300 and s:
            n=s[0]
            if n in title2id: out.add(title2id[n])
    return out

def closure(seeds):
    seen=set(); stack=list(seeds)
    while stack:
        x=stack.pop()
        if x in seen or x not in idx: continue
        seen.add(x)
        for y in edges(x): stack.append(y)
    return seen

H=closure(T)
print("H closure size",len(H))
# callers of closure from outside
outside=collections.defaultdict(list)
for e in ce:
    if e["id"] in H: continue
    for y in edges(e["id"]):
        if y in H: outside[y].append(e["id"])
roots=[x for x in H if x not in {y for e in ce if e["id"] in H for y in edges(e["id"])}]
print("roots inside closure:",sorted(roots))
print("outside callers -> closure members:")
for k,v in sorted(outside.items()):
    print("  ev%d(%s) <- %s"%(k,idx[k]["title"],[ "ce%d"%x for x in sorted(set(v))]))
json.dump({"H":sorted(H)},open(os.path.join(W,"_m3_hclosure.json"),"w"))
