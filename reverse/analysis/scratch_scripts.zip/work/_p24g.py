import json, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
by = {e['id']: e for e in ce}
def norm(c):
    if 'c' in c: return c['c'], c['a'], c['s']
    return c['code'], c['ints'], c['strs']
def dump(eid, lo, hi, maxs=60):
    ev = by[eid]
    print('### ev', eid, ev['title'])
    for i in range(lo, min(hi, len(ev['cmds']))):
        c,a,s = norm(ev['cmds'][i])
        if c==0: print(f'  {i:4d}  ---')
        else: print(f'  {i:4d}  {c:4d} a={a} s={[x[:maxs] for x in s]}')
dump(131, 0, 60)
print()
dump(94, 20, 80)

