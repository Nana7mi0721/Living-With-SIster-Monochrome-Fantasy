
import os,io,json
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
W('== 23 .wolf in work/all ==')
tot=0; rows=[]
for root,ds,fs in os.walk('work/all'):
    for f in fs:
        if f.lower().endswith('.wolf'):
            p=os.path.join(root,f); s=os.path.getsize(p); rows.append((s,os.path.relpath(p,'work/all'))); tot+=s
for s,p in sorted(rows,reverse=True): W('%12d  %s'%(s,p))
W('total %d files / %d B'%(len(rows),tot))
G=r'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy\Data'
W('\n== install Data/ listing ==')
t=0
for f in sorted(os.listdir(G)):
    p=os.path.join(G,f)
    if os.path.isfile(p):
        s=os.path.getsize(p); t+=s
        W('%12d  %s'%(s,f))
W('Data/ files total %d B'%t)
open('work/_audit_out35.txt','w',encoding='utf-8').write(OUT.getvalue()); print('ok')
