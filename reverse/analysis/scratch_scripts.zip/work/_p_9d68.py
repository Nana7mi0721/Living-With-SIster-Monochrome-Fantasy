import io, os
p = "crates/wolf-cli/src/main.rs"
t = io.open(p, encoding="utf-8", newline="").read()
def rep(a, b):
    global t
    assert t.count(a) == 1, (a[:60], t.count(a))
    t = t.replace(a, b)

# 1. flag
rep("            \"--boot\" => boot = true,",
    "            \"--hold-message\" => hold_message = true,\n            \"--boot\" => boot = true,")
# 2. default + call site
rep("                run_capture(&root, out, frames, answer, entry)",
    "                run_capture(&root, out, frames, answer, hold_message, entry)")
# 3. signature
rep("fn run_capture(\n    root: &Path,\n    out: Option<PathBuf>,\n    frames: usize,\n    answer: Option<usize>,\n    entry: Entry<'_>,\n) -> ExitCode {",
    "fn run_capture(\n    root: &Path,\n    out: Option<PathBuf>,\n    frames: usize,\n    answer: Option<usize>,\n    hold_message: bool,\n    entry: Entry<'_>,\n) -> ExitCode {")
# 4. auto_advance
rep("    game.auto_advance = true;",
    "    // --hold-message parks the run on the first 101 message instead, which is how a\n    // capture photographs the message window (the story scripts talk before they branch).\n    game.auto_advance = !hold_message;")
# 5. help line
rep("    println!(\"    -m, --map <NAME>  Capture a map instead of the boot sequence (e.g. SampleMapA.mps).\");",
    "    println!(\"    --hold-message    Park on the first 101 message instead of dismissing it.\");\n    println!(\"    -m, --map <NAME>  Capture a map instead of the boot sequence (e.g. SampleMapA.mps).\");")
io.open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("main.rs args patched")