import json, sys, re
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'], c['a'], c['s']
    return c['code'], c['ints'], c['strs']
pat = re.compile('セーブ|ロード|Save|Load|変数ID|変数番号')
for ev in ce:
    for i,c in enumerate(ev['cmds']):
        code,a,s = norm(c)
        if code in (103,) and s and pat.search(s[0]):
            print(f"ev {ev['id']:3d} pc{i:4d} {s[0][:120]!r}")

