from PIL import Image
import os
sheet = Image.open('work/full/MapChip/[A]Grass1_pipo.png').convert('RGBA')
def quadrant(tile, code, qx, qy, frame=0):
    src = (frame*16 + qx*8, code*16 + qy*8, 8, 8)
    return sheet.crop(src)
def compose(raw, frame=0):
    idv = raw // 100000
    tail = raw % 10000
    codes = [(tail//1000)%10, (tail//100)%10, (tail//10)%10, tail%10]
    cell = Image.new('RGBA', (16,16), (0,0,0,0))
    for qy in range(2):
        for qx in range(2):
            c = codes[qy*2+qx]
            cell.paste(quadrant(idv, c, qx, qy, frame), (qx*8, qy*8))
    return cell
# 4x4 grid of 104444 (all-joined) vs a single 100000
def grid(raws, w, h):
    out = Image.new('RGBA', (w*16, h*16), (0,0,0,0))
    for y in range(h):
        for x in range(w):
            out.paste(compose(raws[x]), (x*16, y*16))
    return out
g = grid([104444]*6, 6, 2)
g2 = grid([100000, 104444, 104422, 102244, 104141, 101414], 6, 1)
out = Image.new('RGBA', (96, 48), (0,0,0,255))
out.paste(g, (0,0)); out.paste(g2, (0,32))
out = out.resize((96*6, 48*6), Image.NEAREST)
out.save('work/out/autotile_test.png')
print('wrote', out.size)
