import json
ces=json.load(open('work/_ce_full.json',encoding='utf-8'))
by={e['id']:e for e in ces}
def magic111(c):
    a=c.get('a',[])
    if not a: return False
    n=a[0]&0xF
    for i in range(n):
        b=1+3*i
        if b+1<len(a) and abs(a[b+1])>=1000000: return True
    return False
# CE372 callers
print("CE372 title",repr(by[372]['title']))
for e in ces:
    for i,c in enumerate(e['cmds']):
        a=c.get('a',[])
        if c['c']==210 and a and a[0]==500372:
            print(f"CALLER CE{e['id']} pc{i} 210 {a}")
        if c['c']==300 and c.get('s') and c['s'] and c['s'][0]==by[372]['title']:
            print(f"CALLER CE{e['id']} pc{i} 300 {a}")
print("=== per-event magic111 counts (selected) ===")
sel=[65,152,153,154,157,159,160,161,162,163,164,167,176,172,188,190,192,216,226,252,258,323,371,372]
for eid in sel:
    if eid not in by: 
        print(eid,"MISSING"); continue
    e=by[eid]; hits=[]
    for i,c in enumerate(e['cmds']):
        if c['c']==111 and magic111(c): hits.append(i)
    print(f"CE{eid} {e['title']!r}: magic111 pcs={hits}")
print("=== CE323 / CE371 magic 111 detail ===")
for eid in (323,371):
    if eid not in by: continue
    e=by[eid]
    for i,c in enumerate(e['cmds']):
        if c['c']==111 and magic111(c):
            print(f"CE{eid} pc{i} 111 {c.get('a')}")

