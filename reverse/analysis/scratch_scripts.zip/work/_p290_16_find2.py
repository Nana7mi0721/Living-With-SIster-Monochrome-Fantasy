
import zipfile, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')

def find(w):
    return [m.start() for m in re.finditer(re.escape(w.encode('utf-16-le')), data)]
def dump(a, b):
    s = data[a:b].decode('utf-16-le', errors='replace')
    return ''.join(ch if (ch in '\r\n\t' or 0x20 <= ord(ch) < 0xfffd) else '·' for ch in s)

for w in ['明滅フラッシュ','拡大率補正','角度補正','不透明度補正','全エフェクト解除','変換系','Zｵｰﾀﾞｰ','Zオーダー','ｶﾗｰ補正','色変換']:
    print('---', w, [hex(x) for x in find(w)[:10]])
