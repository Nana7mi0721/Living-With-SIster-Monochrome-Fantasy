
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')

refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure2.json',encoding='utf-8'))
live_common=set(int(x) for x in cl['gcreach2'])
dead_maps={'Dungeon','Map002','SampleMapB'}
DATA_DIRS={'BasicData','MapData'}

def size(p):
    try: return os.path.getsize(os.path.join('work/all',p))
    except OSError: return 0

def site_live(s):
    src,loc=s[0],s[1]
    if src in ('db','sysdb','tileset'): return True
    if src=='common':
        ev=int(loc.split('#')[0].replace('ev',''))
        return ev in live_common
    if src=='map':
        base=loc.split(' ev')[0].split('.')[0]
        return base not in dead_maps
    return True

# --- inventory
allfiles=[]
for dp,dn,fn in os.walk('work/all'):
    for f in fn:
        p=os.path.join(dp,f)
        rel=os.path.relpath(p,'work/all').replace('\\','/')
        allfiles.append((rel,os.path.getsize(p)))
arch=[f for f in allfiles if f[0].endswith('.wolf')]
data=[f for f in allfiles if not f[0].endswith('.wolf')]
W('== inventory ==')
W('work/all total: %d files / %d B'%(len(allfiles),sum(b for _,b in allfiles)))
W('  archives(.wolf): %d / %d'%(len(arch),sum(b for _,b in arch)))
W('  unpacked data  : %d / %d'%(len(data),sum(b for _,b in data)))

# --- referenced classification
resolved=refs['referenced']; missing=refs['missing']
live={p:s for p,s in resolved.items() if any(site_live(x) for x in s)}
dead={p:s for p,s in resolved.items() if not any(site_live(x) for x in s)}
W('\n== reference resolution ==')
W('distinct referenced paths: %d'%(len(resolved)+len(missing)))
W('  resolved: %d files / %d B'%(len(resolved),sum(size(p) for p in resolved)))
W('  missing : %d paths'%len(missing))
W('resolved & reachable(live): %d / %d B'%(len(live),sum(size(p) for p in live)))
W('resolved but dead-only     : %d / %d B'%(len(dead),sum(size(p) for p in dead)))

# --- unreferenced unpacked files
refset=set(resolved)
unref=[(p,b) for p,b in data if p not in refset]
W('\n== unreferenced unpacked files: %d / %d B'%(len(unref),sum(b for _,b in unref)))
unref_assets=[(p,b) for p,b in unref if p.split('/')[0] not in DATA_DIRS]
unref_data=[(p,b) for p,b in unref if p.split('/')[0] in DATA_DIRS]
W('  of which assets (non BasicData/MapData): %d / %d B'%(len(unref_assets),sum(b for _,b in unref_assets)))
W('  of which data files (BasicData/MapData) : %d / %d B'%(len(unref_data),sum(b for _,b in unref_data)))

# --- the three buckets, asset-only
databytes=sum(b for p,b in data if p.split('/')[0] in DATA_DIRS)
assetfiles=[(p,b) for p,b in data if p.split('/')[0] not in DATA_DIRS]
W('\n== asset bucket (excludes BasicData/MapData which are game data) ==')
W('assets on disk: %d / %d B'%(len(assetfiles),sum(b for _,b in assetfiles)))
live_assets=[(p,b) for p,b in assetfiles if p in live]
dead_ref_assets=[(p,b) for p,b in assetfiles if p in dead]
never_assets=[(p,b) for p,b in assetfiles if p not in refset]
W('  live (referenced by reachable code) : %d / %d B'%(len(live_assets),sum(b for _,b in live_assets)))
W('  referenced only by dead code       : %d / %d B'%(len(dead_ref_assets),sum(b for _,b in dead_ref_assets)))
W('  never referenced at all            : %d / %d B'%(len(never_assets),sum(b for _,b in never_assets)))
W('  data files (BasicData+MapData)     : %d / %d B'%(len(data)-len(assetfiles),databytes))
W('check sum: %d'%(sum(b for _,b in live_assets)+sum(b for _,b in dead_ref_assets)+sum(b for _,b in never_assets)+databytes))

json.dump({'live':sorted(p for p,_ in live_assets),'deadref':sorted(p for p,_ in dead_ref_assets),
           'never':sorted(p for p,_ in never_assets),
           'sizes':dict(assetfiles)},open('work/_audit_final.json','w',encoding='utf-8'),ensure_ascii=False)
open('work/_audit_out14.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
