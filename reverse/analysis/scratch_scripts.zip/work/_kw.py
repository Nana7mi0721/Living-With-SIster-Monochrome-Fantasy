import io,re
t=io.open(r'E:/Study/github program/imoto life/work/imouto/ce_titles.txt',encoding='utf-8',errors='replace').read()
for kw in ['ギルド','依頼','クエスト','探索','戦闘','バトル','テスト','ダンジョン','店','所持金','行動力']:
    n=t.count(kw)
    print(kw,n)