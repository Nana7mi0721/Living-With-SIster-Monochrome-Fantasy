import io, os
p = "crates/wolf-game/src/choice.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = "let panel = layout(&options_one(&option), 0);"
b = "let panel = layout(std::slice::from_ref(&option), 0);"
assert t.count(a) == 1
t = t.replace(a, b)
open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("ok")