# -*- coding: utf-8 -*-
"""Static call-graph closure of common event 42 (the M1 title screen).

Reads work/_ce_full.json (raw parse of work/full/BasicData/CommonEvent.dat) and
walks the 210 (CommonEvent) / 300 (CallByName) edges transitively from event 42.

The 210 target encoding is the interpreter's: 500000..599999 -> id = raw-500000,
600000..699999 -> id = raw-600000 (crates/wolf-vm/src/exec.rs:1247-1252).
The 300 target is a title string, resolved through the event title table.

Output: work/_m1_closure.json + a stdout report.
"""
import collections
import io
import json

PLAN_EVENTS = 4
PLAN_INSTRUCTIONS = 671
PLAN_OPCODES = [99, 102, 103, 106, 111, 121, 123, 130, 140, 150, 170, 171, 172,
                175, 179, 180, 210, 212, 213, 250, 270, 300, 401, 420, 498, 499]

events = json.load(open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
by_title = {}
for e in events:
    by_title.setdefault(e['title'], e['id'])

def decode_210(raw):
    if 500000 <= raw <= 599999:
        return raw - 500000
    if 600000 <= raw <= 699999:
        return raw - 600000
    return None

# ---- edges ---------------------------------------------------------------
edges = collections.defaultdict(set)
for e in events:
    for c in e['cmds']:
        if c['c'] == 210 and c['a']:
            t = decode_210(int(c['a'][0]))
            if t is not None and t in by_id:
                edges[e['id']].add(t)
        elif c['c'] == 300 and c['s']:
            t = by_title.get(c['s'][0])
            if t is not None:
                edges[e['id']].add(t)

# ---- closure -------------------------------------------------------------
def closure(start):
    seen = []
    visited = set()
    stack = [start]
    while stack:
        cur = stack.pop()
        if cur in visited or cur not in by_id:
            continue
        visited.add(cur)
        seen.append(cur)
        stack.extend(sorted(edges[cur], reverse=True))
    return seen

reached = sorted(closure(42))

rows = []
union_ops = collections.Counter()
total_slots = 0
total_real = 0
for eid in reached:
    e = by_id[eid]
    slots = len(e['cmds'])
    real = sum(1 for c in e['cmds'] if c['c'] != 0)
    ops = collections.Counter(c['c'] for c in e['cmds'] if c['c'] != 0)
    union_ops.update(ops)
    total_slots += slots
    total_real += real
    rows.append({
        'id': eid,
        'title': e['title'],
        'run': e['run'],
        'slots': slots,
        'real': real,
        'opcodes': sorted(ops),
        'calls': sorted(edges[eid]),
    })

print('=== closure of event 42 (static, 210 + 300 edges) ===')
print('reachable events: %d  (PLAN.md claims %d)' % (len(reached), PLAN_EVENTS))
print('total slots      : %d' % total_slots)
print('non-empty instrs : %d  (PLAN.md claims %d)' % (total_real, PLAN_INSTRUCTIONS))
print()
for r in rows:
    print('  ev%-4d run=%d slots=%-4d real=%-4d calls=%s' % (r['id'], r['run'], r['slots'], r['real'], r['calls']))
print()

closure_ops = sorted(union_ops)
print('=== opcodes ===')
print('closure opcode set: %d distinct (PLAN.md claims %d)' % (len(closure_ops), len(PLAN_OPCODES)))
print('  %s' % closure_ops)
print()
print('counts: %s' % sorted(union_ops.items(), key=lambda kv: (-kv[1], kv[0])))
print()
missing = [op for op in PLAN_OPCODES if op not in union_ops]
extra = [op for op in closure_ops if op not in PLAN_OPCODES]
print('in PLAN list but NOT in closure (%d): %s' % (len(missing), missing))
print('in closure but NOT in PLAN list (%d): %s' % (len(extra), extra))
print()
for op in closure_ops:
    who = [r['id'] for r in rows if op in r['opcodes']]
    print('  %-5d n=%-5d events=%s' % (op, union_ops[op], who))

json.dump({'reached': rows,
           'opcodes': dict(union_ops),
           'total_slots': total_slots,
           'total_real': total_real},
          io.open('work/_m1_closure.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
