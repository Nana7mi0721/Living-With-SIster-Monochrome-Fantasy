import io, os
p = 'crates/wolf-save/tests/rebuild.rs'
s = io.open(p, encoding='utf-8', newline='').read()
bad = [l for l in s.split(chr(10)) if 'clone_into' in l]
print('BAD', bad)
s = s.replace('    fresh.part5.events.clone_into(&mut part5.events);' + chr(10), '')
io.open(p + '.new', 'w', encoding='utf-8', newline='').write(s)
os.replace(p + '.new', p)
print('ok')