import io, os
path = "docs/M2_SLICE.md"
t = io.open(path, encoding="utf-8", newline="").read()
a = """| git HEAD | `5e26bec` + **本批**（styled 101 message `layout_styled` / SavePart5 图片表写回 / vardb `write_into` 接线 / 220 mode 0 整档保存） |"""
b = """| git HEAD | `dc85636`（styled 101 message `layout_styled` / SavePart5 图片表写回 / vardb `write_into` 接线 / 220 mode 0 整档保存） |"""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")