import os
p=r'E:/Study/github program/imoto life/work/imouto/Data/BasicData/CommonEvent.dat'
b=open(p,'rb').read()
def dump(enc,minlen=2):
    out=[];cur=bytearray()
    for ch in b:
        ok=False
        if enc=='cp932': ok = (0x20<=ch<=0x7e) or (0x81<=ch<=0x9f) or (0xe0<=ch<=0xfc)
        else: ok = ch>=0x20
        if ok: cur.append(ch)
        else:
            if len(cur)>=minlen:
                try: out.append(bytes(cur).decode(enc))
                except Exception: pass
            cur=bytearray()
    if len(cur)>=minlen:
        try: out.append(bytes(cur).decode(enc))
        except Exception: pass
    return out
a=dump('cp932')
u=dump('utf-8',3)
def hascjk(s): return any('\u4e00'<=c<='\u9fff' for c in s)
ua=[s for s in u if hascjk(s) and len(s)<=40]
print('utf8 cjk strings',len(ua))
print('|'.join(ua[:120]))
print()
ca=[s for s in a if hascjk(s) and len(s)<=40]
print('cp932 cjk strings',len(ca))
print('|'.join(ca[:200]))