import io
p = r"E:\Study\github program\imoto life\crates\wolf-vm\src\exec.rs"
s = io.open(p, encoding="utf-8").read()
a = """                // An unanswered field must leave the destination alone, not write 0.
                cmd(124, &[2_000_003, 0x4000, 12_005, 77], &[]),
                cmd(121, &[2_000_003, 7, 0, 0], &[]),
                cmd(121, &[2_000_003, 2_000_003, 1, 0x100], &[]),"""
b = """                // An unanswered field must leave the destination alone, not write 0:
                // seed it with 7 first, then ask a field nobody answers.
                cmd(121, &[2_000_003, 7, 0, 0], &[]),
                cmd(124, &[2_000_003, 0x4000, 12_005, 77], &[]),"""
assert a in s
s = s.replace(a, b)
a2 = 'assert_eq!(vm.vars.get(3), 8, "unanswered field keeps the old value");'
b2 = 'assert_eq!(vm.vars.get(3), 7, "unanswered field keeps the old value");'
assert a2 in s
s = s.replace(a2, b2)
io.open(p, "w", encoding="utf-8", newline="\n").write(s)
print("ok")
