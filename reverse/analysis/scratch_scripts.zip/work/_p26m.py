
import json, collections, sys
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('E:/Study/github program/imoto life/work/_ce_full.json', encoding='utf-8'))
maps = json.load(open('E:/Study/github program/imoto life/work/maps_full.json', encoding='utf-8'))
cnt = collections.Counter()
for ev in ce:
    for c in ev['cmds']:
        for v in c['a']:
            if 1600000 <= v <= 1600099:
                cnt[v] += 1
for m in maps.values():
    for e in m.get('events') or []:
        for c in e.get('cmds') or []:
            for v in c.get('ints') or []:
                if 1600000 <= v <= 1600099:
                    cnt[v] += 1
for k in sorted(cnt):
    if k <= 1600010:
        print(k, cnt[k])
