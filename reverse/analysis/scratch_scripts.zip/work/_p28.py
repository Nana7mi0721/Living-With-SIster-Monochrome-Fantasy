
import json, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
meta = json.load(open('work/_ce_meta.json', encoding='utf-8'))
byid = {e['id']: e for e in ce}
def writes(eid, slot):
    out = []
    for pc, c in enumerate(byid[eid]['cmds']):
        a = c['a']
        if c['c'] in (121, 122, 124) and a and a[0] == slot: out.append((pc, c['c']))
        if c['c'] in (210, 300, 211) and len(a) >= 2 and (a[1] >> 24) & 1:
            i = 2 + (a[1]&0xF) + ((a[1]>>4)&0xF)
            if i < len(a) and a[i] == slot: out.append((pc, c['c'], 'ret'))
    return out
for eid, slot in [(17, 1600010), (22, 1600030), (23, 1600009), (262, 1600009), (263, 1600004)]:
    print('ev', eid, repr(byid[eid]['title']), 'slot', slot, '->', writes(eid, slot)[:6])
print()
# ev17 comment lines
for pc, c in enumerate(byid[17]['cmds'][:40]):
    if c['c'] == 103: print(pc, c['s'])

