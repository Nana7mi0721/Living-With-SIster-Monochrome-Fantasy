
import sys,collections
sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image
for f in ('WindowBase.png','WindowBase_amania.png'):
    im=Image.open('work/all/SystemFile/'+f).convert('RGBA')
    w,h=im.size; px=im.load()
    c=collections.Counter(px[x,y] for y in range(h) for x in range(w))
    print(f,w,h,'colors',len(c))
    for col,n in c.most_common(8): print('   ',col,n)
    print('   col0 rows:',[px[0,y] for y in range(h)])
    print('   center col rows:',[px[w//2,y] for y in range(h)])
