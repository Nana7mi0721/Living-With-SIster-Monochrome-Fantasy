
import json,os
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
def show(ev,pc0=0,pc1=99999):
    e=idx[ev]
    print("=== ev%d %s slots=%d run=%d ==="%(ev,e["title"],len(e["cmds"]),e["run"]))
    for k in range(pc0,min(pc1,len(e["cmds"]))):
        c=e["cmds"][k]
        if c["c"]==0: continue
        print(" pc%-5d bd%d op%-4d a=%s s=%s"%(k,c["bd"],c["c"],c["a"],c["s"]))
show(338)
