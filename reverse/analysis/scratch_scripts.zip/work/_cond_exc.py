import json
pages=json.load(open("work/_sw3.json"))
for p in pages:
    for j,x in enumerate(p["sw"]):
        if (x&0xF) and (p["vars"][j]==[1000000,0]):
            print("enabled+default:",p["map"],"ev",p["eid"],"pg",p["pi"],"slot",j,hex(x),p["vars"][j],"trig",p["trig"])
# also SampleMapA ev9/ev10 event ids sanity: print id list
