import json, collections
ce=json.load(open('work/_ce_full.json',encoding='utf-8'))
argc=collections.Counter(); byform=collections.Counter()
for ev in ce:
    for c in ev['cmds']:
        if c['c']!=150: continue
        a=c['a']
        if not a: continue
        if (a[0] & 0x0F) != 2: continue
        argc[len(a)]+=1
print('erase action argc histogram (all common events):', sorted(argc.items()))
