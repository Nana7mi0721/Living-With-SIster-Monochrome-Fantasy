
import json,os,sys
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
def dump(eid,limit=None,path=None):
    e=idx[eid]
    L=["# ev%d  %s  run=%d op=%d slots=%d"%(eid,e["title"],e["run"],e["op"],len(e["cmds"]))]
    for i,c in enumerate(e["cmds"]):
        if not c["c"]: continue
        s=c.get("s") or []
        L.append("pc%-5d op%-5d bd%-2d a=%s s=%s"%(i,c["c"],c.get("bd",0),c.get("a"),json.dumps(s,ensure_ascii=False) if s else ""))
        if limit and len(L)>limit: L.append("... truncated"); break
    open(os.path.join(W,path),"w",encoding="utf-8").write("\n".join(L))
    return len(L)
print(dump(350,None,"_m3_ev350.txt"))
print(dump(338,None,"_m3_ev338.txt"))
print(dump(365,None,"_m3_ev365.txt"))
print(dump(407,None,"_m3_ev407.txt"))
print(dump(367,None,"_m3_ev367.txt"))
