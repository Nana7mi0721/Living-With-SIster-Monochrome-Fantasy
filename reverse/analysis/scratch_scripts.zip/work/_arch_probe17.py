# -*- coding: utf-8 -*-
import struct, os
G = "E:\\SteamLibrary\\steamapps\\common\\Living With SIster Monochrome Fantasy"
D = os.path.join(G, "Data")

def keycreate(src):
    if src is None:
        k = bytearray(b"\xaa"*12)
    else:
        b = src.encode("latin1") if isinstance(src, str) else src
        k = bytearray()
        while len(k) < 12:
            k += b
        k = k[:12]
    r = bytearray(k)
    r[0] = (~k[0]) & 0xff
    r[1] = ((k[1] >> 4) | (k[1] << 4)) & 0xff
    r[2] = k[2] ^ 0x8a
    r[3] = (~(((k[3] >> 4) | (k[3] << 4)) & 0xff)) & 0xff
    r[4] = (~k[4]) & 0xff
    r[5] = k[5] ^ 0xac
    r[6] = (~k[6]) & 0xff
    r[7] = (~(((k[7] >> 3) | (k[7] << 5)) & 0xff)) & 0xff
    r[8] = ((k[8] >> 5) | (k[8] << 3)) & 0xff
    r[9] = k[9] ^ 0x7f
    r[10] = ((((k[10] >> 4) | (k[10] << 4)) & 0xff) ^ 0xd6)
    r[11] = k[11] ^ 0xcc
    return bytes(r)

def keyconv(data, pos, key):
    pos %= 12
    out = bytearray(data)
    j = pos
    for i in range(len(out)):
        out[i] ^= key[j]
        j = (j + 1) % 12
    return bytes(out)

cands = {"NULL(0xAA)": None, "gamedat_key": "WLFRPrO!p(;s5((8P@((UFWlu$#5(="}
for fn in ["word.wolf", "FIcon.wolf", "BasicData.wolf", "SystemFile.wolf", "MapData.wolf"]:
    p = os.path.join(D, fn)
    if not os.path.exists(p):
        print("missing", fn); continue
    raw = open(p, "rb").read(48)
    print("==", fn, "stored:", raw[:8].hex())
    for name, src in cands.items():
        k = keycreate(src)
        d = keyconv(raw, 0, k)
        print("   %-12s key=%s -> Head=%s Ver=%d HeadSize=0x%x DataStart=0x%x" % (
            name, k.hex(), d[:2].hex(), struct.unpack_from("<H", d, 2)[0],
            struct.unpack_from("<I", d, 4)[0], struct.unpack_from("<Q", d, 8)[0]))
