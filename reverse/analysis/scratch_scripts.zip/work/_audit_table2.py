
import json,io,os,collections
OUT=io.StringIO()
W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
live=set(fin['live']); deadref=set(fin['deadref']); never=set(fin['never'])
sizes=fin['sizes']
# full disk inventory incl. BasicData/MapData
disk={}
for dp,dn,fn in os.walk('work/all'):
    for f in fn:
        p=os.path.join(dp,f); rel=os.path.relpath(p,'work/all').replace('\\','/')
        if rel.endswith('.wolf'): continue
        disk[rel]=os.path.getsize(p)
W('disk data files %d / %d B'%(len(disk),sum(disk.values())))
W('sizes dict %d / %d B'%(len(sizes),sum(sizes.values())))
diff=set(disk)-set(sizes)
W('in disk not in sizes: %d  (should be BasicData+MapData)'%len(diff))
dirs=sorted(set(p.split('/')[0] for p in disk))
rows=[]
for d in dirs:
    ps=[p for p in disk if p.split('/')[0]==d]
    rows.append((d,len(ps),sum(disk[p] for p in ps),
        len([p for p in ps if p in live]),sum(disk[p] for p in ps if p in live),
        len([p for p in ps if p in deadref]),sum(disk[p] for p in ps if p in deadref),
        len([p for p in ps if p in never]),sum(disk[p] for p in ps if p in never)))
W('\n%-22s %5s %12s %5s %12s %5s %10s %5s %12s'%('dir','files','bytes','live','liveB','dref','drefB','never','neverB'))
t=[0]*8
for r in sorted(rows,key=lambda r:-r[2]):
    W('%-22s %5d %12d %5d %12d %5d %10d %5d %12d'%r)
    for i in range(1,8): t[i-1]+=r[i]
W('%-22s %5d %12d %5d %12d %5d %10d %5d %12d'%('TOTAL',*t))
# archives per dir
W('\n== .wolf archives ==')
ab=0; an=0
for dp,dn,fn in os.walk('work/all'):
    for f in fn:
        if f.endswith('.wolf'):
            b=os.path.getsize(os.path.join(dp,f)); ab+=b; an+=1
W('%d archives / %d B'%(an,ab))
W('\n== shipping footprint if only live assets + data files ==')
lf=sum(disk[p] for p in live)
df=sum(disk[p] for p in disk if p.split('/')[0] in ('BasicData','MapData'))
W('live assets %d + data files %d = %d B (%.1f MB)'%(lf,df,lf+df,(lf+df)/1048576))
W('full unpacked %d B (%.1f MB)'%(sum(disk.values()),sum(disk.values())/1048576))
W('savings vs unpacked: %d B (%.1f%%)'%(sum(disk.values())-lf-df,100*(sum(disk.values())-lf-df)/sum(disk.values())))
open('work/_audit_out19.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
