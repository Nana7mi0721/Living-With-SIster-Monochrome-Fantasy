import os,struct
root=r'E:/Study/github program/imoto life/work/imouto/Data/BasicData'
def scan_strs(b):
    out=[]
    i=0;n=len(b)
    while i+4<=n:
        ln=struct.unpack_from('<I',b,i)[0]
        if 2<=ln<=300 and i+4+ln<=n:
            body=b[i+4:i+4+ln]
            if body[-1:]==b'\x00':
                try:
                    s=body[:-1].decode('cp932')
                    if s and all(c=='\n' or c=='\t' or c>=' ' for c in s):
                        out.append((i,s));i+=4+ln;continue
                except Exception: pass
        i+=1
    return out
for name in ['SysDatabase.dat','DataBase.dat','CDataBase.dat']:
    b=open(os.path.join(root,name),'rb').read()
    ss=scan_strs(b)
    print('==',name,'strings',len(ss),'first bytes',b[:12].hex(),'last bytes',b[-4:].hex())
    print('|'.join('%d:%s'%(o,s) for o,s in ss[:400]))
    print()