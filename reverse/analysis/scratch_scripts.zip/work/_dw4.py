import struct
src=open('work/_dw2.py').read()
exec(src.split("names=[]")[0])
def name_of(na):
    n=struct.unpack_from('<H', hb, na)[0]
    start=na+n*4+4
    end=hb.find(bytes([0]), start)
    return n, hb[start:end].decode('cp932', errors='replace'), hb[na:na+8].hex(' ')
daddr,pdir,num,faddr=d_at(DirStart)
for i in range(6):
    na,attr,da,ds,ps=f_at(FileStart+faddr+i*64)
    print(i, name_of(na), 'attr',attr,'ds',ds)