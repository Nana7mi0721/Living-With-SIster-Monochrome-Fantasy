
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
maps=json.load(open(os.path.join(W,"maps_full.json"),encoding="utf-8"))
T=[338,340,341,343,346,350,351,353,354,357,358,365,367,372,407,410,445]
Ts=set(T)
L=[]
def p(s=""): L.append(s)

# any command whose int args contain raw-500000 for a target (any opcode)
p("## any-opcode references to 500<T> / 600<T> / <T> in int args")
hits=collections.defaultdict(list)
def scan(cmds,src):
    for i,c in enumerate(cmds):
        op=c.get("c") if isinstance(c,dict) else c[0]
        ints=c.get("a") if isinstance(c,dict) else c[1]
        for k,v in enumerate(ints or []):
            for t in T:
                if v in (500000+t,600000+t):
                    hits[t].append((src,op,i,k,v))
for e in ce: scan(e["cmds"],"ce%d"%e["id"])
for mn,m in maps.items():
    for ev in m.get("events",[]): scan(ev.get("cmds",[]),"map:%s#ev%s"%(mn,ev.get("id")))
for t in T:
    h=hits.get(t,[])
    p("ev%-4d refs=%d :: %s"%(t,len(h),"; ".join("%s op%d pc%d arg[%d]=%d"%(s,o,i,k,v) for s,o,i,k,v in h[:12])))

p("")
p("## opcode distribution of reference opcodes")
oc=collections.Counter(o for t in T for (s,o,i,k,v) in hits.get(t,[]))
p(str(dict(oc)))
open(os.path.join(W,"_m3_out4.txt"),"w",encoding="utf-8").write("\n".join(L))
print("lines",len(L))
