
import json,io,collections
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
refs=json.load(open('work/_audit_refs.json',encoding='utf-8'))
cl=json.load(open('work/_audit_closure.json',encoding='utf-8'))
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
sizes=fin['sizes']
evs=set(); maps=set()
for s in cl['boot']:
    s=s.strip()
    if s.startswith("('c'"): evs.add(int(s.split(',')[1].strip(' )')))
    elif s.startswith("('m'"):
        p=s.split(','); maps.add((p[1].strip().strip("'\""),int(p[2].strip(' )'))))
W('boot closure: %d common events, maps %s'%(len(evs),sorted(maps)))
def size(p): return sizes.get(p,0)
ps=set()
for p,sites in refs['referenced'].items():
    for src,loc,op in sites:
        if src=='common':
            ev=int(loc.split('#')[0].replace('ev',''))
            if ev in evs: ps.add(p); break
        if src=='map':
            if loc.startswith('TitleMap'): ps.add(p); break
W('M1 boot assets: %d files / %d B'%(len(ps),sum(size(p) for p in ps)))
agg=collections.defaultdict(lambda:[0,0])
for p in ps:
    d=p.split('/')[0]; agg[d][0]+=1; agg[d][1]+=size(p)
for d,(n,b) in sorted(agg.items(),key=lambda kv:-kv[1][1]): W('   %-22s %4d %10d'%(d,n,b))
open('work/_audit_out32.txt','w',encoding='utf-8').write(OUT.getvalue()); print('ok')
