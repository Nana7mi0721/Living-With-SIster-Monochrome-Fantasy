
import json,os,sys
sys.stdout.reconfigure(encoding="utf-8")
ce=json.load(open("work/_ce_full.json",encoding="utf-8"))
# find all events that call op210 with event id 217 (500217)
for e in ce:
    calls=[(i,c["a"]) for i,c in enumerate(e["cmds"]) if c["c"]==210 and c["a"] and c["a"][0]==500217]
    if calls:
        print("ev%-5d %-20s run=%d slots=%d calls=%s"%(e["id"],e["title"],e["run"],len(e["cmds"]),calls[:4]))
