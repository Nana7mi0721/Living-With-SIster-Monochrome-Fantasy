import io, json
p = r"E:\Study\github program\imoto life\docs\BASELINE.json"
s = io.open(p, encoding="utf-8").read()
block = """     "boot_screen": {
  "entry": "MapData/TitleMap.mps event 2 (autorun, 133 commands)",
  "splash_event": 549,
  "splash_event_title": "forSteam[caution]",
  "sequence": [
   {"frames": "0-60", "screen": "Kagura/bg.png (1024x576 solid black)"},
   {"frames": "62-190", "screen": "Kagura/Kagura.png (KAGURA GAMES fox-mask logo + CN thank-you lines)"},
   {"frames": "~220-400", "screen": "Kagura/Disc.png (disclaimer: fictitious characters, all 18+)"},
   {"frames": "~450-620", "screen": "Kagura/inusuku.png (inusuku developer logo card)"},
   {"frames": "700+", "screen": "Picture/title01.jpg (1024x576) + SystemFile/Button01.png hint banner, parked in the key-wait loop"}
  ],
  "capture_frames": 800,
  "instructions": 2813,
  "picture_ops": 10,
  "pictures_live": 2,
  "quads": 2,
  "non_black": 538282,
  "non_black_total": 589824,
  "non_black_percent": 91.3,
  "hint_banner": {
   "file": "SystemFile/Button01.png",
   "size": [606, 35],
   "head_word": 4096,
   "anchor": "centre",
   "raw_xy": [512, 520],
   "placed_rect": [209, 502, 606, 35]
  },
  "pixel_diff_vs_retail": {
   "reference": "work/out/ScreenShot_2026_1028_21_21_35.png",
   "mean_abs": 0.349,
   "psnr_db": 37.75,
   "within_2_percent": 98.58,
   "above_32_percent": 0.52,
   "note": "the remaining error is entirely inside the hint banner and is the srgb-vs-linear alpha blend space (measured: a 0-alpha-191 texel over a 251 background gives 63 in the retail frame, which is the gamma-space formula; our linear-space pipeline gives 136). Fixing wolf-render to blend in gamma space is task-10."
  },
  "picture_anchor": {
   "field": "opcode 150 arg[0] bits 12..14",
   "codes": {"0x0000": "top-left (8,911 samples)", "0x1000": "centre, both axes (4,393 samples)", "0x2000-0x6000": "unverified, treated as top-left (333 samples)"},
   "rounding": "origin truncates (520 - 35/2 = 502.5 -> 502, which is the retail row); extent rounds"
  }
 },
     "verify": {"""
assert chr(34) + "title_screen" + chr(34) + ": {" in s
a = s.index(chr(34) + "verify" + chr(34) + ": {")
head = s[:a]
tail = s[a:]
break_at = tail.index(chr(44))
old = tail[:break_at]
new_block = block.replace(chr(34) + "verify" + chr(34) + ": {", old)
new_block = new_block.rstrip()
if new_block.endswith(chr(44)):
    new_block = new_block[:-1]
s2 = head + new_block + chr(10) + " " + tail[break_at:]
json.loads(s2)
io.open(p, "w", encoding="utf-8", newline=chr(10)).write(s2)
print("ok", len(s2))