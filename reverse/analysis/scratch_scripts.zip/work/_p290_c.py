import json,sys,collections
sys.stdout.reconfigure(encoding='utf-8')
ev=json.load(open('work/_ce_full.json',encoding='utf-8'))
rows=[]
for e in ev:
    for i,c in enumerate(e['cmds']):
        if c['c']==290: rows.append((e['id'],e['title'],i,c['a']))
for t in (8,9,10,7,6):
    g=[r for r in rows if r[3][0]>>4==t]
    print(f"=== type {t} count={len(g)}")
    print("   dur:",collections.Counter(r[3][1] for r in g).most_common(10))
    print("   a2==a3:",sum(1 for r in g if r[3][2]==r[3][3]),"/",len(g))
    for r in g[:12]:
        print(f"   ev{r[0]:<4} pc{r[2]:<6} a={r[3]} {r[1][:24]}")
