
import io, re
data = io.open(r"E:\Study\github program\imoto life\work\full\BasicData\CommonEvent.dat","rb").read()
for kw in ["キーコード","キー入力","入力","ｷｰｺｰﾄﾞ","キー"]:
    b = kw.encode("utf-8")
    n = data.count(b)
    print(kw, n)
# dump contexts for キーコード
b = "キーコード".encode("utf-8")
for m in re.finditer(re.escape(b), data):
    s = max(0, m.start()-200); e = min(len(data), m.end()+300)
    chunk = data[s:e]
    # extract printable utf8 strings roughly
    txt = chunk.decode("utf-8", "ignore")
    txt = "".join(ch if (ch.isprintable() or ch in "\n") else " " for ch in txt)
    print("----", m.start())
    print(txt[:400])
