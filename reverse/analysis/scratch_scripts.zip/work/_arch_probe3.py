
import os, collections
os.chdir(r'E:\Study\github program\imoto life')
gd=r'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
print('game root:', os.listdir(gd))
d=os.path.join(gd,'Data')
if os.path.isdir(d):
    items=os.listdir(d)
    print('Data entries:', len(items))
    for f in sorted(items):
        p=os.path.join(d,f)
        if os.path.isfile(p): print('  FILE %-28s %10.1f MB'%(f, os.path.getsize(p)/1048576))
    for f in sorted(items):
        p=os.path.join(d,f)
        if os.path.isdir(p):
            n=sum(len(fn) for _,_,fn in os.walk(p))
            print('  DIR  %-28s %d files'%(f,n))
# audio file listing sample
for sub in ['BGM','SE']:
    p=os.path.join('work/alldata',sub)
    if os.path.isdir(p):
        fl=os.listdir(p)
        print(sub, len(fl), sorted(fl)[:8])
