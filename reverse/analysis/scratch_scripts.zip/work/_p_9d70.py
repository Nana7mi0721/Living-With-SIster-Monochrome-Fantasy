import io, os
p = "crates/wolf-cli/src/main.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = "    let mut boot = true;"
assert t.count(a) == 1
t = t.replace(a, "    let mut hold_message = false;" + chr(10) + a)
old = ("    let items: Vec<TextItem> = texts" + chr(10) +
       "        .iter()" + chr(10) +
       "        .map(|text| TextItem::new(text.text.clone(), text.rect, choice::TEXT_PX).with_alpha(text.alpha))" + chr(10) +
       "        .collect();" + chr(10) +
       "    renderer.draw_text(&items);" + chr(10))
assert t.count(old) == 1, t.count(old)
snip = io.open("work/_snip_9d70.txt", encoding="utf-8", newline="").read()
t = t.replace(old, snip)
io.open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("draw patched")