import io, os
def patch(path, pairs):
    t = io.open(path, encoding="utf-8", newline="").read()
    for a, b in pairs:
        assert t.count(a) == 1, (path, a, t.count(a))
        t = t.replace(a, b)
    io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
    os.replace(path + ".new", path)

patch("crates/wolf-game/src/savegame.rs", [
    ("""pub enum SaveRequest {
    /// Load the given file into the live game.
    Load(std::path::PathBuf),
}""", """pub enum SaveRequest {
    /// Load the given file into the live game.
    Load(std::path::PathBuf),
    /// Write the live game state to the given file.
    Save(std::path::PathBuf),
}"""),
])

patch("crates/wolf-game/src/game.rs", [
    ("""                } else {
                    // Writing a full save needs the map snapshot and runtime tables
                    // that the port does not model yet; report rather than write a
                    // half-empty file that the retail engine would refuse.
                    self.note(format!(
                        "220 SaveLoad: full save to {} not modelled yet",
                        path.display()
                    ));
                }""", """                } else {
                    // A full save needs the map template and every live VM bank, so it
                    // is queued for the same post-step slot as a load.
                    self.save_requests
                        .push(crate::savegame::SaveRequest::Save(path));
                }"""),
    ("""                crate::savegame::SaveRequest::Load(path) => {
                    match crate::savegame::load_into(self, &path) {
                        Ok(loaded) => {
                            self.diagnostics.insert(
                                format!(
                                    "220 SaveLoad: loaded {} picture(s), {} variable(s)",
                                    loaded.pictures, loaded.normal_vars
                                ),
                                1,
                            );
                        }
                        Err(err) => {
                            self.diagnostics
                                .entry(format!("220 SaveLoad: {err}"))
                                .or_insert(0);
                        }
                    }
                }
            }
        }""", """                crate::savegame::SaveRequest::Load(path) => {
                    match crate::savegame::load_into(self, &path) {
                        Ok(loaded) => {
                            self.diagnostics.insert(
                                format!(
                                    "220 SaveLoad: loaded {} picture(s), {} variable(s)",
                                    loaded.pictures, loaded.normal_vars
                                ),
                                1,
                            );
                        }
                        Err(err) => {
                            self.diagnostics
                                .entry(format!("220 SaveLoad: {err}"))
                                .or_insert(0);
                        }
                    }
                }
                crate::savegame::SaveRequest::Save(path) => match self.save_to(&path) {
                    Ok(bytes) => {
                        self.diagnostics
                            .insert(format!("220 SaveLoad: wrote {bytes} byte(s)"), 1);
                    }
                    Err(err) => {
                        self.diagnostics.entry(err).or_insert(0);
                    }
                },
            }
        }"""),
])
print("patched")
