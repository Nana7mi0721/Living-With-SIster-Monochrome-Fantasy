import io, os
path = "crates/wolf-game/src/game.rs"
t = io.open(path, encoding="utf-8", newline="").read()
start = t.index("impl crate::textpic::Colours for PictureColours")
end = t.index("/// Per-frame borrow shim", start)
q = chr(39)
block = ("impl crate::textpic::Colours for PictureColours<" + q + "_> {\n"
         "    fn colour(&self, index: i32) -> Option<[u8; 3]> {\n"
         "        self.databases.colour(index)\n"
         "    }\n"
         "}\n\n"
         "impl crate::message::Colours for PictureColours<" + q + "_> {\n"
         "    fn colour(&self, index: u32) -> Option<[u8; 3]> {\n"
         "        self.databases.colour(index as i32)\n"
         "    }\n"
         "}\n\n")
t = t[:start] + block + t[end:]
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("ok")