import json, io, sys
from collections import Counter
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
def norm(c):
    if 'c' in c: return c['c'], c['a'], c['s']
    return c['code'], c['ints'], c['strs']
evs = {e['id']: e for e in ce}
def find(grp, want2, limit=6):
    out=[]
    for e in ce:
        for i,c in enumerate(e['cmds']):
            code,a,s = norm(c)
            if code not in (121,124): continue
            if len(a)<4: continue
            if (a[3]>>12)&0xF != grp: continue
            if a[2] != want2: continue
            ctx=[]
            for j in range(i, min(i+4, len(e['cmds']))):
                cc,aa,ss = norm(e['cmds'][j])
                ctx.append('%d:%s%s'%(cc,aa, (' '+str([x[:16] for x in ss])) if ss else ''))
            out.append((e['id'], e['title'][:26], i, a, ctx))
            if len(out)>=limit: return out
    return out
print('### 0x3000 arg2==2')
for t in find(3,2): print(t[0], t[1], 'pc',t[2], t[3]); print('    ', ' | '.join(t[4]))
print('### 0x3000 arg2==100')
for t in find(3,100,4): print(t[0], t[1], 'pc',t[2], t[3]); print('    ', ' | '.join(t[4]))
print('### 0x3000 arg2==10000')
for t in find(3,10000,4): print(t[0], t[1], 'pc',t[2], t[3]); print('    ', ' | '.join(t[4]))
print('### 0x4000 arg2==10000')
for t in find(4,10000,5): print(t[0], t[1], 'pc',t[2], t[3]); print('    ', ' | '.join(t[4]))
print('### 0x4000 arg2==20000')
for t in find(4,20000,4): print(t[0], t[1], 'pc',t[2], t[3]); print('    ', ' | '.join(t[4]))
print('### 0x4000 arg2==3600')
for t in find(4,3600,3): print(t[0], t[1], 'pc',t[2], t[3]); print('    ', ' | '.join(t[4]))