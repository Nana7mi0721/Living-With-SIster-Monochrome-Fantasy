import io, os
p = "crates/wolf-game/src/choice.rs"
t = io.open(p, encoding="utf-8", newline="").read()
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a))
    t = t.replace(a, b)
rep("fn advance(ch: char) -> f32 {\n    if is_wide(ch) {\n        TEXT_PX\n    } else {\n        TEXT_PX * 0.5\n    }\n}",
    "/// Advance of one character at a given font size, in pixels.\n///\n/// Full-width glyphs (CJK, kana, hangul, full-width forms) take one em; everything\n/// else takes half an em. The message window draws at Sys8 rather than [`TEXT_PX`],\n/// so the advance has to be a function of the font size, not a constant.\npub fn advance_at(ch: char, font_px: f32) -> f32 {\n    if is_wide(ch) {\n        font_px\n    } else {\n        font_px * 0.5\n    }\n}\n\nfn advance(ch: char) -> f32 {\n    advance_at(ch, TEXT_PX)\n}")
rep("pub fn text_width(text: &str) -> f32 {\n    text.chars().map(advance).sum()\n}",
    "pub fn text_width(text: &str) -> f32 {\n    text_width_at(text, TEXT_PX)\n}\n\n/// Width `text` needs when the text pass draws it at `font_px`, in pixels.\npub fn text_width_at(text: &str, font_px: f32) -> f32 {\n    text.chars().map(|ch| advance_at(ch, font_px)).sum()\n}")
io.open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("patched")