import io, os
p = 'E:/Study/github program/imoto life/docs/OPCODE_210_RETURN.md'
s = io.open(p, encoding='utf-8', newline='').read()
old_start = '> 注：' + chr(96) + 'docs/OPCODE_SPEC.md' + chr(96) + ' §3.2'
i = s.index(old_start)
j = s.index('\n', i)
new = ('> 注：' + chr(96) + 'docs/OPCODE_SPEC.md' + chr(96) + ' §3.2 第 213-214 行已经同步成同一条结论（438/107 站点、三条证据），两处口径一致。')
s = s[:i] + new + s[j:]
io.open(p + '.new', 'w', encoding='utf-8', newline='').write(s)
os.replace(p + '.new', p)
print('ok')