# -*- coding: utf-8 -*-
"""Per-picture-number history of the M1 title screen, from work/_m1_trace2.txt.

Groups the 3261 '150' trace lines by picture number and reports, for each number:
  * operation count, breakdown by (action, kind)
  * every distinct asset / text the slot ever carried
  * the distinct geometry states written into the slot, in order of first appearance
    (field semantics from crates/wolf-game/src/picture.rs: args[1..2]=window w/h,
     args[4]=opacity, args[5]=x, args[6]=y, args[7]=scale, args[8]=blend)
  * first / last trace line number

Also collects every asset path seen in the trace (for the availability table).
Output: work/_m1_history.json + stdout report.
"""
import io
import json
import re
from collections import OrderedDict

LINE = re.compile(r'^  150 picture  #(-?\d+) kind (\d+) (\w+) file=(.*?) text=(.*?) args=\[(.*?)\]$')
UNCHANGED = -1000000


def load(path):
    ops = []
    with io.open(path, encoding='utf-8') as fh:
        for lineno, raw in enumerate(fh, 1):
            line = raw.rstrip('\n')
            if not line.startswith('  150 picture'):
                continue
            m = LINE.match(line)
            if not m:
                raise SystemExit('unparsed %d: %s' % (lineno, line))
            args = [int(x) for x in m.group(6).split(',') if x.strip()]
            ops.append({'line': lineno, 'number': int(m.group(1)), 'kind': int(m.group(2)),
                        'action': m.group(3), 'file': m.group(4), 'text': m.group(5),
                        'args': args})
    return ops


def take(args, i):
    return args[i] if i < len(args) and args[i] != UNCHANGED else None


def geometry(args):
    g = {}
    for i, key in ((4, 'opacity'), (5, 'x'), (6, 'y'), (7, 'scale'), (8, 'blend')):
        v = take(args, i)
        if v is not None:
            g[key] = v
    w, h = take(args, 1), take(args, 2)
    if w is not None and h is not None and w > 0 and h > 0:
        g['window'] = [w, h]
    return g


ops = load('work/_m1_trace2.txt')

hist = OrderedDict()
assets = {}
for op in ops:
    n = op['number']
    h = hist.setdefault(n, {'number': n, 'ops': 0, 'actions': OrderedDict(),
                            'kinds': OrderedDict(), 'files': OrderedDict(),
                            'texts': OrderedDict(), 'first_line': op['line'],
                            'last_line': op['line'], 'states': OrderedDict()})
    h['ops'] += 1
    h['actions'][op['action']] = h['actions'].get(op['action'], 0) + 1
    h['kinds'][str(op['kind'])] = h['kinds'].get(str(op['kind']), 0) + 1
    h['last_line'] = op['line']
    if op['file']:
        h['files'][op['file']] = h['files'].get(op['file'], 0) + 1
        assets[op['file']] = assets.get(op['file'], 0) + 1
    if op['text']:
        h['texts'][op['text']] = h['texts'].get(op['text'], 0) + 1
    g = geometry(op['args'])
    if g:
        key = json.dumps(g, sort_keys=True, ensure_ascii=False)
        if key not in h['states']:
            h['states'][key] = {'count': 0, 'first_line': op['line'], 'action': op['action']}
        h['states'][key]['count'] += 1

print('=== 150 picture operations grouped by picture number ===')
for n in sorted(hist):
    h = hist[n]
    print('')
    print('#%d  ops=%d  trace lines %d..%d' % (n, h['ops'], h['first_line'], h['last_line']))
    print('   actions: %s' % dict(h['actions']))
    print('   kinds  : %s' % dict(h['kinds']))
    for f, c in h['files'].items():
        print('   file   : %s  (x%d)' % (f, c))
    for t, c in h['texts'].items():
        print('   text   : %r  (x%d)' % (t[:150], c))
    print('   distinct geometry states: %d' % len(h['states']))
    for key, meta in list(h['states'].items())[:8]:
        g = json.loads(key)
        print('     %s  (x%d, first at line %d, %s)' % (g, meta['count'], meta['first_line'], meta['action']))
    if len(h['states']) > 8:
        print('     ... %d more' % (len(h['states']) - 8))

print('')
print('=== distinct assets referenced by 150 instructions in the trace ===')
for f, c in sorted(assets.items(), key=lambda kv: -kv[1]):
    print('  %-46s x%d' % (f if f else '(empty name)', c))

json.dump({'hist': {str(k): v for k, v in hist.items()}, 'assets': assets},
          io.open('work/_m1_history.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
