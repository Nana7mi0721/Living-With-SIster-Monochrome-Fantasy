
import json,os,re,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=sorted(json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"])
esc=collections.Counter(); kindc=collections.Counter(); per=collections.defaultdict(collections.Counter)
texts=[]
for i in H:
    for c in idx[i]["cmds"]:
        if c["c"]!=150: continue
        head=c["a"][0]; kind=(head>>4)&7
        kindc[kind]+=1
        per[i][kind]+=1
        if kind in (2,4) and c["s"]:
            t=c["s"][0]
            for m in re.findall(r"\\[a-zA-Z]+",t): esc[m]+=1
            texts.append((i,t))
print("kind totals:",dict(kindc))
print("escapes:",dict(esc))
print("text picture count:",len(texts))
print("--- per event kind mix ---")
for i in H:
    print(i, idx[i]["title"][:28], dict(per[i]))
print("--- sample texts ---")
for i,t in texts[:25]: print(i,repr(t))
print("--- distinct text strings ---")
u=sorted(set(t for _,t in texts))
print(len(u))
for t in u[:40]: print(repr(t))
