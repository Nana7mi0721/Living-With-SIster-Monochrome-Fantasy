import io, os
def rep(path, a, b):
    t = io.open(path, encoding='utf-8', newline='').read()
    assert t.count(a) == 1, (path, a[:60], t.count(a))
    t = t.replace(a, b)
    tmp = path + '.new'
    w = io.open(tmp, 'w', encoding='utf-8', newline='')
    w.write(t); w.close()
    os.replace(tmp, path)

P = 'crates/wolf-vm/src/program.rs'
rep(P, '            return_value_id: NO_RETURN_VALUE,\n            slots,',
    '            return_value_id: NO_RETURN_VALUE,\n            self_base: MAP_SELF_BASE,\n            slots,')

E = 'crates/wolf-vm/src/exec.rs'
rep(E, 'impl VarLookup for Instance {\n    fn lookup_num(&self, bank: EscapeBank, index: usize) -> i32 {\n        match bank {\n            EscapeBank::SelfVar => self.self_vars.get(index),',
    '/// `\\cself[n]` names slot `n` of the running event, which is NOT bank `n`:\n'
    '/// a common event keeps its own variables in group 6, a map page in group 1\n'
    '/// (see [`crate::program::COMMON_SELF_BASE`]). The file spells the same slots\n'
    '/// absolutely as magic `1_600_000 + n`, so only the escape needs this offset.\n'
    'impl VarLookup for Instance {\n    fn lookup_num(&self, bank: EscapeBank, index: usize) -> i32 {\n        match bank {\n            EscapeBank::SelfVar => self.self_vars.get(self.program.self_base + index),')

rep(E, '            EscapeBank::SelfVar => self.self_vars.get_str(index).to_owned(),',
    '            EscapeBank::SelfVar => {\n                self.self_vars.get_str(self.program.self_base + index).to_owned()\n            }')

rep(E, '            EscapeBank::SelfVar => self.inst.self_vars.get(index),',
    '            EscapeBank::SelfVar => self.inst.self_vars.get(self.inst.program.self_base + index),')

rep(E, '            EscapeBank::SelfVar => self.inst.self_vars.get_str(index).to_owned(),',
    '            EscapeBank::SelfVar => self\n                .inst\n                .self_vars\n                .get_str(self.inst.program.self_base + index)\n                .to_owned(),')
print('patched')