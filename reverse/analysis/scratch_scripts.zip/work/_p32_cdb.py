import io, json, sys
sys.stdout.reconfigure(encoding='utf-8')
root = r'E:/Study/github program/imoto life'
p = root + '/work/wolftl/dump/db/CDataBase.json'
d = json.load(io.open(p, encoding='utf-8'))
print('top keys:', list(d.keys())[:10] if isinstance(d, dict) else type(d))
types = d['types'] if isinstance(d, dict) and 'types' in d else None
if types is None:
    print(json.dumps(d, ensure_ascii=False)[:400])
else:
    t0 = types[0]
    print('type0 keys:', list(t0.keys()))
    for k, v in t0.items():
        if isinstance(v, list):
            print(' ', k, 'len', len(v), 'first', json.dumps(v[:3], ensure_ascii=False)[:200])
        else:
            print(' ', k, '=', v)
