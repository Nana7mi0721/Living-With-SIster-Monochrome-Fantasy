# -*- coding: utf-8 -*-
"""Full title-screen closure: TitleMap map-event 2 (the game's entry) plus every
common event it can reach through 210 (CommonEvent) / 300 (CallByName).

Inputs : work/_ce_full.json (CommonEvent.dat raw parse)
         work/wolftl/dump/mps/TitleMap.json (WolfTL dump of the title map)
Output : work/_m1_closure2.json + stdout report

210 encoding (crates/wolf-vm/src/exec.rs:1247-1252): 500000..599999 -> raw-500000,
600000..699999 -> raw-600000. 300 takes an event *title* string.
"""
import collections, io, json

PLAN = {'events': 4, 'instrs': 671,
        'ops': [99,102,103,106,111,121,123,130,140,150,170,171,172,175,179,180,
                210,212,213,250,270,300,401,420,498,499]}
UNCHANGED = -1000000

events = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by_id = {e['id']: e for e in events}
by_title = {}
for e in events:
    by_title.setdefault(e['title'], e['id'])

tm = json.load(io.open('work/wolftl/dump/mps/TitleMap.json', encoding='utf-8'))
map_evs = {e['id']: e for e in tm['events']}

def norm(cmds):
    out = []
    for c in cmds:
        if 'c' in c:
            out.append({'c': c['c'], 'a': [int(x) for x in c['a']], 's': c.get('s') or []})
        else:
            out.append({'c': c.get('code', 0),
                        'a': [int(x) for x in (c.get('intArgs') or [])],
                        's': list(c.get('stringArgs') or [])})
    return out

def decode_210(raw):
    if 500000 <= raw <= 599999: return raw - 500000
    if 600000 <= raw <= 699999: return raw - 600000
    return None

# node key: ('c', id) common event, ('m', id) map event
nodes, edges = {}, collections.defaultdict(set)
for e in events:
    nodes[('c', e['id'])] = norm(e['cmds'])
for mid, e in map_evs.items():
    cmds = []
    for p in e['pages']:
        cmds.extend(norm(p['list']))
    nodes[('m', mid)] = cmds

for key, cmds in nodes.items():
    for c in cmds:
        if c['c'] == 210 and c['a']:
            t = decode_210(c['a'][0])
            if t is not None and ('c', t) in nodes:
                edges[key].add(('c', t))
        elif c['c'] == 300 and c['s']:
            t = by_title.get(c['s'][0])
            if t is not None:
                edges[key].add(('c', t))

def closure(start):
    seen, visited, stack, order = [], set(), [start], {}
    while stack:
        cur = stack.pop(0)
        if cur in visited or cur not in nodes:
            continue
        visited.add(cur); seen.append(cur)
        for nxt in sorted(edges[cur]):
            if nxt not in visited:
                stack.append(nxt)
    return seen

def report(start, label):
    reached = closure(start)
    ops = collections.Counter(); slots = real = 0; rows = []
    for key in reached:
        cmds = nodes[key]
        r = sum(1 for c in cmds if c['c'] != 0)
        cnt = collections.Counter(c['c'] for c in cmds if c['c'] != 0)
        ops.update(cnt); slots += len(cmds); real += r
        cid = key[1]
        title = (by_id[cid]['title'] if key[0] == 'c' else map_evs[cid]['name'])
        rows.append({'kind': key[0], 'id': cid, 'title': title,
                     'slots': len(cmds), 'real': r, 'opcodes': sorted(cnt),
                     'calls': sorted('%s%d' % (k[0], k[1]) for k in edges[key])})
    rows.sort(key=lambda x: (x['kind'], x['id']))
    print('=== closure from %s ===' % label)
    print('nodes: %d   slots: %d   non-empty instrs: %d   distinct opcodes: %d'
          % (len(reached), slots, real, len(ops)))
    print('')
    for r in rows:
        print('  %s%-4d slots=%-4d real=%-4d calls=%s  %s'
              % (r['kind'], r['id'], r['slots'], r['real'], r['calls'], r['title']))
    print('')
    print('opcode frequency (n, #events):')
    for op, n in sorted(ops.items(), key=lambda kv: -kv[1]):
        who = sum(1 for r in rows if op in r['opcodes'])
        print('  %-5d n=%-5d events=%d' % (op, n, who))
    print('')
    extra = [op for op in sorted(ops) if op not in PLAN['ops']]
    missing = [op for op in PLAN['ops'] if op not in ops]
    print('PLAN list missing from closure: %s' % missing)
    print('closure opcodes not in PLAN : %s' % extra)
    print('')
    return {'reached': rows, 'slots': slots, 'real': real,
            'opcodes': dict(ops), 'extra': extra, 'missing': missing}

a = report(('m', 2), 'TitleMap map event 2 (game entry)')
b = report(('c', 42), 'common event 42 alone')
out = {'from_map_event2': a, 'from_event42': b}
json.dump(out, io.open('work/_m1_closure2.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
