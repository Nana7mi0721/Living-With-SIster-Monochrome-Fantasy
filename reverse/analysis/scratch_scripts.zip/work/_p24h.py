import json, io, sys
sys.stdout.reconfigure(encoding='utf-8')
CE = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
by = {e['id']: e for e in CE}
ids = [2,38,42,48,94,131,223,269,271,341,426,435,436,23]
for i in ids:
    e = by.get(i)
    if not e: 
        print(i, 'MISSING'); continue
    cmds = e['cmds']
    from collections import Counter
    c = Counter(x['c'] for x in cmds)
    print('%3d run=%d n=%4d  %-40s  150=%d 102=%d 101=%d 220=%d 221=%d 222=%d 1000=%d 105=%d 174=%d' % (
        i, e['run'], len(cmds), e['title'][:40], c.get(150,0), c.get(102,0), c.get(101,0), c.get(220,0), c.get(221,0), c.get(222,0), c.get(1000,0), c.get(105,0), c.get(174,0)))
print()
# dump ev94 picture/choice/220-222 sites
e = by[94]
for k, x in enumerate(e['cmds']):
    if x['c'] in (150, 102, 220, 221, 222, 1000):
        print('ev94', k, x['c'], x['a'], [s[:30] for s in x['s']])
