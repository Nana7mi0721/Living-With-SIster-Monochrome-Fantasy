
import sys, io, json, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
if isinstance(ce, dict): ce = list(ce.values())
maps = json.load(open('work/maps_full.json', encoding='utf-8'))
sites = []
byid = {}
for ev in ce:
    byid['CE%s' % ev.get('id')] = ev
    for i, c in enumerate(ev.get('cmds') or []):
        if c.get('c') == 290: sites.append(('CE%s' % ev.get('id'), i, c.get('a') or []))
for mk, mv in maps.items():
    for ev in mv.get('events') or []:
        for i, c in enumerate(ev.get('cmds') or []):
            if c.get('code') == 290: sites.append(('%s:ev%s' % (mk, ev.get('id')), i, c.get('ints') or []))
print('total 290 =', len(sites))
h = collections.Counter(a[0] for (_, _, a) in sites)
print('head histogram:', dict(sorted(h.items())))
print('head & 0xF nonzero sites:', sum(1 for (_, _, a) in sites if a[0] & 0xF))
print('head >= 176 (type>=11):', sum(1 for (_, _, a) in sites if (a[0] >> 4) >= 11))
print('type 6 (head 96):', h.get(96, 0))
# type3 回数
t3 = [a for (_, _, a) in sites if (a[0] >> 4) == 3]
print('type3 n=%d, 回数>=100000: %d, 回数==99999: %d' % (len(t3), sum(1 for a in t3 if a[6] >= 100000), sum(1 for a in t3 if a[6] == 99999)))
# type3 shake X/Y pairs
print('type3 (X,Y) top:', collections.Counter((a[4], a[5]) for a in t3).most_common(8))
# ev8 of SampleMapA: 290 context
m = maps.get('SampleMapA.mps') or maps.get('SampleMapA')
ev8 = None
for ev in (m.get('events') or []):
    if str(ev.get('id')) == '8': ev8 = ev
print()
print('### SampleMapA ev8 first 12 290 sites with 6 cmds of context')
if ev8:
    cmds = ev8.get('cmds') or []
    n = 0
    for i, c in enumerate(cmds):
        if c.get('code') == 290 and n < 6:
            n += 1
            print('  --- pc%d a=%s' % (i, c.get('ints')))
            for j in range(max(0, i-3), min(len(cmds), i+3)):
                cc = cmds[j]
                print('      pc%-4d %-4s %s %s' % (j, cc.get('code'), cc.get('ints'), (cc.get('strs') or [])[:1]))
