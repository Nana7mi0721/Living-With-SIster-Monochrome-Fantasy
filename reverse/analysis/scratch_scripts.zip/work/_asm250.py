import io,sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
parts = ['p1','p2','p3','p4','p4b','p5','p5b','p6','p7']
s = ''
for p in parts:
    t = open('work/_doc250_%s.md' % p, encoding='utf-8').read()
    if not t.endswith('\n'): t += '\n'
    s += t
tick = chr(96)
s = s.replace('@@BT@@', tick)
s = s.replace(tick*3 + 'rust', '~~~rust').replace(tick*3, '~~~')
lines = s.split(chr(10))
bad = [i for i,l in enumerate(lines) if l.startswith('#') and not (l.startswith('# ') or l.startswith('## ') or l.startswith('### ') or l.startswith('#### '))]
open('docs/OPCODE_250.md','w',encoding='utf-8',newline='\n').write(s)
print('bytes', len(s.encode('utf-8')), 'lines', len(lines))
print('h1', sum(1 for l in lines if l.startswith('# ')), 'h2', sum(1 for l in lines if l.startswith('## ')), 'h3', sum(1 for l in lines if l.startswith('### ')), 'h4', sum(1 for l in lines if l.startswith('#### ')))
print('fences', s.count('~~~'), 'tables', sum(1 for l in lines if l.startswith('|')))
print('unverified marks', s.count('未验证'), 'verified', s.count('已验证'), 'measured', s.count('已实测'))
print('BT left', s.count('@@BT@@'), 'triple-bad', bad[:5])