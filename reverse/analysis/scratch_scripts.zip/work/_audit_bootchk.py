
import json,io
OUT=io.StringIO(); W=lambda *a: OUT.write(' '.join(str(x) for x in a)+'\n')
d=json.load(open('work/_audit_closure2.json',encoding='utf-8'))
W('boot2 (%d): %s'%(len(d['boot2']),sorted(d['boot2'])))
W('gcreach2 %d dead2 %d game2 %d'%(len(d['gcreach2']),len(d['dead2']),len(d['game2'])))
b=json.load(open('work/_audit_boot_assets.json',encoding='utf-8'))
W('boot_assets type %s len %d sample %s'%(type(b).__name__,len(b),b[:5]))
fin=json.load(open('work/_audit_final.json',encoding='utf-8'))
sizes=fin['sizes']
W('sum boot bytes %d'%sum(sizes.get(p,0) for p in b))
open('work/_audit_out29.txt','w',encoding='utf-8').write(OUT.getvalue())
print('ok')
