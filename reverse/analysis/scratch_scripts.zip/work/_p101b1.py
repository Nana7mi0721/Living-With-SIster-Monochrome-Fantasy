import json, io, sys, collections, re
sys.stdout.reconfigure(encoding='utf-8')
ce = json.load(io.open('work/_ce_full.json', encoding='utf-8'))
B = chr(92)
single = collections.Counter(); angle = collections.Counter()
c_idx = collections.Counter(); f_idx = collections.Counter(); v_idx = collections.Counter()
cself_idx = collections.Counter(); cdb_tok = collections.Counter(); sp_idx = collections.Counter()
pat_single = re.compile(B+B+'([>.^<!~N])')
pat_c = re.compile(B+B+'c'+B+B+'[(\\d+)]')
pat_f = re.compile(B+B+'f'+B+B+'[(\\d+)]')
pat_v = re.compile(B+B+'v'+B+B+'[(\\d+)]')
pat_cself = re.compile(B+B+'cself'+B+B+'[(\\d+)]')
pat_cdb = re.compile(B+B+'cdb'+B+B+'[[^'+B+B+']]*'+B+B+']')
pat_sp = re.compile(B+B+'sp'+B+B+'[(\\d+)]')
pat_angle = re.compile('<[A-Za-z]>')
for ev in ce:
    for c in ev['cmds']:
        if c['c'] != 101: continue
        for s in c['s']:
            for m in pat_single.finditer(s): single[m.group(1)] += 1
            for m in pat_c.finditer(s): c_idx[m.group(1)] += 1
            for m in pat_f.finditer(s): f_idx[m.group(1)] += 1
            for m in pat_v.finditer(s): v_idx[m.group(1)] += 1
            for m in pat_cself.finditer(s): cself_idx[m.group(1)] += 1
            for m in pat_cdb.finditer(s): cdb_tok[m.group(0)] += 1
            for m in pat_sp.finditer(s): sp_idx[m.group(1)] += 1
            for m in pat_angle.finditer(s): angle[m.group(0)] += 1
print('single-char:', single.most_common())
print('angle:', angle.most_common())
print('c idx:', c_idx.most_common())
print('f idx:', f_idx.most_common())
print('v idx:', v_idx.most_common())
print('cself idx:', cself_idx.most_common())
print('cdb:', cdb_tok.most_common())
print('sp:', sp_idx.most_common())