
import json,os,collections
root=r"E:\Study\github program\imoto life"
W=os.path.join(root,"work")
ce=json.load(open(os.path.join(W,"_ce_full.json"),encoding="utf-8"))
idx={e["id"]:e for e in ce}
H=sorted(json.load(open(os.path.join(W,"_m3_hclosure.json")))["H"])
# 1) which opcodes used per event, with 180 wait arg values
ops=collections.Counter()
for i in H:
    for c in idx[i]["cmds"]:
        if c["c"]!=0: ops[c["c"]]+=1
print("ops:",dict(ops))
# 2) 290 tone detail
for i in H:
    for k,c in enumerate(idx[i]["cmds"]):
        if c["c"]==290:
            print("290 in ev%d pc%d a=%s s=%s"%(i,k,c["a"],c["s"]))
# 3) 124 detail
for i in H:
    for k,c in enumerate(idx[i]["cmds"]):
        if c["c"]==124:
            print("124 ev%d pc%d a=%s"%(i,k,c["a"]))
# 4) 180 wait arg distribution
w=collections.Counter()
for i in H:
    for c in idx[i]["cmds"]:
        if c["c"]==180 and c["a"]: w[c["a"][0]]+=1
print("180 args:",dict(sorted(w.items())))
# 5) 342 / 371 full dump
for eid in (342,371,374,217,333):
    e=idx[eid]
    print("=== ev%d %s run=%d slots=%d"%(eid,e["title"],e["run"],len(e["cmds"])))
