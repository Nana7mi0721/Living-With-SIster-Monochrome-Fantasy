import json,subprocess,os
d=json.load(open('work/_steam_app.json',encoding='utf-8'))
shots=d['2429860']['data']['screenshots']
for i,s in enumerate(shots):
    out=f'work/out/steamshots/ss{i}.jpg'
    subprocess.run(['curl','-sS','--max-time','60','-x','http://127.0.0.1:7890','-o',out,s['path_full']],check=True)
    print(i,os.path.getsize(out))
