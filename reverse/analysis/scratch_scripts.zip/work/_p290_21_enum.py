
import zipfile, sys, io, json, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')
OFF = [0xa847e0,0xa847ec,0xa847f8,0xa84812,0xa8481c,0xa84824,0xa84838,0xa84852,0xa84866,0xa84882,0xa848a2]
NAMES = ['フラッシュ','カラー補正','描画座標シフト[最終値]','シェイク','ズーム','点滅A[明滅]',
         '点滅B[自動ﾌﾗｯｼｭ]','自動拡大縮小[％]','自動ﾊﾟﾀｰﾝ切替[1回]','自動ﾊﾟﾀｰﾝ切替[ﾙｰﾌﾟ]','自動ﾊﾟﾀｰﾝ切替[往復]']
print('### Editor.exe 3.735 effect enum (contiguous literal table)')
ok = True
for i, (off, nm) in enumerate(zip(OFF, NAMES)):
    n = int.from_bytes(data[off:off+2], 'little')
    s = data[off+2:off+2+2*n].decode('utf-16-le')
    assert s == nm, (i, s, nm)
    print('  %2d  %-28s len=%-3d off=0x%x' % (i, s, n, off))
print('  all 11 literals contiguous 0x%x..0x%x -> indices are the runtime type ids' % (OFF[0], OFF[-1]+2+26))

ce = json.load(open('work/_ce_full.json', encoding='utf-8'))
if isinstance(ce, dict): ce = list(ce.values())
maps = json.load(open('work/maps_full.json', encoding='utf-8'))
sites = []
for ev in ce:
    for i, c in enumerate(ev.get('cmds') or []):
        if c.get('c') == 290: sites.append(('CE%s' % ev.get('id'), i, c.get('a') or []))
for mk, mv in maps.items():
    for ev in mv.get('events') or []:
        for i, c in enumerate(ev.get('cmds') or []):
            if c.get('code') == 290: sites.append(('%s:ev%s' % (mk, ev.get('id')), i, c.get('ints') or []))
print()
print('### total 290 sites =', len(sites))
bytype = collections.defaultdict(list)
for (tag, pc, a) in sites:
    if len(a) < 2: continue
    bytype[(a[0] >> 4) & 0xF].append((tag, pc, a))
for t in sorted(bytype):
    rows = bytype[t]
    print()
    print('== type %d  %-24s n=%d' % (t, NAMES[t], len(rows)))
    print('   dur  ', dict(sorted(collections.Counter(r[2][1] for r in rows).items())))
    for k in (2,3,4,5,6):
        vals = collections.Counter(r[2][k] for r in rows if len(r[2]) > k)
        if len(vals) <= 14: print('   arg%d ' % k, dict(sorted(vals.items())))
        else: print('   arg%d ' % k, 'distinct=%d top' % len(vals), vals.most_common(10))
    print('   triples', collections.Counter(tuple(r[2][4:7]) for r in rows).most_common(5))
    print('   events ', collections.Counter(r[0] for r in rows).most_common(5))
