
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Native {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, int extra);
  [DllImport("user32.dll")] public static extern IntPtr FindWindow(string cls, string title);
  public struct RECT { public int left, top, right, bottom; }
  public struct POINT { public int x, y; }
}
"@
$gameDir = 'E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy'
$outDir  = 'E:\Study\github program\imoto life\work\out'
$p = Start-Process -FilePath (Join-Path $gameDir 'Game.exe') -WorkingDirectory $gameDir -PassThru
Start-Sleep -Seconds 5
$h = $p.MainWindowHandle
if ($h -eq [IntPtr]::Zero) {
  for ($i = 0; $i -lt 20; $i++) { Start-Sleep -Milliseconds 500; $p.Refresh(); if ($p.MainWindowHandle -ne [IntPtr]::Zero) { $h = $p.MainWindowHandle; break } }
}
Write-Output ("hwnd=" + $h)
[void][Native]::ShowWindow($h, 9)
[void][Native]::SetForegroundWindow($h)
Start-Sleep -Milliseconds 800
$r = New-Object Native+RECT
[void][Native]::GetClientRect($h, [ref]$r)
$pt = New-Object Native+POINT
[void][Native]::ClientToScreen($h, [ref]$pt)
$w = $r.right - $r.left; $ht = $r.bottom - $r.top
Write-Output ("client " + $w + "x" + $ht + " at " + $pt.x + "," + $pt.y)
for ($i = 0; $i -lt 16; $i++) {
  try {
    $bmp = New-Object System.Drawing.Bitmap($w, $ht)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($pt.x, $pt.y, 0, 0, (New-Object System.Drawing.Size($w, $ht)))
    $file = Join-Path $outDir ("gt_" + $i.ToString('00') + ".png")
    $bmp.Save($file, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose()
    Write-Output ("shot " + $i)
  } catch { Write-Output ("shot " + $i + " failed: " + $_.Exception.Message) }
  [Native]::keybd_event(0x0D, 0x1C, 0, 0)
  Start-Sleep -Milliseconds 60
  [Native]::keybd_event(0x0D, 0x1C, 2, 0)
  Start-Sleep -Milliseconds 60
  [Native]::keybd_event(0x20, 0x39, 0, 0)
  Start-Sleep -Milliseconds 60
  [Native]::keybd_event(0x20, 0x39, 2, 0)
  Start-Sleep -Seconds 3
}
[void]$p.CloseMainWindow()
Start-Sleep -Seconds 1
if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force }
Write-Output "done"
