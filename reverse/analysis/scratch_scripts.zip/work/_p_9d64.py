import io, os
p = "crates/wolf-game/src/message.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = "        let layout = layout(\"甲乙丙\", &vars, 61);"
assert t.count(a) == 1
t = t.replace(a, "        let layout = layout(\"甲乙丙\", &vars, 1);")
io.open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("ok")