
import zipfile, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
z = zipfile.ZipFile('work/_wolked.zip')
data = z.read('Editor.exe')

def dump(a, b):
    seg = data[a:b]
    # decode utf-16le loosely, replace non-printables
    s = seg.decode('utf-16-le', errors='replace')
    out = []
    for ch in s:
        o = ord(ch)
        if ch in '\r\n\t' or (0x20 <= o < 0xfffd and (o >= 0x20)):
            out.append(ch)
        else:
            out.append('·')
    return ''.join(out)

for (a,b,label) in [(0xa847c0, 0xa84960, 'cluster-A'), (0xa8d500, 0xa8d5a0, 'cluster-B'), (0xa8df60, 0xa8e180, 'cluster-C'), (0xa8e180, 0xa8e320, 'cluster-D')]:
    print('#####', label, hex(a))
    print(dump(a,b))
    print()
