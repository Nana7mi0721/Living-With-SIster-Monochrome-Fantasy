import json,sys,collections
sys.stdout.reconfigure(encoding='utf-8')
d={e['id']:e for e in json.load(open('work/_ce_full.json',encoding='utf-8'))}
H=[217,333,338,340,341,342,343,346,350,351,353,354,357,358,365,367,371,372,374,407,410,445]
refs=collections.Counter(); callers=collections.defaultdict(set)
for eid,e in d.items():
    for c in e['cmds']:
        if c['c'] not in (210,211): continue
        for a in c['a']:
            for base in (500000,600000):
                t=a-base
                if 0<=t<600 and t in H:
                    refs[t]+=1; callers[t].add(eid)
for h in H:
    print(h, 'refs=',refs.get(h,0), 'callers=',len(callers.get(h,())), sorted(callers.get(h,()))[:6])
