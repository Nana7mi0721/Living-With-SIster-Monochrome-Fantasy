# -*- coding: utf-8 -*-
import os, re, struct
G = r"E:\SteamLibrary\steamapps\common\Living With SIster Monochrome Fantasy"
D = os.path.join(G, "Data")
for fn in ["word.wolf", "FIcon.wolf", "MapChip.wolf"]:
    p = os.path.join(D, fn)
    b = open(p, "rb").read()
    print("==", fn, "size", len(b), "hex", hex(len(b)))
    # find ascii runs >=4
    runs = re.findall(rb"[\x20-\x7e]{4,}", b)
    print("   ascii runs:", len(runs), runs[:12])
