import io, os
p = "crates/wolf-game/src/picture.rs"
t = io.open(p, encoding="utf-8", newline="").read()
a = """        for number in -2..=1 {"""
b = """        for number in [-2, -1] {"""
assert t.count(a) == 1
t = t.replace(a, b)
open(p + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(p + ".new", p)
print("ok")