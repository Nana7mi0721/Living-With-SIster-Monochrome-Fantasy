import io, os
path = "crates/wolf-game/src/savegame.rs"
t = io.open(path, encoding="utf-8", newline="").read()
a = """    loaded.normal_vars = normal.len();

    // Choice-window anchor."""
b = """    loaded.normal_vars = normal.len();

    // The variable database travels inside the save. Character creation writes the
    // player name into CDataBase type 0 row 12, and the HUD reads it back through
    // opcode 250, so a load must overlay it before the first frame is drawn.
    game.databases.apply_saved_database(&save.vardb);

    // Choice-window anchor."""
assert t.count(a) == 1
t = t.replace(a, b)
io.open(path + ".new", "w", encoding="utf-8", newline="").write(t)
os.replace(path + ".new", path)
print("patched")
