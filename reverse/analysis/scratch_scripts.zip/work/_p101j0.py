
import sys,collections
sys.stdout.reconfigure(encoding='utf-8')
try:
    from PIL import Image
except ImportError:
    print('no PIL'); raise SystemExit
im=Image.open('work/out/m2msg600.png').convert('RGBA')
w,h=im.size
px=im.load()
print('size',w,h)
for pt in [(520,250),(600,300),(700,340),(515,245),(640,243),(640,245),(640,388),(514,300),(770,300)]:
    print(pt,px[pt[0],pt[1]])
# histogram inside window region
c=collections.Counter()
for y in range(245,389):
    for x in range(516,770):
        c[px[x,y]]+=1
print('inside histogram top6',c.most_common(6))
# rows/cols of bright border
bright=[(x,y) for y in range(0,h) for x in range(0,w) if px[x,y][:3]==(242,243,243) or px[x,y][:3]==(255,255,255)]
xs=[p[0] for p in bright]; ys=[p[1] for p in bright]
print('bright pixels',len(bright),'bbox',min(xs),min(ys),max(xs),max(ys))
