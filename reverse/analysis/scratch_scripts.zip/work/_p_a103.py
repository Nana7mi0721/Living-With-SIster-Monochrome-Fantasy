import json, io, os
p='docs/BASELINE.json'
d=json.load(io.open(p,encoding='utf-8'))
pa=d['picture_actions']
pa['kind_counts']={'0_file':14106,'1_file_from_string_var':82,'2_text':2179,'3_window_file':258,'4_window_string':91}
pa['action_counts']={'0_draw':10272,'1_move':3365,'2_erase':2835,'3_hide':244}
pa['commands_total']=16716
io.open(p+'.new','w',encoding='utf-8',newline='').write(json.dumps(d,ensure_ascii=False,indent=1)+chr(10))
os.replace(p+'.new',p)
print(json.dumps(d['picture_actions'],ensure_ascii=False,indent=1)[:400])
